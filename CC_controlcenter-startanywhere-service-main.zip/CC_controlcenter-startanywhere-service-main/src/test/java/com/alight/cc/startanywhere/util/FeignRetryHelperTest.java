package com.alight.cc.startanywhere.util;

import feign.FeignException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FeignRetryHelperTest {

    FeignRetryHelper helper = new FeignRetryHelper();

    @Test
    void is5xx_returnsTrueForFeignExceptionWith5xxStatus() {
        FeignException fe = feign.FeignException.errorStatus(
                "GET", feign.Response.builder()
                        .status(503)
                        .reason("Service Unavailable")
                        .request(feign.Request.create(feign.Request.HttpMethod.GET, "/", java.util.Collections.emptyMap(), null, null, null))
                        .build());
        assertTrue(helper.is5xx(fe));
    }

    @Test
    void is5xx_returnsFalseForFeignExceptionWith4xxStatus() {
        FeignException fe = feign.FeignException.errorStatus(
                "GET", feign.Response.builder()
                        .status(404)
                        .reason("Not Found")
                        .request(feign.Request.create(feign.Request.HttpMethod.GET, "/", java.util.Collections.emptyMap(), null, null, null))
                        .build());
        assertFalse(helper.is5xx(fe));
    }

    @Test
    void is5xx_returnsFalseForNonFeignException() {
        Throwable t = new RuntimeException("Some error");
        assertFalse(helper.is5xx(t));
    }
}