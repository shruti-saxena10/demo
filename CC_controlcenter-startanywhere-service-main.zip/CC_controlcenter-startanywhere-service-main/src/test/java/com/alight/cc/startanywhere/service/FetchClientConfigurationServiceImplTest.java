package com.alight.cc.startanywhere.service;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.alight.cc.dto.OrganizationDetailsDTO;
import com.alight.cc.dto.UserOrganizationDetailResponseDTO;
import com.alight.cc.model.DomainLookup;
import com.alight.cc.repository.DomainLookupRepository;
import com.alight.cc.startanywhere.configuration.SaviyntConfigurationBean;
import com.alight.cc.startanywhere.entity.SecurityManagerEntitlementEntity;
import com.alight.cc.startanywhere.feign.SaviyntClient;
import com.alight.cc.startanywhere.model.ClientConfigError;
import com.alight.cc.startanywhere.model.ClientConfigurationResponse;
import com.alight.cc.startanywhere.model.ClientRequest;
import com.alight.cc.startanywhere.model.ClientResponse;
import com.alight.cc.startanywhere.model.SecurityManagerRequest;
import com.alight.cc.startanywhere.repository.SecurityManagerEntitlementRepository;
import com.alight.cc.startanywhere.saviynt.model.EntitlementDetail;
import com.alight.cc.startanywhere.saviynt.model.EntitlementsResponse;
import com.alight.cc.startanywhere.saviynt.model.User;
import com.alight.cc.startanywhere.saviynt.model.UserDetailsResponse;
import com.alight.cc.startanywhere.service.impl.FetchClientConfigurationServiceImpl;
import com.alight.cc.startanywhere.util.SaviyntRequestBuilder;

import feign.FeignException;

@ExtendWith(SpringExtension.class)
class FetchClientConfigurationServiceImplTest {

	private FetchClientConfigurationServiceImpl service;

	@Mock
	private DomainLookupRepository domainRepo;
	@Mock
	private SecurityManagerEntitlementRepository entitlementRepo;
    @Mock private ClientDataRetrievalService clientDataService;
    @Mock private UserService userService;
    @Mock private SaviyntClient saviyntClient;
    @Mock private SaviyntRequestBuilder requestBuilder;
    @Mock private SaviyntConfigurationBean saviyntConfigurationBean;
    @Mock
    private SecurityManagerEntitlementRepository securityManagerEntitlementRepository;


    @BeforeEach
    void setup() throws Exception {
        MockitoAnnotations.openMocks(this);
        service = new FetchClientConfigurationServiceImpl();

        inject("domainLookupRepository", domainRepo);
        inject("securityManagerEntitlementRepository", entitlementRepo);
        inject("clientDataRetrievalService", clientDataService);
        inject("userService", userService);
        inject("saviyntClient", saviyntClient);
        inject("saviyntRequestBuilder", requestBuilder);
        inject("bean", saviyntConfigurationBean);
        inject("securityManagerEntitlementRepository", securityManagerEntitlementRepository);

        when(saviyntConfigurationBean.getPrefix()).thenReturn("PFX_");
        when(saviyntConfigurationBean.getApplication()).thenReturn("APP");
        when(saviyntConfigurationBean.getEndpoint()).thenReturn("internal-endpoint");
        when(saviyntConfigurationBean.getDefaultEmailID()).thenReturn("abc.@alight.com");
    }

    void inject(String name, Object value) throws Exception {
        Field field = FetchClientConfigurationServiceImpl.class.getDeclaredField(name);
        field.setAccessible(true);
        field.set(service, value);
    }

    

    @Test
    void testClientConfig_ClientDataHasErrors() throws Exception {
        ClientRequest request = new ClientRequest();
        request.setClientId("ERR");
        ClientResponse clientData = new ClientResponse();
        ClientConfigError clientConfigError = new ClientConfigError();
        clientConfigError.setErrorCode("POS104");       
        clientData.setErrors(List.of(clientConfigError));
        request.setSecurityManagers(new ArrayList<>()); 
        when(clientDataService.getClientData(any(), any(), eq("ERR"))).thenReturn(clientData);
        ClientConfigurationResponse response = service.getClientConfigurationDetails("t", "h", request);
        assertEquals("POS104", response.getErrors().get(0).getErrorCode());
    }

    @Test
    void testGetEndpoint_internal() {
        assertEquals("internal-endpoint", service.getEndpoint("INTERNAL"));
    }

    @Test
    void testGetEndpoint_externalOrNull() {
        assertNull(service.getEndpoint("EXTERNAL"));
        assertNull(service.getEndpoint(null));
    }

    @Test
    void testGetDisplayNames_valid() {
        SecurityManagerEntitlementEntity entity = new SecurityManagerEntitlementEntity();
        entity.setDisplayName("Role-<ClientID>");
        List<String> result = service.getDisplayNamesWithClientId(List.of(entity), "123");
        assertEquals("PFX_Role-123,APP", result.get(0));
    }

    @Test
    void testGetDisplayNames_emptyOrNullList() {
        assertTrue(service.getDisplayNamesWithClientId(null, "123").isEmpty());
        assertTrue(service.getDisplayNamesWithClientId(Collections.emptyList(), "123").isEmpty());
    }
    @Test
    void testIsInternalDomain_matchAndMismatch() throws Exception {
        DomainLookup domain = new DomainLookup();
        domain.setDomainName("alight.com");

        Method method = FetchClientConfigurationServiceImpl.class.getDeclaredMethod(
            "isInternalDomain", List.class, String.class);
        method.setAccessible(true);

        assertTrue((Boolean) method.invoke(service, List.of(domain), "john@alight.com"));
        assertFalse((Boolean) method.invoke(service, List.of(domain), "guest@other.com"));
    }

    @Test
    void testLoadEntitlements_success() throws Exception {
        EntitlementDetail detail = new EntitlementDetail();
        detail.setEntitlement_value("value123");
        detail.setEntitlementOwner(List.of("owner1"));
        detail.setDescription("desc");
        detail.setStatus("active");
        detail.setEndpoint("endpoint");

        EntitlementsResponse response = new EntitlementsResponse();
        response.setStatusCode(200);
        response.setEntitlementdetails(List.of(detail));

        when(saviyntClient.getEntitlements(any(), any())).thenReturn(response);

        Method method = FetchClientConfigurationServiceImpl.class.getDeclaredMethod(
            "loadEntitlements", String.class, String.class, String.class,
            List.class, Integer.class, String.class);
        method.setAccessible(true);

        EntitlementsResponse result = (EntitlementsResponse) method.invoke(
            service, "user", "endpoint", "token", new ArrayList<>(), 0, "CLIENT123");

        assertEquals(1, result.getEntitlementdetails().size());
    }

    @Test
    void testLoadEntitlements_nullResponseThrows() throws Exception {
        when(saviyntClient.getEntitlements(any(), any())).thenReturn(null);

        Method method = FetchClientConfigurationServiceImpl.class.getDeclaredMethod(
            "loadEntitlements", String.class, String.class, String.class,
            List.class, Integer.class, String.class);
        method.setAccessible(true);

        assertThrows(Exception.class, () -> method.invoke(
            service, "user", "endpoint", "token", new ArrayList<>(), 0, "CLIENT123"));
    }

    @Test
    void testLoadEntitlements_errorStatusThrows() throws Exception {
        EntitlementsResponse response = new EntitlementsResponse();
        response.setStatusCode(400);
        response.setErrorCode("ERR001");
        response.setMsg("Bad Request");

        when(saviyntClient.getEntitlements(any(), any())).thenReturn(response);

        Method method = FetchClientConfigurationServiceImpl.class.getDeclaredMethod(
            "loadEntitlements", String.class, String.class, String.class,
            List.class, Integer.class, String.class);
        method.setAccessible(true);

        assertThrows(Exception.class, () -> method.invoke(
            service, "user", "endpoint", "token", new ArrayList<>(), 0, "CLIENT123"));
    }
    
	// handleRetryFailure 
    @Test
    void testClientConfig_AccessTokenMissing() throws Exception {
        ClientRequest request = new ClientRequest();
        request.setClientId("NO_TOKEN");
        request.setSecurityManagers(new ArrayList<>(List.of(new SecurityManagerRequest("x@example.com"))));

        when(clientDataService.getClientData(any(), any(), eq("NO_TOKEN"))).thenReturn(new ClientResponse());
        when(userService.getAccessToken()).thenReturn(null);

        ClientConfigurationResponse response = service.getClientConfigurationDetails("t", "h", request);
        assertEquals("SAV102", response.getErrors().get(0).getErrorCode());
    }

    @Test
    void testClientConfig_EmailMismatch() throws Exception {
        ClientRequest request = new ClientRequest();
        request.setClientId("MISMATCH");
        request.setSecurityManagers(new ArrayList<>(List.of(new SecurityManagerRequest("match@example.com"))));

        when(clientDataService.getClientData(any(), any(), eq("MISMATCH"))).thenReturn(new ClientResponse());
        when(userService.getAccessToken()).thenReturn("abc");

        User u = new User();
        u.setEmail("wrong@example.com");
        u.setUsername("userX");
        UserDetailsResponse ud = new UserDetailsResponse();
        ud.setUserdetails(List.of(u));
        when(requestBuilder.buildGetUserQuery(any())).thenReturn("q");
        when(saviyntClient.getUser(any(), any())).thenReturn(ud);

        ClientConfigurationResponse response = service.getClientConfigurationDetails("t", "h", request);
        assertEquals("SAV002", response.getErrors().get(0).getErrorCode());
    }

    @Test
    void testClientConfig_NoSecurityManagers() throws Exception {
        ClientRequest request = new ClientRequest();
        request.setClientId("NO_SM");
        request.setSecurityManagers(new ArrayList<>());

        when(clientDataService.getClientData(any(), any(), eq("NO_SM"))).thenReturn(new ClientResponse());

        ClientConfigurationResponse response = service.getClientConfigurationDetails("tok", "hdr", request);
        assertEquals("200", response.getResponseCode());
    }

    
    @Test
    void testClientConfig_Success() throws Exception {
        ClientRequest request = new ClientRequest();
        request.setClientId("CLIENT123");
        request.setSecurityManagers(new ArrayList<>(List.of(new SecurityManagerRequest("manager@example.com"))));

        ClientResponse clientData = new ClientResponse();
        when(clientDataService.getClientData(any(), any(), eq("CLIENT123"))).thenReturn(clientData);
        when(userService.getAccessToken()).thenReturn("tokenX");

        User user = new User();
        user.setEmail("manager@example.com");
        user.setUsername("mgrUser");
        UserDetailsResponse userDetails = new UserDetailsResponse();
        userDetails.setUserdetails(List.of(user));
        when(requestBuilder.buildGetUserQuery(anyString())).thenReturn("query");
        when(saviyntClient.getUser(any(), any())).thenReturn(userDetails);

        OrganizationDetailsDTO org = new OrganizationDetailsDTO();
        org.setOrganizationname("CLIENT123");
        UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
        orgResp.setOrganizations(List.of(org));
        when(saviyntClient.getOrganizationUserDetails(any(), any())).thenReturn(orgResp);

        SecurityManagerEntitlementEntity ent = new SecurityManagerEntitlementEntity();
        ent.setDisplayName("Role-<ClientID>");
        when(entitlementRepo.findByIsSecuritymanager(1)).thenReturn(List.of(ent));

        EntitlementDetail detail = new EntitlementDetail();
        detail.setEntitlement_value("PFX_Role-CLIENT123,APP");
        detail.setEntitlementOwner(List.of("mgrUser"));
        detail.setStatus("Active");
        detail.setEndpoint("endpoint");
        detail.setDescription("desc");
        EntitlementsResponse entResp = new EntitlementsResponse();
        entResp.setStatusCode(200);
        entResp.setEntitlementdetails(List.of(detail));
        when(saviyntClient.getEntitlements(any(), any())).thenReturn(entResp);

        when(saviyntConfigurationBean.getPrefix()).thenReturn("PFX_");
        when(saviyntConfigurationBean.getApplication()).thenReturn("APP");
        when(saviyntConfigurationBean.getEndpoint()).thenReturn("internal-endpoint");

        ClientConfigurationResponse response = service.getClientConfigurationDetails("token", "header", request);

        assertEquals("200", response.getResponseCode());
        
    }

    
    @Test
    void testHandleRetryFailure_feign() {
        FeignException fx = mock(FeignException.class);
        ClientRequest request = new ClientRequest();

        ClientConfigurationResponse result = service.handleRetryFailure(fx, "token", "header", request);
        assertEquals("503", result.getResponseCode());
    }

    @Test
    void testHandleRetryFailure_generic() {
        IOException ex = new IOException("Fail");
        ClientRequest request = new ClientRequest();

        ClientConfigurationResponse result = service.handleRetryFailure(ex, "token", "header", request);
        assertEquals("503", result.getResponseCode());
        //assertEquals("MSGFOR_POS101", result.getReason());
    }
    @Test
    void testClientConfig_OrganizationMissing() throws Exception {
        ClientRequest request = new ClientRequest();
        request.setClientId("CLIENT999");
        request.setSecurityManagers(new ArrayList<>(List.of(new SecurityManagerRequest("manager@example.com")))); // ✅ non-null email

        when(clientDataService.getClientData(any(), any(), eq("CLIENT999"))).thenReturn(new ClientResponse());
        when(userService.getAccessToken()).thenReturn("token");

        User u = new User();
        u.setEmail("manager@example.com"); // ✅ non-null
        u.setUsername("mgrUser");
        UserDetailsResponse ud = new UserDetailsResponse();
        ud.setUserdetails(List.of(u));
        when(requestBuilder.buildGetUserQuery(any())).thenReturn("q");
        when(saviyntClient.getUser(any(), any())).thenReturn(ud);

        OrganizationDetailsDTO org = new OrganizationDetailsDTO();
        org.setOrganizationname("OTHER_CLIENT"); // does not match CLIENT999
        UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
        orgResp.setOrganizations(List.of(org));
        when(saviyntClient.getOrganizationUserDetails(any(), any())).thenReturn(orgResp);

        EntitlementsResponse entResp = new EntitlementsResponse();
        entResp.setStatusCode(200);
        entResp.setEntitlementdetails(Collections.emptyList());
        when(saviyntClient.getEntitlements(any(), any())).thenReturn(entResp);

        when(saviyntConfigurationBean.getPrefix()).thenReturn("PFX_");
        when(saviyntConfigurationBean.getApplication()).thenReturn("APP");
        when(saviyntConfigurationBean.getEndpoint()).thenReturn("internal-endpoint");

        ClientConfigurationResponse response = service.getClientConfigurationDetails("token", "header", request);
        assertEquals("SAV006", response.getErrors().get(0).getErrorCode());
    }
    @Test
    void testClientConfig_UserDetailsMissing() throws Exception {
        ClientRequest request = new ClientRequest();
        request.setClientId("NO_USER");
        request.setSecurityManagers(new ArrayList<>(List.of(new SecurityManagerRequest("x@example.com")))); // ✅ non-null email

        when(clientDataService.getClientData(any(), any(), eq("NO_USER"))).thenReturn(new ClientResponse());
        when(userService.getAccessToken()).thenReturn("xyz");
        when(requestBuilder.buildGetUserQuery(any())).thenReturn("q");

        UserDetailsResponse emptyUserDetails = new UserDetailsResponse();
        emptyUserDetails.setUserdetails(new ArrayList<>()); // ✅ empty but not null
        when(saviyntClient.getUser(any(), any())).thenReturn(emptyUserDetails);

        when(saviyntConfigurationBean.getPrefix()).thenReturn("PFX_");
        when(saviyntConfigurationBean.getApplication()).thenReturn("APP");
        when(saviyntConfigurationBean.getEndpoint()).thenReturn("internal-endpoint");

        ClientConfigurationResponse response = service.getClientConfigurationDetails("t", "h", request);
        assertEquals("SAV103", response.getErrors().get(0).getErrorCode());
    }
    @Test
    void testClientConfig_OrgMismatchTriggersSAV006() throws Exception {
        ClientRequest request = new ClientRequest();
        request.setClientId("CLIENT789");
        request.setSecurityManagers(new ArrayList<>(List.of(new SecurityManagerRequest("manager@example.com"),new SecurityManagerRequest("manager@example.com"))));

        when(clientDataService.getClientData(any(), any(), eq("CLIENT789"))).thenReturn(new ClientResponse());
        when(userService.getAccessToken()).thenReturn("tokenX");

        User user = new User();
        user.setEmail("manager@example.com");
        user.setUsername("mgrUser");
        UserDetailsResponse udResp = new UserDetailsResponse();
        udResp.setUserdetails(List.of(user));
        when(requestBuilder.buildGetUserQuery(any())).thenReturn("query");
        when(saviyntClient.getUser(any(), any())).thenReturn(udResp);

        OrganizationDetailsDTO wrongOrg = new OrganizationDetailsDTO();
        wrongOrg.setOrganizationname("OTHER_CLIENT"); // does not match request.getClientId()
        UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
        orgResp.setOrganizations(List.of(wrongOrg));
        when(saviyntClient.getOrganizationUserDetails(any(), any())).thenReturn(orgResp);

        EntitlementDetail detail = new EntitlementDetail();
        detail.setEntitlement_value("PFX_Role-CLIENT789,APP");
        detail.setEntitlementOwner(List.of("mgrUser"));
        detail.setStatus("Active");
        detail.setEndpoint("endpoint");
        detail.setDescription("desc");

        EntitlementsResponse entResp = new EntitlementsResponse();
        entResp.setStatusCode(200);
        entResp.setEntitlementdetails(List.of(detail));
        when(saviyntClient.getEntitlements(any(), any())).thenReturn(entResp);

        when(saviyntConfigurationBean.getPrefix()).thenReturn("PFX_");
        when(saviyntConfigurationBean.getApplication()).thenReturn("APP");
        when(saviyntConfigurationBean.getEndpoint()).thenReturn("internal-endpoint");

        ClientConfigurationResponse response = service.getClientConfigurationDetails("t", "h", request);
        assertEquals("SAV006", response.getErrors().get(0).getErrorCode()); // ✅ branch covered
    }
    @Test
    void testClientConfig_OrgMismatchTriggersSAV0061() throws Exception {
        ClientRequest request = new ClientRequest();
        request.setClientId("CLIENT789");
        request.setSecurityManagers(new ArrayList<>(List.of(new SecurityManagerRequest("manager@example.com"),new SecurityManagerRequest("manager@example.com"))));

        when(clientDataService.getClientData(any(), any(), eq("CLIENT789"))).thenReturn(new ClientResponse());
        when(userService.getAccessToken()).thenReturn("tokenX");

        User user = new User();
        user.setEmail("manager@example.com");
        user.setUsername("mgrUser");
        UserDetailsResponse udResp = new UserDetailsResponse();
        udResp.setUserdetails(List.of(user));
        when(requestBuilder.buildGetUserQuery(any())).thenReturn("query");
        when(saviyntClient.getUser(any(), any())).thenReturn(udResp);

        OrganizationDetailsDTO wrongOrg = new OrganizationDetailsDTO();
        wrongOrg.setOrganizationname("CLIENT789"); // does not match request.getClientId()
        UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
        orgResp.setOrganizations(List.of(wrongOrg));
        when(saviyntClient.getOrganizationUserDetails(any(), any())).thenReturn(orgResp);

        EntitlementDetail detail = new EntitlementDetail();
        detail.setEntitlement_value("PFX_Role-CLIENT789,APP");
        detail.setEntitlementOwner(List.of("mgrUser"));
        detail.setStatus("Active");
        detail.setEndpoint("endpoint");
        detail.setDescription("desc");

        SecurityManagerEntitlementEntity entity1 = new SecurityManagerEntitlementEntity();
        entity1.setDisplayName("value1"); // set fields as needed
        entity1.setIsSecuritymanager(1);
        SecurityManagerEntitlementEntity entity2 = new SecurityManagerEntitlementEntity();
        entity2.setDisplayName("Role-CLIENT789");
        entity2.setIsSecuritymanager(1);

        List<SecurityManagerEntitlementEntity> entitlementEntities = List.of(entity1, entity2);


        EntitlementsResponse entResp = new EntitlementsResponse();
        entResp.setStatusCode(200);
        entResp.setEntitlementdetails(List.of(detail));
        when(saviyntClient.getEntitlements(any(), any())).thenReturn(entResp);

        when(saviyntConfigurationBean.getPrefix()).thenReturn("PFX_");
        when(saviyntConfigurationBean.getApplication()).thenReturn("APP");
        when(saviyntConfigurationBean.getEndpoint()).thenReturn("internal-endpoint");
        when(securityManagerEntitlementRepository.findByIsSecuritymanager(1)).thenReturn(entitlementEntities);


        ClientConfigurationResponse response = service.getClientConfigurationDetails("t", "h", request);
        assertEquals("SAV008", response.getErrors().get(0).getErrorCode()); // ✅ branch covered
    } 
 
    @Test
    void testMissingAlightRequestHeader() {
        ClientConfigurationResponse response = service.validateClientRequest(null, new ClientRequest());
        assertNotNull(response);
    }

    @Test
    void testNullRequest() {
        ClientConfigurationResponse response = service.validateClientRequest("header", null);
        assertNotNull(response);
    }

    @Test
    void testMissingClientId() {
        ClientRequest request = new ClientRequest();
        request.setClientId("");
        ClientConfigurationResponse response = service.validateClientRequest("header", request);
        assertNotNull(response);
    }

    @Test
    void testMissingClientName() {
        ClientRequest request = new ClientRequest();
        request.setClientId("clientId");
        request.setClientName("");
        ClientConfigurationResponse response = service.validateClientRequest("header", request);
        assertNotNull(response);
    }

    @Test
    void testNullSecurityManagers() {
        ClientRequest request = new ClientRequest();
        request.setClientId("clientId");
        request.setClientName("clientName");
        request.setSecurityManagers(null);
        ClientConfigurationResponse response = service.validateClientRequest("header", request);
        assertNotNull(response);
    }

    @Test
    void testSecurityManagerWithNullEmail() {
        ClientRequest request = new ClientRequest();
        request.setClientId("clientId");
        request.setClientName("clientName");
        SecurityManagerRequest sm = new SecurityManagerRequest();
        sm.setEmailId(null);
        request.setSecurityManagers(List.of(sm));
        ClientConfigurationResponse response = service.validateClientRequest("header", request);
        assertNotNull(response);
    }

    @Test
    void testValidRequest() {
        ClientRequest request = new ClientRequest();
        request.setClientId("clientId");
        request.setClientName("clientName");
        SecurityManagerRequest sm = new SecurityManagerRequest();
        sm.setEmailId("email@example.com");
        request.setSecurityManagers(List.of(sm));
        ClientConfigurationResponse response = service.validateClientRequest("header", request);
        assertNull(response); // Indicates validation passed
    }
}