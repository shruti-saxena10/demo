package com.alight.cc.startanywhere.configuration;

import static org.hamcrest.CoreMatchers.any;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
//import org.junit.Rule;
//import org.junit.Test;
//import org.junit.rules.TemporaryFolder;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import com.alight.cloud.data.store.util.DockerSecretsUtil;

import javax.sql.DataSource;

@ExtendWith(MockitoExtension.class)
public class PostgreRDSConfigTest {

	@Mock
	private StartAnyWhereConfigBean bean;

	@InjectMocks
	private PostgreRDSConfig postgreRDSConfig;

	@Mock
	private DockerSecretsUtil secretsUtil;



	@BeforeEach
	void setUp() {
		// Mocking configuration values
		lenient().when(bean.getDriverClassName()).thenReturn("org.postgresql.Driver");
		lenient().when(bean.getPostgresServerDatabase()).thenReturn("controlcenterdevdb");
		lenient().when(bean.getPostgresServerUserName()).thenReturn("testUser");
		lenient().when(bean.getPostgresServerPassword()).thenReturn("testPassword");

	//	lenient().when(bean.getHbm2ddl()).thenReturn("hibernate.hbm2ddl.auto");
		lenient().when(bean.getDialect()).thenReturn("hibernate.dialect");
		lenient().when(bean.getShow_sql()).thenReturn("hibernate.show_sql");

	}

	@Test
	void testPostgresDataSource() {
		Map<String, String> secrets = secretsUtil.load();
		assertNotNull(secrets.isEmpty());
		// Set values in the bean
		bean.setPostgresServerUserName(secrets.getOrDefault("user", ""));
		bean.setPostgresServerPassword(secrets.getOrDefault("password", ""));

		// Verify values
		assertEquals("testUser", bean.getPostgresServerUserName());
		assertEquals("testPassword", bean.getPostgresServerPassword());
		DataSource dataSource = postgreRDSConfig.PostgresDataSource();
		assertNotNull(dataSource, "DataSource should not be null");
	}

	@Test
	void testPostgresEntityManagerFactory() {
		LocalContainerEntityManagerFactoryBean entityManagerFactory = postgreRDSConfig.PostgresEntityManagerFactory();
		assertNotNull(entityManagerFactory, "EntityManagerFactory should not be null");
	}

	@Test
	void testPostgresTransactionManager() {
		PlatformTransactionManager   transactionManager = postgreRDSConfig.PostgresTransactionManager(postgreRDSConfig.PostgresEntityManagerFactory().getObject());
		assertNotNull(transactionManager, "TransactionManager should not be null");
	}
	 @Test
	    void testSecretsAreAppliedWhenPresent() {
	        Map<String, String> fakeSecrets = Map.of(
	            "postgresql.cc.startanywhere.user", "mockUser",
	            "postgresql.cc.startanywhere.password", "mockPassword"
	        );

	        try (MockedStatic<DockerSecretsUtil> secretsUtil = Mockito.mockStatic(DockerSecretsUtil.class)) {
	            secretsUtil.when(DockerSecretsUtil::load).thenReturn(fakeSecrets);

	            postgreRDSConfig.PostgresDataSource(); // trigger the bean logic

	            verify(bean).setPostgresServerUserName("mockUser");
	            verify(bean).setPostgresServerPassword("mockPassword");
	        }
	    }

	    @Test
	    void testSecretsAreSkippedWhenEmpty() {
	        try (MockedStatic<DockerSecretsUtil> secretsUtil = Mockito.mockStatic(DockerSecretsUtil.class)) {
	            secretsUtil.when(DockerSecretsUtil::load).thenReturn(Map.of());

	            postgreRDSConfig.PostgresDataSource();

	            verify(bean, never()).setPostgresServerUserName(toString());
	            verify(bean, never()).setPostgresServerPassword(toString());
	        }
	    }
	    @Test
	    void testSecretsPresentButUserKeyMissing() {
	        Map<String, String> secrets = Map.of("postgresql.cc.startanywhere.password", "mypassword");

	        try (MockedStatic<DockerSecretsUtil> staticMock = Mockito.mockStatic(DockerSecretsUtil.class)) {
	            staticMock.when(DockerSecretsUtil::load).thenReturn(secrets);

	            postgreRDSConfig.PostgresDataSource();

	            verify(bean).setPostgresServerUserName(""); 
	            verify(bean).setPostgresServerPassword("mypassword");
	        }
	    }

	    @Test
	    void testSecretsPresentButPasswordKeyMissing() {
	        Map<String, String> secrets = Map.of("postgresql.cc.startanywhere.user", "myuser");

	        try (MockedStatic<DockerSecretsUtil> staticMock = Mockito.mockStatic(DockerSecretsUtil.class)) {
	            staticMock.when(DockerSecretsUtil::load).thenReturn(secrets);

	            postgreRDSConfig.PostgresDataSource();

	            verify(bean).setPostgresServerUserName("myuser");
	            verify(bean).setPostgresServerPassword(""); 
	        }
	    }

	    @Test
	    void testSecretsPresentButBothKeysMissing() {
	        Map<String, String> secrets = Map.of("random.key", "value");

	        try (MockedStatic<DockerSecretsUtil> staticMock = Mockito.mockStatic(DockerSecretsUtil.class)) {
	            staticMock.when(DockerSecretsUtil::load).thenReturn(secrets);

	            postgreRDSConfig.PostgresDataSource();

	            verify(bean).setPostgresServerUserName("");
	            verify(bean).setPostgresServerPassword("");
	        }
	    }
}
