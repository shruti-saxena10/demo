package com.alight.cc.startanywhere;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.boot.SpringApplication;
import org.springframework.test.context.junit.jupiter.SpringExtension;


@ExtendWith(SpringExtension.class)
public class StartAnywhereApplicationTest {

	@Test
	public void test() throws Exception{
		Mockito.mockStatic(SpringApplication.class);
		
		StartAnywhereApplication.main(new String[]{});
		
		Mockito.verify(SpringApplication.class);
		SpringApplication.run(StartAnywhereApplication.class, new String[]{});
		
		StartAnywhereApplication appl = new StartAnywhereApplication();
		assertNotNull(appl);
		
	}

}
