package com.alight.cc.startanywhere.util;

import com.alight.cc.startanywhere.configuration.SaviyntConfigurationBean;
import com.alight.cc.startanywhere.repository.SecurityManagerEntitlementRepository;
import com.alight.cc.startanywhere.saviynt.model.CreateRequest;
import com.alight.cc.startanywhere.saviynt.model.Entitlement;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SaviyntRequestBuilderTest {

    @Mock
    SecurityManagerEntitlementRepository entitlementRepo;
    @Mock
    SaviyntConfigurationBean saviyntConfig;

    @InjectMocks
    SaviyntRequestBuilder builder;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(builder, "saviyntCommonNamePath", "/my/path");
        when(saviyntConfig.getPrefix()).thenReturn("prefixVal");
        when(saviyntConfig.getApplication()).thenReturn("appVal");
        when(saviyntConfig.getEntitlementtype()).thenReturn("entType");
        when(saviyntConfig.getBusinessJustification()).thenReturn("bizjust");
        when(saviyntConfig.getEndpoint()).thenReturn("endpointVal");
        when(saviyntConfig.getSecuritySystem()).thenReturn("securitySystemVal");
    }

    @Test
    void buildGetUserQuery_returnsExpectedQuery() {
        String email = "test@example.com";
        String expected = "user.email = 'test@example.com' and user.statuskey = '1'";
        String query = builder.buildGetUserQuery(email);
        assertEquals(expected, query);
    }

    @Test
    void buildEntitlementArray_mapsAllValues() {
        List<String> entList = Arrays.asList("E1", "E2");
        List<Entitlement> result = builder.buildEntitlementArray(entList, "clientId");
        assertEquals(2, result.size());
        Entitlement ent1 = result.get(0);
        assertEquals("entType", ent1.getEntitlementtype());
        assertEquals("prefixValE1,appVal", ent1.getEntitlementvalue());
        assertEquals("bizjust", ent1.getBusinessjustification());
        assertEquals("ADD", ent1.getUpdatetype());
    }

    @Test
    void buildAccountRequest_setsAllFields() {
        Entitlement ent = Entitlement.builder()
                .entitlementtype("type")
                .entitlementvalue("v")
                .businessjustification("b")
                .updatetype("ADD")
                .build();
        List<Entitlement> ents = Arrays.asList(ent);
        CreateRequest req = builder.buildAccountRequest(ents, "user", "accname");
        assertEquals("accname", req.getAccountname());
        assertEquals("endpointVal", req.getEndpoint());
        assertEquals(ents, req.getEntitlement());
        assertEquals("BULKUPDATE", req.getRequesttype());
        assertEquals("securitySystemVal", req.getSecuritysystem());
        assertEquals("1", req.getStatus());
        assertEquals("user", req.getUsername());
    }
}