package com.alight.cc.startanywhere.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.contains;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import com.alight.cc.dto.OrganizationDetailsDTO;
import com.alight.cc.dto.OrganizationUserDTO;
import com.alight.cc.dto.UpdateOrganizationRequestDTO;
import com.alight.cc.dto.UserOrganizationDetailResponseDTO;
import com.alight.cc.startanywhere.exception.CCServiceException;
import com.alight.cc.startanywhere.feign.SaviyntClient;
import com.alight.cc.startanywhere.model.CreateOrganizationRequestDTO;
import com.alight.cc.startanywhere.model.OrganizationUserDetailResponseDTO;
import com.alight.cc.startanywhere.model.UserOrganizationDetailsDTO;
import com.alight.cc.startanywhere.saviynt.model.CreateOrganizationRequest;
import com.alight.cc.startanywhere.saviynt.model.CreateOrganizationResponse;
import com.alight.cc.startanywhere.saviynt.model.OrganisationUserDetailRequest;
import com.alight.cc.startanywhere.saviynt.model.OrganizationUser;
import com.alight.cc.startanywhere.saviynt.model.UpdateOrganizationRequest;
import com.alight.cc.startanywhere.saviynt.model.UpdateOrganizationResponse;
import com.alight.cc.startanywhere.saviynt.model.UserOrganisationDetailRequest;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;
import com.alight.cc.startanywhere.util.StartAnywhereUtil;
import com.alight.logging.helpers.InfoTypeLogEventHelper;


@ExtendWith(MockitoExtension.class)
class OrganizationServiceTest {

    @Mock
    UserService userService;

    @Mock
    SaviyntClient saviyntClient;

    @InjectMocks
    OrganizationService organisationService;

    @Test
    void createOrganisation_successfulBranch() {
        String accessToken = "token";
        CreateOrganizationRequestDTO dto = new CreateOrganizationRequestDTO();
        dto.setOrganizationname("orgName");
        dto.setUsername("userName");

        CreateOrganizationRequest expectedRequest = CreateOrganizationRequest.builder()
                .organizationname("orgName")
                .username("userName")
                .build();

        CreateOrganizationResponse feignResponse = CreateOrganizationResponse.builder()
                .msg("created").errorCode("0").build();

        try (MockedStatic<StartAnywhereUtil> utilMock = Mockito.mockStatic(StartAnywhereUtil.class);
             MockedStatic<InfoTypeLogEventHelper> logMock = Mockito.mockStatic(InfoTypeLogEventHelper.class)) {

            when(saviyntClient.createOrganization(anyString(), any(CreateOrganizationRequest.class)))
                    .thenReturn(feignResponse);
            utilMock.when(() -> StartAnywhereUtil.calculateSaviyntStatusCode(0)).thenReturn(200);

            CreateOrganizationResponse response = organisationService.createOrganization(dto, accessToken);
            assertEquals("created", response.getMsg());
            assertEquals("0", response.getErrorCode());
            assertEquals(200, response.getStatusCode());

            verify(saviyntClient).createOrganization(eq(StartAnyWhereConstants.AUTH_TOKEN_PREFIX + accessToken), any());
            logMock.verify(() ->
                    InfoTypeLogEventHelper.logInfoEvent(eq(UserService.class.getName()), contains("Response from create organisation:")), times(1));
        }
    }

    @Test
    void createOrganisation_missingMandatoryParams_throwsException() {
        String accessToken = "token";
        CreateOrganizationRequestDTO dto = new CreateOrganizationRequestDTO();
        dto.setOrganizationname("");
        dto.setUsername(null);

        CCServiceException exception = assertThrows(CCServiceException.class,
                () -> organisationService.createOrganization(dto, accessToken));
        assertEquals(HttpStatus.PRECONDITION_FAILED, exception.getHttpStatus());
        assertTrue(exception.getMessage().contains("Missing mandatory parameter"));
    }

    @Test
    void updateUserToOrganization_successfulBranch() {
        String accessToken = "token";
        OrganizationUserDTO userDto = new OrganizationUserDTO();
        userDto.setUpdatetype("ADD");
        userDto.setUsername("user1");

        UpdateOrganizationRequestDTO dto = new UpdateOrganizationRequestDTO();
        dto.setOrganizationname("orgName");
        dto.setUsername("adminUser");
        dto.setUsers(List.of(userDto));
        OrganizationUser user = OrganizationUser.builder().username("u1").updatetype("REMOVE").build();
        UpdateOrganizationRequest expectedRequest = UpdateOrganizationRequest.builder()
                .organizationname("orgName")
                .username("adminUser")
                .users(List.of(user))
                .build();

        UpdateOrganizationResponse feignResponse = UpdateOrganizationResponse.builder()
                .msg("updated").errorCode("0").build();

        try (MockedStatic<StartAnywhereUtil> utilMock = Mockito.mockStatic(StartAnywhereUtil.class);
             MockedStatic<InfoTypeLogEventHelper> logMock = Mockito.mockStatic(InfoTypeLogEventHelper.class)) {

            when(saviyntClient.addUsersToOrganization(anyString(), any(UpdateOrganizationRequest.class)))
                    .thenReturn(feignResponse);
            utilMock.when(() -> StartAnywhereUtil.calculateSaviyntStatusCode(0)).thenReturn(200);

            UpdateOrganizationResponse response = organisationService.updateUserToOrganization(dto, accessToken);
            assertEquals("updated", response.getMsg());
            assertEquals("0", response.getErrorCode());
            assertEquals(200, response.getStatusCode());

            verify(saviyntClient).addUsersToOrganization(eq(StartAnyWhereConstants.AUTH_TOKEN_PREFIX + accessToken), any());
            logMock.verify(() ->
                    InfoTypeLogEventHelper.logInfoEvent(eq(UserService.class.getName()), contains("Response from adding or removing  user:")), times(1));
        }
    }

    @Test
    void updateUserToOrganization_missingMandatoryParams_throwsException() {
        String accessToken = "token";
        UpdateOrganizationRequestDTO dto = new UpdateOrganizationRequestDTO();
        dto.setOrganizationname("");
        dto.setUsername(null);
        dto.setUsers(null);

        CCServiceException exception = assertThrows(CCServiceException.class,
                () -> organisationService.updateUserToOrganization(dto, accessToken));
        assertEquals(HttpStatus.PRECONDITION_FAILED, exception.getHttpStatus());
        assertTrue(exception.getMessage().contains("Missing mandatory parameter"));
    }

    @Test
    void updateUserToOrganization_emptyUsers_throwsException() {
        String accessToken = "token";
        UpdateOrganizationRequestDTO dto = new UpdateOrganizationRequestDTO();
        dto.setOrganizationname("someOrg");
        dto.setUsername("admin");
        dto.setUsers(Collections.emptyList());

        CCServiceException exception = assertThrows(CCServiceException.class,
                () -> organisationService.updateUserToOrganization(dto, accessToken));
        assertEquals(HttpStatus.PRECONDITION_FAILED, exception.getHttpStatus());
        assertTrue(exception.getMessage().contains("Missing mandatory parameter"));
    }

//    @Test
//    void buildUpdateOrgRequest_copiesFields() {
//        UpdateOrganizationRequestDTO dto = new UpdateOrganizationRequestDTO();
//        dto.setOrganizationname("org");
//        dto.setUsername("uadmin");
//        OrganizationUserDTO userDto = new OrganizationUserDTO();
//        userDto.setUpdatetype("ADD");
//        userDto.setUsername("user1");
//
//        OrganizationUser user = OrganizationUser.builder().username("u1").updatetype("REMOVE").build();
//        dto.setUsers(List.of(userDto));
//
//        UpdateOrganizationResponse request = organisationService
//                .updateUserToOrganization(dto, "tok"); // this will call buildUpdateOrgRequest internally (success path)
//
//        // The test above already covers buildUpdateOrgRequest, but let's call it directly for completeness
//        UpdateOrganizationRequest result = invokeBuildUpdateOrgRequest(dto);
//        assertEquals("org", result.getOrganizationname());
//        assertEquals("uadmin", result.getUsername());
//        assertEquals("u1", result.getUsers().get(0).getUsername());
//        assertEquals("REMOVE", result.getUsers().get(0).getUpdatetype());
//    }
//
//    // Helper to call private method for full coverage
//    private UpdateOrganizationRequest invokeBuildUpdateOrgRequest(UpdateOrganizationRequestDTO dto) {
//        try {
//            var m = OrganisationService.class.getDeclaredMethod("buildUpdateOrgRequest", UpdateOrganizationRequestDTO.class);
//            m.setAccessible(true);
//            return (UpdateOrganizationRequest) m.invoke(organisationService, dto);
//        } catch (Exception e) {
//            throw new RuntimeException(e);
//        }
//    }
    
    @Test
    void testGetUserDetailsForOrganization_ValidRequest_ReturnsResponse() {
        String accessToken = "abc123";
        String username = "john.doe";

        UserOrganisationDetailRequest request = UserOrganisationDetailRequest.builder()
                .username(username)
                .max(StartAnyWhereConstants.MAX)
                .build();

        List<OrganizationDetailsDTO> organizations = new ArrayList<>();
        OrganizationDetailsDTO dto = new OrganizationDetailsDTO();
        dto.setOrganizationname("1234");
        dto.setOrgmembership("secondary");
        organizations.add(dto);
        
        UserOrganizationDetailResponseDTO mockResponse = UserOrganizationDetailResponseDTO.builder()
                .msg("Success")
                .displaycount("1")
                .max("500")
                .organizations(organizations)
                .username(username)
                .errorCode("200")
                .totalcount("1")
                .build();
        try (MockedStatic<StartAnywhereUtil> utilMock = Mockito.mockStatic(StartAnywhereUtil.class)){
        when(saviyntClient.getOrganizationUserDetails(anyString(), any()))
                .thenReturn(mockResponse);
        when(StartAnywhereUtil.calculateSaviyntStatusCode(200)).thenReturn(200);

       UserOrganizationDetailResponseDTO result = organisationService.getUserDetailsForOrganization(accessToken, request);

        assertNotNull(result);
        assertEquals("Success", result.getMsg());
        assertEquals("john.doe", result.getUsername());
        assertEquals(200, result.getStatusCode());
    }
    }

    @Test
    void testGetUserDetailsForOrganization_EmptyUsername_ThrowsException() {
        UserOrganisationDetailRequest request = UserOrganisationDetailRequest.builder()
                .username("")
                .max(StartAnyWhereConstants.MAX)
                .build();

        CCServiceException exception = assertThrows(CCServiceException.class, () ->
        organisationService.getUserDetailsForOrganization("1234", request));

        assertEquals(HttpStatus.PRECONDITION_FAILED, exception.getHttpStatus());
        assertEquals("Unable to get user details for the organization", exception.getMessage());
    }

    
    @Test
    void updateUserToOrganization_missingUsername_throwsException() {
        UpdateOrganizationRequestDTO requestDTO = new UpdateOrganizationRequestDTO();
        requestDTO.setOrganizationname("TestOrg");
        requestDTO.setUsername(""); // Empty username

        String accessToken = "dummyToken";

        CCServiceException exception = assertThrows(CCServiceException.class, () -> {
        	organisationService.updateUserToOrganization(requestDTO, accessToken);
        });

        assertEquals(HttpStatus.PRECONDITION_FAILED, exception.getHttpStatus());
        assertTrue(exception.getMessage().contains("Missing mandatory parameter"));
    }
    
    @Test
    void getUserDetailsForOrganization_withNullRequest_throwsException() {
        String accessToken = "dummyToken";

        CCServiceException exception = assertThrows(CCServiceException.class, () -> {
        	organisationService.getUserDetailsForOrganization(accessToken, null);
        });

        assertEquals(HttpStatus.PRECONDITION_FAILED, exception.getHttpStatus());
        assertTrue(exception.getMessage().contains("Unable to get user details"));
    }
    
    @Test
    void getUserDetailsForOrganization_withEmptyUsername_throwsException() {
        String accessToken = "dummyToken";
        UserOrganisationDetailRequest request = UserOrganisationDetailRequest.builder()
            .username("") // Empty username
            .build();

        CCServiceException exception = assertThrows(CCServiceException.class, () -> {
        	organisationService.getUserDetailsForOrganization(accessToken, request);
        });

        assertEquals(HttpStatus.PRECONDITION_FAILED, exception.getHttpStatus());
        assertTrue(exception.getMessage().contains("Unable to get user details"));
    }

    @Test
    void getUserOrganizationDetails_withNullRequest_returnsNull() {
        String accessToken = "dummyToken";
        String clientId = "TestOrg";

        OrganizationUserDetailResponseDTO response = organisationService.getUserOrganizationDetails(accessToken, null, clientId);

        assertNull(response);
    }

    @Test
    void getUserOrganizationDetails_withEmptyOrganizationName_throwsException() {
        String accessToken = "dummyToken";
        String clientId = "TestOrg";

        OrganisationUserDetailRequest request = OrganisationUserDetailRequest.builder()
            .organizationname("") // Empty
            .build();

        CCServiceException exception = assertThrows(CCServiceException.class, () -> {
        	organisationService.getUserOrganizationDetails(accessToken, request, clientId);
        });

        assertEquals(HttpStatus.PRECONDITION_FAILED, exception.getHttpStatus());
        assertTrue(exception.getMessage().contains("Unable to get organization details"));
    }

    @Test
    void getUserOrganizationDetails_withMismatchedClientId_throwsException() {
        String accessToken = "dummyToken";
        String clientId = "ClientA";

        OrganisationUserDetailRequest request = OrganisationUserDetailRequest.builder()
            .organizationname("ClientB") // Mismatch
            .build();

        CCServiceException exception = assertThrows(CCServiceException.class, () -> {
        	organisationService.getUserOrganizationDetails(accessToken, request, clientId);
        });

        assertEquals(HttpStatus.PRECONDITION_FAILED, exception.getHttpStatus());
        assertTrue(exception.getMessage().contains("Unable to get organization details"));
    }

    @Test
    void getUserOrganizationDetails_withValidRequest_returnsResponse() {
        String accessToken = "dummyToken";
        String clientId = "TestOrg";

        OrganisationUserDetailRequest request = OrganisationUserDetailRequest.builder()
            .organizationname("TestOrg")
            .max("500")
            .build();
        
        List<UserOrganizationDetailsDTO> listdto = List.of(
        	    UserOrganizationDetailsDTO.of("a108", "2023-01-01", "2023-12-31", "member"),
        	    UserOrganizationDetailsDTO.of("b205", "", "", ""),
        	    UserOrganizationDetailsDTO.of("c309", "2022-05-10", "", "guest"),
        	    UserOrganizationDetailsDTO.of("d412", "", "", "")
        	);


        OrganizationUserDetailResponseDTO mockResponse = OrganizationUserDetailResponseDTO.builder()
            .organizationname("TestOrg")
            .displaycount("10")
            .msg("Success")
            .totalcount("100")
            .offset("0")
            .max("50")
            .errorCode("0")
            .users(listdto)
            .build();

        when(saviyntClient.getUserOrganizationDetails(anyString(), any())).thenReturn(mockResponse);

        OrganizationUserDetailResponseDTO response = organisationService.getUserOrganizationDetails(accessToken, request, clientId);

        assertNotNull(response);
        assertEquals("TestOrg", response.getOrganizationname());
        assertEquals("Success", response.getMsg());
        assertEquals("0", response.getErrorCode());
    }


    @Test
    void testCreateOrganization_withMissingUsername_shouldThrowException() {
        CreateOrganizationRequestDTO requestDTO = new CreateOrganizationRequestDTO();
        requestDTO.setOrganizationname("TestOrg");
        requestDTO.setUsername(""); // Empty username

        CCServiceException exception = assertThrows(CCServiceException.class, () -> {
        	organisationService.createOrganization(requestDTO, "access-token");
        });

        assertEquals(HttpStatus.PRECONDITION_FAILED, exception.getHttpStatus());
        assertTrue(exception.getMessage().contains("Missing mandatory parameter"));
    }

}