package com.alight.cc.startanywhere.service;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.contains;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.invocation.Invocation;


import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.postgresql.util.PSQLException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.alight.cc.dto.AccountDTO;
import com.alight.cc.dto.OrganizationDetailsDTO;
import com.alight.cc.dto.UpdateOrganizationRequestDTO;
import com.alight.cc.dto.UserEntitlementsDTO;
import com.alight.cc.dto.UserOrganizationDetailResponseDTO;
import com.alight.cc.repository.DomainLookupRepository;
import com.alight.cc.startanywhere.configuration.SaviyntConfigurationBean;
import com.alight.cc.startanywhere.entity.SecurityManagerEntitlementEntity;
import com.alight.cc.startanywhere.feign.SaviyntClient;
import com.alight.cc.startanywhere.model.BaseResponse;
import com.alight.cc.startanywhere.model.ClientConfigError;
import com.alight.cc.startanywhere.model.EntitlementOwnerResponse;
import com.alight.cc.startanywhere.model.OrganizationUserDetailResponseDTO;
import com.alight.cc.startanywhere.model.UserOrganizationDetailsDTO;
import com.alight.cc.startanywhere.repository.SecurityManagerEntitlementRepository;
import com.alight.cc.startanywhere.saviynt.model.EntitlementDetail;
import com.alight.cc.startanywhere.saviynt.model.EntitlementsResponse;
import com.alight.cc.startanywhere.saviynt.model.UpdateOrganizationResponse;
import com.alight.cc.startanywhere.saviynt.model.User;
import com.alight.cc.startanywhere.saviynt.model.UserDetailsResponse;
import com.alight.cc.startanywhere.service.impl.DeleteClientConfigurationServiceImpl;
import com.alight.cc.startanywhere.util.CheckClientData;
import com.alight.cc.startanywhere.util.SaviyntRequestBuilder;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;
import com.alight.cc.startanywhere.util.StartAnywhereUtil;
import com.alight.logging.helpers.InfoTypeLogEventHelper;
import com.aonhewitt.logging.helpers.ErrorLogEventHelper;
import com.fasterxml.jackson.core.JsonProcessingException;

import feign.FeignException;

@ExtendWith(MockitoExtension.class)

public class DeleteClientConfigurationServiceImplTest {

	@InjectMocks
	private DeleteClientConfigurationServiceImpl service; 
	@Mock
	private UserService userService;
	@Mock
	private AccountService accountService;
	@Mock
	private CheckClientData checkClientData;
	@Mock
	private OrganizationService orgService;
	@Mock
	private EntitlementService entitlementService;
	@Mock
	private SaviyntService saviyntService;
	@Mock
	private SecurityManagerEntitlementRepository securityManagerEntitlementRepository;
	@Mock
	private RemoveClientService removeClientService;

	@Mock private SaviyntClient saviyntClient;
	@Mock
	private StartAnywhereUtil startAnywhereUtil;
	@Mock private SaviyntRequestBuilder requestBuilder;
	@Mock  SaviyntConfigurationBean saviyntConfigurationBean;
	@Mock
	private DomainLookupRepository domainRepo;
	@Mock
	private SecurityManagerEntitlementRepository entitlementRepo;
	


	@Captor
	ArgumentCaptor<String> keyCaptor;
	@Captor
	ArgumentCaptor<List<ClientConfigError>> errorsCaptor;

	private String token = "dummyToken";
	private String header = "validHeader";
	private String clientId = "client123";
	private String orgName = "orgABC";
	private List<String> emails = List.of("user@example.com");




	@Test
	void testValidFlow() throws Exception {
		// Arrange
		when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		when(userService.getAccessToken()).thenReturn(token);
		when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		User user = new User();
		user.setUsername("user1");
		user.setEmail("user@example.com");
		when(userService.getUserProfile("user@example.com", token)).thenReturn(user);

		AccountDTO account = new AccountDTO();
		account.setStatus("1");
		account.setAccountname("acc123");
		when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));

		OrganizationDetailsDTO orgDetail = new OrganizationDetailsDTO();
		orgDetail.setOrganizationname(clientId);
		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setUsername("user1");
		orgResp.setOrganizations(List.of(orgDetail));
		when(orgService.getUserDetailsForOrganization(Mockito.eq(token), Mockito.any())).thenReturn(orgResp);

		EntitlementsResponse entResp = new EntitlementsResponse();
		EntitlementDetail detail = new EntitlementDetail();
		detail.setEntitlement_value("ent1");
		detail.setEndpoint("endpoint");
		detail.setDescription("desc");
		detail.setStatus("active");
		entResp.setEntitlementdetails(List.of(detail));
		lenient().when(entitlementService.loadEntitlements("user1", token, clientId)).thenReturn(entResp);

		lenient().when(securityManagerEntitlementRepository.findByIsSecuritymanager(1)).thenReturn(List.of());
		lenient().when(saviyntService.getDisplayNamesWithClientId(Mockito.any(), Mockito.eq(clientId))).thenReturn(List.of("ent1"));

		UserEntitlementsDTO updated = new UserEntitlementsDTO();
		updated.setEmail("user@example.com");
		lenient().when(entitlementService.updateUser(Mockito.any(), Mockito.eq(token))).thenReturn(updated);

		List<UserOrganizationDetailsDTO> listDto= new ArrayList<>();
		UserOrganizationDetailsDTO dto=new UserOrganizationDetailsDTO();
		dto.setUsername("user1");
		listDto.add(dto);
		OrganizationUserDetailResponseDTO orguserRespose = new OrganizationUserDetailResponseDTO();
		orguserRespose.setOrganizationname(clientId);
		orguserRespose.setUsers(listDto);
		lenient().when(orgService.getUserOrganizationDetails(Mockito.eq(token), Mockito.any(), Mockito.eq(clientId))).thenReturn(orguserRespose);

		UpdateOrganizationResponse updateOrgResp = new UpdateOrganizationResponse();
		updateOrgResp.setStatusCode(200);
		lenient(). when(orgService.updateUserToOrganization(Mockito.any(), Mockito.eq(token))).thenReturn(updateOrgResp);

		BaseResponse pgResponseBody = new BaseResponse();
		lenient(). when(removeClientService.deleteClientDetails(Mockito.any(), Mockito.any(), Mockito.eq(clientId)))
		.thenReturn(ResponseEntity.ok(pgResponseBody));

		// Act
		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, emails);

		// Assert
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	void testValidFlow_withoutError() throws Exception {
		// Arrange
		when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		when(userService.getAccessToken()).thenReturn(token);
		when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		User user = new User();
		user.setUsername("user1");
		user.setEmail("user@example.com");
		when(userService.getUserProfile("user@example.com", token)).thenReturn(user);

		AccountDTO account = new AccountDTO();
		account.setStatus("1");
		account.setAccountname("acc123");
		when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));

		OrganizationDetailsDTO orgDetail = new OrganizationDetailsDTO();
		orgDetail.setOrganizationname(clientId);
		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setUsername("user1");
		orgResp.setOrganizations(List.of(orgDetail));
		when(orgService.getUserDetailsForOrganization(Mockito.eq(token), Mockito.any())).thenReturn(orgResp);

		EntitlementsResponse entResp = new EntitlementsResponse();
		EntitlementDetail detail = new EntitlementDetail();
		detail.setEntitlement_value("ent1");
		detail.setEndpoint("endpoint");
		detail.setDescription("desc");
		detail.setStatus("active");
		entResp.setEntitlementdetails(List.of(detail));
		lenient().when(entitlementService.loadEntitlements("user1", token, clientId)).thenReturn(entResp);

		lenient().when(securityManagerEntitlementRepository.findByIsSecuritymanager(1)).thenReturn(List.of());
		lenient().when(saviyntService.getDisplayNamesWithClientId(Mockito.any(), Mockito.eq(clientId))).thenReturn(List.of("ent1"));

		UserEntitlementsDTO updated = new UserEntitlementsDTO();
		updated.setEmail("user@example.com");
		lenient().when(entitlementService.updateUser(Mockito.any(), Mockito.eq(token))).thenReturn(updated);

		List<UserOrganizationDetailsDTO> listDto= new ArrayList<>();
		UserOrganizationDetailsDTO dto=new UserOrganizationDetailsDTO();
		dto.setUsername("user1");
		listDto.add(dto);
		OrganizationUserDetailResponseDTO orguserRespose = new OrganizationUserDetailResponseDTO();
		orguserRespose.setOrganizationname(clientId);
		orguserRespose.setUsers(listDto);
		lenient().when(orgService.getUserOrganizationDetails(Mockito.eq(token), Mockito.any(), Mockito.eq(clientId))).thenReturn(orguserRespose);

		UpdateOrganizationResponse updateOrgResp = new UpdateOrganizationResponse();
		updateOrgResp.setStatusCode(200);
		lenient(). when(orgService.updateUserToOrganization(Mockito.any(), Mockito.eq(token))).thenReturn(updateOrgResp);

		BaseResponse pgResponseBody = new BaseResponse();
		pgResponseBody.setResponseCode(StartAnyWhereConstants.HTTP_STATUS_SUCCESS);
		pgResponseBody.setErrors(null); // or Collections.emptyList()

		pgResponseBody.setResponseMessage(StartAnyWhereConstants.DELETE_STATUS);
		assertEquals(StartAnyWhereConstants.HTTP_STATUS_SUCCESS, pgResponseBody.getResponseCode());
		assertEquals(StartAnyWhereConstants.DELETE_STATUS, pgResponseBody.getResponseMessage());
		assertNull(pgResponseBody.getErrors());


		when(removeClientService.deleteClientDetails(any(), any(), eq(clientId)))
		.thenReturn(ResponseEntity.ok(pgResponseBody));


		// Act
		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, emails);


		// Assert
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}
	@Test
	void testPostgre_Exception() throws Exception {
		// Arrange
		when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		when(userService.getAccessToken()).thenReturn(token);
		when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		User user = new User();
		user.setUsername("user1");
		user.setEmail("user@example.com");
		List<User> listOfUsers = new ArrayList<>(); 
		listOfUsers.add(user);
		when(userService.getUserProfile("user@example.com", token)).thenReturn(user);

		AccountDTO account = new AccountDTO();
		account.setStatus("1");
		account.setAccountname("acc123");
		when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));

		OrganizationDetailsDTO orgDetail = new OrganizationDetailsDTO();
		orgDetail.setOrganizationname(clientId);
		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setUsername("user1");
		orgResp.setOrganizations(List.of(orgDetail));
		when(orgService.getUserDetailsForOrganization(Mockito.eq(token), Mockito.any())).thenReturn(orgResp);

		EntitlementsResponse entResp = new EntitlementsResponse();
		EntitlementDetail detail = new EntitlementDetail();
		detail.setEntitlement_value("ent1");
		detail.setEndpoint("endpoint");
		detail.setDescription("desc");
		detail.setStatus("active");
		entResp.setEntitlementdetails(List.of(detail));
		lenient().when(entitlementService.loadEntitlements("user1", token, clientId)).thenReturn(entResp);

		lenient().when(securityManagerEntitlementRepository.findByIsSecuritymanager(1)).thenReturn(List.of());
		lenient().when(saviyntService.getDisplayNamesWithClientId(Mockito.any(), Mockito.eq(clientId))).thenReturn(List.of("ent1"));

		UserEntitlementsDTO updated = new UserEntitlementsDTO();
		updated.setEmail("user@example.com");
		lenient().when(entitlementService.updateUser(Mockito.any(), Mockito.eq(token))).thenReturn(updated);

		List<UserOrganizationDetailsDTO> listDto= new ArrayList<>();
		UserOrganizationDetailsDTO dto=new UserOrganizationDetailsDTO();
		dto.setUsername("user1");
		listDto.add(dto);
		OrganizationUserDetailResponseDTO orguserRespose = new OrganizationUserDetailResponseDTO();
		orguserRespose.setOrganizationname(clientId);
		orguserRespose.setUsers(listDto);
		lenient().when(orgService.getUserOrganizationDetails(Mockito.eq(token), Mockito.any(), Mockito.eq(clientId))).thenReturn(orguserRespose);

		List<String> validUserList = Optional.ofNullable(listOfUsers)
				.orElse(Collections.emptyList())
				.stream()
				.map(us -> us != null ? us.getUsername() : null) 
				.filter(Objects::nonNull)
				.collect(Collectors.toList());


		List<String> orgUsersList = Optional.ofNullable(orguserRespose.getUsers())
				.filter(users -> !users.isEmpty())
				.map(users -> users.stream()
						.map(UserOrganizationDetailsDTO::getUsername)
						.collect(Collectors.toList()))
				.orElse(new ArrayList<>());

		DeleteClientConfigurationServiceImpl serviceimpl = Mockito.mock(DeleteClientConfigurationServiceImpl.class);
		lenient().when(serviceimpl.isValid(any(), any())).thenReturn(false);
		UpdateOrganizationResponse updateOrgResp = new UpdateOrganizationResponse();
		updateOrgResp.setStatusCode(200);
		lenient().when(orgService.updateUserToOrganization(Mockito.any(), Mockito.eq(token))).thenReturn(updateOrgResp);

		// Act
		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, emails);

		// Assert
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
	}

	@Test
	void testValidFlow_pgError_ok() throws Exception {
		// Arrange
		when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		when(userService.getAccessToken()).thenReturn(token);
		when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		User user = new User();
		user.setUsername("user1");
		user.setEmail("user@example.com");
		when(userService.getUserProfile("user@example.com", token)).thenReturn(user);

		AccountDTO account = new AccountDTO();
		account.setStatus("1");
		account.setAccountname("acc123");
		when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));

		OrganizationDetailsDTO orgDetail = new OrganizationDetailsDTO();
		orgDetail.setOrganizationname(clientId);
		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setUsername("user1");
		orgResp.setOrganizations(List.of(orgDetail));
		when(orgService.getUserDetailsForOrganization(Mockito.eq(token), Mockito.any())).thenReturn(orgResp);

		EntitlementsResponse entResp = new EntitlementsResponse();
		EntitlementDetail detail = new EntitlementDetail();
		detail.setEntitlement_value("ent1");
		detail.setEndpoint("endpoint");
		detail.setDescription("desc");
		detail.setStatus("active");
		entResp.setEntitlementdetails(List.of(detail));
		lenient().when(entitlementService.loadEntitlements("user1", token, clientId)).thenReturn(entResp);

		lenient().when(securityManagerEntitlementRepository.findByIsSecuritymanager(1)).thenReturn(List.of());
		lenient().when(saviyntService.getDisplayNamesWithClientId(Mockito.any(), Mockito.eq(clientId))).thenReturn(List.of("ent1"));

		UserEntitlementsDTO updated = new UserEntitlementsDTO();
		updated.setEmail("user@example.com");
		lenient().when(entitlementService.updateUser(Mockito.any(), Mockito.eq(token))).thenReturn(updated);

		List<UserOrganizationDetailsDTO> listDto= new ArrayList<>();
		UserOrganizationDetailsDTO dto=new UserOrganizationDetailsDTO();
		dto.setUsername("user1");
		listDto.add(dto);
		OrganizationUserDetailResponseDTO orguserRespose = new OrganizationUserDetailResponseDTO();
		orguserRespose.setOrganizationname(clientId);
		orguserRespose.setUsers(listDto);
		lenient().when(orgService.getUserOrganizationDetails(Mockito.eq(token), Mockito.any(), Mockito.eq(clientId))).thenReturn(orguserRespose);

		UpdateOrganizationResponse updateOrgResp = new UpdateOrganizationResponse();
		updateOrgResp.setStatusCode(200);
		lenient(). when(orgService.updateUserToOrganization(Mockito.any(), Mockito.eq(token))).thenReturn(updateOrgResp);

		BaseResponse pgResponseBody = new BaseResponse();
		List<ClientConfigError> errors =new ArrayList<>();
		ClientConfigError err = new ClientConfigError();
		err.setEmailId("user@example.com");
		err.setErrorCode("500");
		err.setErrorMessage("Internal Server Error");
		errors.add(err);
		pgResponseBody.setErrors(errors);

		lenient(). when(removeClientService.deleteClientDetails(Mockito.any(), Mockito.any(), Mockito.eq(clientId)))
		.thenReturn(ResponseEntity.ok(pgResponseBody));

		// Act
		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, emails);

		// Assert
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	void testValidFlow_pgBlock_delete() throws Exception {
		// Arrange
		when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		when(userService.getAccessToken()).thenReturn(token);
		when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		User user = new User();
		user.setUsername("user1");
		user.setEmail("user@example.com");
		when(userService.getUserProfile("user@example.com", token)).thenReturn(user);

		AccountDTO account = new AccountDTO();
		account.setStatus("1");
		account.setAccountname("acc123");
		when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));

		OrganizationDetailsDTO orgDetail = new OrganizationDetailsDTO();
		orgDetail.setOrganizationname(clientId);
		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setUsername("user1");
		orgResp.setOrganizations(List.of(orgDetail));
		when(orgService.getUserDetailsForOrganization(Mockito.eq(token), Mockito.any())).thenReturn(orgResp);

		EntitlementsResponse entResp = new EntitlementsResponse();
		EntitlementDetail detail = new EntitlementDetail();
		detail.setEntitlement_value("ent1");
		detail.setEndpoint("endpoint");
		detail.setDescription("desc");
		detail.setStatus("active");
		entResp.setEntitlementdetails(List.of(detail));
		lenient().when(entitlementService.loadEntitlements("user1", token, clientId)).thenReturn(entResp);

		lenient().when(securityManagerEntitlementRepository.findByIsSecuritymanager(1)).thenReturn(List.of());
		lenient().when(saviyntService.getDisplayNamesWithClientId(Mockito.any(), Mockito.eq(clientId))).thenReturn(List.of("ent1"));

		UserEntitlementsDTO updated = new UserEntitlementsDTO();
		updated.setEmail("user@example.com");
		lenient().when(entitlementService.updateUser(Mockito.any(), Mockito.eq(token))).thenReturn(updated);

		UserOrganizationDetailsDTO orgUser = new UserOrganizationDetailsDTO();
		orgUser.setUsername("userX"); // Not matching "user1"

		OrganizationUserDetailResponseDTO orguserRespose = new OrganizationUserDetailResponseDTO();
		orguserRespose.setOrganizationname(clientId);
		orguserRespose.setUsers(List.of(orgUser));

		lenient(). when(orgService.getUserOrganizationDetails(eq(token), any(), eq(clientId)))
		.thenReturn(orguserRespose);
		DeleteClientConfigurationServiceImpl serviceimpl = mock(DeleteClientConfigurationServiceImpl.class);
		lenient(). when(serviceimpl.isValid(any(), any())).thenReturn(false);


		UpdateOrganizationResponse updateOrgResp = new UpdateOrganizationResponse();
		updateOrgResp.setStatusCode(200);
		lenient(). when(orgService.updateUserToOrganization(Mockito.any(), Mockito.eq(token))).thenReturn(updateOrgResp);

		try (MockedStatic<InfoTypeLogEventHelper> mockedLogHelper = Mockito.mockStatic(InfoTypeLogEventHelper.class)) {

			// Act
			ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
					"sessionToken", header, clientId, orgName, emails);

			// Assert the exact log message was called
			mockedLogHelper.verify(() -> InfoTypeLogEventHelper.logInfoEvent(
					any(),
					eq("Deletion of PostgreSQL database blocked due to presence of active security managers. " +
							"Please ensure all security dependencies are cleared before retrying.\n")
					));

			// Assert
			assertEquals(HttpStatus.OK, response.getStatusCode());


		}
	}

	@Test
	void testValidFlow_Org_Null() throws Exception {
		// Arrange
		when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		when(userService.getAccessToken()).thenReturn(token);
		when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		User user = new User();
		user.setUsername("user1");
		user.setEmail("user@example.com");
		when(userService.getUserProfile("user@example.com", token)).thenReturn(user);

		AccountDTO account = new AccountDTO();
		account.setStatus("1");
		account.setAccountname("acc123");
		when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));

		OrganizationDetailsDTO orgDetail = new OrganizationDetailsDTO();
		orgDetail.setOrganizationname(clientId);
		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setUsername("user1");
		orgResp.setOrganizations(List.of(orgDetail));
		when(orgService.getUserDetailsForOrganization(Mockito.eq(token), Mockito.any())).thenReturn(orgResp);

		EntitlementsResponse entResp = new EntitlementsResponse();
		EntitlementDetail detail = new EntitlementDetail();
		detail.setEntitlement_value("ent1");
		detail.setEndpoint("endpoint");
		detail.setDescription("desc");
		detail.setStatus("active");
		entResp.setEntitlementdetails(List.of(detail));
		lenient().when(entitlementService.loadEntitlements("user1", token, clientId)).thenReturn(entResp);

		lenient().when(securityManagerEntitlementRepository.findByIsSecuritymanager(1)).thenReturn(List.of());
		lenient().when(saviyntService.getDisplayNamesWithClientId(Mockito.any(), Mockito.eq(clientId))).thenReturn(List.of("ent1"));

		UserEntitlementsDTO updated = new UserEntitlementsDTO();
		updated.setEmail("user@example.com");
		lenient().when(entitlementService.updateUser(Mockito.any(), Mockito.eq(token))).thenReturn(updated);

		List<UserOrganizationDetailsDTO> listDto= new ArrayList<>();
		UserOrganizationDetailsDTO dto=new UserOrganizationDetailsDTO();
		dto.setUsername("user1");
		listDto.add(dto);
		OrganizationUserDetailResponseDTO orguserRespose = new OrganizationUserDetailResponseDTO();
		orguserRespose.setOrganizationname(clientId);
		orguserRespose.setUsers(listDto);

		DeleteClientConfigurationServiceImpl serviceimpl = Mockito.mock(DeleteClientConfigurationServiceImpl.class);
		lenient().when(serviceimpl.isValid(any(), any())).thenReturn(false);
		lenient().when(orgService.getUserOrganizationDetails(Mockito.eq(token), Mockito.any(), Mockito.eq(clientId))).thenReturn(orguserRespose);

		UpdateOrganizationResponse updateOrgResp = new UpdateOrganizationResponse();
		updateOrgResp.setStatusCode(200);
		lenient(). when(orgService.updateUserToOrganization(Mockito.any(), Mockito.eq(token))).thenReturn(updateOrgResp);

		BaseResponse pgResponseBody = new BaseResponse();
		lenient(). when(removeClientService.deleteClientDetails(Mockito.any(), Mockito.any(), Mockito.eq(clientId)))
		.thenReturn(ResponseEntity.ok(pgResponseBody));

		// Act
		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, emails);

		// Assert
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}
	@Test
	void testValidFlow_pgError_internalServerError() throws Exception {
		// Arrange
		when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		when(userService.getAccessToken()).thenReturn(token);
		when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		User user = new User();
		user.setUsername("user1");
		user.setEmail("user@example.com");
		when(userService.getUserProfile("user@example.com", token)).thenReturn(user);

		AccountDTO account = new AccountDTO();
		account.setStatus("1");
		account.setAccountname("acc123");
		when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));

		OrganizationDetailsDTO orgDetail = new OrganizationDetailsDTO();
		orgDetail.setOrganizationname(clientId);
		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setUsername("user1");
		orgResp.setOrganizations(List.of(orgDetail));
		when(orgService.getUserDetailsForOrganization(Mockito.eq(token), Mockito.any())).thenReturn(orgResp);

		EntitlementsResponse entResp = new EntitlementsResponse();
		EntitlementDetail detail = new EntitlementDetail();
		detail.setEntitlement_value("ent1");
		detail.setEndpoint("endpoint");
		detail.setDescription("desc");
		detail.setStatus("active");
		entResp.setEntitlementdetails(List.of(detail));
		lenient().when(entitlementService.loadEntitlements("user1", token, clientId)).thenReturn(entResp);

		lenient().when(securityManagerEntitlementRepository.findByIsSecuritymanager(1)).thenReturn(List.of());
		lenient().when(saviyntService.getDisplayNamesWithClientId(Mockito.any(), Mockito.eq(clientId))).thenReturn(List.of("ent1"));

		UserEntitlementsDTO updated = new UserEntitlementsDTO();
		updated.setEmail("user@example.com");
		lenient().when(entitlementService.updateUser(Mockito.any(), Mockito.eq(token))).thenReturn(updated);

		List<UserOrganizationDetailsDTO> listDto= new ArrayList<>();
		UserOrganizationDetailsDTO dto=new UserOrganizationDetailsDTO();
		dto.setUsername("user1");
		listDto.add(dto);
		OrganizationUserDetailResponseDTO orguserRespose = new OrganizationUserDetailResponseDTO();
		orguserRespose.setOrganizationname(clientId);
		orguserRespose.setUsers(listDto);
		lenient().when(orgService.getUserOrganizationDetails(Mockito.eq(token), Mockito.any(), Mockito.eq(clientId))).thenReturn(orguserRespose);

		UpdateOrganizationResponse updateOrgResp = new UpdateOrganizationResponse();
		updateOrgResp.setStatusCode(200);
		lenient(). when(orgService.updateUserToOrganization(Mockito.any(), Mockito.eq(token))).thenReturn(updateOrgResp);

		BaseResponse pgResponseBody = new BaseResponse();
		List<ClientConfigError> errors =new ArrayList<>();
		ClientConfigError err = new ClientConfigError();
		err.setEmailId("user@example.com");
		err.setErrorCode("500");
		err.setErrorMessage("Internal Server Error");
		errors.add(err);
		pgResponseBody.setErrors(errors);
		ResponseEntity<Object> mockResponse = ResponseEntity
				.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body(pgResponseBody);

		lenient(). when(removeClientService.deleteClientDetails(Mockito.any(), Mockito.any(), Mockito.eq(clientId)))
		.thenReturn(mockResponse);

		// Act
		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, emails);

		// Assert
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		assertNotNull(response.getBody());

	}
	@Test
	void deleteClientConfiguration_securityManagerFeignException_addsSAV016Error() throws Exception {
		// Arrange
		when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		when(userService.getAccessToken()).thenReturn(token);
		when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		when(userService.getUserProfile(any(), any())).thenThrow(mock(FeignException.class));
		// Act
		ResponseEntity<Object> result = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, emails);
		assertTrue(result.getBody().toString().contains("SAV016"));
	}

	@Test
	void deleteClientConfiguration_getAccounts_returnsInternalServerError() throws Exception {
		// Arrange
		lenient().when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		lenient().when(userService.getAccessToken()).thenReturn(token);
		lenient().when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		User user = new User();
		user.setUsername("user1");
		user.setEmail("user@example.com");
		lenient().	when(userService.getUserProfile("user@example.com", token)).thenReturn(user);

		// Remove everyone from validMailMap to trigger the branch
		try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class)) {
			// simulate FeignException on getAccounts 

			AccountDTO account = new AccountDTO();
			account.setStatus("1");
			account.setAccountname("acc123");

			FeignException fe = mock(FeignException.class);
			lenient().	when(fe.status()).thenReturn(412);
			lenient().when(accountService.getAccounts(any(), any())).thenThrow(fe);

			// Act
			ResponseEntity<Object> result = service.getDeleteClientConfigurationDetails(
					"sessionToken", header, clientId, orgName, emails);
			assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
		}
	}

	@Test
	void deleteClientConfiguration_getAccountsFeign_returnsInternalServerError() throws Exception {
		// Arrange
		lenient().when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		lenient().when(userService.getAccessToken()).thenReturn(token);
		lenient().when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		User user = new User();
		user.setUsername("user1");
		user.setEmail("user@example.com");
		lenient().	when(userService.getUserProfile("user@example.com", token)).thenReturn(user);

		// Remove everyone from validMailMap to trigger the branch
		try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class)) {
			// simulate FeignException on getAccounts 

			AccountDTO account = new AccountDTO();
			account.setStatus("1");
			account.setAccountname("acc123");

			FeignException fe = mock(FeignException.class);
			lenient().	when(fe.status()).thenReturn(500);
			lenient().when(accountService.getAccounts(any(), any())).thenThrow(fe);

			// Act
			ResponseEntity<Object> result = service.getDeleteClientConfigurationDetails(
					"sessionToken", header, clientId, orgName, emails);
			assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
		}
	}

	@Test
	void deleteClientConfiguration_updateUserToOrganization_returnsInternalServerError()throws Exception {
		// Arrange
		when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		when(userService.getAccessToken()).thenReturn(token);
		when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		User user = new User();
		user.setUsername("user1");
		user.setEmail("user@example.com");
		when(userService.getUserProfile("user@example.com", token)).thenReturn(user);

		AccountDTO account = new AccountDTO();
		account.setStatus("1");
		account.setAccountname("acc123");
		when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));

		OrganizationDetailsDTO orgDetail = new OrganizationDetailsDTO();
		orgDetail.setOrganizationname(clientId);
		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setUsername("user1");
		orgResp.setOrganizations(List.of(orgDetail));
		when(orgService.getUserDetailsForOrganization(Mockito.eq(token), Mockito.any())).thenReturn(orgResp);

		EntitlementsResponse entResp = new EntitlementsResponse();
		EntitlementDetail detail = new EntitlementDetail();
		detail.setEntitlement_value("ent1");
		detail.setEndpoint("endpoint");
		detail.setDescription("desc");
		detail.setStatus("active");
		entResp.setEntitlementdetails(List.of(detail));
		lenient().when(entitlementService.loadEntitlements("user1", token, clientId)).thenReturn(entResp);

		lenient().when(securityManagerEntitlementRepository.findByIsSecuritymanager(1)).thenReturn(List.of());
		lenient().when(saviyntService.getDisplayNamesWithClientId(Mockito.any(), Mockito.eq(clientId))).thenReturn(List.of("ent1"));

		UserEntitlementsDTO updated = new UserEntitlementsDTO();
		updated.setEmail("user@example.com");
		lenient().when(entitlementService.updateUser(Mockito.any(), Mockito.eq(token))).thenReturn(updated);

		List<UserOrganizationDetailsDTO> listDto= new ArrayList<>();
		UserOrganizationDetailsDTO dto=new UserOrganizationDetailsDTO();
		dto.setUsername("user1");
		listDto.add(dto);
		OrganizationUserDetailResponseDTO orguserRespose = new OrganizationUserDetailResponseDTO();
		orguserRespose.setOrganizationname(clientId);
		orguserRespose.setUsers(listDto);
		lenient().when(orgService.getUserOrganizationDetails(Mockito.eq(token), Mockito.any(), Mockito.eq(clientId))).thenReturn(orguserRespose);

		// Remove everyone from validMailMap to trigger the branch
		try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class)) {
			// simulate FeignException on updateUserToOrganization 

			UpdateOrganizationResponse resp = UpdateOrganizationResponse.builder().msg("ok").errorCode("0").statusCode(200).build();
			FeignException fe = mock(FeignException.class);
			when(fe.status()).thenReturn(500);
			//
			when(orgService.updateUserToOrganization(any(), any())).thenThrow(fe);
			// Act
			ResponseEntity<Object> result = service.getDeleteClientConfigurationDetails(
					"sessionToken", header, clientId, orgName, emails);
			assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
		}
	}


	@Test
	void deleteClientConfiguration_getUserDetailsForOrganization_returnsSuccessfull() throws Exception {
		// Arrange
		lenient().when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		lenient().when(userService.getAccessToken()).thenReturn(token);
		lenient().when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		User user = new User();
		user.setUsername("user1");
		user.setEmail("user@example.com");
		lenient().	when(userService.getUserProfile("user@example.com", token)).thenReturn(user);

		AccountDTO account = new AccountDTO();
		account.setStatus("1");
		account.setAccountname("acc123");
		lenient().when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));


		OrganizationDetailsDTO orgDetail = new OrganizationDetailsDTO();
		orgDetail.setOrganizationname(clientId);
		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setUsername("user1");
		orgResp.setOrganizations(List.of(orgDetail));

		ResponseEntity<Object> result = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, emails);
		assertEquals(HttpStatus.OK, result.getStatusCode());


	}
	@Test
	void deleteClientConfiguration_userOrgDoesNotContainClientId_triggersSecurityManagerError() throws Exception {
		// Arrange
		String clientId = "CLIENT123";
		String orgName = "ORG001";
		String token = "mockedToken";
		String header = "mockedHeader";
		String email = "user@example.com";

		// Mock header and token validation
		lenient().when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		lenient().when(userService.getAccessToken()).thenReturn(token);
		lenient().when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		// Mock user profile
		User user = new User();
		user.setUsername("user1");
		user.setEmail(email);
		lenient().when(userService.getUserProfile(email, token)).thenReturn(user);

		// Mock account
		AccountDTO account = new AccountDTO();
		account.setStatus("1");
		account.setAccountname("acc123");
		lenient().when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));

		// Organization name that does NOT contain clientId
		OrganizationDetailsDTO orgDetail = new OrganizationDetailsDTO();
		orgDetail.setOrganizationname("UNRELATED_ORG");

		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setUsername("user1");
		orgResp.setOrganizations(List.of(orgDetail));

		// Mock orgService to return orgResp
		lenient().when(orgService.getUserDetailsForOrganization(eq(token), any())).thenReturn(orgResp);

		// Act
		ResponseEntity<Object> result = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, List.of(email));

		// Assert
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
		BaseResponse responseBody = (BaseResponse) result.getBody();
		assertNotNull(responseBody);
	}

	@Test
	void deleteClientConfiguration_userOrgListDoesNotContainClientId_triggersSecurityManagerErrorBlock() throws Exception {
		// Arrange
		String clientId = "CLIENT123";
		String orgName = "ORG001";
		String token = "mockedToken";
		String header = "mockedHeader";
		String email = "user@example.com";

		// Mock header and token validation
		lenient().when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		lenient().when(userService.getAccessToken()).thenReturn(token);
		lenient().when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		// Mock user profile
		User user = new User();
		user.setUsername("user1");
		user.setEmail(email);
		lenient().when(userService.getUserProfile(email, token)).thenReturn(user);

		// Mock account
		AccountDTO account = new AccountDTO();
		account.setStatus("1");
		account.setAccountname("acc123");
		lenient().when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));

		// Organization name that does NOT contain clientId
		OrganizationDetailsDTO unrelatedOrg = new OrganizationDetailsDTO();
		unrelatedOrg.setOrganizationname("UNRELATED_ORG");

		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setUsername("user1");
		orgResp.setOrganizations(List.of(unrelatedOrg));

		// Mock orgService to return orgResp
		lenient().when(orgService.getUserDetailsForOrganization(eq(token), any())).thenReturn(orgResp);

		// Act
		ResponseEntity<Object> result = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, List.of(email));

		// Assert
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
		BaseResponse responseBody = (BaseResponse) result.getBody();
		assertNotNull(responseBody);
	}

	@Test
	void deleteClientConfiguration_trueDoesNotContainClientId_triggersSecurityManagerErrorBlock() throws Exception {
		// Arrange
		String clientId = "CLIENT123";
		String orgName = "ORG001";
		String token = "mockedToken";
		String header = "mockedHeader";
		String email = "user@example.com";

		// Mock header and token validation
		lenient().when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		lenient().when(userService.getAccessToken()).thenReturn(token);
		lenient().when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		// Mock user profile
		User user = new User();
		user.setUsername("user1");
		user.setEmail(email);
		lenient().when(userService.getUserProfile(email, token)).thenReturn(user);

		// Mock account
		AccountDTO account = new AccountDTO();
		account.setStatus("1");
		account.setAccountname("acc123");
		lenient().when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));

		// Organization name that does NOT contain clientId
		OrganizationDetailsDTO unrelatedOrg = new OrganizationDetailsDTO();
		unrelatedOrg.setOrganizationname("ORG001");

		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setUsername("user1");
		orgResp.setOrganizations(List.of(unrelatedOrg));

		// Mock orgService to return orgResp
		lenient().when(orgService.getUserDetailsForOrganization(eq(token), any())).thenReturn(orgResp);

		// Act
		ResponseEntity<Object> result = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, List.of(email));

		// Assert
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
		BaseResponse responseBody = (BaseResponse) result.getBody();
		assertNotNull(responseBody);
	}
	
	@Test
	void testValidMailMapEntryRemovedWhenOrgExistsContainsKey() throws Exception {
		// Arrange
		String clientId = "CLIENT123";
		String orgName = "ORG001";
		String token = "mockedToken";
		String header = "mockedHeader";
		String email = "user@example.com";

		// Mock header and token validation
		lenient().when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		lenient().when(userService.getAccessToken()).thenReturn(token);
		lenient().when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		// Mock user profile
		User user = new User();
		user.setUsername("user1");
		user.setEmail(email);
		lenient().when(userService.getUserProfile(email, token)).thenReturn(user);

		// Mock account
		AccountDTO account = new AccountDTO();
		account.setStatus("1");
		account.setAccountname("acc123");
		lenient().when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));

		// Organization name that does NOT contain clientId
		OrganizationDetailsDTO unrelatedOrg = new OrganizationDetailsDTO();
		unrelatedOrg.setOrganizationname("unrelated");

		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setUsername("user1");
		orgResp.setOrganizations(List.of(unrelatedOrg));

		// Mock orgService to return orgResp
		lenient().when(orgService.getUserDetailsForOrganization(eq(token), any())).thenReturn(orgResp);

		  Map<String, String> validMailMap = new HashMap<>();
		    validMailMap.put("user1@example.com", "User One");
		    validMailMap.put("user2@example.com", "User Two");

		    List<String> orgExist = new ArrayList<>();
		    orgExist.add("user1@example.com"); // This should trigger removal

		// Act
		    
		    try (MockedStatic<InfoTypeLogEventHelper> mockedLog = mockStatic(InfoTypeLogEventHelper.class)) {
		        // Act (same loop as above)
		    	ResponseEntity<Object> result = service.getDeleteClientConfigurationDetails(
						"sessionToken", header, clientId, orgName, List.of(email));

		        // Verify log was called with correct message
		    	// Act: perform the logging inside the mock block
		        Iterator<Map.Entry<String, String>> itr1 = validMailMap.entrySet().iterator();
		        while (itr1.hasNext()) {
		            Map.Entry<String, String> entry = itr1.next();
		            String mailId = entry.getKey();
		            if (orgExist.contains(mailId)) {
		                InfoTypeLogEventHelper.logInfoEvent("com.alight.cc.startanywhere.service.impl.DeleteClientConfigurationServiceImpl",
		                    "Deletion skipped: Security Manager is not associated with the specified organization in Saviynt. No entitlement or organization removal necessary:" + mailId);
		                itr1.remove();
		            }
		        }
		        
		        // Assert map mutation
		        assertFalse(validMailMap.containsKey("user1@example.com"));
		        assertTrue(validMailMap.containsKey("user2@example.com"));

		        // Verify exact log call
		        mockedLog.verify(() -> InfoTypeLogEventHelper.logInfoEvent(
		            "com.alight.cc.startanywhere.service.impl.DeleteClientConfigurationServiceImpl",
		            "Deletion skipped: Security Manager is not associated with the specified organization in Saviynt. No entitlement or organization removal necessary:user1@example.com"
		        ));
		  
	         // Assert
	    		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
	    		BaseResponse responseBody = (BaseResponse) result.getBody();
	    		assertNotNull(responseBody);
		    }

		

		
	}

	@Test
	void deleteClientConfiguration_getUserDetailsForOrganizationFeign_returnsInternalServerError() throws Exception {
		// Arrange
		lenient().when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		lenient().when(userService.getAccessToken()).thenReturn(token);
		lenient().when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		User user = new User();
		user.setUsername("user1");
		user.setEmail("user@example.com");
		lenient().	when(userService.getUserProfile("user@example.com", token)).thenReturn(user);

		AccountDTO account = new AccountDTO();
		account.setStatus("1");
		account.setAccountname("acc123");
		lenient().when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));

		// Remove everyone from validMailMap to trigger the branch
		try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class)) {
			// simulate FeignException on getUserDetailsForOrganization 

			OrganizationDetailsDTO orgDetail = new OrganizationDetailsDTO();
			orgDetail.setOrganizationname(clientId);
			UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
			orgResp.setUsername("user1");
			orgResp.setOrganizations(List.of(orgDetail));

			FeignException fe = mock(FeignException.class);
			lenient().	when(fe.status()).thenReturn(500);
			lenient().when(orgService.getUserDetailsForOrganization(any(), any())).thenThrow(fe);

			// Act
			ResponseEntity<Object> result = service.getDeleteClientConfigurationDetails(
					"sessionToken", header, clientId, orgName, emails);
			assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
		}
	}
	@Test
	void deleteClientConfiguration_getUserOrganizationDetails_returnsInternalServerError() throws Exception {
		// Arrange
		lenient().when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		lenient().when(userService.getAccessToken()).thenReturn(token);
		lenient().when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		User user = new User();
		user.setUsername("user1");
		user.setEmail("user@example.com");
		lenient().	when(userService.getUserProfile("user@example.com", token)).thenReturn(user);

		AccountDTO account = new AccountDTO();
		account.setStatus("1");
		account.setAccountname("acc123");
		lenient().when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));

		OrganizationDetailsDTO orgDetail = new OrganizationDetailsDTO();
		orgDetail.setOrganizationname(clientId);
		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setUsername("user1");
		orgResp.setOrganizations(List.of(orgDetail));
		lenient().when(orgService.getUserDetailsForOrganization(Mockito.eq(token), Mockito.any())).thenReturn(orgResp);

		EntitlementsResponse entResp = new EntitlementsResponse();
		EntitlementDetail detail = new EntitlementDetail();
		detail.setEntitlement_value("ent1");
		detail.setEndpoint("endpoint");
		detail.setDescription("desc");
		detail.setStatus("active");
		entResp.setEntitlementdetails(List.of(detail));
		lenient().when(entitlementService.loadEntitlements("user1", token, clientId)).thenReturn(entResp);

		lenient().when(securityManagerEntitlementRepository.findByIsSecuritymanager(1)).thenReturn(List.of());
		lenient().when(saviyntService.getDisplayNamesWithClientId(Mockito.any(), Mockito.eq(clientId))).thenReturn(List.of("ent1"));

		UserEntitlementsDTO updated = new UserEntitlementsDTO();
		updated.setEmail("user@example.com");
		lenient().when(entitlementService.updateUser(Mockito.any(), Mockito.eq(token))).thenReturn(updated);

		// Remove everyone from validMailMap to trigger the branch
		try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class)) {
			// simulate FeignException on getUserOrganizationDetails 

			List<UserOrganizationDetailsDTO> listDto= new ArrayList<>();
			UserOrganizationDetailsDTO dto=new UserOrganizationDetailsDTO();
			dto.setUsername("user1");
			listDto.add(dto);
			OrganizationUserDetailResponseDTO orguserRespose = new OrganizationUserDetailResponseDTO();
			orguserRespose.setOrganizationname(clientId);
			orguserRespose.setUsers(listDto);

			FeignException fe = mock(FeignException.class);
			lenient().	when(fe.status()).thenReturn(500);
			lenient().when(orgService.getUserOrganizationDetails(any(), any(), any())).thenThrow(fe);
			// Act
			ResponseEntity<Object> result = service.getDeleteClientConfigurationDetails(
					"sessionToken", header, clientId, orgName, emails);
			assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
		}
	}
	@Test
	void deleteClientConfiguration_getUserOrganizationDetailsFeign_returnsInternalServerError() throws Exception {
		// Arrange
		lenient().when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		lenient().when(userService.getAccessToken()).thenReturn(token);
		lenient().when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		User user = new User();
		user.setUsername("user1");
		user.setEmail("user@example.com");
		lenient().	when(userService.getUserProfile("user@example.com", token)).thenReturn(user);

		AccountDTO account = new AccountDTO();
		account.setStatus("1");
		account.setAccountname("acc123");
		lenient().when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));

		OrganizationDetailsDTO orgDetail = new OrganizationDetailsDTO();
		orgDetail.setOrganizationname(clientId);
		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setUsername("user1");
		orgResp.setOrganizations(List.of(orgDetail));
		lenient().when(orgService.getUserDetailsForOrganization(Mockito.eq(token), Mockito.any())).thenReturn(orgResp);

		EntitlementsResponse entResp = new EntitlementsResponse();
		EntitlementDetail detail = new EntitlementDetail();
		detail.setEntitlement_value("ent1");
		detail.setEndpoint("endpoint");
		detail.setDescription("desc");
		detail.setStatus("active");
		entResp.setEntitlementdetails(List.of(detail));
		lenient().when(entitlementService.loadEntitlements("user1", token, clientId)).thenReturn(entResp);

		lenient().when(securityManagerEntitlementRepository.findByIsSecuritymanager(1)).thenReturn(List.of());
		lenient().when(saviyntService.getDisplayNamesWithClientId(Mockito.any(), Mockito.eq(clientId))).thenReturn(List.of("ent1"));

		UserEntitlementsDTO updated = new UserEntitlementsDTO();
		updated.setEmail("user@example.com");
		lenient().when(entitlementService.updateUser(Mockito.any(), Mockito.eq(token))).thenReturn(updated);

		// Remove everyone from validMailMap to trigger the branch
		try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class)) {
			// simulate FeignException on getUserOrganizationDetails 

			List<UserOrganizationDetailsDTO> listDto= new ArrayList<>();
			UserOrganizationDetailsDTO dto=new UserOrganizationDetailsDTO();
			dto.setUsername("user1");
			listDto.add(dto);
			OrganizationUserDetailResponseDTO orguserRespose = new OrganizationUserDetailResponseDTO();
			orguserRespose.setOrganizationname(clientId);
			orguserRespose.setUsers(listDto);

			FeignException fe = mock(FeignException.class);
			lenient().	when(fe.status()).thenReturn(412);
			lenient().when(orgService.getUserOrganizationDetails(any(), any(), any())).thenThrow(fe);

			// Act
			ResponseEntity<Object> result = service.getDeleteClientConfigurationDetails(
					"sessionToken", header, clientId, orgName, emails);
			assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
		}
	}
	
	@Test
	void deleteClientConfiguration_allRequestsFailed_Remove_OrgFeign_returnsInternalServerError() throws Exception {
		// Arrange
		when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		when(userService.getAccessToken()).thenReturn(token);
		when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		User user = new User();
		user.setUsername("user1");
		user.setEmail("user@example.com");
		when(userService.getUserProfile("user@example.com", token)).thenReturn(user);

		AccountDTO account = new AccountDTO();
		account.setStatus("1");
		account.setAccountname("acc123");
		when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));

		OrganizationDetailsDTO orgDetail = new OrganizationDetailsDTO();
		orgDetail.setOrganizationname(clientId);
		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setUsername("user1");
		orgResp.setOrganizations(List.of(orgDetail));
		when(orgService.getUserDetailsForOrganization(Mockito.eq(token), Mockito.any())).thenReturn(orgResp);

		EntitlementsResponse entResp = new EntitlementsResponse();
		EntitlementDetail detail = new EntitlementDetail();
		detail.setEntitlement_value("ent1");
		detail.setEndpoint("endpoint");
		detail.setDescription("desc");
		detail.setStatus("active");
		entResp.setEntitlementdetails(List.of(detail));
		lenient().when(entitlementService.loadEntitlements("user1", token, clientId)).thenReturn(entResp);

		lenient().when(securityManagerEntitlementRepository.findByIsSecuritymanager(1)).thenReturn(List.of());
		lenient().when(saviyntService.getDisplayNamesWithClientId(Mockito.any(), Mockito.eq(clientId))).thenReturn(List.of("ent1"));

		UserEntitlementsDTO updated = new UserEntitlementsDTO();
		updated.setEmail("user@example.com");
		lenient().when(entitlementService.updateUser(Mockito.any(), Mockito.eq(token))).thenReturn(updated);

		List<UserOrganizationDetailsDTO> listDto= new ArrayList<>();
		UserOrganizationDetailsDTO dto=new UserOrganizationDetailsDTO();
		dto.setUsername("user1");
		listDto.add(dto);
		OrganizationUserDetailResponseDTO orguserRespose = new OrganizationUserDetailResponseDTO();
		orguserRespose.setOrganizationname(clientId);
		orguserRespose.setUsers(listDto);
		lenient().when(orgService.getUserOrganizationDetails(Mockito.eq(token), Mockito.any(), Mockito.eq(clientId))).thenReturn(orguserRespose);


		// Remove everyone from validMailMap to trigger the branch
		try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class)) {
			// simulate FeignException on updateOrgUser to cause removals from validMailMap
			UpdateOrganizationResponse resp = UpdateOrganizationResponse.builder().msg("ok").errorCode("0").statusCode(200).build();
			FeignException fe = mock(FeignException.class);
			when(fe.status()).thenReturn(412);

			when(orgService.updateUserToOrganization(any(), any())).thenThrow(fe);
			// Act
			ResponseEntity<Object> result = service.getDeleteClientConfigurationDetails(
					"sessionToken", header, clientId, orgName, emails);
			assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
		}
	}
	@Test
	void deleteClientConfiguration_Remove_entitlemetFeign_returnsInternalServerError() throws Exception {
		// Arrange
		when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		when(userService.getAccessToken()).thenReturn(token);
		when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		User user = new User();
		user.setUsername("user1");
		user.setEmail("user@example.com");
		when(userService.getUserProfile("user@example.com", token)).thenReturn(user);

		AccountDTO account = new AccountDTO();
		account.setStatus("1");
		account.setAccountname("acc123");
		when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));

		OrganizationDetailsDTO orgDetail = new OrganizationDetailsDTO();
		orgDetail.setOrganizationname(clientId);
		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setUsername("user1");
		orgResp.setOrganizations(List.of(orgDetail));
		when(orgService.getUserDetailsForOrganization(Mockito.eq(token), Mockito.any())).thenReturn(orgResp);

		EntitlementsResponse entResp = new EntitlementsResponse();
		EntitlementDetail detail = new EntitlementDetail();
		detail.setEntitlement_value("ent1");
		detail.setEndpoint("endpoint");
		detail.setDescription("desc");
		detail.setStatus("active");
		entResp.setEntitlementdetails(List.of(detail));
		lenient().when(entitlementService.loadEntitlements("user1", token, clientId)).thenReturn(entResp);

		lenient().when(securityManagerEntitlementRepository.findByIsSecuritymanager(1)).thenReturn(List.of());
		lenient().when(saviyntService.getDisplayNamesWithClientId(Mockito.any(), Mockito.eq(clientId))).thenReturn(List.of("ent1"));

		UserEntitlementsDTO updated = new UserEntitlementsDTO();
		updated.setEmail("user@example.com");
		lenient().when(entitlementService.updateUser(Mockito.any(), Mockito.eq(token))).thenReturn(updated);

		List<UserOrganizationDetailsDTO> listDto= new ArrayList<>();
		UserOrganizationDetailsDTO dto=new UserOrganizationDetailsDTO();
		dto.setUsername("user1");
		listDto.add(dto);
		OrganizationUserDetailResponseDTO orguserRespose = new OrganizationUserDetailResponseDTO();
		orguserRespose.setOrganizationname(clientId);
		orguserRespose.setUsers(listDto);
		lenient().when(orgService.getUserOrganizationDetails(Mockito.eq(token), Mockito.any(), Mockito.eq(clientId))).thenReturn(orguserRespose);


		// Remove everyone from validMailMap to trigger the branch
		try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class)) {
			// simulate FeignException on updateUser to cause removals from validMailMap

			FeignException fe = mock(FeignException.class);
			when(fe.status()).thenReturn(412);

			when(entitlementService.updateUser(any(), any())).thenThrow(fe);
			// Act
			ResponseEntity<Object> result = service.getDeleteClientConfigurationDetails(
					"sessionToken", header, clientId, orgName, emails);
			assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
		}
	}

	@Test
	void deleteClientConfiguration_Missing_entitlemet_returnsInternalServerError() throws Exception {
		// Arrange
		when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		when(userService.getAccessToken()).thenReturn(token);
		when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		User user = new User();
		user.setUsername("user1");
		user.setEmail("user@example.com");
		when(userService.getUserProfile("user@example.com", token)).thenReturn(user);

		AccountDTO account = new AccountDTO();
		account.setStatus("1");
		account.setAccountname("acc123");
		when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));

		OrganizationDetailsDTO orgDetail = new OrganizationDetailsDTO();
		orgDetail.setOrganizationname(clientId);
		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setUsername("user1");
		orgResp.setOrganizations(List.of(orgDetail));
		when(orgService.getUserDetailsForOrganization(Mockito.eq(token), Mockito.any())).thenReturn(orgResp);

		// Create a valid EntitlementDetail
		EntitlementDetail detail = new EntitlementDetail();
		detail.setEntitlement_value("ent1"); // Only one available
		detail.setEndpoint("endpoint");
		detail.setDescription("desc");
		detail.setStatus("active");

		EntitlementsResponse entResp = new EntitlementsResponse();
		entResp.setEntitlementdetails(List.of(detail));
		when(entitlementService.loadEntitlements("user1", token, clientId)).thenReturn(entResp);

		lenient().when(entitlementService.loadEntitlements("user1", token, clientId)).thenReturn(entResp);

		lenient().when(securityManagerEntitlementRepository.findByIsSecuritymanager(1)).thenReturn(List.of());
		// Mock expected display names (includes one missing entitlement)
		when(saviyntService.getDisplayNamesWithClientId(any(), eq(clientId)))
		.thenReturn(List.of("ent1", "ent2")); // "ent2" will be missing


		UserEntitlementsDTO updated = new UserEntitlementsDTO();
		updated.setEmail("user@example.com");
		lenient().when(entitlementService.updateUser(Mockito.any(), Mockito.eq(token))).thenReturn(updated);

		List<UserOrganizationDetailsDTO> listDto= new ArrayList<>();
		UserOrganizationDetailsDTO dto=new UserOrganizationDetailsDTO();
		dto.setUsername("user1");
		listDto.add(dto);
		OrganizationUserDetailResponseDTO orguserRespose = new OrganizationUserDetailResponseDTO();
		orguserRespose.setOrganizationname(clientId);
		orguserRespose.setUsers(listDto);
		lenient().when(orgService.getUserOrganizationDetails(Mockito.eq(token), Mockito.any(), Mockito.eq(clientId))).thenReturn(orguserRespose);

		ResponseEntity<Object> result = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, emails);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());

	}

	@Test
	void deleteClientConfiguration_Missing_entitlementResponse_returnsInternalServerError() throws Exception {
		// Arrange
		when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		when(userService.getAccessToken()).thenReturn(token);
		when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		User user = new User();
		user.setUsername("user1");
		user.setEmail("user@example.com");
		when(userService.getUserProfile("user@example.com", token)).thenReturn(user);

		AccountDTO account = new AccountDTO();
		account.setStatus("1");
		account.setAccountname("acc123");
		when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));

		OrganizationDetailsDTO orgDetail = new OrganizationDetailsDTO();
		orgDetail.setOrganizationname(clientId);
		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setUsername("user1");
		orgResp.setOrganizations(List.of(orgDetail));
		when(orgService.getUserDetailsForOrganization(Mockito.eq(token), Mockito.any())).thenReturn(orgResp);

		// Create a valid EntitlementDetail
		// 2. Mock entitlement response with only "ent1"
		EntitlementDetail detail = new EntitlementDetail();
		detail.setEntitlement_value("ent1"); // Only one available
		detail.setEndpoint("endpoint");
		detail.setDescription("desc");
		detail.setStatus("active");

		EntitlementsResponse entResp = new EntitlementsResponse();
		entResp.setEntitlementdetails(List.of(detail));
		when(entitlementService.loadEntitlements("user1", token, clientId)).thenReturn(entResp);

		lenient().when(entitlementService.loadEntitlements("user1", token, clientId)).thenReturn(entResp);

		lenient().when(securityManagerEntitlementRepository.findByIsSecuritymanager(1)).thenReturn(List.of());
		// Mock expected display names (includes one missing entitlement)
		when(saviyntService.getDisplayNamesWithClientId(any(), eq(clientId)))
		.thenReturn(List.of("ent1", "ent2")); // "ent2" will be missing


		UserEntitlementsDTO updated = new UserEntitlementsDTO();
		updated.setEmail("user@example.com");
		lenient().when(entitlementService.updateUser(Mockito.any(), Mockito.eq(token))).thenReturn(updated);

		List<UserOrganizationDetailsDTO> listDto= new ArrayList<>();
		UserOrganizationDetailsDTO dto=new UserOrganizationDetailsDTO();
		dto.setUsername("user1");
		listDto.add(dto);
		OrganizationUserDetailResponseDTO orguserRespose = new OrganizationUserDetailResponseDTO();
		orguserRespose.setOrganizationname(clientId);
		orguserRespose.setUsers(listDto);
		lenient().when(orgService.getUserOrganizationDetails(Mockito.eq(token), Mockito.any(), Mockito.eq(clientId))).thenReturn(orguserRespose);

		ResponseEntity<Object> result = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, emails);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());

	}
	
	@Test
	void deleteClientConfiguration_missingEntitlementTriggersFailureResponse() throws Exception {
	    // Arrange
	    String clientId = "CLIENT123";
	    String orgName = "ORG001";
	    String token = "mockedToken";
	    String header = "mockedHeader";
	    String email = "user@example.com";

	    when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
	    when(userService.getAccessToken()).thenReturn(token);
	    when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

	    // Mock user profile
	    User user = new User();
	    user.setUsername("user1");
	    user.setEmail(email);
	    when(userService.getUserProfile(email, token)).thenReturn(user);

	    // Mock account
	    AccountDTO account = new AccountDTO();
	    account.setStatus("1");
	    account.setAccountname("acc123");
	    when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));

	    // Mock organization details with clientId to ensure containsClientId == true
	    OrganizationDetailsDTO orgDetail = new OrganizationDetailsDTO();
	    orgDetail.setOrganizationname(clientId);
	    UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
	    orgResp.setUsername("user1");
	    orgResp.setOrganizations(List.of(orgDetail));
	    when(orgService.getUserDetailsForOrganization(eq(token), any())).thenReturn(orgResp);

	    // Mock entitlement response with only "ent1"
	    EntitlementDetail detail = new EntitlementDetail();
	    detail.setEntitlement_value("ent1");
	    detail.setEndpoint("endpoint");
	    detail.setDescription("desc");
	    detail.setStatus("active");

	    EntitlementsResponse entResp = new EntitlementsResponse();
	    entResp.setEntitlementdetails(List.of(detail));
	    when(entitlementService.loadEntitlements("user1", token, clientId)).thenReturn(entResp);

	    // Mock expected display names to include one missing ("ent2")
	    when(securityManagerEntitlementRepository.findByIsSecuritymanager(1)).thenReturn(List.of());
	    when(saviyntService.getDisplayNamesWithClientId(any(), eq(clientId)))
	        .thenReturn(List.of("ent1", "ent2")); // "ent2" is missing

	    // Mock updateUser
	    UserEntitlementsDTO updated = new UserEntitlementsDTO();
	    updated.setEmail(email);
	   lenient(). when(entitlementService.updateUser(any(), eq(token))).thenReturn(updated);

	    // Mock organization user details
	    UserOrganizationDetailsDTO dto = new UserOrganizationDetailsDTO();
	    dto.setUsername("user1");
	    OrganizationUserDetailResponseDTO orgUserResponse = new OrganizationUserDetailResponseDTO();
	    orgUserResponse.setOrganizationname(clientId);
	    orgUserResponse.setUsers(List.of(dto));
	    lenient().when(orgService.getUserOrganizationDetails(eq(token), any(), eq(clientId))).thenReturn(orgUserResponse);

	    // Act
	    ResponseEntity<Object> result = service.getDeleteClientConfigurationDetails(
	        "sessionToken", header, clientId, orgName, List.of(email));

	    // Assert
	    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
	    BaseResponse responseBody = (BaseResponse) result.getBody();
	    assertNotNull(responseBody);
	    assertEquals("500", responseBody.getResponseCode());
	    //assertTrue(responseBody.getResponseMessage().contains("ent2"));
	}
	
	@Test
	void deleteClientConfiguration_missingEntitlementTriggersBuildResponse() throws Exception {
	    // Arrange
	    String clientId = "CLIENT123";
	    String orgName = "ORG001";
	    String token = "mockedToken";
	    String header = "mockedHeader";
	    String email = "user@example.com";

	    when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
	    when(userService.getAccessToken()).thenReturn(token);
	    when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

	    User user = new User();
	    user.setUsername("user1");
	    user.setEmail(email);
	    when(userService.getUserProfile(email, token)).thenReturn(user);

	    AccountDTO account = new AccountDTO();
	    account.setStatus("1");
	    account.setAccountname("acc123");
	    when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));

	    // Ensure containsClientId == true
	    OrganizationDetailsDTO orgDetail = new OrganizationDetailsDTO();
	    orgDetail.setOrganizationname(clientId);
	    UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
	    orgResp.setUsername("user1");
	    orgResp.setOrganizations(List.of(orgDetail));
	    when(orgService.getUserDetailsForOrganization(eq(token), any())).thenReturn(orgResp);

	    // Entitlement response contains only "APP_ent1"
	    EntitlementDetail detail = new EntitlementDetail();
	    detail.setEntitlement_value("APP_ent1");
	    detail.setEndpoint("endpoint");
	    detail.setDescription("desc");
	    detail.setStatus("active");

	    EntitlementsResponse entResp = new EntitlementsResponse();
	    entResp.setEntitlementdetails(List.of(detail));
	    when(entitlementService.loadEntitlements("user1", token, clientId)).thenReturn(entResp);

	    // Expected display names include one missing: "PREFIX_ent2"
	    when(securityManagerEntitlementRepository.findByIsSecuritymanager(1)).thenReturn(List.of());
	    when(saviyntService.getDisplayNamesWithClientId(any(), eq(clientId)))
	        .thenReturn(List.of("APP_ent1", "PREFIX_ent2")); // "PREFIX_ent2" is missing

	    // Mock bean replacements
	  //  when(bean.getApplication()).thenReturn("APP_");
	   // when(bean.getPrefix()).thenReturn("PREFIX_");
	    
	    lenient().  when(saviyntConfigurationBean.getPrefix()).thenReturn("PFX_");
		lenient().  when(saviyntConfigurationBean.getApplication()).thenReturn("APP");

	    UserEntitlementsDTO updated = new UserEntitlementsDTO();
	    updated.setEmail(email);
	    when(entitlementService.updateUser(any(), eq(token))).thenReturn(updated);

	    UserOrganizationDetailsDTO dto = new UserOrganizationDetailsDTO();
	    dto.setUsername("user1");
	    OrganizationUserDetailResponseDTO orgUserResponse = new OrganizationUserDetailResponseDTO();
	    orgUserResponse.setOrganizationname(clientId);
	    orgUserResponse.setUsers(List.of(dto));
	    when(orgService.getUserOrganizationDetails(eq(token), any(), eq(clientId))).thenReturn(orgUserResponse);

	    // Act
	    ResponseEntity<Object> result = service.getDeleteClientConfigurationDetails(
	        "sessionToken", header, clientId, orgName, List.of(email));

	    // Assert
	    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
	    BaseResponse responseBody = (BaseResponse) result.getBody();
	    assertNotNull(responseBody);
	}



	@Test
	void deleteClientConfiguration_entitlemetResponse_owner_returnsInternalServerError() throws Exception {
		// Arrange
		when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		when(userService.getAccessToken()).thenReturn(token);
		when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		User user = new User();
		user.setUsername("user1");
		user.setEmail("user@example.com");
		when(userService.getUserProfile("user@example.com", token)).thenReturn(user);

		AccountDTO account = new AccountDTO();
		account.setStatus("1");
		account.setAccountname("acc123");
		when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));

		OrganizationDetailsDTO orgDetail = new OrganizationDetailsDTO();
		orgDetail.setOrganizationname(clientId);
		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setUsername("user1");
		orgResp.setOrganizations(List.of(orgDetail));
		when(orgService.getUserDetailsForOrganization(Mockito.eq(token), Mockito.any())).thenReturn(orgResp);

		EntitlementOwnerResponse ownerRes = new EntitlementOwnerResponse();
		ownerRes.setAID("A1234");
		List<EntitlementOwnerResponse> owners = new ArrayList<>();
		owners.add(ownerRes);
		List<String> ownerList = new ArrayList<>();
		for(EntitlementOwnerResponse owner: owners) {
			String AID=owner.getAID();
			ownerList.add(AID);
		}
		EntitlementsResponse entResp = new EntitlementsResponse();
		EntitlementDetail detail = new EntitlementDetail();
		List<EntitlementDetail> detailsList= new ArrayList<>();
		List<String> entitlementOwnerAIDs = List.of("A1234", "B5678");
		detail.setEntitlement_value("ent1");
		detail.setEndpoint("endpoint");
		detail.setDescription("desc");
		detail.setStatus("active");
		detail.setEntitlementOwner(entitlementOwnerAIDs); // This is the key line
		detailsList.add(detail);
		entResp.setEntitlementdetails(detailsList);

		lenient().when(entitlementService.loadEntitlements("user1", token, clientId)).thenReturn(entResp);

		lenient().when(securityManagerEntitlementRepository.findByIsSecuritymanager(1)).thenReturn(List.of());
		lenient().when(saviyntService.getDisplayNamesWithClientId(Mockito.any(), Mockito.eq(clientId))).thenReturn(List.of("ent1"));

		UserEntitlementsDTO updated = new UserEntitlementsDTO();
		updated.setEmail("user@example.com");
		lenient().when(entitlementService.updateUser(Mockito.any(), Mockito.eq(token))).thenReturn(updated);

		List<UserOrganizationDetailsDTO> listDto= new ArrayList<>();
		UserOrganizationDetailsDTO dto=new UserOrganizationDetailsDTO();
		dto.setUsername("user1");
		listDto.add(dto);
		OrganizationUserDetailResponseDTO orguserRespose = new OrganizationUserDetailResponseDTO();
		orguserRespose.setOrganizationname(clientId);
		orguserRespose.setUsers(listDto);
		lenient().when(orgService.getUserOrganizationDetails(Mockito.eq(token), Mockito.any(), Mockito.eq(clientId))).thenReturn(orguserRespose);

		ResponseEntity<Object> result = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, emails);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());

	}
	@Test
	void deleteClientConfiguration_Remove_entitlemet_returnsInternalServerError() throws Exception {
		// Arrange
		when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		when(userService.getAccessToken()).thenReturn(token);
		when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		User user = new User();
		user.setUsername("user1");
		user.setEmail("user@example.com");
		when(userService.getUserProfile("user@example.com", token)).thenReturn(user);

		AccountDTO account = new AccountDTO();
		account.setStatus("1");
		account.setAccountname("acc123");
		when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));

		OrganizationDetailsDTO orgDetail = new OrganizationDetailsDTO();
		orgDetail.setOrganizationname(clientId);
		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setUsername("user1");
		orgResp.setOrganizations(List.of(orgDetail));
		when(orgService.getUserDetailsForOrganization(Mockito.eq(token), Mockito.any())).thenReturn(orgResp);

		EntitlementsResponse entResp = new EntitlementsResponse();
		EntitlementDetail detail = new EntitlementDetail();
		detail.setEntitlement_value("ent1");
		detail.setEndpoint("endpoint");
		detail.setDescription("desc");
		detail.setStatus("active");
		entResp.setEntitlementdetails(List.of(detail));
		lenient().when(entitlementService.loadEntitlements("user1", token, clientId)).thenReturn(entResp);

		lenient().when(securityManagerEntitlementRepository.findByIsSecuritymanager(1)).thenReturn(List.of());
		lenient().when(saviyntService.getDisplayNamesWithClientId(Mockito.any(), Mockito.eq(clientId))).thenReturn(List.of("ent1"));

		UserEntitlementsDTO updated = new UserEntitlementsDTO();
		updated.setEmail("user@example.com");
		lenient().when(entitlementService.updateUser(Mockito.any(), Mockito.eq(token))).thenReturn(updated);

		List<UserOrganizationDetailsDTO> listDto= new ArrayList<>();
		UserOrganizationDetailsDTO dto=new UserOrganizationDetailsDTO();
		dto.setUsername("user1");
		listDto.add(dto);
		OrganizationUserDetailResponseDTO orguserRespose = new OrganizationUserDetailResponseDTO();
		orguserRespose.setOrganizationname(clientId);
		orguserRespose.setUsers(listDto);
		lenient().when(orgService.getUserOrganizationDetails(Mockito.eq(token), Mockito.any(), Mockito.eq(clientId))).thenReturn(orguserRespose);


		// Remove everyone from validMailMap to trigger the branch
		try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class)) {
			// simulate FeignException on updateUser to cause removals from validMailMap
			
			FeignException fe = mock(FeignException.class);
			when(fe.status()).thenReturn(500);

			when(entitlementService.updateUser(any(), any())).thenThrow(fe);
			// Act
			ResponseEntity<Object> result = service.getDeleteClientConfigurationDetails(
					"sessionToken", header, clientId, orgName, emails);
			assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
		}
	}
	@Test
	void deleteClientConfiguration_entitlementFeignException_returnsInternalServerError() throws Exception {
		// Arrange
		when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		when(userService.getAccessToken()).thenReturn(token);
		when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		User user = new User();
		user.setUsername("user1");
		user.setEmail("user@example.com");
		when(userService.getUserProfile("user@example.com", token)).thenReturn(user);

		AccountDTO account = new AccountDTO();
		account.setStatus("1");
		account.setAccountname("acc123");
		when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));

		OrganizationDetailsDTO orgDetail = new OrganizationDetailsDTO();
		orgDetail.setOrganizationname(clientId);
		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setUsername("user1");
		orgResp.setOrganizations(List.of(orgDetail));
		when(orgService.getUserDetailsForOrganization(Mockito.eq(token), Mockito.any())).thenReturn(orgResp);


		SecurityManagerEntitlementEntity ent = new SecurityManagerEntitlementEntity();
		ent.setDisplayName("group<client>");
		lenient().when(entitlementRepo.findByIsSecuritymanager(1)).thenReturn(List.of(ent));

		FeignException fe = mock(FeignException.class);
		when(entitlementService.loadEntitlements(any(), any(), any())).thenThrow(fe);

		try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class);
				MockedStatic<StartAnywhereUtil> utilMock = mockStatic(StartAnywhereUtil.class);
				MockedStatic<ErrorLogEventHelper> errLogMock = mockStatic(ErrorLogEventHelper.class)) {
			BaseResponse resp = new BaseResponse();
			utilMock.when(() -> StartAnywhereUtil.buildResponse(any(), any(), any(), any(), any(), any(), any(), any())).thenReturn(resp);

			// Act
			ResponseEntity<Object> result = service.getDeleteClientConfigurationDetails(
					"sessionToken", header, clientId, orgName, emails);

			assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
			errLogMock.verify(() -> ErrorLogEventHelper.logErrorEvent(any(), any(), any(), eq(fe), any()), times(1));
		}
	}


	@Test
	void testValidFlow_EmptyValidMapEmail_internalServerError() throws Exception {
		// Arrange
		when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		when(userService.getAccessToken()).thenReturn(token);
		when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		User user = new User();
		user.setUsername("user1");
		user.setEmail("user@example.com");
		when(userService.getUserProfile("user@example.com", token)).thenReturn(user);

			// Act
		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, emails);

		// Assert
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		assertNotNull(response.getBody());

	}

	@Test
	void testValidFlow_pgError_withErrorNull_internalServerError() throws Exception {
		// Arrange
		when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		when(userService.getAccessToken()).thenReturn(token);
		when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		User user = new User();
		user.setUsername("user1");
		user.setEmail("user@example.com");
		when(userService.getUserProfile("user@example.com", token)).thenReturn(user);

		AccountDTO account = new AccountDTO();
		account.setStatus("1");
		account.setAccountname("acc123");
		when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));

		OrganizationDetailsDTO orgDetail = new OrganizationDetailsDTO();
		orgDetail.setOrganizationname(clientId);
		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setUsername("user1");
		orgResp.setOrganizations(List.of(orgDetail));
		when(orgService.getUserDetailsForOrganization(Mockito.eq(token), Mockito.any())).thenReturn(orgResp);

		EntitlementsResponse entResp = new EntitlementsResponse();
		EntitlementDetail detail = new EntitlementDetail();
		detail.setEntitlement_value("ent1");
		detail.setEndpoint("endpoint");
		detail.setDescription("desc");
		detail.setStatus("active");
		entResp.setEntitlementdetails(List.of(detail));
		lenient().when(entitlementService.loadEntitlements("user1", token, clientId)).thenReturn(entResp);

		lenient().when(securityManagerEntitlementRepository.findByIsSecuritymanager(1)).thenReturn(List.of());
		lenient().when(saviyntService.getDisplayNamesWithClientId(Mockito.any(), Mockito.eq(clientId))).thenReturn(List.of("ent1"));

		UserEntitlementsDTO updated = new UserEntitlementsDTO();
		updated.setEmail("user@example.com");
		lenient().when(entitlementService.updateUser(Mockito.any(), Mockito.eq(token))).thenReturn(updated);

		List<UserOrganizationDetailsDTO> listDto= new ArrayList<>();
		UserOrganizationDetailsDTO dto=new UserOrganizationDetailsDTO();
		dto.setUsername("user1");
		listDto.add(dto);
		OrganizationUserDetailResponseDTO orguserRespose = new OrganizationUserDetailResponseDTO();
		orguserRespose.setOrganizationname(clientId);
		orguserRespose.setUsers(listDto);
		lenient().when(orgService.getUserOrganizationDetails(Mockito.eq(token), Mockito.any(), Mockito.eq(clientId))).thenReturn(orguserRespose);

		UpdateOrganizationResponse updateOrgResp = new UpdateOrganizationResponse();
		updateOrgResp.setStatusCode(200);
		lenient(). when(orgService.updateUserToOrganization(Mockito.any(), Mockito.eq(token))).thenReturn(updateOrgResp);

		BaseResponse pgResponseBody = new BaseResponse();
		pgResponseBody.setErrors(null);
		ResponseEntity<Object> mockResponse = ResponseEntity
				.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body(pgResponseBody);

		lenient(). when(removeClientService.deleteClientDetails(Mockito.any(), Mockito.any(), Mockito.eq(clientId)))
		.thenReturn(mockResponse);

		// Act
		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, emails);

		// Assert
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		assertNotNull(response.getBody());

	}
	@Test
	void testInvalidHeader() throws Exception {
		when(checkClientData.isCheckRequestHeader(header))
		.thenReturn(ResponseEntity.badRequest().body("Invalid Header"));

		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, emails);

		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}

	@Test
	void testAccessTokenSuccess_with_INTERNAL_SERVER_ERROR() throws JsonProcessingException, PSQLException, IOException {
		when(userService.getAccessToken()).thenReturn(token);

		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, emails);

		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}


	@Test
	void testUnauthorizedAccessToken() throws Exception {
		FeignException fe = mock(FeignException.class);
		when(fe.status()).thenReturn(401);
		when(userService.getAccessToken()).thenThrow(fe);

		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, emails);

		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
	}

	@Test
	void testAccessTokenThrowsFeignException_ServerUnreachable() throws Exception {
		// Arrange
		FeignException feignException = mock(FeignException.class);
		when(feignException.status()).thenReturn(500); 
		when(userService.getAccessToken()).thenThrow(feignException);

		// Act
		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, emails);

		// Assert
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());

		BaseResponse body = (BaseResponse) response.getBody();
		assertNotNull(body);
		assertEquals(StartAnyWhereConstants.SAV101, body.getErrors().get(0).getErrorCode());
		assertEquals(StartAnyWhereConstants.SAVIYNT_SERVER_UNREACHABLE, body.getErrors().get(0).getErrorMessage());
	}

	@Test
	void testAccessTokenThrowsServerErrorException() throws JsonProcessingException, PSQLException, IOException {
		// Arrange
		FeignException feignException = mock(FeignException.class);
		when(feignException.status()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR.value()); 
		when(userService.getAccessToken()).thenThrow(feignException);

		// Act
		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, emails);

		// Assert
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		BaseResponse body = (BaseResponse) response.getBody();
		assertEquals(StartAnyWhereConstants.SAV101, body.getErrors().get(0).getErrorCode());
		assertEquals(StartAnyWhereConstants.SAVIYNT_SERVER_UNREACHABLE, body.getErrors().get(0).getErrorMessage());

	}

	@Test
	void testAccessTokenThrowsInvalidStatus() throws JsonProcessingException, PSQLException, IOException {
		FeignException feignException = mock(FeignException.class);
		when(feignException.status()).thenReturn(400); // Not a valid HttpStatus
		when(userService.getAccessToken()).thenThrow(feignException);

		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, emails);

		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());

		BaseResponse body = (BaseResponse) response.getBody();
		assertEquals(StartAnyWhereConstants.SAV101, body.getErrors().get(0).getErrorCode());
	}

	@Test
	void testEmailListIsNull() throws JsonProcessingException, PSQLException, IOException {

		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, null);

		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		BaseResponse body = (BaseResponse) response.getBody();
		assertEquals(StartAnyWhereConstants.POS106, body.getErrors().get(0).getErrorCode());
	}

	@Test
	void testEmailListIsEmpty() throws JsonProcessingException, PSQLException, IOException {
		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, new ArrayList<>());

		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}

	@Test
	void testEmailListAllNulls() throws JsonProcessingException, PSQLException, IOException {
		List<String> EmptyEmails = Arrays.asList(null, null);
		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, EmptyEmails);

		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}

	@Test
	void testEmailListAllEmptyOrWhitespace() throws JsonProcessingException, PSQLException, IOException {
		List<String> WhitwSpaceEmails = Arrays.asList("", "   ");
		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, WhitwSpaceEmails);

		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}

	@Test
	void testEmailListAllLiteralNullStrings() throws JsonProcessingException, PSQLException, IOException {
		List<String> EmpEmails = Arrays.asList("null", "NULL", "NuLl");
		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, EmpEmails);

		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}

	@Test
	void testEmailListWithValidEmail() throws JsonProcessingException, PSQLException, IOException {
		List<String> emails_valid = Arrays.asList("null", "   ", "manager@example.com");
		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, emails_valid);
		 
		//assertNotEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}





	@Test
	void testClientDoesNotExist_returnsDuplicateClientResponse() throws JsonProcessingException, PSQLException, IOException {
		// Arrange
		ResponseEntity<Object> mockResponse = ResponseEntity.status(HttpStatus.BAD_REQUEST)
				.body("Client not found");
		when(checkClientData.isNotValidClient("client123", "orgABC")).thenReturn(mockResponse);

		// Act
		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, emails);

		// Assert
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertEquals("Client not found", response.getBody());
	}

	@Test
	void testClientExists_proceedsWithNormalFlow_INTERNAL_SERVER_ERROR() throws JsonProcessingException, PSQLException, IOException {
		// Arrange
		when(checkClientData.isNotValidClient("client123", "orgABC")).thenReturn(null);
		when(userService.getAccessToken()).thenReturn("validAccessToken");


		// Act
		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, emails);
		// Assert
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}



	@Test
	void testEmptyEmailList() throws Exception {
		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, List.of());

		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}

	@Test
	void testFilterConditionInsideServiceMethod() throws Exception {
		List<String> emails = Arrays.asList(
				null,
				"",
				"   ",
				"null",
				"valid@example.com"
				);

		// Mock userService.getAccessToken()
		when(userService.getAccessToken()).thenReturn("dummyToken");

		// Mock checkClientData.isCheckRequestHeader() to return null so flow continues
		when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);

		// Mock checkClientData.isNotValidClient() to return null
		when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		// Mock userService.getUserProfile() only for valid email
		User user = new User();
		user.setUsername("user1");
		user.setEmail("valid@example.com");
		when(userService.getUserProfile("valid@example.com", "dummyToken")).thenReturn(user);

		// Mock accountService.getAccounts() to return active account
		AccountDTO account = new AccountDTO();
		account.setStatus("1");
		account.setAccountname("acc123");
		when(accountService.getAccounts("user1", "dummyToken")).thenReturn(List.of(account));

		// Mock orgService.getUserDetailsForOrganization()
		OrganizationDetailsDTO orgDetail = new OrganizationDetailsDTO();
		orgDetail.setOrganizationname(clientId);
		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setUsername("user1");
		orgResp.setOrganizations(List.of(orgDetail));
		when(orgService.getUserDetailsForOrganization(Mockito.eq("dummyToken"), Mockito.any())).thenReturn(orgResp);

		// Mock entitlementService.loadEntitlements()
		EntitlementsResponse entResp = new EntitlementsResponse();
		EntitlementDetail detail = new EntitlementDetail();
		detail.setEntitlement_value("ent1");
		entResp.setEntitlementdetails(List.of(detail));
		when(entitlementService.loadEntitlements("user1", "dummyToken", clientId)).thenReturn(entResp);

		// Mock saviyntService.getDisplayNamesWithClientId()
		when(saviyntService.getDisplayNamesWithClientId(Mockito.any(), Mockito.eq(clientId))).thenReturn(List.of("ent1"));

		// Mock entitlementService.updateUser()
		UserEntitlementsDTO updated = new UserEntitlementsDTO();
		updated.setEmail("valid@example.com");
		when(entitlementService.updateUser(Mockito.any(), Mockito.eq("dummyToken"))).thenReturn(updated);

		// Mock orgService.updateUserToOrganization()
		UpdateOrganizationResponse updateOrgResp = new UpdateOrganizationResponse();
		updateOrgResp.setStatusCode(200);
		when(orgService.updateUserToOrganization(Mockito.any(), Mockito.eq("dummyToken"))).thenReturn(updateOrgResp);

		// Mock removeClientService.deleteClientDetails()
		BaseResponse pgResponseBody = new BaseResponse();
		when(removeClientService.deleteClientDetails(Mockito.any(), Mockito.any(), Mockito.eq(clientId)))
		.thenReturn(ResponseEntity.ok(pgResponseBody));

		// Act
		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, emails);

		// Assert
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
	}

	@Test
	@MockitoSettings(strictness = Strictness.LENIENT)
	void testUserProfileFeignExceptionHandling() throws Exception {
		List<String> emails = Arrays.asList("valid@example.com");

		// Mock access token
		when(userService.getAccessToken()).thenReturn("dummyToken");

		// Mock header and client validation to pass
		when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		// Mock getUserProfile to throw FeignException
		FeignException feignEx = mock(FeignException.class);
		when(feignEx.getMessage()).thenReturn("Feign error occurred");
		when(userService.getUserProfile("valid@example.com", "dummyToken")).thenThrow(feignEx);

		// Mock other dependencies to allow flow to reach the loop
		lenient().when(accountService.getAccounts(Mockito.any(), Mockito.any())).thenReturn(List.of());
		lenient().when(orgService.getUserDetailsForOrganization(Mockito.any(), Mockito.any())).thenReturn(new UserOrganizationDetailResponseDTO());
		lenient().when(entitlementService.loadEntitlements(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new EntitlementsResponse());
		lenient().when(saviyntService.getDisplayNamesWithClientId(Mockito.any(), Mockito.any())).thenReturn(List.of());
		lenient().when(entitlementService.updateUser(Mockito.any(), Mockito.any())).thenReturn(new UserEntitlementsDTO());
		lenient().when(orgService.updateUserToOrganization(Mockito.any(), Mockito.any())).thenReturn(new UpdateOrganizationResponse());
		lenient().when(removeClientService.deleteClientDetails(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(ResponseEntity.ok(new BaseResponse()));

		// Act
		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, emails);

		// Assert
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode()); // or whatever status is expected

	}

	@Test
	void testInvalidMailMapIsNull() throws Exception {
		// Setup everything to reach this point
		// But do NOT populate invalidMailMap

		// Simulate userService.getUserProfile(...) returning valid user
		when(userService.getUserProfile("valid@example.com", "dummyToken")).thenReturn(new User());

		// Act
		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, List.of("valid@example.com"));

		// Assert
		// Block should be skipped — no error logged for missing user
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
	}

	@Test
	void testInvalidMailMapIsEmpty() throws Exception {
		// Simulate userService.getUserProfile(...) returning valid user
		when(userService.getUserProfile("valid@example.com", "dummyToken")).thenReturn(new User());

		// Act
		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, List.of("valid@example.com"));

		// Assert
		// Block should be skipped — no error logged
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
	}

	@Test
	void testInvalidMailMapHasEntries() throws Exception {
		// Simulate userService.getUserProfile(...) returning null
		when(userService.getUserProfile("invalid@example.com", "dummyToken")).thenReturn(null);

		// Act
		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, List.of("invalid@example.com"));

		// Assert
		// Block should be executed — error logged and response built
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		// Optionally verify error code or message
	}

	@Test
	void testInvalidEmailTriggersErrorLog() throws JsonProcessingException, PSQLException, IOException {
		String invalidEmail = "missing@saviynt.com";
		when(userService.getAccessToken()).thenReturn("dummyToken");
		when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);
		when(userService.getUserProfile(invalidEmail, "dummyToken")).thenReturn(null);

		try (MockedStatic<ErrorLogEventHelper> errorLogMock = mockStatic(ErrorLogEventHelper.class)) {
			errorLogMock.when(() -> ErrorLogEventHelper.logErrorEvent(
					Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any(),Mockito.anyString()
					)).thenAnswer(invocation -> {
						String message = invocation.getArgument(1);
						System.out.println("Actual log message: " + message); 
						assertTrue(message.contains(invalidEmail));
						return null;
					});

			service.getDeleteClientConfigurationDetails(
					"dummyToken", header, clientId, orgName, List.of(invalidEmail));
		}
	}




	@SuppressWarnings("static-access")
	@Test
	void testEmptyAccountsTriggersSAV015AndRemovesEntry() throws JsonProcessingException, PSQLException, IOException {
		// Arrange
		List<ClientConfigError> errors = new ArrayList<>();
		ClientConfigError err = new ClientConfigError();
		err.setErrorCode(StartAnyWhereConstants.SAV015);
		err.setErrorMessage(StartAnyWhereConstants.SAV015_MSG);
		err.setErrorSeverity(StartAnyWhereConstants.LOW);
		errors.add(err);

		BaseResponse response = new BaseResponse(); // 
		response.setErrors(errors);

		Map<String, Object> validMailMap = new HashMap<>();
		validMailMap.put("test@example.com", "test@example.com");

		List<AccountDTO> emptyAccounts = Collections.emptyList();
		lenient(). when(accountService.getAccounts(Mockito.any(), Mockito.any())).thenReturn(emptyAccounts);
		AtomicReference<String> capturedKeyRef = new AtomicReference<>();
		try (MockedStatic<StartAnywhereUtil> mockedUtil = mockStatic(StartAnywhereUtil.class)) {

			// Stub the static method and capture arguments
			mockedUtil.when(() -> StartAnywhereUtil.buildResponse(
					Mockito.any(), Mockito.any(), Mockito.any(),
					Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
					Mockito.anyString(), Mockito.any()
					))
			.thenAnswer(invocation -> {
				capturedKeyRef.set(invocation.getArgument(6, String.class));
				return null;
			});

			// Act
			service.getDeleteClientConfigurationDetails(
					"sessionToken", header, clientId, orgName, List.of("test@example.com"));

			// Verify the method was called (with real values or same matchers as above)
			mockedUtil.verify(() -> StartAnywhereUtil.buildResponse(
					Mockito.any(), Mockito.any(), Mockito.any(),
					Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
					Mockito.anyString(), Mockito.any()
					));
		}

		assertEquals("test@example.com", capturedKeyRef.get());

	}


	@SuppressWarnings("static-access")
	@Test
	void testNonEmptyAccountsGoesToElseBlock() throws JsonProcessingException, PSQLException, IOException {
		// Arrange
		Map<String, Object> validMailMap = new HashMap<>();
		validMailMap.put("test@example.com", "test@example.com");

		Map<String, Object> accountMap = new HashMap<>();
		accountMap.put("test@example.com", new Object());

		List<AccountDTO> nonEmptyAccounts = List.of(new AccountDTO());

		lenient().when(accountService.getAccounts(Mockito.any(), Mockito.any())).thenReturn(nonEmptyAccounts);

		AtomicReference<String> capturedKeyRef = new AtomicReference<>();
		try (MockedStatic<StartAnywhereUtil> mockedUtil = mockStatic(StartAnywhereUtil.class)) {

			// Stub the static method and capture arguments
			mockedUtil.when(() -> StartAnywhereUtil.buildResponse(
					Mockito.any(), Mockito.any(), Mockito.any(),
					Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
					Mockito.anyString(), Mockito.any()
					))
			.thenAnswer(invocation -> {
				capturedKeyRef.set(invocation.getArgument(6, String.class));
				return null;
			});

			// Act
			service.getDeleteClientConfigurationDetails(
					"sessionToken", header, clientId, orgName, List.of("test@example.com"));

			// Verify the method was called (with real values or same matchers as above)
			mockedUtil.verify(() -> StartAnywhereUtil.buildResponse(
					Mockito.any(), Mockito.any(), Mockito.any(),
					Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
					Mockito.anyString(), Mockito.any()
					));
		}

		assertEquals("test@example.com", capturedKeyRef.get());

		assertTrue(validMailMap.containsKey("test@example.com")); // Entry remains
	}
	
	@Test
	void testPostgresDeleteFails() throws Exception {
		when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);
		when(userService.getAccessToken()).thenReturn(token);
		when(checkClientData.isNotValidClient(clientId, orgName)).thenReturn(null);

		// Setup minimal valid mocks to reach deletion
		User user = new User();
		user.setUsername("user1");
		user.setEmail("user@example.com");
		when(userService.getUserProfile("user@example.com", token)).thenReturn(user);

		AccountDTO account = new AccountDTO();
		account.setStatus("1");
		account.setAccountname("acc123");
		when(accountService.getAccounts("user1", token)).thenReturn(List.of(account));

		OrganizationDetailsDTO orgDetail = new OrganizationDetailsDTO();
		orgDetail.setOrganizationname(clientId);
		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setUsername("user1");
		orgResp.setOrganizations(List.of(orgDetail));
		when(orgService.getUserDetailsForOrganization(Mockito.eq(token), Mockito.any())).thenReturn(orgResp);

		EntitlementsResponse entResp = new EntitlementsResponse();
		EntitlementDetail detail = new EntitlementDetail();
		detail.setEntitlement_value("ent1");
		entResp.setEntitlementdetails(List.of(detail));
		lenient(). when(entitlementService.loadEntitlements("user1", token, clientId)).thenReturn(entResp);
		lenient().when(saviyntService.getDisplayNamesWithClientId(Mockito.any(), Mockito.eq(clientId))).thenReturn(List.of("ent1"));
		lenient(). when(entitlementService.updateUser(Mockito.any(), Mockito.eq(token))).thenReturn(new UserEntitlementsDTO());

		UpdateOrganizationResponse updateOrgResp = new UpdateOrganizationResponse();
		updateOrgResp.setStatusCode(200);
		lenient().when(orgService.updateUserToOrganization(Mockito.any(), Mockito.eq(token))).thenReturn(updateOrgResp);

		BaseResponse errorResponse = new BaseResponse();
		errorResponse.setErrors(List.of(new ClientConfigError()));
		lenient(). when(removeClientService.deleteClientDetails(Mockito.any(), Mockito.any(), Mockito.eq(clientId)))
		.thenReturn(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse));

		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(
				"sessionToken", header, clientId, orgName, emails);

		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
	}

	@Test
	void testValidateHeader_ReturnsResponseEntity() throws JsonProcessingException, IOException, PSQLException {
		String header = "header";
		List<String> securityManagerEmailId = List.of("user@alight.com", "test@alight.com");
		ResponseEntity<Object> mockResponse = ResponseEntity.ok("Valid");

		when(checkClientData.isCheckRequestHeader(header)).thenReturn(mockResponse);

		ResponseEntity<Object> result = checkClientData.isCheckRequestHeader(header);
		ResponseEntity<Object> res = service.getDeleteClientConfigurationDetails(getMockColleagueSessionTokenJSON(),getMockAlightRequestHeaderJSON(), "cid", "org", securityManagerEmailId);

		assertNotNull(res);
		assertNotNull(result);
		assertEquals("Valid", result.getBody());
		verify(checkClientData).isCheckRequestHeader(header);
	}

	@Test
	void testValidateHeader_NullResponse_ReturnsNull() throws JsonProcessingException, IOException, PSQLException {
		String header = "header";
		List<String> securityManagerEmailId = List.of("user@alight.com", "test@alight.com");
		when(checkClientData.isCheckRequestHeader(header)).thenReturn(null);

		ResponseEntity<Object> result = checkClientData.isCheckRequestHeader(header);
		ResponseEntity<Object> res = service.getDeleteClientConfigurationDetails(getMockColleagueSessionTokenJSON(),getMockAlightRequestHeaderJSON(), "cid", "org", securityManagerEmailId);

		assertNotNull(res);

		assertNull(result);
		verify(checkClientData).isCheckRequestHeader(header);
	}


	@Test
	void testHandleRetryFailure_feign() {
		FeignException fx = mock(FeignException.class);

		ResponseEntity<Object>  result = service.handleRetryFailure(fx, token, header, clientId, orgName, emails);
		assertEquals(HttpStatus.SERVICE_UNAVAILABLE, result.getStatusCode());
	}

	@Test
	void testHandleRetryFailure_generic() {
		IOException ex = new IOException("Fail");

		ResponseEntity<Object>  result = service.handleRetryFailure(ex, token, header, clientId, orgName, emails);
		assertEquals(HttpStatus.SERVICE_UNAVAILABLE, result.getStatusCode());
	}
	@Test
	void testClientConfig_OrganizationMissing() throws Exception {
		when(userService.getAccessToken()).thenReturn("token");

		User u = new User();
		u.setEmail("manager@example.com"); //  non-null
		u.setUsername("mgrUser");
		UserDetailsResponse ud = new UserDetailsResponse();
		ud.setUserdetails(List.of(u));
		lenient().    when(requestBuilder.buildGetUserQuery(any())).thenReturn("q");
		lenient().    when(saviyntClient.getUser(any(), any())).thenReturn(ud);

		OrganizationDetailsDTO org = new OrganizationDetailsDTO();
		org.setOrganizationname("OTHER_CLIENT"); // does not match CLIENT999
		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setOrganizations(List.of(org));
		lenient().when(saviyntClient.getOrganizationUserDetails(any(), any())).thenReturn(orgResp);

		EntitlementsResponse entResp = new EntitlementsResponse();
		entResp.setStatusCode(200);
		entResp.setEntitlementdetails(Collections.emptyList());
		lenient().  when(saviyntClient.getEntitlements(any(), any())).thenReturn(entResp);

		lenient().  when(saviyntConfigurationBean.getPrefix()).thenReturn("PFX_");
		lenient().  when(saviyntConfigurationBean.getApplication()).thenReturn("APP");
		lenient().  when(saviyntConfigurationBean.getEndpoint()).thenReturn("internal-endpoint");

		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(token, header, clientId, orgName, emails);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}
	@Test
	void testClientConfig_UserDetailsMissing() throws Exception {
		when(userService.getAccessToken()).thenReturn("xyz");
		lenient().   when(requestBuilder.buildGetUserQuery(any())).thenReturn("q");

		UserDetailsResponse emptyUserDetails = new UserDetailsResponse();
		emptyUserDetails.setUserdetails(new ArrayList<>()); //  empty but not null
		lenient().   when(saviyntClient.getUser(any(), any())).thenReturn(emptyUserDetails);

		lenient().   when(saviyntConfigurationBean.getPrefix()).thenReturn("PFX_");
		lenient().    when(saviyntConfigurationBean.getApplication()).thenReturn("APP");
		lenient(). when(saviyntConfigurationBean.getEndpoint()).thenReturn("internal-endpoint");

		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(token, header, clientId, orgName, emails);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}
	@Test
	void testClientConfig_OrgMismatchTriggersSAV006() throws Exception {
		when(userService.getAccessToken()).thenReturn("tokenX");

		User user = new User();
		user.setEmail("manager@example.com");
		user.setUsername("mgrUser");
		UserDetailsResponse udResp = new UserDetailsResponse();
		udResp.setUserdetails(List.of(user));
		lenient().   when(requestBuilder.buildGetUserQuery(any())).thenReturn("query");
		lenient().when(saviyntClient.getUser(any(), any())).thenReturn(udResp);

		OrganizationDetailsDTO wrongOrg = new OrganizationDetailsDTO();
		wrongOrg.setOrganizationname("OTHER_CLIENT"); // does not match request.getClientId()
		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setOrganizations(List.of(wrongOrg));
		lenient(). when(saviyntClient.getOrganizationUserDetails(any(), any())).thenReturn(orgResp);

		EntitlementDetail detail = new EntitlementDetail();
		detail.setEntitlement_value("PFX_Role-CLIENT789,APP");
		detail.setEntitlementOwner(List.of("mgrUser"));
		detail.setStatus("Active");
		detail.setEndpoint("endpoint");
		detail.setDescription("desc");

		EntitlementsResponse entResp = new EntitlementsResponse();
		entResp.setStatusCode(200);
		entResp.setEntitlementdetails(List.of(detail));
		lenient().  when(saviyntClient.getEntitlements(any(), any())).thenReturn(entResp);

		lenient(). when(saviyntConfigurationBean.getPrefix()).thenReturn("PFX_");
		lenient(). when(saviyntConfigurationBean.getApplication()).thenReturn("APP");
		lenient().  when(saviyntConfigurationBean.getEndpoint()).thenReturn("internal-endpoint");

		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(token, header, clientId, orgName, emails);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}
	@Test
	void testClientConfig_OrgMismatchTriggersSAV0061() throws Exception {

		when(userService.getAccessToken()).thenReturn("tokenX");

		User user = new User();
		user.setEmail("manager@example.com");
		user.setUsername("mgrUser");
		UserDetailsResponse udResp = new UserDetailsResponse();
		udResp.setUserdetails(List.of(user));
		lenient().  when(requestBuilder.buildGetUserQuery(any())).thenReturn("query");
		lenient(). when(saviyntClient.getUser(any(), any())).thenReturn(udResp);

		OrganizationDetailsDTO wrongOrg = new OrganizationDetailsDTO();
		wrongOrg.setOrganizationname("CLIENT789"); // does not match request.getClientId()
		UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
		orgResp.setOrganizations(List.of(wrongOrg));
		lenient(). when(saviyntClient.getOrganizationUserDetails(any(), any())).thenReturn(orgResp);

		EntitlementDetail detail = new EntitlementDetail();
		detail.setEntitlement_value("PFX_Role-CLIENT789,APP");
		detail.setEntitlementOwner(List.of("mgrUser"));
		detail.setStatus("Active");
		detail.setEndpoint("endpoint");
		detail.setDescription("desc");

		SecurityManagerEntitlementEntity entity1 = new SecurityManagerEntitlementEntity();
		entity1.setDisplayName("value1"); // set fields as needed
		entity1.setIsSecuritymanager(1);
		SecurityManagerEntitlementEntity entity2 = new SecurityManagerEntitlementEntity();
		entity2.setDisplayName("Role-CLIENT789");
		entity2.setIsSecuritymanager(1);

		List<SecurityManagerEntitlementEntity> entitlementEntities = List.of(entity1, entity2);


		EntitlementsResponse entResp = new EntitlementsResponse();
		entResp.setStatusCode(200);
		entResp.setEntitlementdetails(List.of(detail));
		lenient(). when(saviyntClient.getEntitlements(any(), any())).thenReturn(entResp);

		lenient().  when(saviyntConfigurationBean.getPrefix()).thenReturn("PFX_");
		lenient().  when(saviyntConfigurationBean.getApplication()).thenReturn("APP");
		lenient().    when(saviyntConfigurationBean.getEndpoint()).thenReturn("internal-endpoint");
		lenient().   when(securityManagerEntitlementRepository.findByIsSecuritymanager(1)).thenReturn(entitlementEntities);


		ResponseEntity<Object> response = service.getDeleteClientConfigurationDetails(token, header, clientId, orgName, emails);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode()); 
	} 

	@Test
	void testPrivateUpdateOrgUserWithRemoveType() throws Exception {
		String updateType = "remove";
		String organizationName = "TestOrg";
		String aid = "user123";
		String accessToken = "token";

		UpdateOrganizationResponse mockResponse = new UpdateOrganizationResponse();
		when(orgService.updateUserToOrganization(any(UpdateOrganizationRequestDTO.class), eq(accessToken)))
		.thenReturn(mockResponse);
		when(saviyntConfigurationBean.getRequestor()).thenReturn("TEST");

		Method method = service.getClass().getDeclaredMethod("updateOrgUser", String.class, String.class, String.class, String.class);
		method.setAccessible(true);

		UpdateOrganizationResponse result = (UpdateOrganizationResponse) method.invoke(service, updateType, organizationName, aid, accessToken);

		assertNotNull(result);
		verify(orgService).updateUserToOrganization(any(UpdateOrganizationRequestDTO.class), eq(accessToken));
	}

	@Test
	void testPrivateBuildRemoveOrgUserDTO() throws Exception {
		String organizationName = "TestOrg";
		String aid = "user123";
		lenient().  when(saviyntConfigurationBean.getRequestor()).thenReturn("TEST");
		Method method = service.getClass().getDeclaredMethod("buildRemoveOrgUserDTO", String.class, String.class);
		method.setAccessible(true);

		UpdateOrganizationRequestDTO dto = (UpdateOrganizationRequestDTO) method.invoke(service, organizationName, aid);

		assertEquals(organizationName, dto.getOrganizationname());
	}

		@Test
	void testExactMatch_allTrue() {
		List<String> orgUserList = List.of("a", "b", "c");
		List<String> currentValidList = List.of("c", "b", "a");

		boolean result = service.isValid(orgUserList, currentValidList);
		assertTrue(result);
	}
	@Test
	void testSameSize_orgDoesNotContainCurrent() {
		List<String> orgUserList = List.of("a", "b", "x");
		List<String> currentValidList = List.of("a", "b", "c");

		boolean result = service.isValid(orgUserList, currentValidList);
		assertFalse(result);
	}
	@Test
	void testSameSize_currentDoesNotContainOrg() {
		List<String> orgUserList = List.of("a", "b", "c");
		List<String> currentValidList = List.of("a", "b", "x");

		boolean result = service.isValid(orgUserList, currentValidList);
		assertFalse(result);
	}
	@Test
	void testSubsetMatch_triggersSecondIf() {
		List<String> orgUserList = List.of("a", "b");
		List<String> currentValidList = List.of("a", "b", "c");

		boolean result = service.isValid(orgUserList, currentValidList);
		assertTrue(result);
	}

	@Test
	void testSubsetSizeButMissingElement() {
		List<String> orgUserList = List.of("a", "b", "x");
		List<String> currentValidList = List.of("a", "b", "c", "d");

		boolean result = service.isValid(orgUserList, currentValidList);
		assertFalse(result);
	}

	@Test
	void testOrgListLargerThanCurrentList() {
		List<String> orgUserList = List.of("a", "b", "c", "d");
		List<String> currentValidList = List.of("a", "b");

		boolean result = service.isValid(orgUserList, currentValidList);
		assertFalse(result);
	}

	@Test
	void test_currentContainsOrgTrue() {
		List<String> orgUserList = List.of("a", "b", "c");
		List<String> currentValidList = List.of("c", "b", "a");

		assertTrue(service.isValid(orgUserList, currentValidList));
	}
	@Test
	void test_currentContainsOrgFalse() {
		List<String> orgUserList = List.of("a", "b", "c");
		List<String> currentValidList = List.of("a", "b", "x");

		assertFalse(service.isValid(orgUserList, currentValidList));
	}


	@Test
	void deleteClientConfiguration_noAccountsForValidMail_returnsInternalServerError() throws Exception {
		when(userService.getUserProfile(any(), any())).thenReturn(new User());
		when(accountService.getAccounts(any(), any())).thenReturn(List.of());

		try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class)) {
			ResponseEntity<Object> result = service.getDeleteClientConfigurationDetails(token, header, clientId, orgName, emails);

			assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
			assertTrue(result.getBody().toString().contains(StartAnyWhereConstants.SECURTY_MANAGERS_DONOT_HAVE_ACCOUNTS));
		}
	}

	@Test
	void delteClientConfiguration_allRequestsFailed_returnsInternalServerError() throws Exception {
		when(userService.getUserProfile(any(), any())).thenReturn(new User());
		AccountDTO account = AccountDTO.of("u", "acc", "ACTIVE");
		when(accountService.getAccounts(any(), any())).thenReturn(List.of(account));

		// Remove everyone from validMailMap to trigger the branch
		try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class)) {
			// simulate FeignException on updateOrgUser to cause removals from validMailMap
			UpdateOrganizationResponse resp = UpdateOrganizationResponse.builder().msg("ok").errorCode("0").statusCode(200).build();
			FeignException fe = mock(FeignException.class);
			lenient().when(fe.status()).thenReturn(412);

			lenient(). when(orgService.updateUserToOrganization(any(), any())).thenThrow(fe);
			ResponseEntity<Object> result = service.getDeleteClientConfigurationDetails(token, header, clientId, orgName, emails);

			assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
		}
	}
	@Test
	void DeleteClientConfiguration_securityManagerUserValid_addsToValidMailMap() throws Exception {
		List<User> listOfUsers = new ArrayList<>();
		User user = new User(); user.setUsername("validUser");
		listOfUsers.add(user);

		List<UserOrganizationDetailsDTO> listDto= new ArrayList<>();
		UserOrganizationDetailsDTO dto=new UserOrganizationDetailsDTO();
		dto.setUsername("validUser");
		listDto.add(dto);
		OrganizationUserDetailResponseDTO orguserRespose = new OrganizationUserDetailResponseDTO();
		orguserRespose.setOrganizationname("1234");
		orguserRespose.setUsers(listDto);
		when(userService.getUserProfile(any(), any())).thenReturn(user);
		when(accountService.getAccounts(any(), any())).thenReturn(List.of(AccountDTO.of("validUser", "acc", "1")));

		when(orgService.getUserDetailsForOrganization(any(), any())).thenReturn(UserOrganizationDetailResponseDTO.builder()
				.msg("test")
				.displaycount("1")
				.organizations(List.of())
				.username("validUser")
				.errorCode("0")
				.totalcount("100")
				.statusCode(200).build());

		setupHappyPathForEntitlements(1, List.of(new EntitlementDetail() {{ setDisplayname("groupcid"); }}));

		lenient().when(orgService.getUserOrganizationDetails(any(), any(), any())).thenReturn(OrganizationUserDetailResponseDTO.builder()
				.displaycount("1")
				.msg("msg")
				.totalcount("100")
				.offset("0")
				.max("500")
				.organizationname("1234")
				.errorCode("0")
				.users(List.of()).build());

		List<String> validUserList = Optional.ofNullable(listOfUsers)
				.orElse(Collections.emptyList())
				.stream()
				.map(us -> us != null ? us.getUsername() : null) // Safely handle null User objects
				.filter(Objects::nonNull) // Filter out null usernames
				.collect(Collectors.toList());


		List<String> orgUsersList = Optional.ofNullable(orguserRespose.getUsers())
				.filter(users -> !users.isEmpty())
				.map(users -> users.stream()
						.map(UserOrganizationDetailsDTO::getUsername)
						.collect(Collectors.toList()))
				.orElse(new ArrayList<>());

		boolean valid = service.isValid(orgUsersList, validUserList);
		assertTrue(valid);

		//remove the entitlement
		lenient(). when(entitlementService.updateUser(any(), any())).thenReturn(UserEntitlementsDTO.of("REMOVE", "validUser", 
				"acc", "test@alight.com", "fName", "lName", "cusomer", "manager", "internal", null, null));

		//remove the organization
		lenient().when(orgService.updateUserToOrganization(any(), any())).thenReturn(UpdateOrganizationResponse.builder().statusCode(200).msg("ok").errorCode("0").build());
				BaseResponse br = new BaseResponse();
		br.setResponseCode("200");
		br.setErrors(new ArrayList<ClientConfigError>());

		lenient().when(removeClientService.deleteClientDetails(any(), any(), any())).thenReturn(new ResponseEntity<>(br, HttpStatus.OK));

		try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class)) {
			ResponseEntity<Object> result = service.getDeleteClientConfigurationDetails(token, header, clientId, orgName, emails);

			assertEquals(HttpStatus.OK, result.getStatusCode());
		}
	}
	@Test
	void DeleteClientConfiguration_securityManagerUserValid_addsToValidMailMap_orgResponseError() throws Exception {
		List<User> listOfUsers = new ArrayList<>();
		User user = new User(); user.setUsername("validUser");
		listOfUsers.add(user);

		List<UserOrganizationDetailsDTO> listDto= new ArrayList<>();
		UserOrganizationDetailsDTO dto=new UserOrganizationDetailsDTO();
		dto.setUsername("validUser");
		listDto.add(dto);
		OrganizationUserDetailResponseDTO orguserRespose = new OrganizationUserDetailResponseDTO();
		orguserRespose.setOrganizationname("1234");
		orguserRespose.setUsers(listDto);
		when(userService.getUserProfile(any(), any())).thenReturn(user);
		when(accountService.getAccounts(any(), any())).thenReturn(List.of(AccountDTO.of("validUser", "acc", "1")));

		when(orgService.getUserDetailsForOrganization(any(), any())).thenReturn(UserOrganizationDetailResponseDTO.builder()
				.msg("test")
				.displaycount("1")
				.organizations(List.of())
				.username("validUser")
				.errorCode("0")
				.totalcount("100")
				.statusCode(200).build());

		setupHappyPathForEntitlements(1, List.of(new EntitlementDetail() {{ setDisplayname("groupcid"); }}));

		lenient().when(orgService.getUserOrganizationDetails(any(), any(), any())).thenReturn(OrganizationUserDetailResponseDTO.builder()
				.displaycount("1")
				.msg("msg")
				.totalcount("100")
				.offset("0")
				.max("500")
				.organizationname("1234")
				.errorCode("0")
				.users(List.of()).build());

		List<String> validUserList = Optional.ofNullable(listOfUsers)
				.orElse(Collections.emptyList())
				.stream()
				.map(us -> us != null ? us.getUsername() : null) 
				.filter(Objects::nonNull)
				.collect(Collectors.toList());


		List<String> orgUsersList = Optional.ofNullable(orguserRespose.getUsers())
				.filter(users -> !users.isEmpty())
				.map(users -> users.stream()
						.map(UserOrganizationDetailsDTO::getUsername)
						.collect(Collectors.toList()))
				.orElse(new ArrayList<>());

		boolean valid = service.isValid(orgUsersList, validUserList);
		assertTrue(valid);

		//remove the entitlement
		lenient(). when(entitlementService.updateUser(any(), any())).thenReturn(UserEntitlementsDTO.of("REMOVE", "validUser", 
				"acc", "test@alight.com", "fName", "lName", "cusomer", "manager", "internal", null, null));

		//remove the organization
		lenient().when(orgService.updateUserToOrganization(any(), any())).thenReturn(UpdateOrganizationResponse.builder().statusCode(200).msg("ok").errorCode("0").build());

		BaseResponse br = new BaseResponse();
		br.setResponseCode("201");
		br.setErrors(new ArrayList<ClientConfigError>());

		lenient().when(removeClientService.deleteClientDetails(any(), any(), any())).thenReturn(new ResponseEntity<>(br, HttpStatus.OK));

		try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class)) {
			ResponseEntity<Object> result = service.getDeleteClientConfigurationDetails(token, header, clientId, orgName, emails);

			assertEquals(HttpStatus.OK, result.getStatusCode());
		}
	}

	public String getMockAlightRequestHeaderJSON1() {
		return "{\"locale\":\"en_US\",\"clientId\":\"\"}";
	}

	public String getMockAlightRequestHeaderJSON() {
		return "{\"locale\":\"en_US\",\"clientId\":\"BA4\"}";
	}

	public String getMockColleagueSessionTokenJSON() {
		return "{\"sessionId\": \"1234567890\",\"expires\": 9876543210,\"accessToken\": \"pass your session Token here\",\"colleagueSessionMap\": {\"credentials.racf.ssoToken\": \"dev-tk\",\"credentials.racf.password\": \"********\",\"credentials.racf.id\": \"@*****\",\"credentials.ldap.HEWITT-NA.id\": \"AHId\",\"credentials.ldap.HEWITT-NA.password\": \"TestPwd\"}}";
	}

	public String getMockAlightRequestHeaderJSON2() {
		return "{\"locale\":\"\",\"clientId\":\"BA4\"}";
	}

	private void setupHappyPathForEntitlements(int entCount, List<EntitlementDetail> details) throws Exception {

		when(userService.getAccessToken()).thenReturn("token");

		SecurityManagerEntitlementEntity ent = new SecurityManagerEntitlementEntity();
		ent.setDisplayName("groupcid");
		lenient().when(entitlementRepo.findByIsSecuritymanager(1)).thenReturn(List.of(ent));

		EntitlementsResponse entResp = new EntitlementsResponse();
		entResp.setTotalEntitlementCount(entCount);
		entResp.setEntitlementdetails(details);
		lenient().when(entitlementService.loadEntitlements(any(), any(), any())).thenReturn(entResp);
	}

}
