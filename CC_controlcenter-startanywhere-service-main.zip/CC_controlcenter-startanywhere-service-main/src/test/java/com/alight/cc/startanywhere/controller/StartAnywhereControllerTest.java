package com.alight.cc.startanywhere.controller;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.anyString;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.postgresql.util.PSQLException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.alight.asg.model.token.v1_0.ColleagueSessionToken;
import com.alight.cc.startanywhere.model.BaseResponse;
import com.alight.cc.startanywhere.model.ClientConfigurationRequest;
import com.alight.cc.startanywhere.model.ClientConfigurationResponse;
import com.alight.cc.startanywhere.model.ClientModel;
import com.alight.cc.startanywhere.model.ClientRequest;
import com.alight.cc.startanywhere.model.ClientResponse;
import com.alight.cc.startanywhere.model.CreateGroupsResponse;
import com.alight.cc.startanywhere.service.ClientConfigurationService;
import com.alight.cc.startanywhere.service.ClientDataRetrievalService;
import com.alight.cc.startanywhere.service.DeleteClientConfigurationService;
import com.alight.cc.startanywhere.service.FetchClientConfigurationService;
import com.alight.cc.startanywhere.service.GroupService;
import com.alight.cc.startanywhere.service.RemoveClientService;
import com.alight.cc.startanywhere.service.StartAnywhereClientService;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;
import com.alight.cc.startanywhere.util.StartAnywhereSecurityUtil;
import com.alight.logging.helpers.InfoTypeLogEventHelper;
import com.aonhewitt.logging.helpers.ErrorLogEventHelper;
import com.fasterxml.jackson.core.JsonLocation;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.exc.MismatchedInputException;

import feign.FeignException;

@ExtendWith(SpringExtension.class)
public class StartAnywhereControllerTest {

	@InjectMocks
	StartAnywhereController controllerMock;
	@Mock
	StartAnywhereClientService clientServiceMock;
	@Mock
	ClientDataRetrievalService clientDataRetrievalServiceMock;
	@Mock
	private RemoveClientService removeClientService;
	@Mock
	private FetchClientConfigurationService fetchClientConfigurationService;
	@Mock
	private ClientConfigurationService clientConfigService;

	@Mock
	private InfoTypeLogEventHelper infoTypeLogEventHelper;

	@Mock
	private ErrorLogEventHelper errorLogEventHelper;

	@Mock
	private StartAnywhereSecurityUtil startAnywhereSecurityUtil;
	
	@Mock
    private GroupService groupService;
	
	@Mock
	private DeleteClientConfigurationService deleteClientConfigurationService;

	@BeforeEach
	public void init() throws Throwable {
		MockitoAnnotations.openMocks(this);
	}

	@AfterEach
	public void close() throws Exception {
		Mockito.clearAllCaches();
	}

	@Test
	public void testAddNewClientConfigurationsDetails_ShouldReturnExpectedResponse() throws Exception {
		// Given: test input and expected result
		ClientModel request = new ClientModel();
		request.setClientId("00095");
		request.setClientName("TestClient");
		request.setOrgName("TestOrg");
		request.setIsDataRestriction(true);

		String jsonInput = "{\"sessionId\": \"1234567890\", \"expires\": 9876543210, \"accessToken\": \"pass your session Token here\", \"colleagueSessionMap\": {\"credentials.ldap.HEWITT-NA.id\": \"ramya.ramar@alight.com\"}}";
		ColleagueSessionToken token = ColleagueSessionToken.parse(jsonInput);
		String ldapId = token.getLdapIdFromColleagueSessionToken();

		// Mock service response
		ResponseEntity<Object> expectedResponse = new ResponseEntity<>(HttpStatus.OK);
		doReturn(expectedResponse).when(clientServiceMock).addNewclientdetails(jsonInput,
				getMockAlightRequestHeaderJSON(), ldapId, request);

		StartAnywhereController controller = Mockito.mock(StartAnywhereController.class);

		controller.addNewclientdetails(jsonInput, getMockAlightRequestHeaderJSON(), request);
		verify(controller).addNewclientdetails(Mockito.anyString(), Mockito.anyString(), Mockito.any());

	}

	@Test
	public void testAddNewClientDetails_Success() throws Exception {
		// Arrange: Setup test data
		String tokenJson = "{ \"session_token\": \"abc123\", \"ldapId\": \"ramya.ramar@alight.com\" }";
		String cleanedToken = tokenJson;
		String cleanedHeader = "sampleHeader";

		ClientModel request = new ClientModel();
		request.setClientId("00095");

		ResponseEntity<Object> expectedResponse = new ResponseEntity<>(HttpStatus.OK);

		// Mock: token parsing
		ColleagueSessionToken mockToken = Mockito.mock(ColleagueSessionToken.class);
		Mockito.when(mockToken.getLdapIdFromColleagueSessionToken()).thenReturn("ramya.ramar@alight.com");

		// Use spy for static-like behavior if needed or wrap parse() logic
		Mockito.mockStatic(ColleagueSessionToken.class).when(() -> ColleagueSessionToken.parse(cleanedToken))
				.thenReturn(mockToken);

		// Mock service response
		Mockito.when(
				clientServiceMock.addNewclientdetails(cleanedToken, cleanedHeader, "ramya.ramar@alight.com", request))
				.thenReturn(expectedResponse);

		// Act
		ResponseEntity<Object> actualResponse = controllerMock.addNewclientdetails(cleanedToken, cleanedHeader,
				request);

		// Assert
		assertNotNull(actualResponse);
		assertEquals(HttpStatus.OK, actualResponse.getStatusCode());
		assertEquals(expectedResponse, actualResponse);
	}

	@Test
	public void testAddNewClientDetails_Fail_ShouldReturn500() throws JsonProcessingException {
		// InvalidJson input (no surrounding braces)
		String InvalidJson = "\"session_token\": \"abc123\", \"ldapId\": \"ramya.ramar@alight.com\" ";
		String cleanedHeader = "sampleHeader";

		ClientModel request = new ClientModel();
		request.setClientId("00095");

		MockedStatic<ColleagueSessionToken> mockStatic = Mockito.mockStatic(ColleagueSessionToken.class);

		mockStatic.when(() -> ColleagueSessionToken.parse("invalid-token"))
				.thenThrow(new JsonParseException(null, "Simulated failure", JsonLocation.NA));

		ResponseEntity<Object> response = controllerMock.addNewclientdetails(InvalidJson, cleanedHeader, request);

		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		// String responseText = response.getBody().toString();
		// assertTrue(responseText.contains("Unable to parse session token"));
	}

	@Test
	public void testShouldThrowMismatchedInputException() throws JsonProcessingException {
		String cleanedHeader = "sampleHeader";

		ClientModel request = new ClientModel();
		request.setClientId("00095");
		request.setClientName("test");
		request.setOrgName("test");
		request.setIsDataRestriction(false);
		ObjectMapper mapper = new ObjectMapper();

		String json = "\"session_token\""; // Just a string — not a valid object

		assertThrows(MismatchedInputException.class, () -> {
			mapper.readValue(json, ColleagueSessionToken.class);
		});

		ResponseEntity<Object> response = controllerMock.addNewclientdetails(json, cleanedHeader, request);

		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		String responseText = response.getBody().toString();
		assertTrue(responseText.contains("Unable to parse session token"));
	}

	@Test
	public void testAddNewClientDetails_Fail() throws Exception {
		// Arrange: Setup test data
		String tokenJson = "\"session_token\": \"abc123\", \"ldapId\": \"ramya.ramar@alight.com\" ";
		String cleanedToken = tokenJson;
		String cleanedHeader = "sampleHeader";

		ClientModel request = new ClientModel();
		request.setClientId("00095");

		ResponseEntity<Object> expectedResponse = new ResponseEntity<>(HttpStatus.OK);

		// Mock: token parsing
		ColleagueSessionToken mockToken = Mockito.mock(ColleagueSessionToken.class);

		Mockito.when(mockToken.getLdapIdFromColleagueSessionToken()).thenReturn("ramya.ramar@alight.com");

		Mockito.mockStatic(ColleagueSessionToken.class).when(() -> ColleagueSessionToken.parse(cleanedToken))
				.thenReturn(mockToken);

		// Mock service response
		Mockito.when(
				clientServiceMock.addNewclientdetails(cleanedToken, cleanedHeader, "ramya.ramar@alight.com", request))
				.thenReturn(expectedResponse);

		// Act
		ResponseEntity<Object> actualResponse = controllerMock.addNewclientdetails(cleanedToken, cleanedHeader,
				request);

		// Assert
		assertNotNull(actualResponse);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, actualResponse.getStatusCode());
		assertNotEquals(expectedResponse, actualResponse);
	}

	@Test
	public void testaddNewclientConfigurationsdetails() throws JsonProcessingException, IOException, PSQLException {
		ClientModel request = new ClientModel();
		request.setClientId("00095");

		String jsonInput = "{\"sessionId\": \"1234567890\",\"expires\": 9876543210,\"accessToken\": \"pass your session Token here\",\"colleagueSessionMap\": {\"credentials.racf.ssoToken\": \"dev-tk\",\"credentials.racf.password\": \"***\",\"credentials.racf.id\": \"@KVSGW\",\"credentials.ldap.HEWITT-NA.id\":\"ramya.ramar@alight.com\",\"credentials.ldap.HEWITT-NA.password\": \"******\"}}";

		// When: parsing and extracting the LDAP ID
		ColleagueSessionToken token = ColleagueSessionToken.parse(jsonInput);
		String ldapId = token.getLdapIdFromColleagueSessionToken();
		// Then: verify the LDAP ID is correct
		assertNotNull(ldapId, "LDAP ID should not be null");

		ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(HttpStatus.OK);

		doReturn(responseEntity).when(clientServiceMock).addNewclientdetails(jsonInput,
				getMockAlightRequestHeaderJSON(), ldapId, request);

		assertNotEquals(responseEntity,
				controllerMock.addNewclientdetails(getMockAlightRequestHeaderJSON(), jsonInput, request));
	}

	@Test
	public void testaddNewclientException() throws Exception {

		ClientModel request = new ClientModel();
		Mockito.doThrow(new RuntimeException()).when(clientServiceMock).addNewclientdetails(Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.any());
		ResponseEntity<Object> responseEntity = controllerMock.addNewclientdetails("", "", request);

		HttpStatusCode StatusCode = responseEntity.getStatusCode();
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, StatusCode);
	}

	@Test
	public void testaddNewclientdetailsBadException() throws Exception {

		ClientModel invalidRequest = new ClientModel();
		invalidRequest.setClientId("00095");
		invalidRequest.setClientName("Test Client");
		invalidRequest.setOrgName("Test Org");
		invalidRequest.setIsDataRestriction(null);
		doThrow(new DataIntegrityViolationException("Database constraint violation")).when(clientServiceMock)
				.addNewclientdetails(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any());
		ResponseEntity<Object> responseEntity = controllerMock.addNewclientdetails(getMockColleagueSessionTokenJSON(),
				getMockAlightRequestHeaderJSON(), invalidRequest);

		HttpStatusCode StatusCode = responseEntity.getStatusCode();
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, StatusCode);
	}

	@Test
	public void testaddNewclientdetailsBadException_JsonParseException() throws Exception {

		ClientModel Request = new ClientModel();
		Request.setClientId("00095");
		Request.setClientName("Test Client");
		Request.setOrgName("Test Org");
		Request.setIsDataRestriction(true);
		doThrow(new JsonParseException("Unable to parse session token")).when(clientServiceMock)
				.addNewclientdetails(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any());
		ResponseEntity<Object> responseEntity = controllerMock.addNewclientdetails(
				getMockColleagueSessionTokenInvalidJSON(), getMockAlightRequestHeaderJSON(), Request);

		HttpStatusCode StatusCode = responseEntity.getStatusCode();
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, StatusCode);
	}

	public String getMockAlightRequestHeaderJSON() {
		return "{\"locale\":\"en_US\",\"clientId\":\"BA4\"}";
	}

	public String getMockColleagueSessionTokenJSON() {
		return "{\"sessionId\": \"1234567890\",\"expires\": 9876543210,\"accessToken\": \"pass your session Token here\",\"colleagueSessionMap\": {\"credentials.racf.ssoToken\": \"dev-tk\",\"credentials.racf.password\": \"********\",\"credentials.racf.id\": \"@*****\",\"credentials.ldap.HEWITT-NA.id\": \"AHId\",\"credentials.ldap.HEWITT-NA.password\": \"TestPwd\"}}";
	}

	public String getMockColleagueSessionTokenInvalidJSON() {
		return "\"sessionId\": \"1234567890\",\"expires\": 9876543210,\"accessToken\": \"pass your session Token here\","
				+ "\"colleagueSessionMap\": {\"credentials.racf.ssoToken\": \"dev-tk\",\"credentials.racf.password\": \"********\",\"credentials.racf.id\": \"@*****\",\"credentials.ldap.HEWITT-NA.id\": \"AHId\",\"credentials.ldap.HEWITT-NA.password\": \"TestPwd\"}}";
	}

	@Test
	void testGetClientDetails_success() throws IOException {
		String token = "mockToken";
		String header = "mockHeader";
		String clientId = "123";
		String orgName = "Org Inc";

		ClientResponse mockResponse = new ClientResponse();
		mockResponse.setClientName(orgName);
		mockResponse.setOrgName("Org Inc");

		when(clientDataRetrievalServiceMock.getClientData(token, header, clientId)).thenReturn(mockResponse);

		ResponseEntity<ClientResponse> response = controllerMock.getClientDetails(token, header, clientId);

		assertEquals(HttpStatus.OK, response.getStatusCode());
		// assertNotNull(response.getBody());
		assertEquals(orgName, response.getBody().getOrgName());
	}

	@Test
	void testGetClientDetails_serviceThrowsException() throws IOException {
		String token = "mockToken";
		String header = "mockHeader";
		String clientId = "123";

		when(clientDataRetrievalServiceMock.getClientData(token, header, clientId))
				.thenThrow(new RuntimeException("Simulated DB failure"));

		ResponseEntity<ClientResponse> response = controllerMock.getClientDetails(token, header, clientId);

		assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
		assertEquals("503", response.getBody().getErrors().get(0).getErrorCode());
		assertEquals(StartAnyWhereConstants.INTERNAL_SERVER_ERROR, response.getBody().getResponseMessage());
	}

	@Test
	void shouldReturn200_whenResponseCodeIsSuccess() throws IOException {
		ClientResponse successResponse = new ClientResponse();
		successResponse.setResponseCode(StartAnyWhereConstants.HTTP_STATUS_SUCCESS);
		successResponse.setResponseMessage(StartAnyWhereConstants.OK);

		Mockito.when(clientDataRetrievalServiceMock.getClientData("token", "header", "BA4"))
				.thenReturn(successResponse);

		ResponseEntity<ClientResponse> response = controllerMock.getClientDetails("token", "header", "BA4");

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals("200", response.getBody().getResponseCode());
	}

	@Test
	void shouldReturn500_whenResponseCodeIs500() throws IOException {
		ClientResponse errorResponse = new ClientResponse();
		errorResponse.setResponseCode(StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR);
		errorResponse.setResponseMessage(StartAnyWhereConstants.INTERNAL_SERVER_ERROR);

		Mockito.when(clientDataRetrievalServiceMock.getClientData("token", "header", "BA4")).thenReturn(errorResponse);

		ResponseEntity<ClientResponse> response = controllerMock.getClientDetails("token", "header", "BA4");

		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		assertEquals("500", response.getBody().getResponseCode());
	}

	@Test
	void shouldReturn500_whenServiceThrowsException() throws IOException {
		Mockito.when(clientDataRetrievalServiceMock.getClientData("token", "header", "BA4"))
				.thenThrow(new RuntimeException("Simulated failure"));

		ResponseEntity<ClientResponse> response = controllerMock.getClientDetails("token", "header", "BA4");

		assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
		assertEquals("503", response.getBody().getResponseCode());
		assertEquals("Internal Server Error", response.getBody().getResponseMessage());
	}

	@Test
	void shouldReturnBadRequest_whenClientIdIsBlank() {
		// given
		String blankClientId = "  ";
		String token = "mock-token";
		String header = "{\"locale\":\"en_US\",\"clientId\":\"BA4\"}";

		// when
		ResponseEntity<ClientResponse> response = controllerMock.getClientDetails(token, header, blankClientId);

		// then
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

		assertEquals(StartAnyWhereConstants.BAD_REQUEST, response.getBody().getResponseMessage());
		assertEquals("400", response.getBody().getResponseCode());

		assertFalse(response.getBody().getErrors().isEmpty());
		assertEquals(StartAnyWhereConstants.BAD_REQUEST_MSG, response.getBody().getErrors().get(0).getErrorMessage());
	}

	@Test
	void shouldReturnBadRequest_whenClientIdIsNull() {
		// given
		String clientId = null;
		String token = "mock-token";
		String header = "{\"locale\":\"en_US\",\"clientId\":\"BA4\"}";

		// when
		ResponseEntity<ClientResponse> response = controllerMock.getClientDetails(token, header, clientId);

		// then
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertNotNull(response.getBody());
		assertEquals("400", response.getBody().getResponseCode());
		assertEquals(StartAnyWhereConstants.BAD_REQUEST, response.getBody().getResponseMessage());
	}

	@Test
	void deleteClientDetails_successful() {
		String token = "token";
		String header = "header";
		String clientId = "client1";
		ResponseEntity<Object> expectedResponse = ResponseEntity.ok("Success!");
		when(removeClientService.deleteClientDetails(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(expectedResponse);

		ResponseEntity<Object> response = controllerMock.deleteClientDetails(token, header, clientId);

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals("Success!", response.getBody());
		verify(removeClientService).deleteClientDetails(token, header, clientId);
	}

	@Test
	void deleteClientDetails_serviceThrowsException_returnsNotImplemented() {
		String token = "token";
		String header = "header";
		String clientId = "client1";
		when(removeClientService.deleteClientDetails(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenThrow(new RuntimeException("Service failed"));

		ResponseEntity<Object> response = controllerMock.deleteClientDetails(token, header, clientId);

		assertEquals(HttpStatus.NOT_IMPLEMENTED, response.getStatusCode());
		assertTrue(response.getBody() instanceof BaseResponse);
		BaseResponse error = (BaseResponse) response.getBody();
		assertEquals(StartAnyWhereConstants.HTTP_STATUS_NOT_IMPLEMENTED, error.getResponseCode());
		assertEquals(StartAnyWhereConstants.NOT_IMPLEMENTED, error.getResponseMessage());
	}

	@Test
	void testGetClientDetails_ServiceUnavailableResponseCode() throws IOException {
		String token = "sampleToken";
		String header = "sampleHeader";
		String clientId = "valid-client-id";

		ClientResponse serviceUnavailableResponse = new ClientResponse();
		serviceUnavailableResponse.setResponseCode(StartAnyWhereConstants.HTTP_STATUS_SERVICE_UNAVAILABLE);
		serviceUnavailableResponse.setResponseMessage("Service Unavailable");

		when(clientDataRetrievalServiceMock.getClientData(token, header, clientId))
				.thenReturn(serviceUnavailableResponse);

		ResponseEntity<ClientResponse> response = controllerMock.getClientDetails(token, header, clientId);

		assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
		assertEquals("Service Unavailable", response.getBody().getResponseMessage());
	}

	// Test for successful response (Normal Flow)
	@Test
	void testGetClientConfigurationDetails_Success() throws FeignException, IOException, RuntimeException {
		String token = "token123";
		String header = "header123";
		ClientRequest request = new ClientRequest();
		request.setClientId("19941");

		ClientConfigurationResponse mockResponse = new ClientConfigurationResponse();
		mockResponse.setResponseCode("200");
		mockResponse.setResponseMessage("OK");

		when(fetchClientConfigurationService.getClientConfigurationDetails(token, header, request))
				.thenReturn(mockResponse);

		ResponseEntity<ClientConfigurationResponse> response = controllerMock.getClientConfigurationDetails(token,
				header, request);

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(mockResponse, response.getBody());
	}

	// Test when service returns SERVICE_UNAVAILABLE
	@Test
	void testGetClientConfigurationDetails_ServiceUnavailable() throws FeignException, IOException, RuntimeException {
		String token = "token123";
		String header = "header123";
		ClientRequest request = new ClientRequest();

		ClientConfigurationResponse mockResponse = new ClientConfigurationResponse();
		mockResponse.setResponseCode(StartAnyWhereConstants.HTTP_STATUS_SERVICE_UNAVAILABLE);
		mockResponse.setResponseMessage("Service temporarily down");

		when(fetchClientConfigurationService.getClientConfigurationDetails(token, header, request))
				.thenReturn(mockResponse);

		ResponseEntity<ClientConfigurationResponse> response = controllerMock.getClientConfigurationDetails(token,
				header, request);

		assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
		assertEquals(mockResponse, response.getBody());
	}

	// Test for exception handling (Missed Branch)
	@Test
	void testGetClientConfigurationDetails_ExceptionThrown() throws FeignException, IOException, RuntimeException {
		String token = "token123";
		String header = "header123";
		ClientRequest request = new ClientRequest();

		when(fetchClientConfigurationService.getClientConfigurationDetails(token, header, request))
				.thenThrow(new RuntimeException("Simulated exception"));

		ResponseEntity<ClientConfigurationResponse> response = controllerMock.getClientConfigurationDetails(token,
				header, request);

		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		assertNotNull(response.getBody());
	}

	@Test
	void addClientConfiguration_returnsSuccess() throws JsonProcessingException, IOException {
		// Arrange
		String header = "token";
		String sessionToken = "session";
		ClientConfigurationRequest configRequest = new ClientConfigurationRequest();
		ResponseEntity<Object> expectedResponse = ResponseEntity.ok("success");

		// Mock static util class methods if needed
		try (MockedStatic<StartAnywhereSecurityUtil> securityUtilMock = mockStatic(StartAnywhereSecurityUtil.class);
				MockedStatic<InfoTypeLogEventHelper> infoLogMock = mockStatic(InfoTypeLogEventHelper.class)) {
			securityUtilMock.when(() -> StartAnywhereSecurityUtil.cleanIt(header)).thenReturn(header);
			securityUtilMock.when(() -> StartAnywhereSecurityUtil.cleanIt(sessionToken)).thenReturn(sessionToken);

			infoLogMock.when(() -> InfoTypeLogEventHelper.logInfoEvent(Mockito.anyString(), Mockito.anyString()))
					.thenAnswer(invocation -> null);

			when(clientConfigService.createClientConfiguration(header, sessionToken, configRequest))
					.thenReturn(expectedResponse);

			// Act
			ResponseEntity<Object> response = controllerMock.addClientConfiguration(header, sessionToken,
					configRequest);

			// Assert
			assertEquals(HttpStatus.OK, response.getStatusCode());
			assertEquals("success", response.getBody());
			verify(clientConfigService).createClientConfiguration(header, sessionToken, configRequest);
		}
	}

	@Test
    void addClientConfiguration_handlesException() throws JsonProcessingException, IOException {
        // Arrange
        String header = "token";
        String sessionToken = "session";
        ClientConfigurationRequest configRequest = new ClientConfigurationRequest();

        RuntimeException serviceException = new RuntimeException("Service Error");

        try (MockedStatic<StartAnywhereSecurityUtil> securityUtilMock = mockStatic(StartAnywhereSecurityUtil.class);
             MockedStatic<InfoTypeLogEventHelper> infoLogMock = mockStatic(InfoTypeLogEventHelper.class);
             MockedStatic<ErrorLogEventHelper> errorLogMock = mockStatic(ErrorLogEventHelper.class)) {
            securityUtilMock.when(() -> StartAnywhereSecurityUtil.cleanIt(header)).thenReturn(header);
            securityUtilMock.when(() -> StartAnywhereSecurityUtil.cleanIt(sessionToken)).thenReturn(sessionToken);

            infoLogMock.when(() -> InfoTypeLogEventHelper.logInfoEvent(Mockito.anyString(), Mockito.anyString())).thenAnswer(invocation -> null);
            errorLogMock.when(() -> ErrorLogEventHelper.logErrorEvent(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenAnswer(invocation -> null);

            when(clientConfigService.createClientConfiguration(header, sessionToken, configRequest)).thenThrow(serviceException);

            // Act
            ResponseEntity<Object> response = controllerMock.addClientConfiguration(header, sessionToken, configRequest);

            // Assert
            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
            assertEquals(serviceException, response.getBody());
            errorLogMock.verify(() -> ErrorLogEventHelper.logErrorEvent(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.eq(serviceException), Mockito.any()));
        }
	}
	private final String token = "dummyToken";
    private final String header = "dummyHeader";
    private final String clientId = "123";
    private final String clientName = "TestClient";

    private CreateGroupsResponse mockResponse(String code) {
        CreateGroupsResponse response = new CreateGroupsResponse();
        response.setResponseCode(code);
        return response;
    }
	 @Test
	    void testCreateGroups_success() throws Exception {
	        when(groupService.checkValidationBeforeAsync(token, header, clientId, clientName))
	            .thenReturn(mockResponse(StartAnyWhereConstants.HTTP_STATUS_SUCCESS));

	        ResponseEntity<CreateGroupsResponse> response = controllerMock.createClientGroups(token, header, clientId, clientName);
	        assertEquals(HttpStatus.OK, response.getStatusCode());
	    }

	    @Test
	    void testCreateGroups_badRequest() throws Exception {
	        when(groupService.checkValidationBeforeAsync(token, header, clientId, clientName))
	            .thenReturn(mockResponse(StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST));

	        ResponseEntity<CreateGroupsResponse> response = controllerMock.createClientGroups(token, header, clientId, clientName);
	        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	    }

	    @Test
	    void testCreateGroups_rateLimitExceeded() throws Exception {
	        when(groupService.checkValidationBeforeAsync(token, header, clientId, clientName))
	            .thenReturn(mockResponse(StartAnyWhereConstants.HTTP_STATUS_RATE_LIMIT_EXCEEDED));

	        ResponseEntity<CreateGroupsResponse> response = controllerMock.createClientGroups(token, header, clientId, clientName);
	        assertEquals(HttpStatus.TOO_MANY_REQUESTS, response.getStatusCode());
	    }

	    @Test
	    void testCreateGroups_created() throws Exception {
	        when(groupService.checkValidationBeforeAsync(token, header, clientId, clientName))
	            .thenReturn(mockResponse(StartAnyWhereConstants.POS201));

	        ResponseEntity<CreateGroupsResponse> response = controllerMock.createClientGroups(token, header, clientId, clientName);
	        assertEquals(HttpStatus.CREATED, response.getStatusCode());
	    }

	    @Test
	    void testCreateGroups_nullResponse() throws Exception {
	        when(groupService.checkValidationBeforeAsync(token, header, clientId, clientName))
	            .thenReturn(null);

	        ResponseEntity<CreateGroupsResponse> response = controllerMock.createClientGroups(token, header, clientId, clientName);
	        assertNull(response); // because method returns null
	    }

	    @Test
	    void testCreateGroups_exception() throws Exception {
	        when(groupService.checkValidationBeforeAsync(token, header, clientId, clientName))
	            .thenThrow(new RuntimeException("Simulated failure"));

	        ResponseEntity<CreateGroupsResponse> response = controllerMock.createClientGroups(token, header, clientId, clientName);
	        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
	        assertEquals(StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR, response.getBody().getResponseCode());
	    }
		
		 @Test
		    void getDeleteClientConfigurationDetails_returnsSuccess() throws JsonProcessingException, PSQLException, IOException {
		        // Arrange
		        String sessionToken = "sessionToken";
		        String requestHeader = "requestHeader";
		        String clientId = "client123";
		        String orgName = "orgABC";
		        List<String> emailList = Arrays.asList("test@alight.com");

		        ResponseEntity<Object> expectedResponse = ResponseEntity.ok("Success");

		        Mockito.when(deleteClientConfigurationService.getDeleteClientConfigurationDetails(
		                Mockito.eq(sessionToken),
		                Mockito.eq(requestHeader),
		                Mockito.eq(clientId),
		                Mockito.eq(orgName),
		                Mockito.anyList()
		        )).thenReturn(expectedResponse);

		        // Act
		        ResponseEntity<Object> actualResponse = controllerMock.getDeleteClientConfigurationDetails(
		                sessionToken,
		                requestHeader,
		                clientId,
		                orgName,
		                emailList
		        );

		        // Assert
		        assertNotNull(actualResponse);
		        assertEquals(HttpStatus.OK, actualResponse.getStatusCode());
		        assertEquals("Success", actualResponse.getBody());
		    }
		 
		 @Test
		    void getDeleteClientConfigurationDetails_handlesExceptionGracefully() throws JsonProcessingException, PSQLException, IOException {
		        // Arrange
		        String sessionToken = "sessionToken";
		        String requestHeader = "requestHeader";
		        String clientId = "client123";
		        String orgName = "orgABC";
		        List<String> emailList = Arrays.asList("test@alight.com");

		        // Simulate exception from service
		        Mockito.when(deleteClientConfigurationService.getDeleteClientConfigurationDetails(
		                Mockito.anyString(),
		                Mockito.anyString(),
		                Mockito.anyString(),
		                Mockito.anyString(),
		                Mockito.anyList()
		        )).thenThrow(new RuntimeException("Simulated service failure"));

		        // Act
		        ResponseEntity<Object> response = controllerMock.getDeleteClientConfigurationDetails(
		                sessionToken,
		                requestHeader,
		                clientId,
		                orgName,
		                emailList
		        );

		        // Assert
		        assertNotNull(response);
		        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		        assertTrue(response.getBody() instanceof BaseResponse);

		        BaseResponse errorResponse = (BaseResponse) response.getBody();
		        assertEquals(StartAnyWhereConstants.INTERNAL_SERVER_ERROR, errorResponse.getErrors().get(0).getErrorMessage());
		        assertEquals(StartAnyWhereConstants.POS500, errorResponse.getErrors().get(0).getErrorCode());
		    }

}
