package com.alight.cc.startanywhere.exception;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import static org.junit.jupiter.api.Assertions.*;

class CCServiceExceptionTest {

    @Test
    void testConstructorAndGettersWithoutCause() {
        CCServiceException ex = new CCServiceException(HttpStatus.BAD_REQUEST, "Error occurred");
        assertEquals(HttpStatus.BAD_REQUEST, ex.getHttpStatus());
        assertEquals("Error occurred", ex.getMessage());
        assertNull(ex.getCause());
    }

    @Test
    void testConstructorAndGettersWithCause() {
        Exception cause = new Exception("Root cause!");
        CCServiceException ex = new CCServiceException(HttpStatus.NOT_FOUND, "Not found", cause);
        assertEquals(HttpStatus.NOT_FOUND, ex.getHttpStatus());
        // The message should include the cause message
        String msg = ex.getMessage();
        assertTrue(msg.startsWith("Not found"));
        assertTrue(msg.contains("Root cause!"));
        assertTrue(msg.contains("Cause:"));
        assertEquals(cause, ex.getCause());
    }

    @Test
    void testGetMessageWhenRootCauseIsNull() {
        // Simulate a case where there is a cause, but it is null (not common, but for coverage)
        CCServiceException ex = new CCServiceException(HttpStatus.INTERNAL_SERVER_ERROR, "Fallback error", null);
        assertEquals("Fallback error", ex.getMessage());
    }
}