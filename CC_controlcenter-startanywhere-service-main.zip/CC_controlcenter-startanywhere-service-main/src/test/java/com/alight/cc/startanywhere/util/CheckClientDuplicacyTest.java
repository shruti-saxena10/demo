package com.alight.cc.startanywhere.util;

import com.alight.cc.startanywhere.entity.ClientEntity;
import com.alight.cc.startanywhere.exception.DuplicateClientException;
import com.alight.cc.startanywhere.model.BaseResponse;
import com.alight.cc.startanywhere.repository.ClientRepository;
import com.alight.logging.helpers.InfoTypeLogEventHelper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CheckClientDuplicacyTest {

    @Mock
    ClientRepository clientRepo;

    @InjectMocks
    CheckClientDuplicacy duplicacy;

    @BeforeEach
    void setup() {
        // No-op
    }

    @Test
    void isDuplicateClient_returnsBadRequest_whenClientNameExists() {
        String clientId = "cid";
        String orgName = "org";
        String clientName = "cname";

        when(clientRepo.existsByNameIgnoreCase(clientName)).thenReturn(true);

        try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class);
             MockedStatic<StartAnywhereUtil> utilMock = mockStatic(StartAnywhereUtil.class)) {

            BaseResponse fakeResponse = new BaseResponse();
            utilMock.when(() -> StartAnywhereUtil.buildResponse(any(), any(), any(), any(), any(), any(), any(), any()))
                    .thenReturn(fakeResponse);

            BaseResponse result = duplicacy.isDuplicateClient(clientId, orgName, clientName);
            assertNotNull(result);
          }
    }

    @Test
    void isDuplicateClient_returnsBadRequest_whenClientIdOrOrgNameAlreadyExists() {
        String clientId = "cid";
        String orgName = "org";
        String clientName = "cname";

        // any of these combinations should trigger the duplicate logic
        when(clientRepo.existsByNameIgnoreCase(clientName)).thenReturn(false);

        // (entityClientId != null && entityOrgName != null)
        when(clientRepo.findByClientIdIgnoreCase(clientId)).thenReturn(new ClientEntity());
        when(clientRepo.findByOrgNameIgnoreCase(orgName)).thenReturn(new ClientEntity());

        try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class);
             MockedStatic<StartAnywhereUtil> utilMock = mockStatic(StartAnywhereUtil.class)) {

            BaseResponse fakeResponse = new BaseResponse();
            utilMock.when(() -> StartAnywhereUtil.buildResponse(any(), any(), any(), any(), any(), any(), any(), any()))
                    .thenReturn(fakeResponse);

            BaseResponse result = duplicacy.isDuplicateClient(clientId, orgName, clientName);
//            assertNotNull(result);
//            assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
//            assertSame(fakeResponse, result.getBody());
//            logMock.verify(() -> InfoTypeLogEventHelper.logInfoEvent(any(), contains("Duplicate client")), times(1));
        }
    }

    @Test
    void isDuplicateClient_returnsBadRequest_whenOnlyOrgNameExists() {
        String clientId = "cid";
        String orgName = "org";
        String clientName = "cname";

        when(clientRepo.existsByNameIgnoreCase(clientName)).thenReturn(false);
        when(clientRepo.findByClientIdIgnoreCase(clientId)).thenReturn(null);
        when(clientRepo.findByOrgNameIgnoreCase(orgName)).thenReturn(new ClientEntity());

        try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class);
             MockedStatic<StartAnywhereUtil> utilMock = mockStatic(StartAnywhereUtil.class)) {

            BaseResponse fakeResponse = new BaseResponse();
            utilMock.when(() -> StartAnywhereUtil.buildResponse(any(), any(), any(), any(), any(), any(), any(), any()))
                    .thenReturn(fakeResponse);

            BaseResponse result = duplicacy.isDuplicateClient(clientId, orgName, clientName);
            assertNotNull(result);
//            assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
//            assertSame(fakeResponse, result.getBody());
//            logMock.verify(() -> InfoTypeLogEventHelper.logInfoEvent(any(), contains("Duplicate client")), times(1));
        }
    }

    @Test
    void isDuplicateClient_returnsBadRequest_whenOnlyClientIdExists() {
        String clientId = "cid";
        String orgName = "org";
        String clientName = "cname";

        when(clientRepo.existsByNameIgnoreCase(clientName)).thenReturn(false);
        when(clientRepo.findByClientIdIgnoreCase(clientId)).thenReturn(new ClientEntity());
        when(clientRepo.findByOrgNameIgnoreCase(orgName)).thenReturn(null);

        try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class);
             MockedStatic<StartAnywhereUtil> utilMock = mockStatic(StartAnywhereUtil.class)) {

            BaseResponse fakeResponse = new BaseResponse();
            utilMock.when(() -> StartAnywhereUtil.buildResponse(any(), any(), any(), any(), any(), any(), any(), any()))
                    .thenReturn(fakeResponse);

            BaseResponse result = duplicacy.isDuplicateClient(clientId, orgName, clientName);
            assertNotNull(result);
//            assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
//            assertSame(fakeResponse, result.getBody());
//            logMock.verify(() -> InfoTypeLogEventHelper.logInfoEvent(any(), contains("Duplicate client")), times(1));
        }
    }

    @Test
    void isDuplicateClient_returnsNull_whenNoDuplicate() {
        String clientId = "cid";
        String orgName = "org";
        String clientName = "cname";

        when(clientRepo.existsByNameIgnoreCase(clientName)).thenReturn(false);
        when(clientRepo.findByClientIdIgnoreCase(clientId)).thenReturn(null);
        when(clientRepo.findByOrgNameIgnoreCase(orgName)).thenReturn(null);

        BaseResponse result = duplicacy.isDuplicateClient(clientId, orgName, clientName);
        assertNull(result);
    }
}