package com.alight.cc.startanywhere.configuration;

import static org.hamcrest.CoreMatchers.any;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.Mockito.mockStatic;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockedStatic;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.alight.cc.startanywhere.saviynt.model.LoginData;
import com.alight.cloud.data.store.util.DockerSecretsUtil;
import com.aonhewitt.exceptions.AHBaseException;
import com.aonhewitt.logging.events.ErrorLogEvent;
import com.aonhewitt.logging.helpers.ErrorLogEventHelper;

@ExtendWith(SpringExtension.class)
class SaviyntLoginTest {

    @InjectMocks
    private SaviyntLogin saviyntLogin;

   
    @BeforeEach
    void setup() throws Exception {
        saviyntLogin = new SaviyntLogin();
        setField("profile", "prod"); // default non-localdev
    }

    void setField(String name, Object value) throws Exception {
        Field field = SaviyntLogin.class.getDeclaredField(name);
        field.setAccessible(true);
        field.set(saviyntLogin, value);
    }

    // ✅ 1. Secrets contain both username and password
    @Test
    void testLoadLoginData_success() {
        Map<String, String> secrets = new HashMap<>();
        secrets.put("controlcenter.startanywhere.saviynt.username", "user1 ");
        secrets.put("controlcenter.startanywhere.saviynt.password", "pass1 ");

        try (MockedStatic<DockerSecretsUtil> mocked = mockStatic(DockerSecretsUtil.class)) {
            mocked.when(DockerSecretsUtil::load).thenReturn(secrets);

            LoginData data = saviyntLogin.loadLoginData();
            assertNotNull(data);
            assertEquals("user1", data.getUsername());
            assertEquals("pass1", data.getPassword());
        }
    }

    // ✅ 2. Secrets missing username, profile ≠ localdev → logs error
    @Test
    void testLoadLoginData_missingUsername_logsError() {
        Map<String, String> secrets = new HashMap<>();
        secrets.put("controlcenter.startanywhere.saviynt.password", "pass1");

        try (MockedStatic<DockerSecretsUtil> mocked = mockStatic(DockerSecretsUtil.class)) {
            mocked.when(DockerSecretsUtil::load).thenReturn(secrets);

            LoginData data = saviyntLogin.loadLoginData();
            assertNull(data); // username missing
        }
    }

    // ✅ 3. Secrets missing password, profile ≠ localdev → logs error
    @Test
    void testLoadLoginData_missingPassword_logsError() {
        Map<String, String> secrets = new HashMap<>();
        secrets.put("controlcenter.startanywhere.saviynt.username", "user1");

        try (MockedStatic<DockerSecretsUtil> mocked = mockStatic(DockerSecretsUtil.class)) {
            mocked.when(DockerSecretsUtil::load).thenReturn(secrets);

            LoginData data = saviyntLogin.loadLoginData();
            assertNull(data); // password missing
        }
    }

    // ✅ 4. Secrets missing both, profile = localdev → no logging
    @Test
    void testLoadLoginData_localdev_skipsLogging() throws Exception {
        setField("profile", "localdev");

        Map<String, String> secrets = new HashMap<>(); // empty
        try (MockedStatic<DockerSecretsUtil> mocked = mockStatic(DockerSecretsUtil.class)) {
            mocked.when(DockerSecretsUtil::load).thenReturn(secrets);

            LoginData data = saviyntLogin.loadLoginData();
            assertNull(data); // no secrets
        }
    }

    // ✅ 5. getLoginData() lazy loads once
    @Test
    void testGetLoginData_lazyLoad() {
        Map<String, String> secrets = new HashMap<>();
        secrets.put("controlcenter.startanywhere.saviynt.username", "lazyuser");
        secrets.put("controlcenter.startanywhere.saviynt.password", "lazypass");

        try (MockedStatic<DockerSecretsUtil> mocked = mockStatic(DockerSecretsUtil.class)) {
            mocked.when(DockerSecretsUtil::load).thenReturn(secrets);

            LoginData data1 = saviyntLogin.getLoginData();
            LoginData data2 = saviyntLogin.getLoginData();

            assertSame(data1, data2); // cached
            assertEquals("lazyuser", data1.getUsername());
        }
    }

    // ✅ 6. @PostConstruct init() loads loginData
    @Test
    void testInit_postConstruct() {
        Map<String, String> secrets = new HashMap<>();
        secrets.put("controlcenter.startanywhere.saviynt.username", "inituser");
        secrets.put("controlcenter.startanywhere.saviynt.password", "initpass");

        try (MockedStatic<DockerSecretsUtil> mocked = mockStatic(DockerSecretsUtil.class)) {
            mocked.when(DockerSecretsUtil::load).thenReturn(secrets);

            saviyntLogin.init(); // simulate @PostConstruct
            LoginData data = saviyntLogin.getLoginData();

            assertEquals("inituser", data.getUsername());
            assertEquals("initpass", data.getPassword());
        }
    }
    @Test
    void testLoadLoginData_missingUsername_andLogs() throws Exception {
        Map<String, String> secrets = new HashMap<>();
        secrets.put("controlcenter.startanywhere.saviynt.password", "secret-password");

        AHBaseException exception = new AHBaseException(); // concrete instance

        try (
            MockedStatic<DockerSecretsUtil> dockerMock = mockStatic(DockerSecretsUtil.class);
            MockedStatic<ErrorLogEventHelper> logMock = mockStatic(ErrorLogEventHelper.class)
        ) {
            dockerMock.when(DockerSecretsUtil::load).thenReturn(secrets);

            // Stub log call so it's callable with expected args
            logMock.when(() -> ErrorLogEventHelper.logErrorEvent(
                SaviyntLogin.class.getName(),
                "controlcenter.startanywhere.saviynt.username is not configured in secret",
                "getSaviyntLogin",
                exception,
                ErrorLogEvent.ERROR_SEVERITY
            )).thenCallRealMethod();

            LoginData data = saviyntLogin.loadLoginData();
            assertNull(data);
        }
    }

    @Test
    void testLoadLoginData_missingPassword_andLogs() throws Exception {
        Map<String, String> secrets = new HashMap<>();
        secrets.put("controlcenter.startanywhere.saviynt.username", "secret-user");

        AHBaseException exception = new AHBaseException(); // concrete instance

        try (
            MockedStatic<DockerSecretsUtil> dockerMock = mockStatic(DockerSecretsUtil.class);
            MockedStatic<ErrorLogEventHelper> logMock = mockStatic(ErrorLogEventHelper.class)
        ) {
            dockerMock.when(DockerSecretsUtil::load).thenReturn(secrets);

            // Stub log call with concrete args
            logMock.when(() -> ErrorLogEventHelper.logErrorEvent(
                SaviyntLogin.class.getName(),
                "controlcenter.startanywhere.saviynt.password is not configured in secret",
                "getSaviyntLogin",
                exception,
                ErrorLogEvent.ERROR_SEVERITY
            )).thenCallRealMethod();

            LoginData data = saviyntLogin.loadLoginData();
            assertNull(data);
        }
    }

}
