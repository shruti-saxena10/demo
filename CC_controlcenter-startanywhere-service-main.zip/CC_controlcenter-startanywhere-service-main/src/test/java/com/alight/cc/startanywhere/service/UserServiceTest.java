package com.alight.cc.startanywhere.service;

import com.alight.cc.model.DomainLookup;
import com.alight.cc.model.DomainLookupType;
import com.alight.cc.repository.DomainLookupRepository;
import com.alight.cc.startanywhere.configuration.SaviyntLogin;
import com.alight.cc.startanywhere.feign.SaviyntClient;
import com.alight.cc.startanywhere.saviynt.model.GetUserRequest;
import com.alight.cc.startanywhere.saviynt.model.LoginData;
import com.alight.cc.startanywhere.saviynt.model.User;
import com.alight.cc.startanywhere.saviynt.model.UserDetailsResponse;
import com.alight.cc.startanywhere.util.SaviyntRequestBuilder;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;
import com.alight.cc.startanywhere.util.StartAnywhereUtil;
import com.alight.logging.helpers.InfoTypeLogEventHelper;
import com.aonhewitt.logging.helpers.DebugLogEventHelper;
import com.aonhewitt.logging.events.ErrorLogEvent;
import com.aonhewitt.logging.helpers.ErrorLogEventHelper;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Mock
    SaviyntClient saviyntClient;

    @Mock
    SaviyntLogin saviyntLogin;

    @Mock
    SaviyntRequestBuilder saviyntRequestBuilder;
    
    @Mock
    private DomainLookupRepository domainLookupRepository;

    @InjectMocks
    UserService userService;

    @Test
    void getAccessToken_tokenReturnedSuccessfully() {
        LoginData loginData = new LoginData();
        JSONObject token = new JSONObject();
        token.put(StartAnyWhereConstants.ACCESS_TOKEN_KEY, "mytoken");

        when(saviyntLogin.getLoginData()).thenReturn(loginData);
        when(saviyntClient.getAuthToken(loginData)).thenReturn(token);

        String result = userService.getAccessToken();
        assertEquals("mytoken", result);
    }

    @Test
    void getAccessToken_loginNull_returnsNull() {
        userService.saviyntLogin = null;
        String result = userService.getAccessToken();
        assertNull(result);
    }

    @Test
    void getAccessToken_loginDataNull_returnsNull() {
        when(saviyntLogin.getLoginData()).thenReturn(null);
        String result = userService.getAccessToken();
        assertNull(result);
    }

//    @Test
//    void getAccessToken_exceptionLogsErrorAndReturnsNull() {
//    	LoginData loginData = new LoginData();
//
//        when(saviyntLogin.getLoginData()).thenReturn(loginData);
//        when(saviyntClient.getAuthToken(loginData)).thenThrow(new RuntimeException("fail"));
//
//        try (MockedStatic<ErrorLogEventHelper> errorLogMock = mockStatic(ErrorLogEventHelper.class)) {
//            String result = userService.getAccessToken();
//            assertNull(result);
//            errorLogMock.verify(() -> ErrorLogEventHelper.logErrorEvent(
//                    any(), contains("Exception occurred while getting access token"), any(), any(), any()), times(1));
//        }
//    }

    @Test
    void getUserProfile_validResponseOneUser() {
        String email = "test@email.com";
        String accessToken = "t0k3n";
        GetUserRequest builtReq = GetUserRequest.builder().userQuery("query").build();

        when(saviyntRequestBuilder.buildGetUserQuery(email)).thenReturn("query");

        User user = new User();
        UserDetailsResponse detailsResponse = new UserDetailsResponse();
        detailsResponse.setStatusCode(HttpStatus.OK.value());
        detailsResponse.setUserdetails(List.of(user));

        try (MockedStatic<StartAnywhereUtil> utilMock = mockStatic(StartAnywhereUtil.class);
             MockedStatic<InfoTypeLogEventHelper> infoLogMock = mockStatic(InfoTypeLogEventHelper.class)) {

            when(saviyntClient.getUser(anyString(), any(GetUserRequest.class))).thenReturn(detailsResponse);
            utilMock.when(() -> StartAnywhereUtil.calculateSaviyntStatusCode(HttpStatus.OK.value()))
                    .thenReturn(HttpStatus.OK.value());

            User result = userService.getUserProfile(email, accessToken);

            assertEquals(user, result);
            infoLogMock.verify(() ->
                    InfoTypeLogEventHelper.logInfoEvent(eq(UserService.class.getName()), contains("Response from get user: ")), times(1));
        }
    }

    @Test
    void getUserProfile_validResponseMultipleUsers_logsDebug() {
        String email = "test@email.com";
        String accessToken = "t0k3n";
        GetUserRequest builtReq = GetUserRequest.builder().userQuery("query").build();

        when(saviyntRequestBuilder.buildGetUserQuery(email)).thenReturn("query");

        User user1 = new User();
        User user2 = new User();
        UserDetailsResponse detailsResponse = new UserDetailsResponse();
        detailsResponse.setStatusCode(HttpStatus.OK.value());
        detailsResponse.setUserdetails(List.of(user1, user2));

        try (MockedStatic<StartAnywhereUtil> utilMock = mockStatic(StartAnywhereUtil.class);
             MockedStatic<InfoTypeLogEventHelper> infoLogMock = mockStatic(InfoTypeLogEventHelper.class);
             MockedStatic<DebugLogEventHelper> debugLogMock = mockStatic(DebugLogEventHelper.class)) {

            when(saviyntClient.getUser(anyString(), any(GetUserRequest.class))).thenReturn(detailsResponse);
            utilMock.when(() -> StartAnywhereUtil.calculateSaviyntStatusCode(HttpStatus.OK.value()))
                    .thenReturn(HttpStatus.OK.value());

            User result = userService.getUserProfile(email, accessToken);

            assertEquals(user1, result);
            debugLogMock.verify(() ->
                    DebugLogEventHelper.logDebugEvent(eq(UserService.class.getName()), contains("More than one user with email found"), eq("getUserProfile"), contains(email)), times(1));
        }
    }

    @Test
    void getUserProfile_nonOkStatus_returnsNull() {
        String email = "test@email.com";
        String accessToken = "t0k3n";
        when(saviyntRequestBuilder.buildGetUserQuery(email)).thenReturn("query");

        UserDetailsResponse detailsResponse = new UserDetailsResponse();
        detailsResponse.setStatusCode(HttpStatus.BAD_REQUEST.value());
        detailsResponse.setUserdetails(List.of());

        try (MockedStatic<StartAnywhereUtil> utilMock = mockStatic(StartAnywhereUtil.class);
             MockedStatic<InfoTypeLogEventHelper> infoLogMock = mockStatic(InfoTypeLogEventHelper.class)) {

            when(saviyntClient.getUser(anyString(), any(GetUserRequest.class))).thenReturn(detailsResponse);
            utilMock.when(() -> StartAnywhereUtil.calculateSaviyntStatusCode(HttpStatus.BAD_REQUEST.value()))
                    .thenReturn(HttpStatus.BAD_REQUEST.value());

            User result = userService.getUserProfile(email, accessToken);

            assertNull(result);
        }
    }

    @Test
    void getUserProfile_emptyUserDetails_returnsNull() {
        String email = "test@email.com";
        String accessToken = "t0k3n";
        when(saviyntRequestBuilder.buildGetUserQuery(email)).thenReturn("query");

        UserDetailsResponse detailsResponse = new UserDetailsResponse();
        detailsResponse.setStatusCode(HttpStatus.OK.value());
        detailsResponse.setUserdetails(List.of());

        try (MockedStatic<StartAnywhereUtil> utilMock = mockStatic(StartAnywhereUtil.class);
             MockedStatic<InfoTypeLogEventHelper> infoLogMock = mockStatic(InfoTypeLogEventHelper.class)) {

            when(saviyntClient.getUser(anyString(), any(GetUserRequest.class))).thenReturn(detailsResponse);
            utilMock.when(() -> StartAnywhereUtil.calculateSaviyntStatusCode(HttpStatus.OK.value()))
                    .thenReturn(HttpStatus.OK.value());

            User result = userService.getUserProfile(email, accessToken);

            assertNull(result);
        }
    }
    
    @Test
    void testDetermineUserType_ExternalDomain() {
        String email = "user@company.com";
        DomainLookup domainLookup = new DomainLookup();
        domainLookup.setDomainName("external");
        domainLookup.setDomainType(DomainLookupType.internal);
        domainLookup.setId(1L);
        
        List<DomainLookup> internalDomains = new ArrayList<>();
        internalDomains.add(domainLookup);

        when(domainLookupRepository.findByDomainType(DomainLookupType.internal))
            .thenReturn(internalDomains);

        assertEquals("external", userService.determineUserTypeByEmailDomain(email));
    }

      @Test
    void testDetermineUserType_InternalDomain() {
        String email = "user@alight.com";
        DomainLookup domainLookup = new DomainLookup();
        domainLookup.setDomainName("alight.com");
        domainLookup.setDomainType(DomainLookupType.internal);
        domainLookup.setId(1L);
        
        List<DomainLookup> internalDomains = new ArrayList<>();
        internalDomains.add(domainLookup);

        when(domainLookupRepository.findByDomainType(DomainLookupType.internal))
            .thenReturn(internalDomains);

        assertEquals("internal", userService.determineUserTypeByEmailDomain(email));
    }
}
