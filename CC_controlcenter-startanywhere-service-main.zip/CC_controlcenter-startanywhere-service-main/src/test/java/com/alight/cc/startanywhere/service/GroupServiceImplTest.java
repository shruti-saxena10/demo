package com.alight.cc.startanywhere.service;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.alight.cc.startanywhere.entity.ClientOnboardingRequestTrackEntity;
import com.alight.cc.startanywhere.model.ClientConfigError;
import com.alight.cc.startanywhere.model.CreateGroupsResponse;
import com.alight.cc.startanywhere.repository.ClientOnboardingRequestTrackRepository;
import com.alight.cc.startanywhere.service.impl.GroupServiceImpl;
import com.alight.cc.startanywhere.service.impl.AsyncGroupServiceImpl;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;
import com.alight.cc.startanywhere.util.StartAnywhereSecurityUtil;
import com.alight.cc.startanywhere.util.StartAnywhereUtil;
import com.alight.asg.model.header.v1_0.RequestHeader;
import com.alight.cc.startanywhere.configuration.SaviyntConfigurationBean;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.util.List;

class GroupServiceImplTest {

    @InjectMocks
    private GroupServiceImpl groupService;

    @Mock
    private ClientOnboardingRequestTrackRepository trackRepo;

    @Mock
    private SaviyntConfigurationBean configBean;

    @Mock
    private AsyncGroupServiceImpl asyncGroupServiceImpl;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // ✅ Case 1: Empty correlationId
    @Test
    void testEmptyCorrelationId_returnsBadRequest() {
        try (
            MockedStatic<StartAnywhereSecurityUtil> securityUtilMock = mockStatic(StartAnywhereSecurityUtil.class);
            MockedStatic<RequestHeader> requestHeaderMock = mockStatic(RequestHeader.class);
            MockedStatic<StartAnywhereUtil> utilMock = mockStatic(StartAnywhereUtil.class)
        ) {
            securityUtilMock.when(() -> StartAnywhereSecurityUtil.unCleanIt(anyString()))
                            .thenReturn("cleaned");

            RequestHeader mockHeader = mock(RequestHeader.class);
            when(mockHeader.getCorrelationId()).thenReturn("");
            requestHeaderMock.when(() -> RequestHeader.parse(anyString()))
                             .thenReturn(mockHeader);

            CreateGroupsResponse expected = new CreateGroupsResponse();
            utilMock.when(() -> StartAnywhereUtil.buildResponse(eq(expected),
                    eq(StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST),
                    eq(StartAnyWhereConstants.MISSING_REQUIRED_PARAMETERS_MESSAGE),
                    any(), any(), any(), any(), any()))
                    .thenReturn(expected);

            CreateGroupsResponse actual = groupService.checkValidationBeforeAsync("token", "header", "clientId", "clientName");

            assertEquals(expected, actual);
        }
    }

    // ✅ Case 2a: trackEntity exists, status = 0, hitCount < limit
    @Test
    void testTrackEntityInProgress_hitCountBelowLimit() {
        try (
            MockedStatic<StartAnywhereSecurityUtil> securityUtilMock = mockStatic(StartAnywhereSecurityUtil.class);
            MockedStatic<RequestHeader> requestHeaderMock = mockStatic(RequestHeader.class);
            MockedStatic<StartAnywhereUtil> utilMock = mockStatic(StartAnywhereUtil.class)
        ) {
            securityUtilMock.when(() -> StartAnywhereSecurityUtil.unCleanIt(anyString()))
                            .thenReturn("cleaned");

            RequestHeader mockHeader = mock(RequestHeader.class);
            when(mockHeader.getCorrelationId()).thenReturn("corr123");
            requestHeaderMock.when(() -> RequestHeader.parse(anyString()))
                             .thenReturn(mockHeader);

            ClientOnboardingRequestTrackEntity entity = new ClientOnboardingRequestTrackEntity();
            entity.setStatus(0);
            entity.setHitCount(1);
            when(configBean.getHitCount()).thenReturn(5);
            when(trackRepo.findByCorrelationIdAndClientId("corr123", "clientId")).thenReturn(entity);

            CreateGroupsResponse expected = new CreateGroupsResponse();
            utilMock.when(() -> StartAnywhereUtil.buildResponse(eq(expected),
                    eq(StartAnyWhereConstants.HTTP_STATUS_SUCCESS),
                    eq(StartAnyWhereConstants.REQUEST_ALREADY_IN_PROGRESS),
                    any(), any(), any(), any(), any()))
                    .thenReturn(expected);

            CreateGroupsResponse actual = groupService.checkValidationBeforeAsync("token", "header", "clientId", "clientName");

            verify(trackRepo).save(entity);
            assertEquals(expected, actual);
        }
    }

    // ✅ Case 2b: trackEntity exists, status = 0, hitCount >= limit
    @Test
    void testTrackEntityInProgress_rateLimitExceeded() {
        try (
            MockedStatic<StartAnywhereSecurityUtil> securityUtilMock = mockStatic(StartAnywhereSecurityUtil.class);
            MockedStatic<RequestHeader> requestHeaderMock = mockStatic(RequestHeader.class);
            MockedStatic<StartAnywhereUtil> utilMock = mockStatic(StartAnywhereUtil.class)
        ) {
            securityUtilMock.when(() -> StartAnywhereSecurityUtil.unCleanIt(anyString()))
                            .thenReturn("cleaned");

            RequestHeader mockHeader = mock(RequestHeader.class);
            when(mockHeader.getCorrelationId()).thenReturn("corr123");
            requestHeaderMock.when(() -> RequestHeader.parse(anyString()))
                             .thenReturn(mockHeader);

            ClientOnboardingRequestTrackEntity entity = new ClientOnboardingRequestTrackEntity();
            entity.setStatus(0);
            entity.setHitCount(5);
            when(configBean.getHitCount()).thenReturn(5);
            when(configBean.getFallbackTime()).thenReturn(30);
            when(trackRepo.findByCorrelationIdAndClientId("corr123", "clientId")).thenReturn(entity);

            CreateGroupsResponse expected = new CreateGroupsResponse();
            utilMock.when(() -> StartAnywhereUtil.buildResponse(eq(expected),
                    eq(StartAnyWhereConstants.HTTP_STATUS_RATE_LIMIT_EXCEEDED),
                    eq(String.format(StartAnyWhereConstants.RATE_LIMIT_EXCEEDED, 30)),
                    any(), any(), eq(StartAnyWhereConstants.HIGH), any(), any()))
                    .thenReturn(expected);

            CreateGroupsResponse actual = groupService.checkValidationBeforeAsync("token", "header", "clientId", "clientName");

            assertEquals(expected, actual);
        }
    }

    // ✅ Case 2c: trackEntity exists, status != 0
    @Test
    void testTrackEntityCompleted() {
        try (
            MockedStatic<StartAnywhereSecurityUtil> securityUtilMock = mockStatic(StartAnywhereSecurityUtil.class);
            MockedStatic<RequestHeader> requestHeaderMock = mockStatic(RequestHeader.class);
            MockedStatic<StartAnywhereUtil> utilMock = mockStatic(StartAnywhereUtil.class)
        ) {
            securityUtilMock.when(() -> StartAnywhereSecurityUtil.unCleanIt(anyString()))
                            .thenReturn("cleaned");

            RequestHeader mockHeader = mock(RequestHeader.class);
            when(mockHeader.getCorrelationId()).thenReturn("corr123");
            requestHeaderMock.when(() -> RequestHeader.parse(anyString()))
                             .thenReturn(mockHeader);

            ClientOnboardingRequestTrackEntity entity = new ClientOnboardingRequestTrackEntity();
            entity.setStatus(1);
            when(trackRepo.findByCorrelationIdAndClientId("corr123", "clientId")).thenReturn(entity);

            CreateGroupsResponse expected = new CreateGroupsResponse();
            utilMock.when(() -> StartAnywhereUtil.buildResponse(eq(expected),
                    eq(StartAnyWhereConstants.HTTP_STATUS_SUCCESS),
                    eq(StartAnyWhereConstants.REQUEST_COMPLETED_SUCCESSFULLY),
                    any(), any(), any(), any(), any()))
                    .thenReturn(expected);

            CreateGroupsResponse actual = groupService.checkValidationBeforeAsync("token", "header", "clientId", "clientName");

            assertEquals(expected, actual);
        }
    }

    // ✅ Case 3: statustrackEntity != null
    @Test
    void testStatusTrackEntityExists_statusZero() {
        try (
            MockedStatic<StartAnywhereSecurityUtil> securityUtilMock = mockStatic(StartAnywhereSecurityUtil.class);
            MockedStatic<RequestHeader> requestHeaderMock = mockStatic(RequestHeader.class);
            MockedStatic<StartAnywhereUtil> utilMock = mockStatic(StartAnywhereUtil.class)
        ) {
            securityUtilMock.when(() -> StartAnywhereSecurityUtil.unCleanIt(anyString()))
                            .thenReturn("cleaned");

            RequestHeader mockHeader = mock(RequestHeader.class);
            when(mockHeader.getCorrelationId()).thenReturn("corr123");
            requestHeaderMock.when(() -> RequestHeader.parse(anyString()))
                             .thenReturn(mockHeader);

            when(trackRepo.findByCorrelationIdAndClientId("corr123", "clientId")).thenReturn(null);

            ClientOnboardingRequestTrackEntity entity = new ClientOnboardingRequestTrackEntity();
            entity.setStatus(0);
            entity.setCorrelationId("corr456");
            when(trackRepo.findByClientId("clientId")).thenReturn(entity);

            CreateGroupsResponse expected = new CreateGroupsResponse();
            utilMock.when(() -> StartAnywhereUtil.buildResponse(eq(expected),
                    eq(StartAnyWhereConstants.HTTP_STATUS_SUCCESS),
                    eq(StartAnyWhereConstants.REQUEST_ALREADY_IN_PROGRESS_WITH_CORR_ID + "corr456"),
                    any(), any(), any(), any(), any()))
                    .thenReturn(expected);

            CreateGroupsResponse actual = groupService.checkValidationBeforeAsync("token", "header", "clientId", "clientName");

            assertEquals(expected, actual);
        }
        
    }
    @Test
    void testStatusTrackEntityExists_statusCompleted() {
        try (
            MockedStatic<StartAnywhereSecurityUtil> securityUtilMock = mockStatic(StartAnywhereSecurityUtil.class);
            MockedStatic<RequestHeader> requestHeaderMock = mockStatic(RequestHeader.class);
            MockedStatic<StartAnywhereUtil> utilMock = mockStatic(StartAnywhereUtil.class)
        ) {
            securityUtilMock.when(() -> StartAnywhereSecurityUtil.unCleanIt(anyString()))
                            .thenReturn("cleaned");

            RequestHeader mockHeader = mock(RequestHeader.class);
            when(mockHeader.getCorrelationId()).thenReturn("corr123");
            requestHeaderMock.when(() -> RequestHeader.parse(anyString()))
                             .thenReturn(mockHeader);

            when(trackRepo.findByCorrelationIdAndClientId("corr123", "clientId")).thenReturn(null);

            ClientOnboardingRequestTrackEntity entity = new ClientOnboardingRequestTrackEntity();
            entity.setStatus(1);
            entity.setCorrelationId("corr789");
            when(trackRepo.findByClientId("clientId")).thenReturn(entity);

            CreateGroupsResponse expected = new CreateGroupsResponse();
            utilMock.when(() -> StartAnywhereUtil.buildResponse(eq(expected),
                    eq(StartAnyWhereConstants.HTTP_STATUS_SUCCESS),
                    eq(StartAnyWhereConstants.REQUEST_COMPLETED_SUCCESSFULLY_WITH_CORR_ID + "corr789"),
                    any(), any(), any(), any(), any()))
                    .thenReturn(expected);

            CreateGroupsResponse actual = groupService.checkValidationBeforeAsync("token", "header", "clientId", "clientName");

            assertEquals(expected, actual);
        }
    }
    @Test
    void testEntitiesNull_triggersAsync() {
        try (
            MockedStatic<StartAnywhereSecurityUtil> securityUtilMock = mockStatic(StartAnywhereSecurityUtil.class);
            MockedStatic<RequestHeader> requestHeaderMock = mockStatic(RequestHeader.class);
            MockedStatic<StartAnywhereUtil> utilMock = mockStatic(StartAnywhereUtil.class)
        ) {
            securityUtilMock.when(() -> StartAnywhereSecurityUtil.unCleanIt(anyString()))
                            .thenReturn("cleaned");

            RequestHeader mockHeader = mock(RequestHeader.class);
            when(mockHeader.getCorrelationId()).thenReturn("corr123");
            requestHeaderMock.when(() -> RequestHeader.parse(anyString()))
                             .thenReturn(mockHeader);

            when(trackRepo.findByCorrelationIdAndClientId("corr123", "clientId")).thenReturn(null);
            when(trackRepo.findByClientId("clientId")).thenReturn(null);

            CreateGroupsResponse expected = new CreateGroupsResponse();
            utilMock.when(() -> StartAnywhereUtil.buildResponse(any(CreateGroupsResponse.class),
                    eq(StartAnyWhereConstants.POS201),
                    eq(StartAnyWhereConstants.REQUEST_SUBMITTED_SUCESSFULLY),
                    any(), any(), any(), any(), any()))
                    .thenReturn(expected);

            CreateGroupsResponse actual = groupService.checkValidationBeforeAsync("token", "header", "clientId", "clientName");

            verify(asyncGroupServiceImpl).createGroupsAsync("token", "cleaned", "clientId", "clientName");
            assertEquals(expected, actual);
        }
    }
    @Test
    void testExceptionThrown_returnsEmptyResponse() {
        try (
            MockedStatic<StartAnywhereSecurityUtil> securityUtilMock = mockStatic(StartAnywhereSecurityUtil.class)
        ) {
            securityUtilMock.when(() -> StartAnywhereSecurityUtil.unCleanIt(anyString()))
                            .thenThrow(new RuntimeException("Unexpected error"));

            CreateGroupsResponse response = groupService.checkValidationBeforeAsync("token", "header", "clientId", "clientName");

            assertNotNull(response);
            assertNull(response.getResponseCode()); // assuming status is null by default
        }
    }

    }
