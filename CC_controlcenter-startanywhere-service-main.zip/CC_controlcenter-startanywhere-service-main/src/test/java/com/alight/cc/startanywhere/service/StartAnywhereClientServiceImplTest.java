package com.alight.cc.startanywhere.service;


import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.postgresql.util.PSQLException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.alight.cc.startanywhere.entity.AttributeRestrictionLookupEntity;
import com.alight.cc.startanywhere.entity.AttributeTypeLookupEntity;
import com.alight.cc.startanywhere.entity.ClientAttributesEntity;
import com.alight.cc.startanywhere.entity.ClientEntity;
import com.alight.cc.startanywhere.entity.ClientMappingEntity;
import com.alight.cc.startanywhere.entity.ClientProfileEntity;
import com.alight.cc.startanywhere.exception.DuplicateClientException;
import com.alight.cc.startanywhere.model.BaseResponse;
import com.alight.cc.startanywhere.model.ClientModel;
import com.alight.cc.startanywhere.repository.AttributeRestrictionLookupRepository;
import com.alight.cc.startanywhere.repository.AttributeTypeLookupRepository;
import com.alight.cc.startanywhere.repository.ClientAttributesRepository;
import com.alight.cc.startanywhere.repository.ClientMappingRepository;
import com.alight.cc.startanywhere.repository.ClientProfileRepository;
import com.alight.cc.startanywhere.repository.ClientRepository;
import com.alight.cc.startanywhere.service.impl.StartAnywhereClientServiceImpl;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;
import com.fasterxml.jackson.core.JsonProcessingException;

@ExtendWith(SpringExtension.class)
public class StartAnywhereClientServiceImplTest {

	@InjectMocks
	StartAnywhereClientServiceImpl serviceMock;

	@Mock
	private ClientRepository clientRepoMock;

	@Mock 
	private ClientAttributesRepository clientAttributesRepoMock;

	@Mock
	private ClientMappingRepository clientMappingRepoMock;

	@Mock
	private ClientProfileRepository clientProfileRepoMock;

	@Mock
	AttributeRestrictionLookupRepository attributeRestrictionLookupRepoMock;

	@Mock
	AttributeTypeLookupRepository attributeTypeLookupRepoMock;

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}


	@Test
	public void testDataIntegrityViolationException() {

		ClientMappingEntity clientMappingEntity = new ClientMappingEntity();
		clientMappingEntity.setCloudCmsProjectId("123456678912345678555555912355555555555545"); // Too long

		doThrow(new DataIntegrityViolationException("CloudCmsProjectId exceeds max length"))
		.when(clientMappingRepoMock).save(Mockito.any(ClientMappingEntity.class));

		// Act 
		Exception exception = assertThrows(DataIntegrityViolationException.class, () -> {
			clientMappingRepoMock.save(clientMappingEntity);
		});

		// Assert 
		assertTrue(exception.getMessage().contains("CloudCmsProjectId exceeds max length"));
	}

	@Test
	public void testaddNewclientdetails_DataIntegrityViolationException() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("ABC123");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(false);
		AttributeRestrictionLookupEntity attribRestrictEntity = new AttributeRestrictionLookupEntity();
		attribRestrictEntity.setKey("Location-User-PII");
		attribRestrictEntity.setId(5L);
		List<AttributeRestrictionLookupEntity> attribRestrictEntityList= new ArrayList<>();
		attribRestrictEntityList.add(attribRestrictEntity);

		AttributeTypeLookupEntity attribTypeLookupEntity = new AttributeTypeLookupEntity();
		attribTypeLookupEntity.setId(1L);
		attribTypeLookupEntity.setKey(StartAnyWhereConstants.NO);
		List<AttributeTypeLookupEntity> attributeTypeLookupEntityList = new ArrayList<>();
		attributeTypeLookupEntityList.add(attribTypeLookupEntity);

		ClientEntity client = new ClientEntity();
		client.setClientId(request.getClientId());
		client.setName(request.getClientName());
		client.setEnvironmentId(1L);
		client.setCreatedAt(new Date());
		client.setUpdatedAt(new Date());
		client.setScrmId(request.getClientId());
		client.setOrgName(request.getOrgName());
		client.setLegalName(request.getOrgName());
		client.setLineage(request.getClientId());
		client.setSuperviewRestrict(false);

		ClientProfileEntity clientProfileEntity = new ClientProfileEntity();
		ClientMappingEntity clientMappingEntity = new ClientMappingEntity();
		ClientAttributesEntity  clientAttributesEntity = new ClientAttributesEntity();

		clientProfileEntity.setClient(client);
		clientProfileEntity.setAttributeTypeLookup(attribTypeLookupEntity);
		clientProfileEntity.setCreatedAt(new Date());
		clientProfileEntity.setCreatedBy("admin");
		clientProfileEntity.setUpdatedAt(new Date());
		clientProfileEntity.setUpdatedBy("admin");

		clientMappingEntity.setClient(client);
		clientMappingEntity.setUdpNormalizedClientId(request.getClientId());
		clientMappingEntity.setLiferayOrgId(request.getClientId());
		clientMappingEntity.setScrmId(request.getClientId());
		clientMappingEntity.setCloudCmsProjectId("1111111111111111111111111111111111111");
		clientMappingEntity.setAssistGcc("");
		clientMappingEntity.setCreatedAt(new Date());
		clientMappingEntity.setCreatedBy("admin");
		clientMappingEntity.setUpdatedAt(new Date());
		clientMappingEntity.setUpdatedBy("admin");

		clientAttributesEntity.setClient(client);
		clientAttributesEntity.setAttributeRestrictionLookup(attribRestrictEntity);
		clientAttributesEntity.setAttributeTypeLookup(attribTypeLookupEntity);
		clientAttributesEntity.setComment("comment");
		clientAttributesEntity.setCreatedAt(new Date());
		clientAttributesEntity.setCreatedBy("admin");
		clientAttributesEntity.setUpdatedAt(new Date());
		clientAttributesEntity.setUpdatedBy("admin");


		//Mock
		when(attributeRestrictionLookupRepoMock.findAll()).thenReturn(attribRestrictEntityList);


		when(attributeTypeLookupRepoMock.findAll()).thenReturn(attributeTypeLookupEntityList);

		when(attributeTypeLookupRepoMock.findByKey(StartAnyWhereConstants.NO))
		.thenReturn(Optional.of(attribTypeLookupEntity));

		when(attributeTypeLookupRepoMock.findByKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK))
		.thenReturn(Optional.of(attribTypeLookupEntity));

		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(client);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(client);


		doThrow(new DataIntegrityViolationException("Database constraint violated"))
		.when(clientRepoMock)
		.save(client);


		when(clientProfileRepoMock.save(any())).thenReturn(clientProfileEntity);

		doThrow(new DataIntegrityViolationException("Database constraint violation"))
		.when(clientMappingRepoMock)
		.save(any(ClientMappingEntity.class));

		when(clientAttributesRepoMock.save(any())).thenReturn(clientAttributesEntity);

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(400, response.getStatusCode().value());
	}

	@Test
	public void testaddNewclientdetails_InternalServer_ClientID() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("ABC123");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(false);
		AttributeRestrictionLookupEntity attribRestrictEntity = new AttributeRestrictionLookupEntity();
		attribRestrictEntity.setKey("Location-User-PII");
		attribRestrictEntity.setId(5L);
		List<AttributeRestrictionLookupEntity> attribRestrictEntityList= new ArrayList<>();
		attribRestrictEntityList.add(attribRestrictEntity);

		AttributeTypeLookupEntity attribTypeLookupEntity = new AttributeTypeLookupEntity();
		attribTypeLookupEntity.setId(1L);
		attribTypeLookupEntity.setKey(StartAnyWhereConstants.NO);
		List<AttributeTypeLookupEntity> attributeTypeLookupEntityList = new ArrayList<>();
		attributeTypeLookupEntityList.add(attribTypeLookupEntity);
		assertEquals(attribTypeLookupEntity.getKey(), StartAnyWhereConstants.NO);

		ClientEntity client = new ClientEntity();
		client.setClientId(request.getClientId());
		client.setName(request.getClientName());
		client.setEnvironmentId(1L);
		client.setCreatedAt(new Date());
		client.setUpdatedAt(new Date());
		client.setScrmId(request.getClientId());
		client.setOrgName(request.getOrgName());
		client.setLegalName(request.getOrgName());
		client.setLineage(request.getClientId());
		client.setSuperviewRestrict(false);

		ClientProfileEntity clientProfileEntity = new ClientProfileEntity();
		ClientMappingEntity clientMappingEntity = new ClientMappingEntity();
		ClientAttributesEntity  clientAttributesEntity = new ClientAttributesEntity();

		clientProfileEntity.setClient(client);
		clientProfileEntity.setAttributeTypeLookup(attribTypeLookupEntity);
		clientProfileEntity.setCreatedAt(new Date());
		clientProfileEntity.setCreatedBy("admin");
		clientProfileEntity.setUpdatedAt(new Date());
		clientProfileEntity.setUpdatedBy("admin");

		clientMappingEntity.setClient(client);
		clientMappingEntity.setUdpNormalizedClientId(request.getClientId());
		clientMappingEntity.setLiferayOrgId(request.getClientId());
		clientMappingEntity.setScrmId(request.getClientId());
		clientMappingEntity.setCloudCmsProjectId(request.getClientId());
		clientMappingEntity.setAssistGcc("");
		clientMappingEntity.setCreatedAt(new Date());
		clientMappingEntity.setCreatedBy("admin");
		clientMappingEntity.setUpdatedAt(new Date());
		clientMappingEntity.setUpdatedBy("admin");

		clientAttributesEntity.setClient(client);
		clientAttributesEntity.setAttributeRestrictionLookup(attribRestrictEntity);
		clientAttributesEntity.setAttributeTypeLookup(attribTypeLookupEntity);
		clientAttributesEntity.setComment("comment");
		clientAttributesEntity.setCreatedAt(new Date());
		clientAttributesEntity.setCreatedBy("admin");
		clientAttributesEntity.setUpdatedAt(new Date());
		clientAttributesEntity.setUpdatedBy("admin");


		//Mock
		when(attributeRestrictionLookupRepoMock.findAll()).thenReturn(attribRestrictEntityList);

		when(attributeTypeLookupRepoMock.findAll()).thenReturn(attributeTypeLookupEntityList);

		when(attributeTypeLookupRepoMock.findByKey(StartAnyWhereConstants.NO))
		.thenReturn(Optional.of(attribTypeLookupEntity));

		when(attributeTypeLookupRepoMock.findByKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK))
		.thenReturn(Optional.of(attribTypeLookupEntity));

		doThrow(new RuntimeException("Database error occurred"))
		.when(clientRepoMock)
		.findByClientIdIgnoreCase(Mockito.anyString());
		
		doThrow(new RuntimeException("Database error occurred"))
		.when(clientRepoMock)
		.findByOrgNameIgnoreCase(Mockito.anyString());

		when(clientRepoMock.save(any())).thenReturn(client);

		when(clientProfileRepoMock.save(any())).thenReturn(clientProfileEntity);

		when(clientMappingRepoMock.save(any())).thenReturn(clientMappingEntity);

		when(clientAttributesRepoMock.save(any())).thenReturn(clientAttributesEntity);

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(500, response.getStatusCode().value());
	}
	
	@Test
	public void testaddNewclientdetails_BAD_REQUEST_ClientName() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("ABC123");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(false);


		ClientEntity entity = new ClientEntity();
		entity.setClientId(request.getClientId());
		entity.setOrgName(request.getOrgName());

		//Mock
		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(null);
		when(clientRepoMock.existsByNameIgnoreCase(request.getClientName())).thenReturn(true);

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(400, response.getStatusCode().value());
	}

	@Test
	public void testaddNewclientdetails_BAD_REQUEST_ClientID_OrgName() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("ABC123");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(false);


		ClientEntity entity = new ClientEntity();
		entity.setClientId(request.getClientId());
		entity.setOrgName(request.getOrgName());

		//Mock
		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(entity);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(entity);


		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(400, response.getStatusCode().value());
	}

	@Test
	public void testaddNewclientdetails_BAD_REQUEST_OrgName() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("ABC123");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(false);

		ClientEntity entity = new ClientEntity();
		entity.setClientId(request.getClientId());
		entity.setOrgName(request.getOrgName());

		//Mock
		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(entity);
		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(400, response.getStatusCode().value());
	}



	@Test
	public void testaddNewclientdetails_BAD_REQUEST_ClientID()throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("ABC123");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(false);


		ClientEntity entity = new ClientEntity();
		entity.setClientId(request.getClientId());
		entity.setOrgName(request.getOrgName());

		//Mock
		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(entity);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(null);

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(400, response.getStatusCode().value());
	}
	@Test
	public void testaddNewclientdetails_BAD_REQUEST_ClientID1()throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("ABC123");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(true);


		ClientEntity entity = new ClientEntity();
		entity.setClientId(request.getClientId());
		entity.setOrgName(request.getOrgName());

		//Mock
		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(entity);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(null);
		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(400, response.getStatusCode().value());
	}
	@Test
	public void testaddNewclientdetails_BAD_REQUEST_OrgName1()throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("ABC123");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(true);


		ClientEntity entity = new ClientEntity();
		entity.setClientId(request.getClientId());
		entity.setOrgName(request.getOrgName());

		//Mock
		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(entity);

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(400, response.getStatusCode().value());
	}

	@Test
	public void testaddNewclientdetails_Success_ClientID()throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("ABC123");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(false);

		//Mock
		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(null);
		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(201, response.getStatusCode().value());
	}
	@Test
	public void testaddNewclientdetails_Success_OrgName()throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("ABC123");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(false);


		//Mock
		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(null);
		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(),"test",  request);

		// Assert
		assertNotNull(response);
		assertEquals(201, response.getStatusCode().value());
	}
	@Test
	public void testaddNewclientdetails_Success_ClietId_OrgName()throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("ABC123");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(true);

		//Mock
		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(null);
		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(),"test",  request);

		// Assert
		assertNotNull(response);
		assertEquals(201, response.getStatusCode().value());
	}

	@Test
	public void testaddNewclientdetails_Success_ClinetIdWrongValue_OrgName()throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("ABC123");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(false);


		ClientEntity entity = new ClientEntity();
		entity.setClientId(request.getClientId());
		entity.setOrgName(request.getOrgName());

		//Mock
		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(entity);
		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(),"test",  request);

		// Assert
		assertNotNull(response);
		assertEquals(400, response.getStatusCode().value());
	}
	@Test
	public void testaddNewclientdetails_Success_ClinetId_OrgName_WrongValue()throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("ABC123");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(false);


		ClientEntity entity = new ClientEntity();
		entity.setClientId(request.getClientId());
		entity.setOrgName(request.getOrgName());

		//Mock
		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(entity);
		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(400, response.getStatusCode().value());
	}
	@Test
	public void testaddNewclientdetails_Success_DataRestriction_NO() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("ABC123");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(false);
		AttributeRestrictionLookupEntity attribRestrictEntity = new AttributeRestrictionLookupEntity();
		attribRestrictEntity.setKey("Reason");
		attribRestrictEntity.setId(5L);
		List<AttributeRestrictionLookupEntity> attribRestrictEntityList= new ArrayList<>();
		attribRestrictEntityList.add(attribRestrictEntity);

		AttributeTypeLookupEntity attribTypeLookupEntity = new AttributeTypeLookupEntity();
		attribTypeLookupEntity.setId(7L);
		attribTypeLookupEntity.setKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK);
		List<AttributeTypeLookupEntity> attributeTypeLookupEntityList = new ArrayList<>();
		attributeTypeLookupEntityList.add(attribTypeLookupEntity);

		ClientEntity client = new ClientEntity();
		client.setClientId(request.getClientId());
		client.setName(request.getClientName());
		client.setEnvironmentId(1L);
		client.setCreatedAt(new Date());
		client.setUpdatedAt(new Date());
		client.setScrmId(request.getClientId());
		client.setOrgName(request.getOrgName());
		client.setLegalName(request.getOrgName());
		client.setLineage(request.getClientId());
		client.setSuperviewRestrict(false);

		ClientProfileEntity clientProfileEntity = new ClientProfileEntity();
		ClientMappingEntity clientMappingEntity = new ClientMappingEntity();
		ClientAttributesEntity  clientAttributesEntity = new ClientAttributesEntity();

		clientProfileEntity.setClient(client);
		clientProfileEntity.setAttributeTypeLookup(attribTypeLookupEntity);
		clientProfileEntity.setCreatedAt(new Date());
		clientProfileEntity.setCreatedBy("admin");
		clientProfileEntity.setUpdatedAt(new Date());
		clientProfileEntity.setUpdatedBy("admin");

		clientMappingEntity.setClient(client);
		clientMappingEntity.setUdpNormalizedClientId(request.getClientId());
		clientMappingEntity.setLiferayOrgId(request.getClientId());
		clientMappingEntity.setScrmId(request.getClientId());
		clientMappingEntity.setCloudCmsProjectId(request.getClientId());
		clientMappingEntity.setAssistGcc("");
		clientMappingEntity.setCreatedAt(new Date());
		clientMappingEntity.setCreatedBy("admin");
		clientMappingEntity.setUpdatedAt(new Date());
		clientMappingEntity.setUpdatedBy("admin");

		clientAttributesEntity.setClient(client);
		clientAttributesEntity.setAttributeRestrictionLookup(attribRestrictEntity);
		clientAttributesEntity.setAttributeTypeLookup(attribTypeLookupEntity);
		clientAttributesEntity.setComment(StartAnyWhereConstants.SMARTLAUNCH_BLANK);
		clientAttributesEntity.setCreatedAt(new Date());
		clientAttributesEntity.setCreatedBy("admin");
		clientAttributesEntity.setUpdatedAt(new Date());
		clientAttributesEntity.setUpdatedBy("admin");

		List<AttributeTypeLookupEntity> attributeLookupList = Arrays.asList(new AttributeTypeLookupEntity(), new AttributeTypeLookupEntity());

		AttributeTypeLookupEntity lookupYes = new AttributeTypeLookupEntity();
		lookupYes.setKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK);

		attributeLookupList.set(0, lookupYes);

		//Mock
		when(attributeRestrictionLookupRepoMock.findAll()).thenReturn(attribRestrictEntityList);

		when(attributeTypeLookupRepoMock.findAll()).thenReturn(attributeLookupList);

		when(attributeTypeLookupRepoMock.findByKey(StartAnyWhereConstants.NO))
		.thenReturn(Optional.of(attribTypeLookupEntity));

		when(attributeTypeLookupRepoMock.findByKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK))
		.thenReturn(Optional.of(attribTypeLookupEntity));

		when(clientRepoMock.save(any())).thenReturn(client); 

		when(clientProfileRepoMock.save(any())).thenReturn(clientProfileEntity);

		when(clientMappingRepoMock.save(any())).thenReturn(clientMappingEntity);

		when(clientAttributesRepoMock.save(any())).thenReturn(clientAttributesEntity);

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(201, response.getStatusCode().value());
	}

	@Test
	void testaddNewclientdetails_Success_DataRestriction_NO_ID() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("ABC123");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(false);
		AttributeRestrictionLookupEntity attribRestrictEntity = new AttributeRestrictionLookupEntity();
		attribRestrictEntity.setKey("Location-User-PII");
		attribRestrictEntity.setId(5L);
		List<AttributeRestrictionLookupEntity> attribRestrictEntityList= new ArrayList<>();
		attribRestrictEntityList.add(attribRestrictEntity);

		AttributeTypeLookupEntity attribTypeLookupEntity = new AttributeTypeLookupEntity();
		attribTypeLookupEntity.setId(6L);
		attribTypeLookupEntity.setKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK);
		List<AttributeTypeLookupEntity> attributeTypeLookupEntityList = new ArrayList<>();
		attributeTypeLookupEntityList.add(attribTypeLookupEntity);

		ClientEntity client = new ClientEntity();
		client.setClientId(request.getClientId());
		client.setName(request.getClientName());
		client.setEnvironmentId(1L);
		client.setCreatedAt(new Date());
		client.setUpdatedAt(new Date());
		client.setScrmId(request.getClientId());
		client.setOrgName(request.getOrgName());
		client.setLegalName(request.getOrgName());
		client.setLineage(request.getClientId());
		client.setSuperviewRestrict(false);

		ClientProfileEntity clientProfileEntity = new ClientProfileEntity();
		ClientMappingEntity clientMappingEntity = new ClientMappingEntity();
		ClientAttributesEntity  clientAttributesEntity = new ClientAttributesEntity();

		clientProfileEntity.setClient(client);
		clientProfileEntity.setAttributeTypeLookup(attribTypeLookupEntity);
		clientProfileEntity.setCreatedAt(new Date());
		clientProfileEntity.setCreatedBy("admin");
		clientProfileEntity.setUpdatedAt(new Date());
		clientProfileEntity.setUpdatedBy("admin");

		clientMappingEntity.setClient(client);
		clientMappingEntity.setUdpNormalizedClientId(request.getClientId());
		clientMappingEntity.setLiferayOrgId(request.getClientId());
		clientMappingEntity.setScrmId(request.getClientId());
		clientMappingEntity.setCloudCmsProjectId(request.getClientId());
		clientMappingEntity.setAssistGcc("");
		clientMappingEntity.setCreatedAt(new Date());
		clientMappingEntity.setCreatedBy("admin");
		clientMappingEntity.setUpdatedAt(new Date());
		clientMappingEntity.setUpdatedBy("admin");

		clientAttributesEntity.setClient(client);
		clientAttributesEntity.setAttributeRestrictionLookup(attribRestrictEntity);
		clientAttributesEntity.setAttributeTypeLookup(attribTypeLookupEntity);
		clientAttributesEntity.setComment(StartAnyWhereConstants.SMARTLAUNCH_BLANK);
		clientAttributesEntity.setCreatedAt(new Date());
		clientAttributesEntity.setCreatedBy("admin");
		clientAttributesEntity.setUpdatedAt(new Date());
		clientAttributesEntity.setUpdatedBy("admin");

		List<AttributeTypeLookupEntity> attributeLookupList = Arrays.asList(new AttributeTypeLookupEntity(), new AttributeTypeLookupEntity());

		AttributeTypeLookupEntity lookupYes = new AttributeTypeLookupEntity();
		lookupYes.setKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK);

		attributeLookupList.set(0, lookupYes);


		//Mock
		when(attributeRestrictionLookupRepoMock.findAll()).thenReturn(attribRestrictEntityList);

		when(attributeTypeLookupRepoMock.findAll()).thenReturn(attributeLookupList);

		when(attributeTypeLookupRepoMock.findByKey(StartAnyWhereConstants.NO))
		.thenReturn(Optional.of(attribTypeLookupEntity));

		when(attributeTypeLookupRepoMock.findByKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK))
		.thenReturn(Optional.of(attribTypeLookupEntity));

		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(null);
		when(clientRepoMock.existsByNameIgnoreCase(request.getClientName())).thenReturn(false);

		when(clientRepoMock.save(any())).thenReturn(client);

		when(clientProfileRepoMock.save(any())).thenReturn(clientProfileEntity);

		when(clientMappingRepoMock.save(any())).thenReturn(clientMappingEntity);

		when(clientAttributesRepoMock.save(any())).thenReturn(clientAttributesEntity);

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(201, response.getStatusCode().value());
	}

	@Test
	public void testaddNewclientdetails_Success_DataRestriction_YES() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("00095");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(true);
		AttributeRestrictionLookupEntity attribRestrictEntity = new AttributeRestrictionLookupEntity();
		attribRestrictEntity.setKey("Location-User-PII");
		attribRestrictEntity.setId(5L);
		List<AttributeRestrictionLookupEntity> attribRestrictEntityList= new ArrayList<>();
		attribRestrictEntityList.add(attribRestrictEntity);

		AttributeTypeLookupEntity attribTypeLookupEntity = new AttributeTypeLookupEntity();
		attribTypeLookupEntity.setId(6L);
		attribTypeLookupEntity.setKey(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);
		List<AttributeTypeLookupEntity> attributeTypeLookupEntityList = new ArrayList<>();
		attributeTypeLookupEntityList.add(attribTypeLookupEntity);

		ClientEntity client = new ClientEntity();
		client.setClientId(request.getClientId());
		client.setName(request.getClientName());
		client.setEnvironmentId(1L);
		client.setCreatedAt(new Date());
		client.setUpdatedAt(new Date());
		client.setScrmId(request.getClientId());
		client.setOrgName(request.getOrgName());
		client.setLegalName(request.getOrgName());
		client.setLineage(request.getClientId());
		client.setSuperviewRestrict(true);

		ClientProfileEntity clientProfileEntity = new ClientProfileEntity();
		ClientMappingEntity clientMappingEntity = new ClientMappingEntity();
		ClientAttributesEntity  clientAttributesEntity = new ClientAttributesEntity();

		clientProfileEntity.setClient(client);
		clientProfileEntity.setAttributeTypeLookup(attribTypeLookupEntity);
		clientProfileEntity.setCreatedAt(new Date());
		clientProfileEntity.setCreatedBy("admin");
		clientProfileEntity.setUpdatedAt(new Date());
		clientProfileEntity.setUpdatedBy("admin");

		clientMappingEntity.setClient(client);
		clientMappingEntity.setUdpNormalizedClientId(request.getClientId());
		clientMappingEntity.setLiferayOrgId(request.getClientId());
		clientMappingEntity.setScrmId(request.getClientId());
		clientMappingEntity.setCloudCmsProjectId(request.getClientId());
		clientMappingEntity.setAssistGcc("");
		clientMappingEntity.setCreatedAt(new Date());
		clientMappingEntity.setCreatedBy("admin");
		clientMappingEntity.setUpdatedAt(new Date());
		clientMappingEntity.setUpdatedBy("admin");

		clientAttributesEntity.setClient(client);
		clientAttributesEntity.setAttributeRestrictionLookup(attribRestrictEntity);
		clientAttributesEntity.setAttributeTypeLookup(attribTypeLookupEntity);
		clientAttributesEntity.setComment(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);
		clientAttributesEntity.setCreatedAt(new Date());
		clientAttributesEntity.setCreatedBy("admin");
		clientAttributesEntity.setUpdatedAt(new Date());
		clientAttributesEntity.setUpdatedBy("admin");

		List<AttributeTypeLookupEntity> attributeLookupList = new ArrayList<>();

		AttributeTypeLookupEntity lookupYes = new AttributeTypeLookupEntity();
		lookupYes.setId(1L);
		lookupYes.setKey(StartAnyWhereConstants.YES);

		AttributeTypeLookupEntity lookupNo = new AttributeTypeLookupEntity();
		lookupNo.setId(2L);
		lookupNo.setKey(StartAnyWhereConstants.NO);

		AttributeTypeLookupEntity lookupAlight_Contract = new AttributeTypeLookupEntity();
		lookupAlight_Contract.setId(3L);
		lookupAlight_Contract.setKey("ALIGHT_CONTRACT");

		AttributeTypeLookupEntity lookupThird_Party_Contract = new AttributeTypeLookupEntity();
		lookupThird_Party_Contract.setId(4L);
		lookupThird_Party_Contract.setKey("THIRD_PARTY_CONTRACT");

		AttributeTypeLookupEntity lookupOther = new AttributeTypeLookupEntity();
		lookupOther.setId(5L);
		lookupOther.setKey("OTHER");

		AttributeTypeLookupEntity lookupSmartLanch_defalut = new AttributeTypeLookupEntity();
		lookupSmartLanch_defalut.setId(6L);
		lookupSmartLanch_defalut.setKey(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);

		AttributeTypeLookupEntity lookupSmartLanch_blank = new AttributeTypeLookupEntity();
		lookupSmartLanch_blank.setId(7L);
		lookupSmartLanch_blank.setKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK);

		attributeLookupList.add(lookupYes);
		attributeLookupList.add(lookupNo);
		attributeLookupList.add(lookupAlight_Contract);
		attributeLookupList.add(lookupThird_Party_Contract);
		attributeLookupList.add(lookupOther);
		attributeLookupList.add(lookupSmartLanch_defalut);
		attributeLookupList.add(lookupSmartLanch_blank);

		// Mock 
		when(attributeRestrictionLookupRepoMock.findAll()).thenReturn(attribRestrictEntityList);

		when(attributeTypeLookupRepoMock.findAll()).thenReturn(attributeLookupList);

		when(attributeTypeLookupRepoMock.findByKey(StartAnyWhereConstants.YES))
		.thenReturn(Optional.of(attribTypeLookupEntity));

		when(attributeTypeLookupRepoMock.findByKey(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT))
		.thenReturn(Optional.of(attribTypeLookupEntity));

		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(null);
		when(clientRepoMock.existsByNameIgnoreCase(request.getClientName())).thenReturn(false);

		when(clientRepoMock.save(any())).thenReturn(client); 

		when(clientProfileRepoMock.save(any())).thenReturn(clientProfileEntity);

		when(clientMappingRepoMock.save(any())).thenReturn(clientMappingEntity);

		when(clientAttributesRepoMock.save(any())).thenReturn(clientAttributesEntity);

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(201, response.getStatusCode().value());
	}

	@Test
	public void testaddNewclientdetails_Success_DataRestriction_List_YES() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("00095");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(true);
		AttributeRestrictionLookupEntity attribRestrictEntity = new AttributeRestrictionLookupEntity();
		attribRestrictEntity.setKey("Location-User-PII");
		attribRestrictEntity.setId(5L);
		List<AttributeRestrictionLookupEntity> attribRestrictEntityList= new ArrayList<>();
		attribRestrictEntityList.add(attribRestrictEntity);

		AttributeTypeLookupEntity attribTypeLookupEntity = new AttributeTypeLookupEntity();
		attribTypeLookupEntity.setId(6L);
		attribTypeLookupEntity.setKey(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);
		List<AttributeTypeLookupEntity> attributeTypeLookupEntityList = new ArrayList<>();
		attributeTypeLookupEntityList.add(attribTypeLookupEntity);

		ClientEntity client = new ClientEntity();
		client.setClientId(request.getClientId());
		client.setName(request.getClientName());
		client.setEnvironmentId(1L);
		client.setCreatedAt(new Date());
		client.setUpdatedAt(new Date());
		client.setScrmId(request.getClientId());
		client.setOrgName(request.getOrgName());
		client.setLegalName(request.getOrgName());
		client.setLineage(request.getClientId());
		client.setSuperviewRestrict(true);

		ClientProfileEntity clientProfileEntity = new ClientProfileEntity();
		ClientMappingEntity clientMappingEntity = new ClientMappingEntity();
		ClientAttributesEntity  clientAttributesEntity = new ClientAttributesEntity();

		clientProfileEntity.setClient(client);
		clientProfileEntity.setAttributeTypeLookup(attribTypeLookupEntity);
		clientProfileEntity.setCreatedAt(new Date());
		clientProfileEntity.setCreatedBy("admin");
		clientProfileEntity.setUpdatedAt(new Date());
		clientProfileEntity.setUpdatedBy("admin");

		clientMappingEntity.setClient(client);
		clientMappingEntity.setUdpNormalizedClientId(request.getClientId());
		clientMappingEntity.setLiferayOrgId(request.getClientId());
		clientMappingEntity.setScrmId(request.getClientId());
		clientMappingEntity.setCloudCmsProjectId(request.getClientId());
		clientMappingEntity.setAssistGcc("");
		clientMappingEntity.setCreatedAt(new Date());
		clientMappingEntity.setCreatedBy("admin");
		clientMappingEntity.setUpdatedAt(new Date());
		clientMappingEntity.setUpdatedBy("admin");

		clientAttributesEntity.setClient(client);
		clientAttributesEntity.setAttributeRestrictionLookup(attribRestrictEntity);
		clientAttributesEntity.setAttributeTypeLookup(attribTypeLookupEntity);
		clientAttributesEntity.setComment(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);
		clientAttributesEntity.setCreatedAt(new Date());
		clientAttributesEntity.setCreatedBy("admin");
		clientAttributesEntity.setUpdatedAt(new Date());
		clientAttributesEntity.setUpdatedBy("admin");


		List<AttributeRestrictionLookupEntity> attribRestrictList = new ArrayList<> ();

		AttributeRestrictionLookupEntity entity1 = new AttributeRestrictionLookupEntity();
		entity1.setId(1L);
		entity1.setKey("Location-User-PII");

		AttributeRestrictionLookupEntity entity2 = new AttributeRestrictionLookupEntity();
		entity2.setId(2L);
		entity2.setKey("Location-User-Non-PII");

		AttributeRestrictionLookupEntity entity3 = new AttributeRestrictionLookupEntity();
		entity3.setId(3L);
		entity3.setKey("Location-User-Physical");

		AttributeRestrictionLookupEntity entity4 = new AttributeRestrictionLookupEntity();
		entity4.setId(4L);
		entity4.setKey("Other");

		attribRestrictList.add(entity1);
		attribRestrictList.add(entity2);
		attribRestrictList.add(entity3);
		attribRestrictList.add(entity4);

		List<AttributeTypeLookupEntity> attributeLookupList = new ArrayList<>();

		AttributeTypeLookupEntity lookupYes = new AttributeTypeLookupEntity();
		lookupYes.setId(1L);
		lookupYes.setKey(StartAnyWhereConstants.YES);

		AttributeTypeLookupEntity lookupNo = new AttributeTypeLookupEntity();
		lookupNo.setId(2L);
		lookupNo.setKey(StartAnyWhereConstants.NO);

		AttributeTypeLookupEntity lookupAlight_Contract = new AttributeTypeLookupEntity();
		lookupAlight_Contract.setId(3L);
		lookupAlight_Contract.setKey("ALIGHT_CONTRACT");

		AttributeTypeLookupEntity lookupThird_Party_Contract = new AttributeTypeLookupEntity();
		lookupThird_Party_Contract.setId(4L);
		lookupThird_Party_Contract.setKey("THIRD_PARTY_CONTRACT");

		AttributeTypeLookupEntity lookupOther = new AttributeTypeLookupEntity();
		lookupOther.setId(5L);
		lookupOther.setKey("OTHER");

		AttributeTypeLookupEntity lookupSmartLanch_defalut = new AttributeTypeLookupEntity();
		lookupSmartLanch_defalut.setId(6L);
		lookupSmartLanch_defalut.setKey(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);

		AttributeTypeLookupEntity lookupSmartLanch_blank = new AttributeTypeLookupEntity();
		lookupSmartLanch_blank.setId(7L);
		lookupSmartLanch_blank.setKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK);

		attributeLookupList.add(lookupYes);
		attributeLookupList.add(lookupNo);
		attributeLookupList.add(lookupAlight_Contract);
		attributeLookupList.add(lookupThird_Party_Contract);
		attributeLookupList.add(lookupOther);
		attributeLookupList.add(lookupSmartLanch_defalut);
		attributeLookupList.add(lookupSmartLanch_blank);


		// Mock 

		Assertions.assertEquals(attributeLookupList.get(0).getKey(), StartAnyWhereConstants.YES);
		Assertions.assertEquals(request.getIsDataRestriction(), Boolean.TRUE);	

		when(attributeRestrictionLookupRepoMock.findAll()).thenReturn(attribRestrictList);

		when(attributeTypeLookupRepoMock.findAll()).thenReturn(attributeLookupList);

		when(attributeTypeLookupRepoMock.findByKey(StartAnyWhereConstants.YES))
		.thenReturn(Optional.of(attribTypeLookupEntity));

		when(attributeTypeLookupRepoMock.findByKey(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT))
		.thenReturn(Optional.of(attribTypeLookupEntity));

		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(null);
		when(clientRepoMock.existsByNameIgnoreCase(request.getClientName())).thenReturn(false);

		
		when(clientRepoMock.save(any())).thenReturn(client); 
		
		when(clientProfileRepoMock.save(any())).thenReturn(clientProfileEntity);

		when(clientMappingRepoMock.save(any())).thenReturn(clientMappingEntity);

		when(clientAttributesRepoMock.save(any())).thenReturn(clientAttributesEntity);

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test",  request);

		// Assert
		assertNotNull(response);
		assertEquals(201, response.getStatusCode().value());
	}

	@Test
	public void testaddNewclientdetails_Success_DataRestriction_List_YES1() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("00095");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(true);
		AttributeRestrictionLookupEntity attribRestrictEntity = new AttributeRestrictionLookupEntity();
		attribRestrictEntity.setKey("Location-User-PII");
		attribRestrictEntity.setId(5L);
		List<AttributeRestrictionLookupEntity> attribRestrictEntityList= new ArrayList<>();
		attribRestrictEntityList.add(attribRestrictEntity);

		AttributeTypeLookupEntity attribTypeLookupEntity = new AttributeTypeLookupEntity();
		attribTypeLookupEntity.setId(6L);
		attribTypeLookupEntity.setKey(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);
		List<AttributeTypeLookupEntity> attributeTypeLookupEntityList = new ArrayList<>();
		attributeTypeLookupEntityList.add(attribTypeLookupEntity);

		ClientEntity client = new ClientEntity();
		client.setClientId(request.getClientId());
		client.setName(request.getClientName());
		client.setEnvironmentId(1L);
		client.setCreatedAt(new Date());
		client.setUpdatedAt(new Date());
		client.setScrmId(request.getClientId());
		client.setOrgName(request.getOrgName());
		client.setLegalName(request.getOrgName());
		client.setLineage(request.getClientId());
		client.setSuperviewRestrict(true);

		ClientProfileEntity clientProfileEntity = new ClientProfileEntity();
		ClientMappingEntity clientMappingEntity = new ClientMappingEntity();
		ClientAttributesEntity  clientAttributesEntity = new ClientAttributesEntity();

		clientProfileEntity.setClient(client);
		clientProfileEntity.setAttributeTypeLookup(attribTypeLookupEntity);
		clientProfileEntity.setCreatedAt(new Date());
		clientProfileEntity.setCreatedBy("admin");
		clientProfileEntity.setUpdatedAt(new Date());
		clientProfileEntity.setUpdatedBy("admin");

		clientMappingEntity.setClient(client);
		clientMappingEntity.setUdpNormalizedClientId(request.getClientId());
		clientMappingEntity.setLiferayOrgId(request.getClientId());
		clientMappingEntity.setScrmId(request.getClientId());
		clientMappingEntity.setCloudCmsProjectId(request.getClientId());
		clientMappingEntity.setAssistGcc("");
		clientMappingEntity.setCreatedAt(new Date());
		clientMappingEntity.setCreatedBy("admin");
		clientMappingEntity.setUpdatedAt(new Date());
		clientMappingEntity.setUpdatedBy("admin");

		clientAttributesEntity.setClient(client);
		clientAttributesEntity.setAttributeRestrictionLookup(attribRestrictEntity);
		clientAttributesEntity.setAttributeTypeLookup(attribTypeLookupEntity);
		clientAttributesEntity.setComment(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);
		clientAttributesEntity.setCreatedAt(new Date());
		clientAttributesEntity.setCreatedBy("admin");
		clientAttributesEntity.setUpdatedAt(new Date());
		clientAttributesEntity.setUpdatedBy("admin");


		List<AttributeRestrictionLookupEntity> attribRestrictList = new ArrayList<> ();

		AttributeRestrictionLookupEntity entity1 = new AttributeRestrictionLookupEntity();
		entity1.setId(1L);
		entity1.setKey("Location-User-PII");

		AttributeRestrictionLookupEntity entity2 = new AttributeRestrictionLookupEntity();
		entity2.setId(2L);
		entity2.setKey("Location-User-Non-PII");

		AttributeRestrictionLookupEntity entity3 = new AttributeRestrictionLookupEntity();
		entity3.setId(3L);
		entity3.setKey("Location-User-Physical");

		AttributeRestrictionLookupEntity entity4 = new AttributeRestrictionLookupEntity();
		entity4.setId(4L);
		entity4.setKey("Other");

		AttributeRestrictionLookupEntity entity5 = new AttributeRestrictionLookupEntity();
		entity5.setId(5L);
		entity5.setKey("Reason");

		attribRestrictList.add(entity1);
		attribRestrictList.add(entity2);
		attribRestrictList.add(entity3);
		attribRestrictList.add(entity4);
		attribRestrictList.add(entity5);
		List<AttributeTypeLookupEntity> attributeLookupList = new ArrayList<>();

		AttributeTypeLookupEntity lookupYes = new AttributeTypeLookupEntity();
		lookupYes.setId(1L);
		lookupYes.setKey(StartAnyWhereConstants.YES);

		AttributeTypeLookupEntity lookupNo = new AttributeTypeLookupEntity();
		lookupNo.setId(2L);
		lookupNo.setKey(StartAnyWhereConstants.NO);

		AttributeTypeLookupEntity lookupAlight_Contract = new AttributeTypeLookupEntity();
		lookupAlight_Contract.setId(3L);
		lookupAlight_Contract.setKey("ALIGHT_CONTRACT");

		AttributeTypeLookupEntity lookupThird_Party_Contract = new AttributeTypeLookupEntity();
		lookupThird_Party_Contract.setId(4L);
		lookupThird_Party_Contract.setKey("THIRD_PARTY_CONTRACT");

		AttributeTypeLookupEntity lookupOther = new AttributeTypeLookupEntity();
		lookupOther.setId(5L);
		lookupOther.setKey("OTHER");

		AttributeTypeLookupEntity lookupSmartLanch_defalut = new AttributeTypeLookupEntity();
		lookupSmartLanch_defalut.setId(6L);
		lookupSmartLanch_defalut.setKey(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);

		AttributeTypeLookupEntity lookupSmartLanch_blank = new AttributeTypeLookupEntity();
		lookupSmartLanch_blank.setId(7L);
		lookupSmartLanch_blank.setKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK);

		attributeLookupList.add(lookupYes);
		attributeLookupList.add(lookupNo);
		attributeLookupList.add(lookupAlight_Contract);
		attributeLookupList.add(lookupThird_Party_Contract);
		attributeLookupList.add(lookupOther);
		attributeLookupList.add(lookupSmartLanch_defalut);
		attributeLookupList.add(lookupSmartLanch_blank);


		// Mock 
		when(attributeRestrictionLookupRepoMock.findAll()).thenReturn(attribRestrictList);

		when(attributeTypeLookupRepoMock.findAll()).thenReturn(attributeLookupList);

		Assertions.assertEquals(attributeLookupList.get(0).getKey(), StartAnyWhereConstants.YES);
		Assertions.assertEquals(request.getIsDataRestriction(), Boolean.TRUE);	

		when(attributeTypeLookupRepoMock.findByKey(StartAnyWhereConstants.YES))
		.thenReturn(Optional.of(attribTypeLookupEntity));

		when(attributeTypeLookupRepoMock.findByKey(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT))
		.thenReturn(Optional.of(attribTypeLookupEntity));

		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(null);
		when(clientRepoMock.existsByNameIgnoreCase(request.getClientName())).thenReturn(false);

		when(clientRepoMock.save(any())).thenReturn(client); 

		when(clientProfileRepoMock.save(any())).thenReturn(clientProfileEntity);

		when(clientMappingRepoMock.save(any())).thenReturn(clientMappingEntity);

		when(clientAttributesRepoMock.save(any())).thenReturn(clientAttributesEntity);

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(201, response.getStatusCode().value());
	}
	@Test
	public void testaddNewclientdetails_Success_DataRestriction_List_YES2() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("00095");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(true);
		AttributeRestrictionLookupEntity attribRestrictEntity = new AttributeRestrictionLookupEntity();
		attribRestrictEntity.setKey("Location-User-PII");
		attribRestrictEntity.setId(5L);
		List<AttributeRestrictionLookupEntity> attribRestrictEntityList= new ArrayList<>();
		attribRestrictEntityList.add(attribRestrictEntity);

		AttributeTypeLookupEntity attribTypeLookupEntity = new AttributeTypeLookupEntity();
		attribTypeLookupEntity.setId(6L);
		attribTypeLookupEntity.setKey(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);
		List<AttributeTypeLookupEntity> attributeTypeLookupEntityList = new ArrayList<>();
		attributeTypeLookupEntityList.add(attribTypeLookupEntity);

		ClientEntity client = new ClientEntity();
		client.setClientId(request.getClientId());
		client.setName(request.getClientName());
		client.setEnvironmentId(1L);
		client.setCreatedAt(new Date());
		client.setUpdatedAt(new Date());
		client.setScrmId(request.getClientId());
		client.setOrgName(request.getOrgName());
		client.setLegalName(request.getOrgName());
		client.setLineage(request.getClientId());
		client.setSuperviewRestrict(true);

		ClientProfileEntity clientProfileEntity = new ClientProfileEntity();
		ClientMappingEntity clientMappingEntity = new ClientMappingEntity();
		ClientAttributesEntity  clientAttributesEntity = new ClientAttributesEntity();

		clientProfileEntity.setClient(client);
		clientProfileEntity.setAttributeTypeLookup(attribTypeLookupEntity);
		clientProfileEntity.setCreatedAt(new Date());
		clientProfileEntity.setCreatedBy("admin");
		clientProfileEntity.setUpdatedAt(new Date());
		clientProfileEntity.setUpdatedBy("admin");

		clientMappingEntity.setClient(client);
		clientMappingEntity.setUdpNormalizedClientId(request.getClientId());
		clientMappingEntity.setLiferayOrgId(request.getClientId());
		clientMappingEntity.setScrmId(request.getClientId());
		clientMappingEntity.setCloudCmsProjectId(request.getClientId());
		clientMappingEntity.setAssistGcc("");
		clientMappingEntity.setCreatedAt(new Date());
		clientMappingEntity.setCreatedBy("admin");
		clientMappingEntity.setUpdatedAt(new Date());
		clientMappingEntity.setUpdatedBy("admin");

		clientAttributesEntity.setClient(client);
		clientAttributesEntity.setAttributeRestrictionLookup(attribRestrictEntity);
		clientAttributesEntity.setAttributeTypeLookup(attribTypeLookupEntity);
		clientAttributesEntity.setComment(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);
		clientAttributesEntity.setCreatedAt(new Date());
		clientAttributesEntity.setCreatedBy("admin");
		clientAttributesEntity.setUpdatedAt(new Date());
		clientAttributesEntity.setUpdatedBy("admin");

		List<AttributeRestrictionLookupEntity> attribRestrictList = new ArrayList<> ();

		AttributeRestrictionLookupEntity entity4 = new AttributeRestrictionLookupEntity();
		entity4.setId(5L);
		entity4.setKey("Reason");

		attribRestrictList.add(entity4);

		List<AttributeTypeLookupEntity> attributeLookupList = new ArrayList<>();

		AttributeTypeLookupEntity lookupYes = new AttributeTypeLookupEntity();
		lookupYes.setId(1L);
		lookupYes.setKey(StartAnyWhereConstants.YES);

		AttributeTypeLookupEntity lookupNo = new AttributeTypeLookupEntity();
		lookupNo.setId(2L);
		lookupNo.setKey(StartAnyWhereConstants.NO);

		AttributeTypeLookupEntity lookupAlight_Contract = new AttributeTypeLookupEntity();
		lookupAlight_Contract.setId(3L);
		lookupAlight_Contract.setKey("ALIGHT_CONTRACT");

		AttributeTypeLookupEntity lookupThird_Party_Contract = new AttributeTypeLookupEntity();
		lookupThird_Party_Contract.setId(4L);
		lookupThird_Party_Contract.setKey("THIRD_PARTY_CONTRACT");

		AttributeTypeLookupEntity lookupOther = new AttributeTypeLookupEntity();
		lookupOther.setId(5L);
		lookupOther.setKey("OTHER");

		AttributeTypeLookupEntity lookupSmartLanch_defalut = new AttributeTypeLookupEntity();
		lookupSmartLanch_defalut.setId(6L);
		lookupSmartLanch_defalut.setKey(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);

		AttributeTypeLookupEntity lookupSmartLanch_blank = new AttributeTypeLookupEntity();
		lookupSmartLanch_blank.setId(7L);
		lookupSmartLanch_blank.setKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK);

		attributeLookupList.add(lookupYes);
		attributeLookupList.add(lookupNo);
		attributeLookupList.add(lookupAlight_Contract);
		attributeLookupList.add(lookupThird_Party_Contract);
		attributeLookupList.add(lookupOther);
		attributeLookupList.add(lookupSmartLanch_defalut);
		attributeLookupList.add(lookupSmartLanch_blank);


		// Mock 
		when(attributeRestrictionLookupRepoMock.findAll()).thenReturn(attribRestrictList);

		when(attributeTypeLookupRepoMock.findAll()).thenReturn(attributeLookupList);

		Assertions.assertEquals(attributeLookupList.get(0).getKey(), StartAnyWhereConstants.YES);
		Assertions.assertEquals(request.getIsDataRestriction(), Boolean.TRUE);	

		when(attributeTypeLookupRepoMock.findByKey(StartAnyWhereConstants.YES))
		.thenReturn(Optional.of(attribTypeLookupEntity));

		when(attributeTypeLookupRepoMock.findByKey(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT))
		.thenReturn(Optional.of(attribTypeLookupEntity));

		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(null);
		
		when(clientRepoMock.save(any())).thenReturn(client); 

		when(clientProfileRepoMock.save(any())).thenReturn(clientProfileEntity);

		when(clientMappingRepoMock.save(any())).thenReturn(clientMappingEntity);

		when(clientAttributesRepoMock.save(any())).thenReturn(clientAttributesEntity);

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(201, response.getStatusCode().value());
	}

	@Test
	public void testaddNewclientdetails_Success_DataRestriction_List_No_Yes() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("00095");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(false);

		List<AttributeTypeLookupEntity> attributeLookupList = new ArrayList<>();

		AttributeTypeLookupEntity lookupYes = new AttributeTypeLookupEntity();
		lookupYes.setId(1L);
		lookupYes.setKey(StartAnyWhereConstants.YES);

		AttributeTypeLookupEntity lookupNo = new AttributeTypeLookupEntity();
		lookupNo.setId(2L);
		lookupNo.setKey(StartAnyWhereConstants.NO);

		AttributeTypeLookupEntity lookupAlight_Contract = new AttributeTypeLookupEntity();
		lookupAlight_Contract.setId(3L);
		lookupAlight_Contract.setKey("ALIGHT_CONTRACT");

		AttributeTypeLookupEntity lookupThird_Party_Contract = new AttributeTypeLookupEntity();
		lookupThird_Party_Contract.setId(4L);
		lookupThird_Party_Contract.setKey("THIRD_PARTY_CONTRACT");

		AttributeTypeLookupEntity lookupOther = new AttributeTypeLookupEntity();
		lookupOther.setId(5L);
		lookupOther.setKey("OTHER");

		AttributeTypeLookupEntity lookupSmartLanch_defalut = new AttributeTypeLookupEntity();
		lookupSmartLanch_defalut.setId(6L);
		lookupSmartLanch_defalut.setKey(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);

		AttributeTypeLookupEntity lookupSmartLanch_blank = new AttributeTypeLookupEntity();
		lookupSmartLanch_blank.setId(7L);
		lookupSmartLanch_blank.setKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK);

		attributeLookupList.add(lookupYes);
		attributeLookupList.add(lookupNo);
		attributeLookupList.add(lookupAlight_Contract);
		attributeLookupList.add(lookupThird_Party_Contract);
		attributeLookupList.add(lookupOther);
		attributeLookupList.add(lookupSmartLanch_defalut);
		attributeLookupList.add(lookupSmartLanch_blank);


		List<AttributeRestrictionLookupEntity> attribRestrictList = new ArrayList<> ();

		AttributeRestrictionLookupEntity entity1 = new AttributeRestrictionLookupEntity();
		entity1.setId(1L);
		entity1.setKey("Location-User-PII");

		AttributeRestrictionLookupEntity entity2 = new AttributeRestrictionLookupEntity();
		entity2.setId(2L);
		entity2.setKey("Location-User-Non-PII");

		AttributeRestrictionLookupEntity entity3 = new AttributeRestrictionLookupEntity();
		entity3.setId(3L);
		entity3.setKey("Location-User-Physical");

		AttributeRestrictionLookupEntity entity4 = new AttributeRestrictionLookupEntity();
		entity4.setId(4L);
		entity4.setKey("Other");

		AttributeRestrictionLookupEntity entity5 = new AttributeRestrictionLookupEntity();
		entity5.setId(5L);
		entity5.setKey("Reason");

		attribRestrictList.add(entity1);
		attribRestrictList.add(entity2);
		attribRestrictList.add(entity3);
		attribRestrictList.add(entity4);
		attribRestrictList.add(entity5);


		ClientEntity client = new ClientEntity();
		client.setClientId(request.getClientId());
		client.setName(request.getClientName());
		client.setEnvironmentId(1L);
		client.setCreatedAt(new Date());
		client.setUpdatedAt(new Date());
		client.setScrmId(request.getClientId());
		client.setOrgName(request.getOrgName());
		client.setLegalName(request.getOrgName());
		client.setLineage(request.getClientId());
		client.setSuperviewRestrict(false);

		ClientProfileEntity clientProfileEntity = new ClientProfileEntity();
		ClientMappingEntity clientMappingEntity = new ClientMappingEntity();
		ClientAttributesEntity  clientAttributesEntity = new ClientAttributesEntity();

		clientProfileEntity.setClient(client);
		clientProfileEntity.setAttributeTypeLookup(attributeLookupList.get(1));
		clientProfileEntity.setCreatedAt(new Date());
		clientProfileEntity.setCreatedBy("admin");
		clientProfileEntity.setUpdatedAt(new Date());
		clientProfileEntity.setUpdatedBy("admin");

		clientMappingEntity.setClient(client);
		clientMappingEntity.setUdpNormalizedClientId(request.getClientId());
		clientMappingEntity.setLiferayOrgId(request.getClientId());
		clientMappingEntity.setScrmId(request.getClientId());
		clientMappingEntity.setCloudCmsProjectId(request.getClientId());
		clientMappingEntity.setAssistGcc("");
		clientMappingEntity.setCreatedAt(new Date());
		clientMappingEntity.setCreatedBy("admin");
		clientMappingEntity.setUpdatedAt(new Date());
		clientMappingEntity.setUpdatedBy("admin");

		clientAttributesEntity.setClient(client);
		for(int i=0; i<=attribRestrictList.size()-1; i++) {
			clientAttributesEntity.setAttributeRestrictionLookup(attribRestrictList.get(i));
		}
		for(int i=0; i<=attributeLookupList.size()-1; i++) {
			clientAttributesEntity.setAttributeTypeLookup(attributeLookupList.get(i));
			clientAttributesEntity.setComment(StartAnyWhereConstants.SMARTLAUNCH_BLANK);
		}

		clientAttributesEntity.setCreatedAt(new Date());
		clientAttributesEntity.setCreatedBy("admin");
		clientAttributesEntity.setUpdatedAt(new Date());
		clientAttributesEntity.setUpdatedBy("admin");

		assertNotNull(attribRestrictList);
		assertNotNull(attributeLookupList);

		// Mock 
		when(attributeRestrictionLookupRepoMock.findAll()).thenReturn(attribRestrictList);

		when(attributeTypeLookupRepoMock.findAll()).thenReturn(attributeLookupList);

		Assertions.assertEquals(attributeLookupList.get(0).getKey(), StartAnyWhereConstants.YES);
		Assertions.assertNotEquals(request.getIsDataRestriction(), Boolean.TRUE);	

		Assertions.assertEquals(attributeLookupList.get(1).getKey(), StartAnyWhereConstants.NO);
		Assertions.assertEquals(request.getIsDataRestriction(), Boolean.FALSE);	
		
		when(attributeTypeLookupRepoMock.findByKey(StartAnyWhereConstants.YES))
		.thenReturn(Optional.of(attributeLookupList.get(0)));
		
		when(attributeTypeLookupRepoMock.findByKey(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT))
		.thenReturn(Optional.of(attributeLookupList.get(5)));
		
		when(attributeTypeLookupRepoMock.findByKey(StartAnyWhereConstants.NO))
		.thenReturn(Optional.of(attributeLookupList.get(1)));

		when(attributeTypeLookupRepoMock.findByKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK))
		.thenReturn(Optional.of(attributeLookupList.get(6)));

		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(null);
		
		when(clientRepoMock.save(any())).thenReturn(client);

		when(clientProfileRepoMock.save(any())).thenReturn(clientProfileEntity);

		when(clientMappingRepoMock.save(any())).thenReturn(clientMappingEntity);

		when(clientAttributesRepoMock.save(any())).thenReturn(clientAttributesEntity);

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test",  request);

		// Assert
		assertNotNull(response);
		assertEquals(201, response.getStatusCode().value());
	}
	@Test
	public void testaddNewclientdetails_Success_DataRestriction_List_Yes_No() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("00095");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(true);

		List<AttributeTypeLookupEntity> attributeLookupList = new ArrayList<>();

		AttributeTypeLookupEntity lookupYes = new AttributeTypeLookupEntity();
		lookupYes.setId(1L);
		lookupYes.setKey(StartAnyWhereConstants.YES);

		AttributeTypeLookupEntity lookupNo = new AttributeTypeLookupEntity();
		lookupNo.setId(2L);
		lookupNo.setKey(StartAnyWhereConstants.NO);

		AttributeTypeLookupEntity lookupAlight_Contract = new AttributeTypeLookupEntity();
		lookupAlight_Contract.setId(3L);
		lookupAlight_Contract.setKey("ALIGHT_CONTRACT");

		AttributeTypeLookupEntity lookupThird_Party_Contract = new AttributeTypeLookupEntity();
		lookupThird_Party_Contract.setId(4L);
		lookupThird_Party_Contract.setKey("THIRD_PARTY_CONTRACT");

		AttributeTypeLookupEntity lookupOther = new AttributeTypeLookupEntity();
		lookupOther.setId(5L);
		lookupOther.setKey("OTHER");

		AttributeTypeLookupEntity lookupSmartLanch_defalut = new AttributeTypeLookupEntity();
		lookupSmartLanch_defalut.setId(6L);
		lookupSmartLanch_defalut.setKey(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);

		AttributeTypeLookupEntity lookupSmartLanch_blank = new AttributeTypeLookupEntity();
		lookupSmartLanch_blank.setId(7L);
		lookupSmartLanch_blank.setKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK);

		attributeLookupList.add(lookupYes);
		attributeLookupList.add(lookupNo);
		attributeLookupList.add(lookupAlight_Contract);
		attributeLookupList.add(lookupThird_Party_Contract);
		attributeLookupList.add(lookupOther);
		attributeLookupList.add(lookupSmartLanch_defalut);
		attributeLookupList.add(lookupSmartLanch_blank);


		List<AttributeRestrictionLookupEntity> attribRestrictList = new ArrayList<> ();

		AttributeRestrictionLookupEntity entity1 = new AttributeRestrictionLookupEntity();
		entity1.setId(1L);
		entity1.setKey("Location-User-PII");

		AttributeRestrictionLookupEntity entity2 = new AttributeRestrictionLookupEntity();
		entity2.setId(2L);
		entity2.setKey("Location-User-Non-PII");

		AttributeRestrictionLookupEntity entity3 = new AttributeRestrictionLookupEntity();
		entity3.setId(3L);
		entity3.setKey("Location-User-Physical");

		AttributeRestrictionLookupEntity entity4 = new AttributeRestrictionLookupEntity();
		entity4.setId(4L);
		entity4.setKey("Other");

		AttributeRestrictionLookupEntity entity5 = new AttributeRestrictionLookupEntity();
		entity5.setId(5L);
		entity5.setKey("Reason");

		attribRestrictList.add(entity1);
		attribRestrictList.add(entity2);
		attribRestrictList.add(entity3);
		attribRestrictList.add(entity4);
		attribRestrictList.add(entity5);


		ClientEntity client = new ClientEntity();
		client.setClientId(request.getClientId());
		client.setName(request.getClientName());
		client.setEnvironmentId(1L);
		client.setCreatedAt(new Date());
		client.setUpdatedAt(new Date());
		client.setScrmId(request.getClientId());
		client.setOrgName(request.getOrgName());
		client.setLegalName(request.getOrgName());
		client.setLineage(request.getClientId());
		client.setSuperviewRestrict(true);

		ClientProfileEntity clientProfileEntity = new ClientProfileEntity();
		ClientMappingEntity clientMappingEntity = new ClientMappingEntity();
		ClientAttributesEntity  clientAttributesEntity = new ClientAttributesEntity();

		clientProfileEntity.setClient(client);
		clientProfileEntity.setAttributeTypeLookup(attributeLookupList.get(1));
		clientProfileEntity.setCreatedAt(new Date());
		clientProfileEntity.setCreatedBy("admin");
		clientProfileEntity.setUpdatedAt(new Date());
		clientProfileEntity.setUpdatedBy("admin");

		clientMappingEntity.setClient(client);
		clientMappingEntity.setUdpNormalizedClientId(request.getClientId());
		clientMappingEntity.setLiferayOrgId(request.getClientId());
		clientMappingEntity.setScrmId(request.getClientId());
		clientMappingEntity.setCloudCmsProjectId(request.getClientId());
		clientMappingEntity.setAssistGcc("");
		clientMappingEntity.setCreatedAt(new Date());
		clientMappingEntity.setCreatedBy("admin");
		clientMappingEntity.setUpdatedAt(new Date());
		clientMappingEntity.setUpdatedBy("admin");

		clientAttributesEntity.setClient(client);
		for(int i=0; i<=attribRestrictList.size()-1; i++) {
			clientAttributesEntity.setAttributeRestrictionLookup(attribRestrictList.get(i));
		}
		for(int i=0; i<=attributeLookupList.size()-1; i++) {
			clientAttributesEntity.setAttributeTypeLookup(attributeLookupList.get(i));
			clientAttributesEntity.setComment(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);
		}
		clientAttributesEntity.setCreatedAt(new Date());
		clientAttributesEntity.setCreatedBy("admin");
		clientAttributesEntity.setUpdatedAt(new Date());
		clientAttributesEntity.setUpdatedBy("admin");

		assertNotNull(attribRestrictList);
		assertNotNull(attributeLookupList);

		// Mock 
		when(attributeRestrictionLookupRepoMock.findAll()).thenReturn(attribRestrictList);

		when(attributeTypeLookupRepoMock.findAll()).thenReturn(attributeLookupList);

		Assertions.assertEquals(attributeLookupList.get(0).getKey(), StartAnyWhereConstants.YES);
		Assertions.assertEquals(request.getIsDataRestriction(), Boolean.TRUE);	

		Assertions.assertEquals(attributeLookupList.get(1).getKey(), StartAnyWhereConstants.NO);
		Assertions.assertNotEquals(request.getIsDataRestriction(), Boolean.FALSE);	

		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(null);
		
		when(clientRepoMock.save(any())).thenReturn(client); // Mock saving

		when(clientProfileRepoMock.save(any())).thenReturn(clientProfileEntity);

		when(clientMappingRepoMock.save(any())).thenReturn(clientMappingEntity);

		when(clientAttributesRepoMock.save(any())).thenReturn(clientAttributesEntity);

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(201, response.getStatusCode().value());
	}

	@Test
	public void testaddNewclientdetails_Success_DataRestriction_List_NO_YES1() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("00095");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(Boolean.FALSE);

		List<AttributeTypeLookupEntity> attributeLookupList = new ArrayList<>();

		AttributeTypeLookupEntity lookupYes = new AttributeTypeLookupEntity();
		lookupYes.setId(1L);
		lookupYes.setKey(StartAnyWhereConstants.YES);

		AttributeTypeLookupEntity lookupNo = new AttributeTypeLookupEntity();
		lookupNo.setId(2L);
		lookupNo.setKey(StartAnyWhereConstants.NO);

		AttributeTypeLookupEntity lookupAlight_Contract = new AttributeTypeLookupEntity();
		lookupAlight_Contract.setId(3L);
		lookupAlight_Contract.setKey("ALIGHT_CONTRACT");

		AttributeTypeLookupEntity lookupThird_Party_Contract = new AttributeTypeLookupEntity();
		lookupThird_Party_Contract.setId(4L);
		lookupThird_Party_Contract.setKey("THIRD_PARTY_CONTRACT");

		AttributeTypeLookupEntity lookupOther = new AttributeTypeLookupEntity();
		lookupOther.setId(5L);
		lookupOther.setKey("OTHER");

		AttributeTypeLookupEntity lookupSmartLanch_defalut = new AttributeTypeLookupEntity();
		lookupSmartLanch_defalut.setId(6L);
		lookupSmartLanch_defalut.setKey(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);

		AttributeTypeLookupEntity lookupSmartLanch_blank = new AttributeTypeLookupEntity();
		lookupSmartLanch_blank.setId(7L);
		lookupSmartLanch_blank.setKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK);

		attributeLookupList.add(lookupYes);
		attributeLookupList.add(lookupNo);
		attributeLookupList.add(lookupAlight_Contract);
		attributeLookupList.add(lookupThird_Party_Contract);
		attributeLookupList.add(lookupOther);
		attributeLookupList.add(lookupSmartLanch_defalut);
		attributeLookupList.add(lookupSmartLanch_blank);

		List<AttributeRestrictionLookupEntity> attribRestrictList = new ArrayList<> ();

		AttributeRestrictionLookupEntity entity5 = new AttributeRestrictionLookupEntity();
		entity5.setId(5L);
		entity5.setKey("Reason");

		attribRestrictList.add(entity5);

		ClientEntity client = new ClientEntity();
		client.setClientId(request.getClientId());
		client.setName(request.getClientName());
		client.setEnvironmentId(1L);
		client.setCreatedAt(new Date());
		client.setUpdatedAt(new Date());
		client.setScrmId(request.getClientId());
		client.setOrgName(request.getOrgName());
		client.setLegalName(request.getOrgName());
		client.setLineage(request.getClientId());
		client.setSuperviewRestrict(true);

		ClientProfileEntity clientProfileEntity = new ClientProfileEntity();
		ClientMappingEntity clientMappingEntity = new ClientMappingEntity();
		ClientAttributesEntity  clientAttributesEntity = new ClientAttributesEntity();

		clientProfileEntity.setClient(client);
		clientProfileEntity.setAttributeTypeLookup(attributeLookupList.get(1));
		clientProfileEntity.setCreatedAt(new Date());
		clientProfileEntity.setCreatedBy("admin");
		clientProfileEntity.setUpdatedAt(new Date());
		clientProfileEntity.setUpdatedBy("admin");

		clientMappingEntity.setClient(client);
		clientMappingEntity.setUdpNormalizedClientId(request.getClientId());
		clientMappingEntity.setLiferayOrgId(request.getClientId());
		clientMappingEntity.setScrmId(request.getClientId());
		clientMappingEntity.setCloudCmsProjectId(request.getClientId());
		clientMappingEntity.setAssistGcc("");
		clientMappingEntity.setCreatedAt(new Date());
		clientMappingEntity.setCreatedBy("admin");
		clientMappingEntity.setUpdatedAt(new Date());
		clientMappingEntity.setUpdatedBy("admin");

		clientAttributesEntity.setClient(client);
		for(int i=0; i<=attribRestrictList.size()-1; i++) {
			clientAttributesEntity.setAttributeRestrictionLookup(attribRestrictList.get(i));
		}
		for(int i=0; i<=attributeLookupList.size()-1; i++) {
			clientAttributesEntity.setAttributeTypeLookup(attributeLookupList.get(i));
			clientAttributesEntity.setComment(StartAnyWhereConstants.SMARTLAUNCH_BLANK);
		}
		clientAttributesEntity.setCreatedAt(new Date());
		clientAttributesEntity.setCreatedBy("admin");
		clientAttributesEntity.setUpdatedAt(new Date());
		clientAttributesEntity.setUpdatedBy("admin");

		assertNotNull(attribRestrictList);
		assertNotNull(attributeLookupList);

		// Mock 
		when(attributeRestrictionLookupRepoMock.findAll()).thenReturn(attribRestrictList);

		when(attributeTypeLookupRepoMock.findAll()).thenReturn(attributeLookupList);

		Assertions.assertEquals(attributeLookupList.get(5).getKey(), StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);
		Assertions.assertNotEquals(request.getIsDataRestriction(), Boolean.TRUE);	

		Assertions.assertEquals(attributeLookupList.get(6).getKey(), StartAnyWhereConstants.SMARTLAUNCH_BLANK);
		Assertions.assertEquals(request.getIsDataRestriction(), Boolean.FALSE);	

		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(null);
		
		when(clientRepoMock.save(any())).thenReturn(client); // Mock saving

		when(clientProfileRepoMock.save(any())).thenReturn(clientProfileEntity);

		when(clientMappingRepoMock.save(any())).thenReturn(clientMappingEntity);

		when(clientAttributesRepoMock.save(any())).thenReturn(clientAttributesEntity);

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(201, response.getStatusCode().value());
	}

	@Test
	public void testaddNewclientdetails_Success_DataRestriction_List_YES_NO1() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("00095");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(Boolean.TRUE);

		List<AttributeTypeLookupEntity> attributeLookupList = new ArrayList<>();

		AttributeTypeLookupEntity lookupYes = new AttributeTypeLookupEntity();
		lookupYes.setId(1L);
		lookupYes.setKey(StartAnyWhereConstants.YES);

		AttributeTypeLookupEntity lookupNo = new AttributeTypeLookupEntity();
		lookupNo.setId(2L);
		lookupNo.setKey(StartAnyWhereConstants.NO);

		AttributeTypeLookupEntity lookupAlight_Contract = new AttributeTypeLookupEntity();
		lookupAlight_Contract.setId(3L);
		lookupAlight_Contract.setKey("ALIGHT_CONTRACT");

		AttributeTypeLookupEntity lookupThird_Party_Contract = new AttributeTypeLookupEntity();
		lookupThird_Party_Contract.setId(4L);
		lookupThird_Party_Contract.setKey("THIRD_PARTY_CONTRACT");

		AttributeTypeLookupEntity lookupOther = new AttributeTypeLookupEntity();
		lookupOther.setId(5L);
		lookupOther.setKey("OTHER");

		AttributeTypeLookupEntity lookupSmartLanch_defalut = new AttributeTypeLookupEntity();
		lookupSmartLanch_defalut.setId(6L);
		lookupSmartLanch_defalut.setKey(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);

		AttributeTypeLookupEntity lookupSmartLanch_blank = new AttributeTypeLookupEntity();
		lookupSmartLanch_blank.setId(7L);
		lookupSmartLanch_blank.setKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK);

		attributeLookupList.add(lookupYes);
		attributeLookupList.add(lookupNo);
		attributeLookupList.add(lookupAlight_Contract);
		attributeLookupList.add(lookupThird_Party_Contract);
		attributeLookupList.add(lookupOther);
		attributeLookupList.add(lookupSmartLanch_defalut);
		attributeLookupList.add(lookupSmartLanch_blank);

		List<AttributeRestrictionLookupEntity> attribRestrictList = new ArrayList<> ();

		AttributeRestrictionLookupEntity entity5 = new AttributeRestrictionLookupEntity();
		entity5.setId(5L);
		entity5.setKey("Reason");

		attribRestrictList.add(entity5);

		ClientEntity client = new ClientEntity();
		client.setClientId(request.getClientId());
		client.setName(request.getClientName());
		client.setEnvironmentId(1L);
		client.setCreatedAt(new Date());
		client.setUpdatedAt(new Date());
		client.setScrmId(request.getClientId());
		client.setOrgName(request.getOrgName());
		client.setLegalName(request.getOrgName());
		client.setLineage(request.getClientId());
		client.setSuperviewRestrict(true);

		ClientProfileEntity clientProfileEntity = new ClientProfileEntity();
		ClientMappingEntity clientMappingEntity = new ClientMappingEntity();
		ClientAttributesEntity  clientAttributesEntity = new ClientAttributesEntity();

		clientProfileEntity.setClient(client);
		clientProfileEntity.setAttributeTypeLookup(attributeLookupList.get(1));
		clientProfileEntity.setCreatedAt(new Date());
		clientProfileEntity.setCreatedBy("admin");
		clientProfileEntity.setUpdatedAt(new Date());
		clientProfileEntity.setUpdatedBy("admin");

		clientMappingEntity.setClient(client);
		clientMappingEntity.setUdpNormalizedClientId(request.getClientId());
		clientMappingEntity.setLiferayOrgId(request.getClientId());
		clientMappingEntity.setScrmId(request.getClientId());
		clientMappingEntity.setCloudCmsProjectId(request.getClientId());
		clientMappingEntity.setAssistGcc("");
		clientMappingEntity.setCreatedAt(new Date());
		clientMappingEntity.setCreatedBy("admin");
		clientMappingEntity.setUpdatedAt(new Date());
		clientMappingEntity.setUpdatedBy("admin");

		clientAttributesEntity.setClient(client);
		for(int i=0; i<=attribRestrictList.size()-1; i++) {
			clientAttributesEntity.setAttributeRestrictionLookup(attribRestrictList.get(i));
		}
		for(int i=0; i<=attributeLookupList.size()-1; i++) {
			clientAttributesEntity.setAttributeTypeLookup(attributeLookupList.get(i));
			clientAttributesEntity.setComment(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);
		}
		clientAttributesEntity.setCreatedAt(new Date());
		clientAttributesEntity.setCreatedBy("admin");
		clientAttributesEntity.setUpdatedAt(new Date());
		clientAttributesEntity.setUpdatedBy("admin");

		assertNotNull(attribRestrictList);
		assertNotNull(attributeLookupList);

		// Mock 
		when(attributeRestrictionLookupRepoMock.findAll()).thenReturn(attribRestrictList);

		when(attributeTypeLookupRepoMock.findAll()).thenReturn(attributeLookupList);

		Assertions.assertEquals(attributeLookupList.get(6).getKey(), StartAnyWhereConstants.SMARTLAUNCH_BLANK);
		Assertions.assertNotEquals(request.getIsDataRestriction(), Boolean.FALSE);	

		Assertions.assertEquals(attributeLookupList.get(5).getKey(), StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);
		Assertions.assertEquals(request.getIsDataRestriction(), Boolean.TRUE);	

		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(null);
		
		when(clientRepoMock.save(any())).thenReturn(client); // Mock saving

		when(clientProfileRepoMock.save(any())).thenReturn(clientProfileEntity);

		when(clientMappingRepoMock.save(any())).thenReturn(clientMappingEntity);

		when(clientAttributesRepoMock.save(any())).thenReturn(clientAttributesEntity);

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(201, response.getStatusCode().value());
	}

	@Test
	public void testaddNewclientdetails_Success_DataRestriction_List_SMARTLAUNCH_BLANK() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("00095");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(Boolean.FALSE);

		List<AttributeTypeLookupEntity> attributeLookupList = new ArrayList<>();

		AttributeTypeLookupEntity lookupYes = new AttributeTypeLookupEntity();
		lookupYes.setId(1L);
		lookupYes.setKey(StartAnyWhereConstants.YES);

		AttributeTypeLookupEntity lookupNo = new AttributeTypeLookupEntity();
		lookupNo.setId(2L);
		lookupNo.setKey(StartAnyWhereConstants.NO);

		AttributeTypeLookupEntity lookupAlight_Contract = new AttributeTypeLookupEntity();
		lookupAlight_Contract.setId(3L);
		lookupAlight_Contract.setKey("ALIGHT_CONTRACT");

		AttributeTypeLookupEntity lookupThird_Party_Contract = new AttributeTypeLookupEntity();
		lookupThird_Party_Contract.setId(4L);
		lookupThird_Party_Contract.setKey("THIRD_PARTY_CONTRACT");

		AttributeTypeLookupEntity lookupOther = new AttributeTypeLookupEntity();
		lookupOther.setId(5L);
		lookupOther.setKey("OTHER");

		AttributeTypeLookupEntity lookupSmartLanch_defalut = new AttributeTypeLookupEntity();
		lookupSmartLanch_defalut.setId(6L);
		lookupSmartLanch_defalut.setKey(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);

		AttributeTypeLookupEntity lookupSmartLanch_blank = new AttributeTypeLookupEntity();
		lookupSmartLanch_blank.setId(7L);
		lookupSmartLanch_blank.setKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK);

		attributeLookupList.add(lookupYes);
		attributeLookupList.add(lookupNo);
		attributeLookupList.add(lookupAlight_Contract);
		attributeLookupList.add(lookupThird_Party_Contract);
		attributeLookupList.add(lookupOther);
		attributeLookupList.add(lookupSmartLanch_defalut);
		attributeLookupList.add(lookupSmartLanch_blank);


		List<AttributeRestrictionLookupEntity> attribRestrictList = new ArrayList<> ();

		AttributeRestrictionLookupEntity entity1 = new AttributeRestrictionLookupEntity();
		entity1.setId(5L);
		entity1.setKey("Reason");

		attribRestrictList.add(entity1);


		Assertions.assertEquals(7, attributeLookupList.size());
		Assertions.assertEquals(lookupYes, attributeLookupList.get(0));
		Assertions.assertEquals(lookupNo, attributeLookupList.get(1));
		Assertions.assertEquals(lookupAlight_Contract, attributeLookupList.get(2));
		Assertions.assertEquals(lookupThird_Party_Contract, attributeLookupList.get(3));
		Assertions.assertEquals(lookupOther, attributeLookupList.get(4));
		Assertions.assertEquals(lookupSmartLanch_defalut, attributeLookupList.get(5));
		Assertions.assertEquals(lookupSmartLanch_blank, attributeLookupList.get(6));

		ClientEntity client = new ClientEntity();
		client.setClientId(request.getClientId());
		client.setName(request.getClientName());
		client.setEnvironmentId(1L);
		client.setCreatedAt(new Date());
		client.setUpdatedAt(new Date());
		client.setScrmId(request.getClientId());
		client.setOrgName(request.getOrgName());
		client.setLegalName(request.getOrgName());
		client.setLineage(request.getClientId());
		client.setSuperviewRestrict(false);

		ClientProfileEntity clientProfileEntity = new ClientProfileEntity();
		ClientMappingEntity clientMappingEntity = new ClientMappingEntity();
		ClientAttributesEntity  clientAttributesEntity = new ClientAttributesEntity();

		clientProfileEntity.setClient(client);
		clientProfileEntity.setAttributeTypeLookup(attributeLookupList.get(1));
		clientProfileEntity.setCreatedAt(new Date());
		clientProfileEntity.setCreatedBy("admin");
		clientProfileEntity.setUpdatedAt(new Date());
		clientProfileEntity.setUpdatedBy("admin");

		clientMappingEntity.setClient(client);
		clientMappingEntity.setUdpNormalizedClientId(request.getClientId());
		clientMappingEntity.setLiferayOrgId(request.getClientId());
		clientMappingEntity.setScrmId(request.getClientId());
		clientMappingEntity.setCloudCmsProjectId(request.getClientId());
		clientMappingEntity.setAssistGcc("");
		clientMappingEntity.setCreatedAt(new Date());
		clientMappingEntity.setCreatedBy("admin");
		clientMappingEntity.setUpdatedAt(new Date());
		clientMappingEntity.setUpdatedBy("admin");

		clientAttributesEntity.setClient(client);
		for(int i=0; i<=attribRestrictList.size()-1; i++) {
			clientAttributesEntity.setAttributeRestrictionLookup(attribRestrictList.get(i));
		}
		for(int i=0; i<=attributeLookupList.size()-1; i++) {
			clientAttributesEntity.setAttributeTypeLookup(attributeLookupList.get(i));
			clientAttributesEntity.setComment(StartAnyWhereConstants.SMARTLAUNCH_BLANK);
		}
		clientAttributesEntity.setCreatedAt(new Date());
		clientAttributesEntity.setCreatedBy("admin");
		clientAttributesEntity.setUpdatedAt(new Date());
		clientAttributesEntity.setUpdatedBy("admin");

		assertNotNull(attribRestrictList);
		assertNotNull(attributeLookupList);

		// Mock 
		when(attributeRestrictionLookupRepoMock.findAll()).thenReturn(attribRestrictList);

		when(attributeTypeLookupRepoMock.findAll()).thenReturn(attributeLookupList);

		Assertions.assertEquals(attributeLookupList.get(6).getKey(), StartAnyWhereConstants.SMARTLAUNCH_BLANK);
		Assertions.assertEquals(request.getIsDataRestriction(), Boolean.FALSE);	
		
		Assertions.assertNotEquals(request.getIsDataRestriction(), Boolean.TRUE);	
		Assertions.assertNotEquals(attributeLookupList.get(6).getKey(), StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);

		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(null);
		
		when(clientRepoMock.save(any())).thenReturn(client); // Mock saving

		when(clientProfileRepoMock.save(any())).thenReturn(clientProfileEntity);

		when(clientMappingRepoMock.save(any())).thenReturn(clientMappingEntity);

		when(clientAttributesRepoMock.save(any())).thenReturn(clientAttributesEntity);

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(201, response.getStatusCode().value());
	}
	@Test
	public void testaddNewclientdetails_Success_DataRestriction_List_SMARTLAUNCH_BLANK1() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("00095");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(Boolean.FALSE);

		List<AttributeTypeLookupEntity> attributeLookupList = new ArrayList<>();

		AttributeTypeLookupEntity lookupYes = new AttributeTypeLookupEntity();
		lookupYes.setId(1L);
		lookupYes.setKey(StartAnyWhereConstants.YES);

		AttributeTypeLookupEntity lookupNo = new AttributeTypeLookupEntity();
		lookupNo.setId(2L);
		lookupNo.setKey(StartAnyWhereConstants.NO);

		AttributeTypeLookupEntity lookupAlight_Contract = new AttributeTypeLookupEntity();
		lookupAlight_Contract.setId(3L);
		lookupAlight_Contract.setKey("ALIGHT_CONTRACT");

		AttributeTypeLookupEntity lookupThird_Party_Contract = new AttributeTypeLookupEntity();
		lookupThird_Party_Contract.setId(4L);
		lookupThird_Party_Contract.setKey("THIRD_PARTY_CONTRACT");

		AttributeTypeLookupEntity lookupOther = new AttributeTypeLookupEntity();
		lookupOther.setId(5L);
		lookupOther.setKey("OTHER");

		AttributeTypeLookupEntity lookupSmartLanch_defalut = new AttributeTypeLookupEntity();
		lookupSmartLanch_defalut.setId(6L);
		lookupSmartLanch_defalut.setKey(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);

		AttributeTypeLookupEntity lookupSmartLanch_blank = new AttributeTypeLookupEntity();
		lookupSmartLanch_blank.setId(7L);
		lookupSmartLanch_blank.setKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK);

		attributeLookupList.add(lookupYes);
		attributeLookupList.add(lookupNo);
		attributeLookupList.add(lookupAlight_Contract);
		attributeLookupList.add(lookupThird_Party_Contract);
		attributeLookupList.add(lookupOther);
		attributeLookupList.add(lookupSmartLanch_defalut);
		attributeLookupList.add(lookupSmartLanch_blank);

		Assertions.assertEquals(7, attributeLookupList.size());
		Assertions.assertEquals(lookupYes, attributeLookupList.get(0));
		Assertions.assertEquals(lookupNo, attributeLookupList.get(1));
		Assertions.assertEquals(lookupAlight_Contract, attributeLookupList.get(2));
		Assertions.assertEquals(lookupThird_Party_Contract, attributeLookupList.get(3));
		Assertions.assertEquals(lookupOther, attributeLookupList.get(4));
		Assertions.assertEquals(lookupSmartLanch_defalut, attributeLookupList.get(5));
		Assertions.assertEquals(lookupSmartLanch_blank, attributeLookupList.get(6));

		List<AttributeRestrictionLookupEntity> attribRestrictList = new ArrayList<> ();

		AttributeRestrictionLookupEntity entity1 = new AttributeRestrictionLookupEntity();
		entity1.setId(1L);
		entity1.setKey("Location-User-PII");

		AttributeRestrictionLookupEntity entity2 = new AttributeRestrictionLookupEntity();
		entity2.setId(2L);
		entity2.setKey("Location-User-Non-PII");

		AttributeRestrictionLookupEntity entity3 = new AttributeRestrictionLookupEntity();
		entity3.setId(3L);
		entity3.setKey("Location-User-Physical");

		AttributeRestrictionLookupEntity entity4 = new AttributeRestrictionLookupEntity();
		entity4.setId(4L);
		entity4.setKey("Other");

		AttributeRestrictionLookupEntity entity5 = new AttributeRestrictionLookupEntity();
		entity5.setId(5L);
		entity5.setKey("Reason");

		attribRestrictList.add(entity1);
		attribRestrictList.add(entity2);
		attribRestrictList.add(entity3);
		attribRestrictList.add(entity4);
		attribRestrictList.add(entity5);


		assertNotNull(attribRestrictList);
		assertNotNull(attributeLookupList);

		List<AttributeTypeLookupEntity> attriLookupEntityList1 = 
				attributeLookupList.subList(attributeLookupList.size() - 2, attributeLookupList.size());

		int index = request.getIsDataRestriction() ? 0 : 1;
		AttributeTypeLookupEntity selected = attriLookupEntityList1.get(index);

		// Act
		String selectedKey = selected.getKey();

		// Assert
		Assertions.assertEquals(1, index);
		Assertions.assertEquals("SMARTLAUNCH_BLANK", selectedKey);

		Assertions.assertEquals(request.getIsDataRestriction(), Boolean.FALSE);	
		Assertions.assertFalse(request.getIsDataRestriction());
		Assertions.assertEquals(attributeLookupList.get(6).getKey(), StartAnyWhereConstants.SMARTLAUNCH_BLANK);
		Assertions.assertEquals(attributeLookupList.get(6).getKey(), selectedKey);

		Assertions.assertNotEquals(request.getIsDataRestriction(), Boolean.TRUE);	
		Assertions.assertNotEquals(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT, selectedKey);

		ClientEntity client = new ClientEntity();
		client.setClientId(request.getClientId());
		client.setName(request.getClientName());
		client.setEnvironmentId(1L);
		client.setCreatedAt(new Date());
		client.setUpdatedAt(new Date());
		client.setScrmId(request.getClientId());
		client.setOrgName(request.getOrgName());
		client.setLegalName(request.getOrgName());
		client.setLineage(request.getClientId());
		client.setSuperviewRestrict(false);

		ClientProfileEntity clientProfileEntity = new ClientProfileEntity();
		ClientMappingEntity clientMappingEntity = new ClientMappingEntity();
		ClientAttributesEntity  clientAttributesEntity = new ClientAttributesEntity();

		clientProfileEntity.setClient(client);
		clientProfileEntity.setAttributeTypeLookup(attributeLookupList.get(1));
		clientProfileEntity.setCreatedAt(new Date());
		clientProfileEntity.setCreatedBy("admin");
		clientProfileEntity.setUpdatedAt(new Date());
		clientProfileEntity.setUpdatedBy("admin");

		clientMappingEntity.setClient(client);
		clientMappingEntity.setUdpNormalizedClientId(request.getClientId());
		clientMappingEntity.setLiferayOrgId(request.getClientId());
		clientMappingEntity.setScrmId(request.getClientId());
		clientMappingEntity.setCloudCmsProjectId(request.getClientId());
		clientMappingEntity.setAssistGcc("");
		clientMappingEntity.setCreatedAt(new Date());
		clientMappingEntity.setCreatedBy("admin");
		clientMappingEntity.setUpdatedAt(new Date());
		clientMappingEntity.setUpdatedBy("admin");

		clientAttributesEntity.setClient(client);
		for(int i=0; i<=attribRestrictList.size()-1; i++) {
			clientAttributesEntity.setAttributeRestrictionLookup(attribRestrictList.get(i));
		}
		for(int i=0; i<=attributeLookupList.size()-1; i++) {
			clientAttributesEntity.setAttributeTypeLookup(attributeLookupList.get(i));
			clientAttributesEntity.setComment(StartAnyWhereConstants.SMARTLAUNCH_BLANK);
		}
		clientAttributesEntity.setCreatedAt(new Date());
		clientAttributesEntity.setCreatedBy("admin");
		clientAttributesEntity.setUpdatedAt(new Date());
		clientAttributesEntity.setUpdatedBy("admin");


		// Mock 
		when(attributeRestrictionLookupRepoMock.findAll()).thenReturn(attribRestrictList);

		when(attributeTypeLookupRepoMock.findAll()).thenReturn(attributeLookupList);

		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(null);
		
		when(clientRepoMock.save(any())).thenReturn(client); // Mock saving

		when(clientProfileRepoMock.save(any())).thenReturn(clientProfileEntity);

		when(clientMappingRepoMock.save(any())).thenReturn(clientMappingEntity);

		when(clientAttributesRepoMock.save(any())).thenReturn(clientAttributesEntity);

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(201, response.getStatusCode().value());
	}


	@Test
	public void testaddNewclientdetails_Success_DataRestriction_List_SMARTLAUNCH_DEFAULT() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("00095");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(Boolean.TRUE);

		List<AttributeTypeLookupEntity> attributeLookupList = new ArrayList<>();

		AttributeTypeLookupEntity lookupYes = new AttributeTypeLookupEntity();
		lookupYes.setId(1L);
		lookupYes.setKey(StartAnyWhereConstants.YES);

		AttributeTypeLookupEntity lookupNo = new AttributeTypeLookupEntity();
		lookupNo.setId(2L);
		lookupNo.setKey(StartAnyWhereConstants.NO);

		AttributeTypeLookupEntity lookupAlight_Contract = new AttributeTypeLookupEntity();
		lookupAlight_Contract.setId(3L);
		lookupAlight_Contract.setKey("ALIGHT_CONTRACT");

		AttributeTypeLookupEntity lookupThird_Party_Contract = new AttributeTypeLookupEntity();
		lookupThird_Party_Contract.setId(4L);
		lookupThird_Party_Contract.setKey("THIRD_PARTY_CONTRACT");

		AttributeTypeLookupEntity lookupOther = new AttributeTypeLookupEntity();
		lookupOther.setId(5L);
		lookupOther.setKey("OTHER");

		AttributeTypeLookupEntity lookupSmartLanch_defalut = new AttributeTypeLookupEntity();
		lookupSmartLanch_defalut.setId(6L);
		lookupSmartLanch_defalut.setKey(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);

		AttributeTypeLookupEntity lookupSmartLanch_blank = new AttributeTypeLookupEntity();
		lookupSmartLanch_blank.setId(7L);
		lookupSmartLanch_blank.setKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK);

		attributeLookupList.add(lookupYes);
		attributeLookupList.add(lookupNo);
		attributeLookupList.add(lookupAlight_Contract);
		attributeLookupList.add(lookupThird_Party_Contract);
		attributeLookupList.add(lookupOther);
		attributeLookupList.add(lookupSmartLanch_defalut);
		attributeLookupList.add(lookupSmartLanch_blank);

		Assertions.assertEquals(7, attributeLookupList.size());
		Assertions.assertEquals(lookupYes, attributeLookupList.get(0));
		Assertions.assertEquals(lookupNo, attributeLookupList.get(1));
		Assertions.assertEquals(lookupAlight_Contract, attributeLookupList.get(2));
		Assertions.assertEquals(lookupThird_Party_Contract, attributeLookupList.get(3));
		Assertions.assertEquals(lookupOther, attributeLookupList.get(4));
		Assertions.assertEquals(lookupSmartLanch_defalut, attributeLookupList.get(5));
		Assertions.assertEquals(lookupSmartLanch_blank, attributeLookupList.get(6));

		List<AttributeRestrictionLookupEntity> attribRestrictList = new ArrayList<> ();

		AttributeRestrictionLookupEntity entity1 = new AttributeRestrictionLookupEntity();
		entity1.setId(1L);
		entity1.setKey("Location-User-PII");

		AttributeRestrictionLookupEntity entity2 = new AttributeRestrictionLookupEntity();
		entity2.setId(2L);
		entity2.setKey("Location-User-Non-PII");

		AttributeRestrictionLookupEntity entity3 = new AttributeRestrictionLookupEntity();
		entity3.setId(3L);
		entity3.setKey("Location-User-Physical");

		AttributeRestrictionLookupEntity entity4 = new AttributeRestrictionLookupEntity();
		entity4.setId(4L);
		entity4.setKey("Other");

		AttributeRestrictionLookupEntity entity5 = new AttributeRestrictionLookupEntity();
		entity5.setId(5L);
		entity5.setKey("Reason");

		attribRestrictList.add(entity1);
		attribRestrictList.add(entity2);
		attribRestrictList.add(entity3);
		attribRestrictList.add(entity4);
		attribRestrictList.add(entity5);


		assertNotNull(attribRestrictList);
		assertNotNull(attributeLookupList);

		List<AttributeTypeLookupEntity> attriLookupEntityList1 = 
				attributeLookupList.subList(attributeLookupList.size() - 2, attributeLookupList.size());

		int index = request.getIsDataRestriction() ? 0 : 1;
		AttributeTypeLookupEntity selected = attriLookupEntityList1.get(index);

		// Act
		String selectedKey = selected.getKey();

		// Assert
		Assertions.assertEquals(0, index);
		Assertions.assertEquals("SMARTLAUNCH_DEFAULT", selectedKey);

		Assertions.assertEquals(request.getIsDataRestriction(), Boolean.TRUE);	
		Assertions.assertEquals(attributeLookupList.get(5).getKey(), StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);

		Assertions.assertEquals(attributeLookupList.get(5).getKey(), selectedKey);

		Assertions.assertNotEquals(request.getIsDataRestriction(), Boolean.FALSE);	
		Assertions.assertNotEquals(StartAnyWhereConstants.SMARTLAUNCH_BLANK, selectedKey);

		ClientEntity client = new ClientEntity();
		client.setClientId(request.getClientId());
		client.setName(request.getClientName());
		client.setEnvironmentId(1L);
		client.setCreatedAt(new Date());
		client.setUpdatedAt(new Date());
		client.setScrmId(request.getClientId());
		client.setOrgName(request.getOrgName());
		client.setLegalName(request.getOrgName());
		client.setLineage(request.getClientId());
		client.setSuperviewRestrict(true);

		ClientProfileEntity clientProfileEntity = new ClientProfileEntity();
		ClientMappingEntity clientMappingEntity = new ClientMappingEntity();
		ClientAttributesEntity  clientAttributesEntity = new ClientAttributesEntity();

		clientProfileEntity.setClient(client);
		clientProfileEntity.setAttributeTypeLookup(attributeLookupList.get(1));
		clientProfileEntity.setCreatedAt(new Date());
		clientProfileEntity.setCreatedBy("admin");
		clientProfileEntity.setUpdatedAt(new Date());
		clientProfileEntity.setUpdatedBy("admin");

		clientMappingEntity.setClient(client);
		clientMappingEntity.setUdpNormalizedClientId(request.getClientId());
		clientMappingEntity.setLiferayOrgId(request.getClientId());
		clientMappingEntity.setScrmId(request.getClientId());
		clientMappingEntity.setCloudCmsProjectId(request.getClientId());
		clientMappingEntity.setAssistGcc("");
		clientMappingEntity.setCreatedAt(new Date());
		clientMappingEntity.setCreatedBy("admin");
		clientMappingEntity.setUpdatedAt(new Date());
		clientMappingEntity.setUpdatedBy("admin");

		clientAttributesEntity.setClient(client);
		for(int i=0; i<=attribRestrictList.size()-1; i++) {
			clientAttributesEntity.setAttributeRestrictionLookup(attribRestrictList.get(i));
		}
		for(int i=0; i<=attributeLookupList.size()-1; i++) {
			clientAttributesEntity.setAttributeTypeLookup(attributeLookupList.get(i));
			clientAttributesEntity.setComment(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);
		}
		clientAttributesEntity.setCreatedAt(new Date());
		clientAttributesEntity.setCreatedBy("admin");
		clientAttributesEntity.setUpdatedAt(new Date());
		clientAttributesEntity.setUpdatedBy("admin");


		// Mock 
		when(attributeRestrictionLookupRepoMock.findAll()).thenReturn(attribRestrictList);

		when(attributeTypeLookupRepoMock.findAll()).thenReturn(attributeLookupList);

		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(null);
		
		when(clientRepoMock.save(any())).thenReturn(client); 

		when(clientProfileRepoMock.save(any())).thenReturn(clientProfileEntity);

		when(clientMappingRepoMock.save(any())).thenReturn(clientMappingEntity);

		when(clientAttributesRepoMock.save(any())).thenReturn(clientAttributesEntity);

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(201, response.getStatusCode().value());
	}

	@Test
	public void testaddNewclientdetails_Success_DataRestriction_List_SMARTLAUNCH_DEFAULT1() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("00095");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(Boolean.TRUE);

		List<AttributeTypeLookupEntity> attributeLookupList = new ArrayList<>();

		AttributeTypeLookupEntity lookupYes = new AttributeTypeLookupEntity();
		lookupYes.setId(1L);
		lookupYes.setKey(StartAnyWhereConstants.YES);

		AttributeTypeLookupEntity lookupNo = new AttributeTypeLookupEntity();
		lookupNo.setId(2L);
		lookupNo.setKey(StartAnyWhereConstants.NO);

		AttributeTypeLookupEntity lookupAlight_Contract = new AttributeTypeLookupEntity();
		lookupAlight_Contract.setId(3L);
		lookupAlight_Contract.setKey("ALIGHT_CONTRACT");

		AttributeTypeLookupEntity lookupThird_Party_Contract = new AttributeTypeLookupEntity();
		lookupThird_Party_Contract.setId(4L);
		lookupThird_Party_Contract.setKey("THIRD_PARTY_CONTRACT");

		AttributeTypeLookupEntity lookupOther = new AttributeTypeLookupEntity();
		lookupOther.setId(5L);
		lookupOther.setKey("OTHER");

		AttributeTypeLookupEntity lookupSmartLanch_defalut = new AttributeTypeLookupEntity();
		lookupSmartLanch_defalut.setId(6L);
		lookupSmartLanch_defalut.setKey(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);

		AttributeTypeLookupEntity lookupSmartLanch_blank = new AttributeTypeLookupEntity();
		lookupSmartLanch_blank.setId(7L);
		lookupSmartLanch_blank.setKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK);

		attributeLookupList.add(lookupYes);
		attributeLookupList.add(lookupNo);
		attributeLookupList.add(lookupAlight_Contract);
		attributeLookupList.add(lookupThird_Party_Contract);
		attributeLookupList.add(lookupOther);
		attributeLookupList.add(lookupSmartLanch_defalut);
		attributeLookupList.add(lookupSmartLanch_blank);

		Assertions.assertEquals(7, attributeLookupList.size());
		Assertions.assertEquals(lookupYes, attributeLookupList.get(0));
		Assertions.assertEquals(lookupNo, attributeLookupList.get(1));
		Assertions.assertEquals(lookupAlight_Contract, attributeLookupList.get(2));
		Assertions.assertEquals(lookupThird_Party_Contract, attributeLookupList.get(3));
		Assertions.assertEquals(lookupOther, attributeLookupList.get(4));
		Assertions.assertEquals(lookupSmartLanch_defalut, attributeLookupList.get(5));
		Assertions.assertEquals(lookupSmartLanch_blank, attributeLookupList.get(6));

		List<AttributeRestrictionLookupEntity> attribRestrictList = new ArrayList<> ();

		AttributeRestrictionLookupEntity entity1 = new AttributeRestrictionLookupEntity();
		entity1.setId(5L);
		entity1.setKey("Reason");

		attribRestrictList.add(entity1);

		assertNotNull(attribRestrictList);
		assertNotNull(attributeLookupList);

		ClientEntity client = new ClientEntity();
		client.setClientId(request.getClientId());
		client.setName(request.getClientName());
		client.setEnvironmentId(1L);
		client.setCreatedAt(new Date());
		client.setUpdatedAt(new Date());
		client.setScrmId(request.getClientId());
		client.setOrgName(request.getOrgName());
		client.setLegalName(request.getOrgName());
		client.setLineage(request.getClientId());
		client.setSuperviewRestrict(true);

		ClientProfileEntity clientProfileEntity = new ClientProfileEntity();
		ClientMappingEntity clientMappingEntity = new ClientMappingEntity();
		ClientAttributesEntity  clientAttributesEntity = new ClientAttributesEntity();

		clientProfileEntity.setClient(client);
		clientProfileEntity.setAttributeTypeLookup(attributeLookupList.get(1));
		clientProfileEntity.setCreatedAt(new Date());
		clientProfileEntity.setCreatedBy("admin");
		clientProfileEntity.setUpdatedAt(new Date());
		clientProfileEntity.setUpdatedBy("admin");

		clientMappingEntity.setClient(client);
		clientMappingEntity.setUdpNormalizedClientId(request.getClientId());
		clientMappingEntity.setLiferayOrgId(request.getClientId());
		clientMappingEntity.setScrmId(request.getClientId());
		clientMappingEntity.setCloudCmsProjectId(request.getClientId());
		clientMappingEntity.setAssistGcc("");
		clientMappingEntity.setCreatedAt(new Date());
		clientMappingEntity.setCreatedBy("admin");
		clientMappingEntity.setUpdatedAt(new Date());
		clientMappingEntity.setUpdatedBy("admin");

		clientAttributesEntity.setClient(client);
		for(int i=0; i<=attribRestrictList.size()-1; i++) {
			clientAttributesEntity.setAttributeRestrictionLookup(attribRestrictList.get(i));
		}
		for(int i=0; i<=attributeLookupList.size()-1; i++) {
			clientAttributesEntity.setAttributeTypeLookup(attributeLookupList.get(i));
			clientAttributesEntity.setComment(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);
		}
		clientAttributesEntity.setCreatedAt(new Date());
		clientAttributesEntity.setCreatedBy("admin");
		clientAttributesEntity.setUpdatedAt(new Date());
		clientAttributesEntity.setUpdatedBy("admin");


		// Mock 
		when(attributeRestrictionLookupRepoMock.findAll()).thenReturn(attribRestrictList);

		when(attributeTypeLookupRepoMock.findAll()).thenReturn(attributeLookupList);

		Assertions.assertEquals(attributeLookupList.get(5).getKey(), StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);
		Assertions.assertEquals(request.getIsDataRestriction(), Boolean.TRUE);	
		
		Assertions.assertNotEquals(request.getIsDataRestriction(), Boolean.FALSE);	
		Assertions.assertNotEquals(attributeLookupList.get(5).getKey(), StartAnyWhereConstants.SMARTLAUNCH_BLANK);

		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(null);
		
		when(clientRepoMock.save(any())).thenReturn(client); 

		when(clientProfileRepoMock.save(any())).thenReturn(clientProfileEntity);

		when(clientMappingRepoMock.save(any())).thenReturn(clientMappingEntity);

		when(clientAttributesRepoMock.save(any())).thenReturn(clientAttributesEntity);

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(201, response.getStatusCode().value());
	}

	@Test
	public void testaddNewclientdetails_Success_DataRestriction_List_NULL_Check() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("00095");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(true);
		List<AttributeTypeLookupEntity> attributeLookupList = Arrays.asList(new AttributeTypeLookupEntity(), new AttributeTypeLookupEntity());

		AttributeTypeLookupEntity attributeLookupEntity = new AttributeTypeLookupEntity();
		attributeLookupEntity.setId(null);
		attributeLookupEntity.setKey(null);

		attributeLookupList.set(0, attributeLookupEntity);

		List<AttributeRestrictionLookupEntity> attribRestrictList = new ArrayList<> ();

		AttributeRestrictionLookupEntity entity1 = new AttributeRestrictionLookupEntity();

		attribRestrictList.add(entity1);

		ClientEntity client = new ClientEntity();
		client.setClientId(request.getClientId());
		client.setName(request.getClientName());
		client.setEnvironmentId(1L);
		client.setCreatedAt(new Date());
		client.setUpdatedAt(new Date());
		client.setScrmId(request.getClientId());
		client.setOrgName(request.getOrgName());
		client.setLegalName(request.getOrgName());
		client.setLineage(request.getClientId());
		client.setSuperviewRestrict(true);

		ClientProfileEntity clientProfileEntity = new ClientProfileEntity();
		ClientMappingEntity clientMappingEntity = new ClientMappingEntity();
		ClientAttributesEntity  clientAttributesEntity = new ClientAttributesEntity();

		clientProfileEntity.setClient(client);
		clientProfileEntity.setAttributeTypeLookup(attributeLookupList.get(1));
		clientProfileEntity.setCreatedAt(new Date());
		clientProfileEntity.setCreatedBy("admin");
		clientProfileEntity.setUpdatedAt(new Date());
		clientProfileEntity.setUpdatedBy("admin");

		clientMappingEntity.setClient(client);
		clientMappingEntity.setUdpNormalizedClientId(request.getClientId());
		clientMappingEntity.setLiferayOrgId(request.getClientId());
		clientMappingEntity.setScrmId(request.getClientId());
		clientMappingEntity.setCloudCmsProjectId(request.getClientId());
		clientMappingEntity.setAssistGcc("");
		clientMappingEntity.setCreatedAt(new Date());
		clientMappingEntity.setCreatedBy("admin");
		clientMappingEntity.setUpdatedAt(new Date());
		clientMappingEntity.setUpdatedBy("admin");

		clientAttributesEntity.setClient(client);
		for(int i=0; i<=attribRestrictList.size()-1; i++) {
			clientAttributesEntity.setAttributeRestrictionLookup(attribRestrictList.get(i));
		}
		for(int i=0; i<=attributeLookupList.size()-1; i++) {
			clientAttributesEntity.setAttributeTypeLookup(attributeLookupList.get(i));
			clientAttributesEntity.setComment(attributeLookupList.get(i).getKey());
		}
		clientAttributesEntity.setCreatedAt(new Date());
		clientAttributesEntity.setCreatedBy("admin");
		clientAttributesEntity.setUpdatedAt(new Date());
		clientAttributesEntity.setUpdatedBy("admin");

		//Assert
		assertNotNull(attribRestrictList);
		assertNotNull(attributeLookupList);
		
		Assertions.assertNotEquals(attributeLookupList.get(0).getKey(), StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);
		Assertions.assertEquals(request.getIsDataRestriction(), Boolean.TRUE);	

		Assertions.assertNotEquals(attributeLookupList.get(0).getKey(), StartAnyWhereConstants.SMARTLAUNCH_BLANK);
		Assertions.assertNotEquals(request.getIsDataRestriction(), Boolean.FALSE);	


		// Mock 
		when(attributeRestrictionLookupRepoMock.findAll()).thenReturn(attribRestrictList);

		when(attributeTypeLookupRepoMock.findAll()).thenReturn(attributeLookupList);
		
		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(null);
		
		when(clientRepoMock.save(any())).thenReturn(client); 

		when(clientProfileRepoMock.save(any())).thenReturn(clientProfileEntity);

		when(clientMappingRepoMock.save(any())).thenReturn(clientMappingEntity);

		when(clientAttributesRepoMock.save(any())).thenReturn(clientAttributesEntity);

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(201, response.getStatusCode().value());
	}

	@Test
	public void testaddNewclientdetails_Success_DataRestriction_List_NO() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("00095");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(false);
		AttributeRestrictionLookupEntity attribRestrictEntity = new AttributeRestrictionLookupEntity();
		attribRestrictEntity.setKey("Location-User-PII");
		attribRestrictEntity.setId(5L);
		List<AttributeRestrictionLookupEntity> attribRestrictEntityList= new ArrayList<>();
		attribRestrictEntityList.add(attribRestrictEntity);

		AttributeTypeLookupEntity attribTypeLookupEntity = new AttributeTypeLookupEntity();
		attribTypeLookupEntity.setId(7L);
		attribTypeLookupEntity.setKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK);
		List<AttributeTypeLookupEntity> attributeTypeLookupEntityList = new ArrayList<>();
		attributeTypeLookupEntityList.add(attribTypeLookupEntity);

		ClientEntity client = new ClientEntity();
		client.setClientId(request.getClientId());
		client.setName(request.getClientName());
		client.setEnvironmentId(1L);
		client.setCreatedAt(new Date());
		client.setUpdatedAt(new Date());
		client.setScrmId(request.getClientId());
		client.setOrgName(request.getOrgName());
		client.setLegalName(request.getOrgName());
		client.setLineage(request.getClientId());
		client.setSuperviewRestrict(false);

		ClientProfileEntity clientProfileEntity = new ClientProfileEntity();
		ClientMappingEntity clientMappingEntity = new ClientMappingEntity();
		ClientAttributesEntity  clientAttributesEntity = new ClientAttributesEntity();

		clientProfileEntity.setClient(client);
		clientProfileEntity.setAttributeTypeLookup(attribTypeLookupEntity);
		clientProfileEntity.setCreatedAt(new Date());
		clientProfileEntity.setCreatedBy("admin");
		clientProfileEntity.setUpdatedAt(new Date());
		clientProfileEntity.setUpdatedBy("admin");

		clientMappingEntity.setClient(client);
		clientMappingEntity.setUdpNormalizedClientId(request.getClientId());
		clientMappingEntity.setLiferayOrgId(request.getClientId());
		clientMappingEntity.setScrmId(request.getClientId());
		clientMappingEntity.setCloudCmsProjectId(request.getClientId());
		clientMappingEntity.setAssistGcc("");
		clientMappingEntity.setCreatedAt(new Date());
		clientMappingEntity.setCreatedBy("admin");
		clientMappingEntity.setUpdatedAt(new Date());
		clientMappingEntity.setUpdatedBy("admin");

		clientAttributesEntity.setClient(client);
		clientAttributesEntity.setAttributeRestrictionLookup(attribRestrictEntity);
		clientAttributesEntity.setAttributeTypeLookup(attribTypeLookupEntity);
		clientAttributesEntity.setComment(StartAnyWhereConstants.SMARTLAUNCH_BLANK);
		clientAttributesEntity.setCreatedAt(new Date());
		clientAttributesEntity.setCreatedBy("admin");
		clientAttributesEntity.setUpdatedAt(new Date());
		clientAttributesEntity.setUpdatedBy("admin");


		List<AttributeRestrictionLookupEntity> attribRestrictList = new ArrayList<> ();

		AttributeRestrictionLookupEntity entity1 = new AttributeRestrictionLookupEntity();
		entity1.setId(1L);
		entity1.setKey("Location-User-PII");

		AttributeRestrictionLookupEntity entity2 = new AttributeRestrictionLookupEntity();
		entity2.setId(2L);
		entity2.setKey("Location-User-Non-PII");

		AttributeRestrictionLookupEntity entity3 = new AttributeRestrictionLookupEntity();
		entity3.setId(3L);
		entity3.setKey("Location-User-Physical");

		AttributeRestrictionLookupEntity entity4 = new AttributeRestrictionLookupEntity();
		entity4.setId(4L);
		entity4.setKey("Other");

		attribRestrictList.add(entity1);
		attribRestrictList.add(entity2);
		attribRestrictList.add(entity3);
		attribRestrictList.add(entity4);

		List<AttributeTypeLookupEntity> attributeLookupList = Arrays.asList(new AttributeTypeLookupEntity(), new AttributeTypeLookupEntity());

		AttributeTypeLookupEntity lookupYes = new AttributeTypeLookupEntity();
		lookupYes.setKey(StartAnyWhereConstants.NO);

		attributeLookupList.set(0, lookupYes);

		Assertions.assertEquals(attributeLookupList.get(0).getKey(), StartAnyWhereConstants.NO);
		Assertions.assertEquals(request.getIsDataRestriction(), Boolean.FALSE);	
		// Mock 
		when(attributeRestrictionLookupRepoMock.findAll()).thenReturn(attribRestrictList);

		when(attributeTypeLookupRepoMock.findAll()).thenReturn(attributeLookupList);

		when(attributeTypeLookupRepoMock.findByKey(StartAnyWhereConstants.YES))
		.thenReturn(Optional.of(attribTypeLookupEntity));

		when(attributeTypeLookupRepoMock.findByKey(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT))
		.thenReturn(Optional.of(attribTypeLookupEntity));

		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(null);
		
		when(clientRepoMock.save(any())).thenReturn(client); // Mock saving

		when(clientProfileRepoMock.save(any())).thenReturn(clientProfileEntity);

		when(clientMappingRepoMock.save(any())).thenReturn(clientMappingEntity);

		when(clientAttributesRepoMock.save(any())).thenReturn(clientAttributesEntity);

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(201, response.getStatusCode().value());
	}

	@Test
	public void testaddNewclientdetails_Success_DataRestriction_NO_Comment() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("00095");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(false);
		AttributeRestrictionLookupEntity attribRestrictEntity = new AttributeRestrictionLookupEntity();
		attribRestrictEntity.setKey("Location-User-PII");
		attribRestrictEntity.setId(5L);
		List<AttributeRestrictionLookupEntity> attribRestrictEntityList= new ArrayList<>();
		attribRestrictEntityList.add(attribRestrictEntity);

		AttributeTypeLookupEntity attribTypeLookupEntity = new AttributeTypeLookupEntity();
		attribTypeLookupEntity.setId(7L);
		attribTypeLookupEntity.setKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK);
		List<AttributeTypeLookupEntity> attributeTypeLookupEntityList = new ArrayList<>();
		attributeTypeLookupEntityList.add(attribTypeLookupEntity);

		ClientEntity client = new ClientEntity();
		client.setClientId(request.getClientId());
		client.setName(request.getClientName());
		client.setEnvironmentId(1L);
		client.setCreatedAt(new Date());
		client.setUpdatedAt(new Date());
		client.setScrmId(request.getClientId());
		client.setOrgName(request.getOrgName());
		client.setLegalName(request.getOrgName());
		client.setLineage(request.getClientId());
		client.setSuperviewRestrict(false);

		ClientProfileEntity clientProfileEntity = new ClientProfileEntity();
		ClientMappingEntity clientMappingEntity = new ClientMappingEntity();
		ClientAttributesEntity  clientAttributesEntity = new ClientAttributesEntity();

		clientProfileEntity.setClient(client);
		clientProfileEntity.setAttributeTypeLookup(attribTypeLookupEntity);
		clientProfileEntity.setCreatedAt(new Date());
		clientProfileEntity.setCreatedBy("admin");
		clientProfileEntity.setUpdatedAt(new Date());
		clientProfileEntity.setUpdatedBy("admin");

		clientMappingEntity.setClient(client);
		clientMappingEntity.setUdpNormalizedClientId(request.getClientId());
		clientMappingEntity.setLiferayOrgId(request.getClientId());
		clientMappingEntity.setScrmId(request.getClientId());
		clientMappingEntity.setCloudCmsProjectId(request.getClientId());
		clientMappingEntity.setAssistGcc("");
		clientMappingEntity.setCreatedAt(new Date());
		clientMappingEntity.setCreatedBy("admin");
		clientMappingEntity.setUpdatedAt(new Date());
		clientMappingEntity.setUpdatedBy("admin");

		clientAttributesEntity.setClient(client);
		clientAttributesEntity.setAttributeRestrictionLookup(attribRestrictEntity);
		clientAttributesEntity.setAttributeTypeLookup(attribTypeLookupEntity);
		clientAttributesEntity.setComment(StartAnyWhereConstants.SMARTLAUNCH_BLANK);
		clientAttributesEntity.setCreatedAt(new Date());
		clientAttributesEntity.setCreatedBy("admin");
		clientAttributesEntity.setUpdatedAt(new Date());
		clientAttributesEntity.setUpdatedBy("admin");

		List<AttributeTypeLookupEntity> attributeLookupList = Arrays.asList(new AttributeTypeLookupEntity(), new AttributeTypeLookupEntity());

		AttributeTypeLookupEntity lookupYes = new AttributeTypeLookupEntity();
		lookupYes.setId(6L);
		lookupYes.setKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK);

		attributeLookupList.set(0, lookupYes);

		// Mock 
		when(attributeRestrictionLookupRepoMock.findAll()).thenReturn(attribRestrictEntityList);

		when(attributeTypeLookupRepoMock.findAll()).thenReturn(attributeLookupList);

		when(attributeTypeLookupRepoMock.findByKey(StartAnyWhereConstants.NO))
		.thenReturn(Optional.of(attribTypeLookupEntity));

		when(attributeTypeLookupRepoMock.findByKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK))
		.thenReturn(Optional.of(attribTypeLookupEntity));

		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(null);
		
		when(clientRepoMock.save(any())).thenReturn(client); 

		when(clientProfileRepoMock.save(any())).thenReturn(clientProfileEntity);

		when(clientMappingRepoMock.save(any())).thenReturn(clientMappingEntity);

		when(clientAttributesRepoMock.save(any())).thenReturn(clientAttributesEntity);

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(201, response.getStatusCode().value());
	}

	@Test
	public void testaddNewclientdetails_Success_DataRestriction_NO3() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("00095");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(Boolean.FALSE);

		List<AttributeTypeLookupEntity> attributeLookupList = new ArrayList<>();

		AttributeTypeLookupEntity lookupYes = new AttributeTypeLookupEntity();
		lookupYes.setId(1L);
		lookupYes.setKey(StartAnyWhereConstants.YES);

		AttributeTypeLookupEntity lookupNo = new AttributeTypeLookupEntity();
		lookupNo.setId(2L);
		lookupNo.setKey(StartAnyWhereConstants.NO);

		AttributeTypeLookupEntity lookupAlight_Contract = new AttributeTypeLookupEntity();
		lookupAlight_Contract.setId(3L);
		lookupAlight_Contract.setKey("ALIGHT_CONTRACT");

		AttributeTypeLookupEntity lookupThird_Party_Contract = new AttributeTypeLookupEntity();
		lookupThird_Party_Contract.setId(4L);
		lookupThird_Party_Contract.setKey("THIRD_PARTY_CONTRACT");

		AttributeTypeLookupEntity lookupOther = new AttributeTypeLookupEntity();
		lookupOther.setId(5L);
		lookupOther.setKey("OTHER");

		AttributeTypeLookupEntity lookupSmartLanch_defalut = new AttributeTypeLookupEntity();
		lookupSmartLanch_defalut.setId(6L);
		lookupSmartLanch_defalut.setKey(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);

		AttributeTypeLookupEntity lookupSmartLanch_blank = new AttributeTypeLookupEntity();
		lookupSmartLanch_blank.setId(7L);
		lookupSmartLanch_blank.setKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK);

		attributeLookupList.add(lookupYes);
		attributeLookupList.add(lookupNo);
		attributeLookupList.add(lookupAlight_Contract);
		attributeLookupList.add(lookupThird_Party_Contract);
		attributeLookupList.add(lookupOther);
		attributeLookupList.add(lookupSmartLanch_defalut);
		attributeLookupList.add(lookupSmartLanch_blank);

		// Assert
		Assertions.assertEquals(7, attributeLookupList.size());
		Assertions.assertEquals(lookupYes, attributeLookupList.get(0));
		Assertions.assertEquals(lookupNo, attributeLookupList.get(1));
		Assertions.assertEquals(lookupAlight_Contract, attributeLookupList.get(2));
		Assertions.assertEquals(lookupThird_Party_Contract, attributeLookupList.get(3));
		Assertions.assertEquals(lookupOther, attributeLookupList.get(4));
		Assertions.assertEquals(lookupSmartLanch_defalut, attributeLookupList.get(5));
		Assertions.assertEquals(lookupSmartLanch_blank, attributeLookupList.get(6));


		List<AttributeRestrictionLookupEntity> attribRestrictList = new ArrayList<> ();

		AttributeRestrictionLookupEntity entity1 = new AttributeRestrictionLookupEntity();
		entity1.setId(1L);
		entity1.setKey("Location-User-PII");

		AttributeRestrictionLookupEntity entity2 = new AttributeRestrictionLookupEntity();
		entity2.setId(2L);
		entity2.setKey("Location-User-Non-PII");

		AttributeRestrictionLookupEntity entity3 = new AttributeRestrictionLookupEntity();
		entity3.setId(3L);
		entity3.setKey("Location-User-Physical");

		AttributeRestrictionLookupEntity entity4 = new AttributeRestrictionLookupEntity();
		entity4.setId(4L);
		entity4.setKey("Other");

		AttributeRestrictionLookupEntity entity5 = new AttributeRestrictionLookupEntity();
		entity5.setId(5L);
		entity5.setKey("Reason");

		attribRestrictList.add(entity1);
		attribRestrictList.add(entity2);
		attribRestrictList.add(entity3);
		attribRestrictList.add(entity4);
		attribRestrictList.add(entity5);

		assertNotNull(attribRestrictList);
		assertNotNull(attributeLookupList);

		ClientEntity client = new ClientEntity();
		client.setClientId(request.getClientId());
		client.setName(request.getClientName());
		client.setEnvironmentId(1L);
		client.setCreatedAt(new Date());
		client.setUpdatedAt(new Date());
		client.setScrmId(request.getClientId());
		client.setOrgName(request.getOrgName());
		client.setLegalName(request.getOrgName());
		client.setLineage(request.getClientId());
		client.setSuperviewRestrict(false);

		ClientProfileEntity clientProfileEntity = new ClientProfileEntity();
		ClientMappingEntity clientMappingEntity = new ClientMappingEntity();
		ClientAttributesEntity  clientAttributesEntity = new ClientAttributesEntity();

		clientProfileEntity.setClient(client);
		clientProfileEntity.setAttributeTypeLookup(attributeLookupList.get(1));
		clientProfileEntity.setCreatedAt(new Date());
		clientProfileEntity.setCreatedBy("admin");
		clientProfileEntity.setUpdatedAt(new Date());
		clientProfileEntity.setUpdatedBy("admin");

		clientMappingEntity.setClient(client);
		clientMappingEntity.setUdpNormalizedClientId(request.getClientId());
		clientMappingEntity.setLiferayOrgId(request.getClientId());
		clientMappingEntity.setScrmId(request.getClientId());
		clientMappingEntity.setCloudCmsProjectId(request.getClientId());
		clientMappingEntity.setAssistGcc("");
		clientMappingEntity.setCreatedAt(new Date());
		clientMappingEntity.setCreatedBy("admin");
		clientMappingEntity.setUpdatedAt(new Date());
		clientMappingEntity.setUpdatedBy("admin");

		assertThat(attributeLookupList.get(6).getKey().equalsIgnoreCase( StartAnyWhereConstants.SMARTLAUNCH_BLANK)).isTrue();

		Assertions.assertEquals(request.getIsDataRestriction(), Boolean.FALSE);	
		
		for(int i=0; i<=attribRestrictList.size()-1; i++) {
			for(int j=0; j<=attributeLookupList.size()-1; j++) {
				clientAttributesEntity.setClient(client);
				clientAttributesEntity.setAttributeRestrictionLookup(attribRestrictList.get(i));
				clientAttributesEntity.setAttributeTypeLookup(attributeLookupList.get(j));
				clientAttributesEntity.setComment(StartAnyWhereConstants.SMARTLAUNCH_BLANK);
				clientAttributesEntity.setCreatedAt(new Date());
				clientAttributesEntity.setCreatedBy("admin");
				clientAttributesEntity.setUpdatedAt(new Date());
				clientAttributesEntity.setUpdatedBy("admin");
			}
		}

		// Mock 
		when(attributeRestrictionLookupRepoMock.findAll()).thenReturn(attribRestrictList);

		when(attributeTypeLookupRepoMock.findAll()).thenReturn(attributeLookupList);

		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(null);
		
		when(clientRepoMock.save(any())).thenReturn(client); 

		when(clientProfileRepoMock.save(any())).thenReturn(clientProfileEntity);

		when(clientMappingRepoMock.save(any())).thenReturn(clientMappingEntity);

		when(clientAttributesRepoMock.save(any())).thenReturn(clientAttributesEntity);

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(201, response.getStatusCode().value());
	}

	@Test
	public void testaddNewclientdetails_Success_DataRestriction_NO4() throws JsonProcessingException, IOException, PSQLException {

		//Mock
		ClientModel model = mock(ClientModel.class);
		when(model.getIsDataRestriction()).thenReturn(Boolean.FALSE);

		ClientEntity client = mock(ClientEntity.class);

		AttributeRestrictionLookupEntity attributeRestrictionLookupEntity = mock(AttributeRestrictionLookupEntity.class);
		when(attributeRestrictionLookupEntity.getKey()).thenReturn("Reason");

		AttributeTypeLookupEntity attributeTypeLookupEntity =mock(AttributeTypeLookupEntity.class);
		when(attributeTypeLookupEntity.getKey()).thenReturn(StartAnyWhereConstants.SMARTLAUNCH_BLANK);


		ClientProfileEntity clientProfileEntity = mock(ClientProfileEntity.class);
		when(clientProfileEntity.getAttributeTypeLookup()).thenReturn(attributeTypeLookupEntity);
		ClientMappingEntity clientMappingEntity = mock(ClientMappingEntity.class);
		when(clientMappingEntity.getUdpNormalizedClientId()).thenReturn("test");

		ClientAttributesEntity  clientAttributesEntity = mock(ClientAttributesEntity.class);
		when(clientAttributesEntity.getAttributeRestrictionLookup()).thenReturn(attributeRestrictionLookupEntity);
		when(clientAttributesEntity.getAttributeTypeLookup()).thenReturn(attributeTypeLookupEntity);
		when(clientAttributesEntity.getComment()).thenReturn(StartAnyWhereConstants.SMARTLAUNCH_BLANK);

		List<AttributeTypeLookupEntity> attributeLookupList = new ArrayList<>();

		AttributeTypeLookupEntity lookupYes = new AttributeTypeLookupEntity();
		lookupYes.setId(1L);
		lookupYes.setKey(StartAnyWhereConstants.YES);

		AttributeTypeLookupEntity lookupNo = new AttributeTypeLookupEntity();
		lookupNo.setId(2L);
		lookupNo.setKey(StartAnyWhereConstants.NO);

		AttributeTypeLookupEntity lookupAlight_Contract = new AttributeTypeLookupEntity();
		lookupAlight_Contract.setId(3L);
		lookupAlight_Contract.setKey("ALIGHT_CONTRACT");

		AttributeTypeLookupEntity lookupThird_Party_Contract = new AttributeTypeLookupEntity();
		lookupThird_Party_Contract.setId(4L);
		lookupThird_Party_Contract.setKey("THIRD_PARTY_CONTRACT");

		AttributeTypeLookupEntity lookupOther = new AttributeTypeLookupEntity();
		lookupOther.setId(5L);
		lookupOther.setKey("OTHER");

		AttributeTypeLookupEntity lookupSmartLanch_defalut = new AttributeTypeLookupEntity();
		lookupSmartLanch_defalut.setId(6L);
		lookupSmartLanch_defalut.setKey(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);

		AttributeTypeLookupEntity lookupSmartLanch_blank = new AttributeTypeLookupEntity();
		lookupSmartLanch_blank.setId(7L);
		lookupSmartLanch_blank.setKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK);

		attributeLookupList.add(lookupYes);
		attributeLookupList.add(lookupNo);
		attributeLookupList.add(lookupAlight_Contract);
		attributeLookupList.add(lookupThird_Party_Contract);
		attributeLookupList.add(lookupOther);
		attributeLookupList.add(lookupSmartLanch_defalut);
		attributeLookupList.add(lookupSmartLanch_blank);

		// Assert
		Assertions.assertEquals(7, attributeLookupList.size());
		Assertions.assertEquals(lookupYes, attributeLookupList.get(0));
		Assertions.assertEquals(lookupNo, attributeLookupList.get(1));
		Assertions.assertEquals(lookupAlight_Contract, attributeLookupList.get(2));
		Assertions.assertEquals(lookupThird_Party_Contract, attributeLookupList.get(3));
		Assertions.assertEquals(lookupOther, attributeLookupList.get(4));
		Assertions.assertEquals(lookupSmartLanch_defalut, attributeLookupList.get(5));
		Assertions.assertEquals(lookupSmartLanch_blank, attributeLookupList.get(6));


		List<AttributeRestrictionLookupEntity> attribRestrictList = new ArrayList<> ();

		AttributeRestrictionLookupEntity entity1 = new AttributeRestrictionLookupEntity();
		entity1.setId(1L);
		entity1.setKey("Location-User-PII");

		AttributeRestrictionLookupEntity entity2 = new AttributeRestrictionLookupEntity();
		entity2.setId(2L);
		entity2.setKey("Location-User-Non-PII");

		AttributeRestrictionLookupEntity entity3 = new AttributeRestrictionLookupEntity();
		entity3.setId(3L);
		entity3.setKey("Location-User-Physical");

		AttributeRestrictionLookupEntity entity4 = new AttributeRestrictionLookupEntity();
		entity4.setId(4L);
		entity4.setKey("Other");

		AttributeRestrictionLookupEntity entity5 = new AttributeRestrictionLookupEntity();
		entity5.setId(5L);
		entity5.setKey("Reason");

		attribRestrictList.add(entity1);
		attribRestrictList.add(entity2);
		attribRestrictList.add(entity3);
		attribRestrictList.add(entity4);
		attribRestrictList.add(entity5);

		// Assert
		assertNotNull(attribRestrictList);
		assertNotNull(attributeLookupList);

		// Mock 
		when(attributeRestrictionLookupRepoMock.findAll()).thenReturn(attribRestrictList);

		when(attributeTypeLookupRepoMock.findAll()).thenReturn(attributeLookupList);


		when(clientRepoMock.findByClientIdIgnoreCase("test")).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase("test")).thenReturn(null);
		
		when(clientRepoMock.save(any())).thenReturn(client); 

		when(clientProfileRepoMock.save(any())).thenReturn(clientProfileEntity);

		when(clientMappingRepoMock.save(any())).thenReturn(clientMappingEntity);

		when(clientAttributesRepoMock.save(any())).thenReturn(clientAttributesEntity);

		//Arrange
		ClientModel request = new ClientModel();
		request.setClientId("00095");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(false);

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(201, response.getStatusCode().value());
	}

	@Test
	public void testaddNewclientdetails_Success_DataRestriction_YES3() throws JsonProcessingException, IOException, PSQLException {

		//Mock
		ClientModel model = mock(ClientModel.class);
		when(model.getIsDataRestriction()).thenReturn(Boolean.TRUE);

		ClientEntity client = mock(ClientEntity.class);

		AttributeRestrictionLookupEntity attributeRestrictionLookupEntity = mock(AttributeRestrictionLookupEntity.class);
		when(attributeRestrictionLookupEntity.getKey()).thenReturn("Reason");

		AttributeTypeLookupEntity attributeTypeLookupEntity =mock(AttributeTypeLookupEntity.class);
		when(attributeTypeLookupEntity.getKey()).thenReturn(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);


		ClientProfileEntity clientProfileEntity = mock(ClientProfileEntity.class);
		when(clientProfileEntity.getAttributeTypeLookup()).thenReturn(attributeTypeLookupEntity);
		ClientMappingEntity clientMappingEntity = mock(ClientMappingEntity.class);
		when(clientMappingEntity.getUdpNormalizedClientId()).thenReturn("test");

		ClientAttributesEntity  clientAttributesEntity = mock(ClientAttributesEntity.class);
		when(clientAttributesEntity.getAttributeRestrictionLookup()).thenReturn(attributeRestrictionLookupEntity);
		when(clientAttributesEntity.getAttributeTypeLookup()).thenReturn(attributeTypeLookupEntity);
		when(clientAttributesEntity.getComment()).thenReturn(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);


		List<AttributeTypeLookupEntity> attributeLookupList = new ArrayList<>();

		AttributeTypeLookupEntity lookupYes = new AttributeTypeLookupEntity();
		lookupYes.setId(1L);
		lookupYes.setKey(StartAnyWhereConstants.YES);

		AttributeTypeLookupEntity lookupNo = new AttributeTypeLookupEntity();
		lookupNo.setId(2L);
		lookupNo.setKey(StartAnyWhereConstants.NO);

		AttributeTypeLookupEntity lookupAlight_Contract = new AttributeTypeLookupEntity();
		lookupAlight_Contract.setId(3L);
		lookupAlight_Contract.setKey("ALIGHT_CONTRACT");

		AttributeTypeLookupEntity lookupThird_Party_Contract = new AttributeTypeLookupEntity();
		lookupThird_Party_Contract.setId(4L);
		lookupThird_Party_Contract.setKey("THIRD_PARTY_CONTRACT");

		AttributeTypeLookupEntity lookupOther = new AttributeTypeLookupEntity();
		lookupOther.setId(5L);
		lookupOther.setKey("OTHER");

		AttributeTypeLookupEntity lookupSmartLanch_defalut = new AttributeTypeLookupEntity();
		lookupSmartLanch_defalut.setId(6L);
		lookupSmartLanch_defalut.setKey(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);

		AttributeTypeLookupEntity lookupSmartLanch_blank = new AttributeTypeLookupEntity();
		lookupSmartLanch_blank.setId(7L);
		lookupSmartLanch_blank.setKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK);

		attributeLookupList.add(lookupYes);
		attributeLookupList.add(lookupNo);
		attributeLookupList.add(lookupAlight_Contract);
		attributeLookupList.add(lookupThird_Party_Contract);
		attributeLookupList.add(lookupOther);
		attributeLookupList.add(lookupSmartLanch_defalut);
		attributeLookupList.add(lookupSmartLanch_blank);

		// Assert
		Assertions.assertEquals(7, attributeLookupList.size());
		Assertions.assertEquals(lookupYes, attributeLookupList.get(0));
		Assertions.assertEquals(lookupNo, attributeLookupList.get(1));
		Assertions.assertEquals(lookupAlight_Contract, attributeLookupList.get(2));
		Assertions.assertEquals(lookupThird_Party_Contract, attributeLookupList.get(3));
		Assertions.assertEquals(lookupOther, attributeLookupList.get(4));
		Assertions.assertEquals(lookupSmartLanch_defalut, attributeLookupList.get(5));
		Assertions.assertEquals(lookupSmartLanch_blank, attributeLookupList.get(6));


		List<AttributeRestrictionLookupEntity> attribRestrictList = new ArrayList<> ();

		AttributeRestrictionLookupEntity entity1 = new AttributeRestrictionLookupEntity();
		entity1.setId(1L);
		entity1.setKey("Location-User-PII");

		AttributeRestrictionLookupEntity entity2 = new AttributeRestrictionLookupEntity();
		entity2.setId(2L);
		entity2.setKey("Location-User-Non-PII");

		AttributeRestrictionLookupEntity entity3 = new AttributeRestrictionLookupEntity();
		entity3.setId(3L);
		entity3.setKey("Location-User-Physical");

		AttributeRestrictionLookupEntity entity4 = new AttributeRestrictionLookupEntity();
		entity4.setId(4L);
		entity4.setKey("Other");

		AttributeRestrictionLookupEntity entity5 = new AttributeRestrictionLookupEntity();
		entity5.setId(5L);
		entity5.setKey("Reason");

		attribRestrictList.add(entity1);
		attribRestrictList.add(entity2);
		attribRestrictList.add(entity3);
		attribRestrictList.add(entity4);
		attribRestrictList.add(entity5);

		// Assert
		assertNotNull(attribRestrictList);
		assertNotNull(attributeLookupList);

		// Mock 
		when(attributeRestrictionLookupRepoMock.findAll()).thenReturn(attribRestrictList);

		when(attributeTypeLookupRepoMock.findAll()).thenReturn(attributeLookupList);

		when(clientRepoMock.findByClientIdIgnoreCase("test")).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase("test")).thenReturn(null);

		when(clientRepoMock.save(any())).thenReturn(client); 

		when(clientProfileRepoMock.save(any())).thenReturn(clientProfileEntity);

		when(clientMappingRepoMock.save(any())).thenReturn(clientMappingEntity);

		when(clientAttributesRepoMock.save(any())).thenReturn(clientAttributesEntity);

		ClientModel request = new ClientModel();
		request.setClientId("00095");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(true);

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(201, response.getStatusCode().value());
	}
	@Test
	public void testaddNewclientdetails_Success_DataRestriction_List_NO1() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("00095");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(false);
		AttributeRestrictionLookupEntity attribRestrictEntity = new AttributeRestrictionLookupEntity();
		attribRestrictEntity.setKey("Location-User-PII");
		attribRestrictEntity.setId(5L);
		List<AttributeRestrictionLookupEntity> attribRestrictEntityList= new ArrayList<>();
		attribRestrictEntityList.add(attribRestrictEntity);

		AttributeTypeLookupEntity attribTypeLookupEntity = new AttributeTypeLookupEntity();
		attribTypeLookupEntity.setId(7L);
		attribTypeLookupEntity.setKey(StartAnyWhereConstants.SMARTLAUNCH_BLANK);
		List<AttributeTypeLookupEntity> attributeTypeLookupEntityList = new ArrayList<>();
		attributeTypeLookupEntityList.add(attribTypeLookupEntity);

		ClientEntity client = new ClientEntity();
		client.setClientId(request.getClientId());
		client.setName(request.getClientName());
		client.setEnvironmentId(1L);
		client.setCreatedAt(new Date());
		client.setUpdatedAt(new Date());
		client.setScrmId(request.getClientId());
		client.setOrgName(request.getOrgName());
		client.setLegalName(request.getOrgName());
		client.setLineage(request.getClientId());
		client.setSuperviewRestrict(false);

		ClientProfileEntity clientProfileEntity = new ClientProfileEntity();
		ClientMappingEntity clientMappingEntity = new ClientMappingEntity();
		ClientAttributesEntity  clientAttributesEntity = new ClientAttributesEntity();

		clientProfileEntity.setClient(client);
		clientProfileEntity.setAttributeTypeLookup(attribTypeLookupEntity);
		clientProfileEntity.setCreatedAt(new Date());
		clientProfileEntity.setCreatedBy("admin");
		clientProfileEntity.setUpdatedAt(new Date());
		clientProfileEntity.setUpdatedBy("admin");

		clientMappingEntity.setClient(client);
		clientMappingEntity.setUdpNormalizedClientId(request.getClientId());
		clientMappingEntity.setLiferayOrgId(request.getClientId());
		clientMappingEntity.setScrmId(request.getClientId());
		clientMappingEntity.setCloudCmsProjectId(request.getClientId());
		clientMappingEntity.setAssistGcc("");
		clientMappingEntity.setCreatedAt(new Date());
		clientMappingEntity.setCreatedBy("admin");
		clientMappingEntity.setUpdatedAt(new Date());
		clientMappingEntity.setUpdatedBy("admin");

		clientAttributesEntity.setClient(client);
		clientAttributesEntity.setAttributeRestrictionLookup(attribRestrictEntity);
		clientAttributesEntity.setAttributeTypeLookup(attribTypeLookupEntity);
		clientAttributesEntity.setComment(StartAnyWhereConstants.SMARTLAUNCH_BLANK);
		clientAttributesEntity.setCreatedAt(new Date());
		clientAttributesEntity.setCreatedBy("admin");
		clientAttributesEntity.setUpdatedAt(new Date());
		clientAttributesEntity.setUpdatedBy("admin");


		List<AttributeRestrictionLookupEntity> attribRestrictList = new ArrayList<> ();

		AttributeRestrictionLookupEntity entity4 = new AttributeRestrictionLookupEntity();
		entity4.setId(5L);
		entity4.setKey("Reason");
		attribRestrictList.add(entity4);

		List<AttributeTypeLookupEntity> attributeLookupList = Arrays.asList(new AttributeTypeLookupEntity(), new AttributeTypeLookupEntity());

		AttributeTypeLookupEntity lookupYes = new AttributeTypeLookupEntity();
		lookupYes.setKey(StartAnyWhereConstants.NO);

		attributeLookupList.set(0, lookupYes);

		// Assert
		Assertions.assertEquals(attributeLookupList.get(0).getKey(), StartAnyWhereConstants.NO);
		Assertions.assertEquals(request.getIsDataRestriction(), Boolean.FALSE);	
		
		// Mock 
		when(attributeRestrictionLookupRepoMock.findAll()).thenReturn(attribRestrictList);

		when(attributeTypeLookupRepoMock.findAll()).thenReturn(attributeLookupList);

		when(attributeTypeLookupRepoMock.findByKey(StartAnyWhereConstants.YES))
		.thenReturn(Optional.of(attribTypeLookupEntity));

		when(attributeTypeLookupRepoMock.findByKey(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT))
		.thenReturn(Optional.of(attribTypeLookupEntity));

		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(null);

		when(clientRepoMock.save(any())).thenReturn(client); 

		when(clientProfileRepoMock.save(any())).thenReturn(clientProfileEntity);

		when(clientMappingRepoMock.save(any())).thenReturn(clientMappingEntity);

		when(clientAttributesRepoMock.save(any())).thenReturn(clientAttributesEntity);

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(201, response.getStatusCode().value());
	}

	@Test
	void testaddNewclientdetails_InvalidToken() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("ABC123");
		request.setClientName("Test Client");

		// Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails("", "", "", request);

		// Assert
		assertNotNull(response);
		assertEquals(400, response.getStatusCode().value());
	}


	@Test
	void testaddNewclientdetails_ClientId() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("ABC123");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(true);
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON1(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(201, response.getStatusCode().value());
	}
	
	@Test
	void testaddNewclientdetails_localeException() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("ABC123");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(true);
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON2(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(400, response.getStatusCode().value());
	}
	@Test
	void testaddNewclientdetails_ColleagueEmailIdException() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("ABC123");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(true);
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), null, request);

		// Assert
		assertNotNull(response);
		assertEquals(400, response.getStatusCode().value());
	}

	@Test
	public void testaddNewclientdetailsExceptionTest() throws Exception  {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("ABC123");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(true);
		
		//Mock
		
		when(clientRepoMock.findByClientIdIgnoreCase(Mockito.anyString()))
		.thenThrow(new RuntimeException(new PSQLException("", null)));
		
		when(clientRepoMock.findByOrgNameIgnoreCase(Mockito.anyString()))
		.thenThrow(new RuntimeException(new PSQLException("", null)));

		//Act
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON1(), "test", request);

	}

	@Test
	public void testAddClientThrowsDuplicateException() throws JsonProcessingException, PSQLException, IOException {
		
		//Arrange
		ClientModel request = new ClientModel();
		request.setClientId("9999145");
		request.setClientName("ramyatest7");

		//Mock
		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(null);

		StartAnywhereClientService serviceMockTest = Mockito.mock(StartAnywhereClientService.class);

		//Check
		doThrow(new DuplicateClientException("Client id '9999145' or client name ramyatest7 already exists"))
		.when(serviceMockTest)
		.addNewclientdetails(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

	}
	@Test
	public void testAddClientThrowsDuplicateException_clientIdAndOrgName() throws JsonProcessingException, PSQLException, IOException {
		//Arrange
		ClientModel request = new ClientModel();

		request.setClientName("ramyatest7");
		request.setOrgName("test");

		//Mock
		when(clientRepoMock.findByClientIdIgnoreCase(request.getClientId())).thenReturn(null);
		when(clientRepoMock.findByOrgNameIgnoreCase(request.getOrgName())).thenReturn(null);

		StartAnywhereClientService serviceMockTest = Mockito.mock(StartAnywhereClientService.class);

         //Check
		doThrow(new DuplicateClientException("Client id 9999145 or org name ramyatest75 already exists"))
		.when(serviceMockTest)
		.addNewclientdetails(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

	}

	@Test
	public void testaddNewclientdetails_Header_Fail() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("ABC123");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(true);
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), null, " test", request);

		// Assert
		assertNotNull(response);
		assertEquals(400, response.getStatusCode().value());
	}

	@Test
	public void testaddNewclientdetails_ColleagueSessionToken_Fail() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("ABC123");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(true);
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(null, getMockAlightRequestHeaderJSON(),"test",  request);

		// Assert
		assertNotNull(response);
		assertEquals(400, response.getStatusCode().value());
	}

	@Test
	public void testaddNewclientdetails_HeaderAndColleagueSessionTokenJ_Fail() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("ABC123");
		request.setClientName("Test Client");
		request.setOrgName("Test Org");
		request.setIsDataRestriction(true);
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(null, null, null, request);

		// Assert
		assertNotNull(response);
		assertEquals(400, response.getStatusCode().value());
	}

	@Test
	public void testaddNewclientdetails_Request_DataRestriction_Fail() throws JsonProcessingException, IOException, PSQLException {
		// Arrange
		ClientModel request = new ClientModel();
		request.setClientId("1234");
		request.setClientName("test");
		request.setOrgName("/test");
		request.setIsDataRestriction(null);
		ResponseEntity<Object> response = serviceMock.addNewclientdetails(getMockColleagueSessionTokenJSON(), getMockAlightRequestHeaderJSON(), "test", request);

		// Assert
		assertNotNull(response);
		assertEquals(201, response.getStatusCode().value());
	}
	
	 @Test
	    void testHandleRetryFailure_shouldReturnExpectedResponse() {
	        // Given
	        Exception simulatedException = new Exception("Simulated failure");
	        String token = "testToken";
	        String header = "testHeader";
	        ClientModel mockRequest = new ClientModel(); // Populate fields if necessary

	        // When
	        ResponseEntity<Object> response = serviceMock.handleRetryFailure(
	                simulatedException, token, header, mockRequest);

	        // Then
	        assertNotNull(response);
	        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());

	        BaseResponse body = (BaseResponse) response.getBody();
	        assertNotNull(body);
	        assertEquals("503", body.getResponseCode());
	        assertEquals(StartAnyWhereConstants.DB_UNREACHABLE, body.getResponseMessage());
	        assertEquals(StartAnyWhereConstants.MSGFOR_POS101, body.getErrors().get(0).getErrorMessage());
	    }

	public String getMockAlightRequestHeaderJSON1() {
		return "{\"locale\":\"en_US\",\"clientId\":\"\"}";
	}

	public String getMockAlightRequestHeaderJSON() {
		return "{\"locale\":\"en_US\",\"clientId\":\"BA4\"}";
	}

	public String getMockColleagueSessionTokenJSON() {
		return "{\"sessionId\": \"1234567890\",\"expires\": 9876543210,\"accessToken\": \"pass your session Token here\",\"colleagueSessionMap\": {\"credentials.racf.ssoToken\": \"dev-tk\",\"credentials.racf.password\": \"********\",\"credentials.racf.id\": \"@*****\",\"credentials.ldap.HEWITT-NA.id\": \"AHId\",\"credentials.ldap.HEWITT-NA.password\": \"TestPwd\"}}";
	}
	
	public String getMockAlightRequestHeaderJSON2() {
		return "{\"locale\":\"\",\"clientId\":\"BA4\"}";
	}
	
	

}
