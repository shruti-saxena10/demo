package com.alight.cc.startanywhere.util;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import com.alight.cc.startanywhere.model.BaseResponse;
import com.alight.cc.startanywhere.model.ClientConfigError;
import com.alight.cc.startanywhere.model.ClientResponse;
import com.alight.cc.startanywhere.util.StartAnywhereUtil;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
@ExtendWith(MockitoExtension.class)
class StartAnywhereUtilTest {
	@Spy
	StartAnywhereUtil startAnywhereUtilMock;
    @Test
    void testBuildResponse_shouldPopulateFieldsCorrectly() {
        ClientResponse response = new ClientResponse();
        List<ClientConfigError> errors = new ArrayList<>();

        ClientResponse result = StartAnywhereUtil.buildResponse(
            response,
            "200",
            "Success",
            "ERR001",
            "Error message",
            "HIGH",
            "test@example.com",
            errors
        );

        assertEquals("200", result.getResponseCode());
        assertEquals("Success", result.getResponseMessage());
        assertNotNull(result.getErrors());
        assertEquals(1, result.getErrors().size());

        ClientConfigError error = result.getErrors().get(0);
        assertEquals("ERR001", error.getErrorCode());
        assertEquals("Error message", error.getErrorMessage());
        assertEquals("HIGH", error.getErrorSeverity());
        assertEquals("test@example.com", error.getEmailId());
    }

    @Test
    void testBuildResponse_shouldHandleEmptyErrorList() {
        ClientResponse response = new ClientResponse();

        // Passing empty error list
        ClientResponse result = StartAnywhereUtil.buildResponse(
            response,
            "400",
            "Bad Request",
            "ERR400",
            "Missing Data",
            "LOW",
            null,
            new ArrayList<>()
        );

        assertEquals("400", result.getResponseCode());
        assertEquals("Bad Request", result.getResponseMessage());
        assertEquals(1, result.getErrors().size());
        assertNull(result.getErrors().get(0).getEmailId());
    }

    @Test
    void testCalculateSaviyntStatusCode1_shouldReturnOK() {
        int statusCode = StartAnywhereUtil.calculateSaviyntStatusCode(0);
        assertEquals(HttpStatus.OK.value(), statusCode);
    }

    @Test
    void testCalculateSaviyntStatusCode1_shouldReturnProvidedCode() {
        int customStatusCode = HttpStatus.BAD_REQUEST.value();
        int result = StartAnywhereUtil.calculateSaviyntStatusCode(customStatusCode);
        assertEquals(customStatusCode, result);
    }
}
