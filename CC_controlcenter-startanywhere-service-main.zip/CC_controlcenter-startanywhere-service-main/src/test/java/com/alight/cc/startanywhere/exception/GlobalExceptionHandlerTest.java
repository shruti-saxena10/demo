package com.alight.cc.startanywhere.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.method.annotation.HandlerMethodValidationException;

import com.alight.cc.startanywhere.model.BaseResponse;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import jakarta.validation.ConstraintViolationException;

class GlobalExceptionHandlerTest {

	private final GlobalExceptionHandler handler = new GlobalExceptionHandler();

	@Test
	void handleValidationException_returnsBadRequest() {
		BindingResult bindingResult = mock(BindingResult.class);
		FieldError fieldError = new FieldError("object", "field", "must not be blank");
		when(bindingResult.getFieldError()).thenReturn(fieldError);


		MethodParameter methodParameter = mock(MethodParameter.class);

		MethodArgumentNotValidException ex = new MethodArgumentNotValidException(methodParameter, bindingResult);

		ResponseEntity<?> response = handler.handleValidationException(ex);

		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		BaseResponse body = (BaseResponse) response.getBody();
		assertEquals(StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST, body.getResponseCode());
		assertEquals(StartAnyWhereConstants.BAD_REQUEST, body.getResponseMessage());

	}

	@Test
	void missingRequestParameterException_returnsBadRequest() {
		MissingServletRequestParameterException ex = new MissingServletRequestParameterException("clientId", "String");
		ResponseEntity<?> response = handler.missingRequestParameterException(ex);

		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		BaseResponse body = (BaseResponse) response.getBody();
		assertEquals(StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST, body.getResponseCode());
		assertEquals(StartAnyWhereConstants.BAD_REQUEST, body.getResponseMessage());
	}

	@Test
	void handlerMethodValidationException_returnsBadRequest() {
		HandlerMethodValidationException ex = mock(HandlerMethodValidationException.class);
		ResponseEntity<?> response = handler.handlerMethodValidationException(ex);

		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		BaseResponse body = (BaseResponse) response.getBody();
		assertEquals(StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST, body.getResponseCode());
		assertEquals(StartAnyWhereConstants.BAD_REQUEST, body.getResponseMessage());
	}

	@Test
	void handleException_returnsInternalServerError() {
		Exception ex = new Exception("Something went wrong");
		ResponseEntity<?> response = handler.handleException(ex);

		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		BaseResponse body = (BaseResponse) response.getBody();
		assertEquals(StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR, body.getResponseCode());
		assertEquals(StartAnyWhereConstants.INTERNAL_SERVER_ERROR, body.getResponseMessage());
	}
	
	@Test
	void handleJsonParseError_returnsBadRequestError() {
	    Throwable cause = new JsonMappingException(null, "Cannot deserialize value of type `java.lang.Boolean` from String \"xyz\"");
	    HttpMessageNotReadableException ex = new HttpMessageNotReadableException("JSON parse error", cause);
	   
	    ResponseEntity<?> response = handler.handleJsonParseError(ex);

		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		BaseResponse body = (BaseResponse) response.getBody();
		assertEquals(StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST, body.getResponseCode());
		assertEquals(StartAnyWhereConstants.BAD_REQUEST, body.getResponseMessage());
	}
	
	@Test
	void handleConstraintViolation_returnsBadRequest() {
		ConstraintViolationException ex = mock(ConstraintViolationException.class);
		  when(ex.getMessage()).thenReturn("ConstraintViolationException: Invalid email format");

		ResponseEntity<?> response = handler.handleConstraintViolation(ex);
		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		BaseResponse body = (BaseResponse) response.getBody();
		assertEquals(StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST, body.getResponseCode());
		assertEquals(StartAnyWhereConstants.BAD_REQUEST, body.getResponseMessage());
	}
	@Test
	void handleConstraintViolation_withNullMessage_returnsDefaultError() {
	    ConstraintViolationException ex = mock(ConstraintViolationException.class);
	    when(ex.getMessage()).thenReturn(null); // Simulate null message

	    ResponseEntity<?> response = handler.handleConstraintViolation(ex);

	    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	    BaseResponse body = (BaseResponse) response.getBody();
	    assertEquals(StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST, body.getResponseCode());
	    assertEquals(StartAnyWhereConstants.BAD_REQUEST, body.getResponseMessage());
	    assertEquals("Invalid input", body.getErrors().get(0).getErrorMessage()); // Assuming this maps to finalMessage
	}
	
	@Test
	void handleConstraintViolation_withCommaInMessage_trimsFinalMessage() {
	    ConstraintViolationException ex = mock(ConstraintViolationException.class);
	    when(ex.getMessage()).thenReturn("ConstraintViolationException: Invalid email format, must contain '@'");

	    ResponseEntity<?> response = handler.handleConstraintViolation(ex);

	    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	    BaseResponse body = (BaseResponse) response.getBody();
	    assertEquals(StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST, body.getResponseCode());
	    assertEquals(StartAnyWhereConstants.BAD_REQUEST, body.getResponseMessage());
	    assertEquals("Invalid email format", body.getErrors().get(0).getErrorMessage()); // Final message trimmed before comma
	}
	
}