package com.alight.cc.startanywhere.service;

import com.alight.asg.model.header.v1_0.ResponseHeader;
import com.alight.asg.model.token.v1_0.ColleagueSessionToken;
import com.alight.cc.dto.AccountDTO;
import com.alight.cc.dto.OrganizationUserDTO;
import com.alight.cc.dto.UpdateOrganizationRequestDTO;
import com.alight.cc.startanywhere.configuration.SaviyntConfigurationBean;
import com.alight.cc.startanywhere.entity.SecurityManagerEntitlementEntity;
import com.alight.cc.startanywhere.model.*;
import com.alight.cc.startanywhere.repository.SecurityManagerEntitlementRepository;
import com.alight.cc.startanywhere.saviynt.model.*;
import com.alight.cc.startanywhere.service.*;
import com.alight.cc.startanywhere.service.impl.ClientConfigurationServiceImpl;
import com.alight.cc.startanywhere.service.impl.StartAnywhereClientServiceImpl;
import com.alight.cc.startanywhere.util.CheckClientDuplicacy;
import com.alight.cc.startanywhere.util.SaviyntRequestBuilder;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;
import com.alight.cc.startanywhere.util.StartAnywhereUtil;
import com.alight.logging.helpers.InfoTypeLogEventHelper;
import com.aonhewitt.logging.events.ErrorLogEvent;
import com.aonhewitt.logging.helpers.ErrorLogEventHelper;
import com.fasterxml.jackson.core.JsonProcessingException;

import feign.FeignException;

import org.json.simple.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.postgresql.util.PSQLException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.IOException;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ClientConfigurationServiceImplTest {

    @Mock UserService userService;
    @Mock OrganizationService orgService;
    @Mock AccountService accountService;
    @Mock EntitlementService entitlementService;
    @Mock SaviyntRequestBuilder requestBuilder;
    @Mock StartAnywhereClientServiceImpl pgService;
    @Mock ClientOnboardingRequestTrackService trackService;
    @Mock SecurityManagerEntitlementRepository entitlementRepo;
    @Mock CheckClientDuplicacy checkClientDuplicacy;
    @Mock SaviyntConfigurationBean configBeanMock;

    @InjectMocks ClientConfigurationServiceImpl service;

    ClientConfigurationRequest configRequest;
    String alightRequestHeader = "header";
    String alightColleagueSessionToken = "{\"sessionId\": \"1234567890\",\"expires\": 9876543210,\"accessToken\": \"pass your session Token here\",\"colleagueSessionMap\": {\"credentials.racf.ssoToken\": \"dev-tk\",\"credentials.racf.password\": \"*****\",\"credentials.racf.id\": \"@****\",\"credentials.ldap.HEWITT-NA.id\": \"test@alight.com\",\"credentials.ldap.HEWITT-NA.password\": \"*****\",\"clientId\":\"99887707\"}}";

    @BeforeEach
    void setup() {
        configRequest = new ClientConfigurationRequest();
        configRequest.setClientId("cid");
        configRequest.setClientName("cname");
        configRequest.setOrgName("oname");
        configRequest.setIsDataRestriction(false);
        SecurityManagerEmail sm = new SecurityManagerEmail();
        sm.setEmailId("sm@email.com");
        configRequest.setSecurityManagers(List.of(sm));
    }

    @Test
    void createClientConfiguration_returnsStatus_whenTrackServiceReturnsNonNull() throws Exception {
        ResponseEntity<Object> statusResponse = new ResponseEntity<>("already exists", HttpStatus.OK);
        when(trackService.checkStatus(alightRequestHeader, configRequest)).thenReturn(statusResponse);

        try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class)) {
            ResponseEntity<Object> result = service.createClientConfiguration(alightRequestHeader, alightColleagueSessionToken, configRequest);
            assertEquals(statusResponse, result);
        }
    }

    @Test
    void createClientConfiguration_duplicateClient_returnsDuplicateClientResponse() throws Exception {
        when(trackService.checkStatus(alightRequestHeader, configRequest)).thenReturn(null);
        
        when(checkClientDuplicacy.isDuplicateClient(any(), any(), any()))
                .thenReturn(new BaseResponse("400", "Bad Request",List.of(new ClientConfigError()) ));

        doNothing().when(trackService).saveTrack(any(), any());
        doNothing().when(trackService).updateTrack(any(), any(), any(),any());

        try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class)) {
            ResponseEntity<Object> result = service.createClientConfiguration(alightRequestHeader, alightColleagueSessionToken, configRequest);
            assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
        }
    }

    @Test
    void createClientConfiguration_accessTokenUnauthorized_returnsInternalServerError() throws Exception {
        when(trackService.checkStatus(alightRequestHeader, configRequest)).thenReturn(null);
        when(checkClientDuplicacy.isDuplicateClient(any(), any(), any())).thenReturn(null);
        doNothing().when(trackService).saveTrack(any(), any());
        FeignException unauthorized = mock(FeignException.class);
        when(unauthorized.status()).thenReturn(401);
        when(userService.getAccessToken()).thenThrow(unauthorized);

        try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class);
             MockedStatic<StartAnywhereUtil> utilMock = mockStatic(StartAnywhereUtil.class)) {
            BaseResponse resp = new BaseResponse();
            utilMock.when(() -> StartAnywhereUtil.buildResponse(any(), any(), any(), any(), any(), any(), any(), any())).thenReturn(resp);

            ResponseEntity<Object> result = service.createClientConfiguration(alightRequestHeader, alightColleagueSessionToken, configRequest);

            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
        }
    }
    @Test
    void createClientConfiguration_accessTokeOtherFEError_returnsInternalServerError() throws Exception {
        when(trackService.checkStatus(alightRequestHeader, configRequest)).thenReturn(null);
        when(checkClientDuplicacy.isDuplicateClient(any(), any(), any())).thenReturn(null);
        doNothing().when(trackService).saveTrack(any(), any());
        FeignException unauthorized = mock(FeignException.class);
        when(unauthorized.status()).thenReturn(500);
        when(userService.getAccessToken()).thenThrow(unauthorized);

        try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class);
             MockedStatic<StartAnywhereUtil> utilMock = mockStatic(StartAnywhereUtil.class)) {
            BaseResponse resp = new BaseResponse();
            utilMock.when(() -> StartAnywhereUtil.buildResponse(any(), any(), any(), any(), any(), any(), any(), any())).thenReturn(resp);

            ResponseEntity<Object> result = service.createClientConfiguration(alightRequestHeader, alightColleagueSessionToken, configRequest);

            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
        }
    }
  
    @Test
    void createClientConfiguration_entitlementCountZero_returnsInternalServerError() throws Exception {
        setupHappyPathForEntitlements(0, List.of());
        try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class);
             MockedStatic<StartAnywhereUtil> utilMock = mockStatic(StartAnywhereUtil.class)) {
            BaseResponse resp = new BaseResponse();
            utilMock.when(() -> StartAnywhereUtil.buildResponse(any(), any(), any(), any(), any(), any(), any(), any())).thenReturn(resp);

            ResponseEntity<Object> result = service.createClientConfiguration(alightRequestHeader, alightColleagueSessionToken, configRequest);

            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
        }
    }

    @Test
    void createClientConfiguration_entitlementListEmpty_returnsInternalServerError() throws Exception {
        EntitlementDetail detail = new EntitlementDetail();
        detail.setDisplayname("someOtherGroup");
        setupHappyPathForEntitlements(1, List.of(detail));
        try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class);
             MockedStatic<StartAnywhereUtil> utilMock = mockStatic(StartAnywhereUtil.class)) {
            BaseResponse resp = new BaseResponse();
            utilMock.when(() -> StartAnywhereUtil.buildResponse(any(), any(), any(), any(), any(), any(), any(), any())).thenReturn(resp);

            ResponseEntity<Object> result = service.createClientConfiguration(alightRequestHeader, alightColleagueSessionToken, configRequest);

            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
        }
    }
//    @Test
//    void createClientConfiguration_TargetentitlementListEmpty_returnsInternalServerError() throws Exception {
//        setupHappyPathForEntitlements(1, List.of());
//        try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class);
//             MockedStatic<StartAnywhereUtil> utilMock = mockStatic(StartAnywhereUtil.class)) {
//            BaseResponse resp = new BaseResponse();
//            utilMock.when(() -> StartAnywhereUtil.buildResponse(any(), any(), any(), any(), any(), any(), any(), any())).thenReturn(resp);
//
//            ResponseEntity<Object> result = service.createClientConfiguration(alightRequestHeader, alightColleagueSessionToken, configRequest);
//
//            assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
//        }
//    }

    @Test
    void createClientConfiguration_entitlementFeignException_returnsInternalServerError() throws Exception {
        when(trackService.checkStatus(any(),any())).thenReturn(null);
        when(checkClientDuplicacy.isDuplicateClient(any(), any(), any())).thenReturn(null);
        doNothing().when(trackService).saveTrack(any(), any());
        when(userService.getAccessToken()).thenReturn("token");

        SecurityManagerEntitlementEntity ent = new SecurityManagerEntitlementEntity();
        ent.setDisplayName("group<client>");
        when(entitlementRepo.findByIsSecuritymanager(1)).thenReturn(List.of(ent));

        FeignException fe = mock(FeignException.class);
        when(entitlementService.loadEntitlements(any(), any(), any())).thenThrow(fe);

        try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class);
             MockedStatic<StartAnywhereUtil> utilMock = mockStatic(StartAnywhereUtil.class);
             MockedStatic<ErrorLogEventHelper> errLogMock = mockStatic(ErrorLogEventHelper.class)) {
            BaseResponse resp = new BaseResponse();
            utilMock.when(() -> StartAnywhereUtil.buildResponse(any(), any(), any(), any(), any(), any(), any(), any())).thenReturn(resp);

            ResponseEntity<Object> result = service.createClientConfiguration(alightRequestHeader, alightColleagueSessionToken, configRequest);

            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
            errLogMock.verify(() -> ErrorLogEventHelper.logErrorEvent(any(), any(), any(), eq(fe), any()), times(1));
        }
    }

    @Test
    void createClientConfiguration_noValidMailMap_returnsBadRequest() throws Exception {
        setupHappyPathForEntitlements(1, List.of(new EntitlementDetail() {{ setDisplayname("groupcid"); }}));
        when(configBeanMock.getRequestor()).thenReturn("TEST");

        when(userService.getUserProfile(any(), any())).thenReturn(null);
        when(requestBuilder.buildEntitlementArray(any(), any())).thenReturn(List.of());
        when(requestBuilder.buildAccountRequest(any(), any(), any())).thenReturn(CreateRequest.builder().build());
        when(accountService.createRequestBulk(any(), any())).thenReturn(new JSONObject());
        // simulate orgService.createOrganisation
        when(orgService.createOrganization(any(), any())).thenReturn(CreateOrganizationResponse.builder().statusCode(200).msg("ok").errorCode("0").build());
        when(orgService.updateUserToOrganization(any(), any())).thenReturn(UpdateOrganizationResponse.builder().statusCode(200).msg("ok").errorCode("0").build());
        BaseResponse br = new BaseResponse();
        br.setResponseCode("201");
        br.setErrors(new ArrayList<ClientConfigError>());
        when(pgService.addNewclientdetails(any(), any(), any(), any())).thenReturn(new ResponseEntity<>(br, HttpStatus.OK));
        doNothing().when(trackService).updateTrack(any(), any(), any(), any());

        try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class)) {
            ResponseEntity<Object> result = service.createClientConfiguration(alightRequestHeader, alightColleagueSessionToken, configRequest);

            assertEquals(HttpStatus.OK, result.getStatusCode());
        }
    }

    @Test
    void createClientConfiguration_noAccountsForValidMail() throws Exception {
        setupHappyPathForEntitlements(1, List.of(new EntitlementDetail() {{ setDisplayname("groupcid"); }}));
        when(userService.getUserProfile(any(), any())).thenReturn(new User());
        when(accountService.getAccounts(any(), any())).thenReturn(List.of());
        when(requestBuilder.buildEntitlementArray(any(), any())).thenReturn(List.of());
        when(requestBuilder.buildAccountRequest(any(), any(), any())).thenReturn(CreateRequest.builder().build());
        when(accountService.createRequestBulk(any(), any())).thenReturn(new JSONObject());
        // simulate orgService.createOrganisation
        when(orgService.createOrganization(any(), any())).thenReturn(CreateOrganizationResponse.builder().statusCode(200).msg("ok").errorCode("0").build());
        when(orgService.updateUserToOrganization(any(), any())).thenReturn(UpdateOrganizationResponse.builder().statusCode(200).msg("ok").errorCode("0").build());
        BaseResponse br = new BaseResponse();
        br.setResponseCode("201");
        br.setErrors(new ArrayList<ClientConfigError>());
        when(pgService.addNewclientdetails(any(), any(), any(), any())).thenReturn(new ResponseEntity<>(br, HttpStatus.OK));
        doNothing().when(trackService).updateTrack(any(), any(), any(), any());
        when(configBeanMock.getRequestor()).thenReturn("TEST");
        try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class)) {
            ResponseEntity<Object> result = service.createClientConfiguration(alightRequestHeader, alightColleagueSessionToken, configRequest);

            assertEquals(HttpStatus.OK, result.getStatusCode());
        }
    }

//    @Test
//    void createClientConfiguration_allRequestsFailed_returnsInternalServerError() throws Exception {
//        setupHappyPathForEntitlements(1, List.of(new EntitlementDetail() {{ setDisplayname("groupcid"); }}));
//        when(userService.getUserProfile(any(), any())).thenReturn(new User());
//        AccountDTO account = AccountDTO.of("u", "acc", "0");
//        when(accountService.getAccounts(any(), any())).thenReturn(List.of(account));
//        doNothing().when(trackService).updateTrack(any(), any(), any(), any());
//        when(configBeanMock.getRequestor()).thenReturn("TEST");
//
//        // Remove everyone from validMailMap to trigger the branch
//        try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class)) {
//            // simulate FeignException on updateOrgUser to cause removals from validMailMap
//            ResponseEntity<Object> result = service.createClientConfiguration(alightRequestHeader, alightColleagueSessionToken, configRequest);
//
//            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
//        }
//    }

//    @Test
//    void createClientConfiguration_securityManagerUserNull_addsInvalidError() throws Exception {
//        // from image1: ensure invalidMailMap branch is covered!
//        setupHappyPathForEntitlements(1, List.of(new EntitlementDetail() {{ setDisplayname("groupcid"); }}));
//        when(userService.getUserProfile(any(), any())).thenReturn(null);
//        doNothing().when(trackService).updateTrack(any(), any(), any(), any());
//        ResponseEntity<Object> result = service.createClientConfiguration(alightRequestHeader, alightColleagueSessionToken, configRequest);
////        assertTrue(result.getBody().toString().contains("invalid emailId"));
//    }

    @Test
    void createClientConfiguration_securityManagerUserValid_addsToValidMailMap() throws Exception {
        setupHappyPathForEntitlements(1, List.of(new EntitlementDetail() {{ setDisplayname("groupcid"); }}));
        User user = new User(); user.setUsername("validUser");
        when(userService.getUserProfile(any(), any())).thenReturn(user);
        when(accountService.getAccounts(any(), any())).thenReturn(List.of(AccountDTO.of("validUser", "acc", "1")));
        when(requestBuilder.buildEntitlementArray(any(), any())).thenReturn(List.of());
        when(requestBuilder.buildAccountRequest(any(), any(), any())).thenReturn(CreateRequest.builder().build());
        when(accountService.createRequestBulk(any(), any())).thenReturn(new JSONObject());
        // simulate orgService.createOrganisation
        when(orgService.createOrganization(any(), any())).thenReturn(CreateOrganizationResponse.builder().statusCode(200).msg("ok").errorCode("0").build());
        when(orgService.updateUserToOrganization(any(), any())).thenReturn(UpdateOrganizationResponse.builder().statusCode(200).msg("ok").errorCode("0").build());
        BaseResponse br = new BaseResponse();
        br.setResponseCode("201");
        br.setErrors(new ArrayList<ClientConfigError>());
        when(pgService.addNewclientdetails(any(), any(), any(), any())).thenReturn(new ResponseEntity<>(br, HttpStatus.OK));
        doNothing().when(trackService).updateTrack(any(), any(), any(), any());

        try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class)) {
            ResponseEntity<Object> result = service.createClientConfiguration(alightRequestHeader, alightColleagueSessionToken, configRequest);
            assertEquals(HttpStatus.OK, result.getStatusCode());
        }
    }

    @Test
    void createClientConfiguration_securityManagerFeignException_addsSAV016Error() throws Exception {
        setupHappyPathForEntitlements(1, List.of(new EntitlementDetail() {{ setDisplayname("groupcid"); }}));
        when(configBeanMock.getRequestor()).thenReturn("TEST");
        when(userService.getUserProfile(any(), any())).thenThrow(mock(FeignException.class));
        when(requestBuilder.buildEntitlementArray(any(), any())).thenReturn(List.of());
        when(requestBuilder.buildAccountRequest(any(), any(), any())).thenReturn(CreateRequest.builder().build());
        when(accountService.createRequestBulk(any(), any())).thenReturn(new JSONObject());
        // simulate orgService.createOrganisation
        when(orgService.createOrganization(any(), any())).thenReturn(CreateOrganizationResponse.builder().statusCode(200).msg("ok").errorCode("0").build());
        when(orgService.updateUserToOrganization(any(), any())).thenReturn(UpdateOrganizationResponse.builder().statusCode(200).msg("ok").errorCode("0").build());
        BaseResponse br = new BaseResponse();
        br.setResponseCode("201");
        br.setErrors(new ArrayList<ClientConfigError>());
        when(pgService.addNewclientdetails(any(), any(), any(), any())).thenReturn(new ResponseEntity<>(br, HttpStatus.OK));

        doNothing().when(trackService).updateTrack(any(), any(), any(), any());
        ResponseEntity<Object> result = service.createClientConfiguration(alightRequestHeader, alightColleagueSessionToken, configRequest);
        assertTrue(result.getBody().toString().contains("SAV016"));
    }

    @Test
    void buildAddOrgUserDTO_and_buildRemoveOrgUserDTO_returnExpectedDTO() {
        ClientConfigurationRequest req = new ClientConfigurationRequest();
        req.setClientId("clientId");
        UpdateOrganizationRequestDTO addDto = invokeBuildAddOrgUserDTO(req, "someAid");
        assertEquals("clientId", addDto.getOrganizationname());
        assertEquals("ADD", addDto.getUsers().get(0).getUpdatetype());

        UpdateOrganizationRequestDTO removeDto = invokeBuildRemoveOrgUserDTO(req, "someAid");
        assertEquals("clientId", removeDto.getOrganizationname());
        assertEquals("Remove", removeDto.getUsers().get(0).getUpdatetype());
    }

//    @Test
    void getResponseEntity_handlesAllBranches() throws Exception {
        BaseResponse response = new BaseResponse();
        Exception ex = new Exception("ex");
        try (MockedStatic<ErrorLogEventHelper> errLogMock = mockStatic(ErrorLogEventHelper.class)) {
            ResponseEntity<Object> resp = invokeGetResponseEntity(response, "msg", HttpStatus.INTERNAL_SERVER_ERROR, ex, null);
            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, resp.getStatusCode());
            errLogMock.verify(() -> ErrorLogEventHelper.logErrorEvent(any(), any(), any(), eq(ex), any()), times(1));
        }

        try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class)) {
            ResponseEntity<Object> resp = invokeGetResponseEntity(response, "msg", HttpStatus.OK, null, "debug");
            assertEquals(HttpStatus.OK, resp.getStatusCode());
            logMock.verify(() -> InfoTypeLogEventHelper.logInfoEvent(any(), contains("createClientConfiguration()debug")), times(1));
        }

        // Simulate JsonProcessingException branch
        BaseResponse resp2 = new BaseResponse();
        ResponseEntity<Object> responseEntity = null;
        ResponseHeader badHeader = mock(ResponseHeader.class);
        when(badHeader.toJson()).thenThrow(JsonProcessingException.class);

        try (MockedStatic<ResponseHeader> headerMock = mockStatic(ResponseHeader.class, CALLS_REAL_METHODS)) {
            headerMock.when(ResponseHeader::new).thenReturn(badHeader);
            responseEntity = invokeGetResponseEntity(resp2, "msg", HttpStatus.OK, null, null);
            assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        }
    }
    @Test
    void createClientConfiguration_accountServiceThrowsFeignException_addsSAV014Error() throws Exception {
        // Arrange: Set up to reach the account fetching block with one validMailMap entry
        setupHappyPathForEntitlements(3, List.of(new EntitlementDetail() {{ setDisplayname("groupcid"); }}));
        User user = new User(); user.setUsername("validUser");
        when(userService.getUserProfile(any(), any())).thenReturn(user);
        when(configBeanMock.getRequestor()).thenReturn("TEST");
        // Simulate FeignException thrown by accountService.getAccounts
        when(accountService.getAccounts(any(), any())).thenThrow(mock(feign.FeignException.class));
        when(orgService.createOrganization(any(), any())).thenReturn(CreateOrganizationResponse.builder().statusCode(200).msg("ok").errorCode("0").build());
        when(orgService.updateUserToOrganization(any(), any())).thenReturn(UpdateOrganizationResponse.builder().statusCode(200).msg("ok").errorCode("0").build());
        when(accountService.createRequestBulk(any(), any())).thenReturn(new org.json.simple.JSONObject());
        BaseResponse br = new BaseResponse();
        br.setResponseCode("201");
        br.setErrors(new ArrayList<ClientConfigError>());
        when(pgService.addNewclientdetails(any(), any(), any(), any())).thenReturn(new ResponseEntity<>(br, HttpStatus.OK));
        doNothing().when(trackService).updateTrack(any(), any(), any(), any());

        // Act
        ResponseEntity<Object> result = service.createClientConfiguration(alightRequestHeader, alightColleagueSessionToken, configRequest);

        // Assert: Should have SAV014 error in response
        assertNotNull(result.getBody());
        assertTrue(result.getBody().toString().contains("SAV014"));
    }
    
    @Test
    void createClientConfiguration_organisationFeignException412_addsSav001Error() throws Exception {
        setupHappyPathForEntitlements(1, List.of(new EntitlementDetail() {{ setDisplayname("groupcid"); }}));
        User user = new User(); user.setUsername("validUser");
        when(userService.getUserProfile(any(), any())).thenReturn(user);
        when(accountService.getAccounts(any(), any())).thenReturn(List.of(AccountDTO.of("validUser", "acc", "1")));
//        when(requestBuilder.buildEntitlementArray(any(), any())).thenReturn(List.of());
//        when(requestBuilder.buildAccountRequest(any(), any(), any())).thenReturn(CreateRequest.builder().build());
        when(accountService.createRequestBulk(any(), any())).thenReturn(new org.json.simple.JSONObject());

        // Simulate FeignException with status 412 from orgService.createOrganisation
        FeignException fe = mock(FeignException.class);
        when(fe.status()).thenReturn(412);
        when(orgService.createOrganization(any(), any())).thenThrow(fe);

        when(orgService.updateUserToOrganization(any(), any())).thenReturn(UpdateOrganizationResponse.builder().statusCode(200).msg("ok").errorCode("0").build());
        when(pgService.addNewclientdetails(any(), any(), any(), any())).thenReturn(new ResponseEntity<>(new BaseResponse(), HttpStatus.OK));
        doNothing().when(trackService).updateTrack(any(), any(), any(), any());

        try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class)) {
            ResponseEntity<Object> result = service.createClientConfiguration(alightRequestHeader, alightColleagueSessionToken, configRequest);
            assertNotNull(result.getBody());
            assertTrue(result.getBody().toString().contains("SAV001")); // SAV001 error should be present
//            logMock.verify(() -> InfoTypeLogEventHelper.logInfoEvent(any(), contains("Organisation already exists")), atLeastOnce());
        }
    }
    @Test
    void createClientConfiguration_organisationFeignExceptionOther_addsOrgCreationFailedError() throws Exception {
        setupHappyPathForEntitlements(1, List.of(new EntitlementDetail() {{ setDisplayname("groupcid"); }}));
        User user = new User(); user.setUsername("validUser");
        when(userService.getUserProfile(any(), any())).thenReturn(user);
        when(accountService.getAccounts(any(), any())).thenReturn(List.of(AccountDTO.of("validUser", "acc", "1")));
//        when(requestBuilder.buildEntitlementArray(any(), any())).thenReturn(List.of());
//        when(requestBuilder.buildAccountRequest(any(), any(), any())).thenReturn(CreateRequest.builder().build());
//        when(accountService.createRequestBulk(any(), any())).thenReturn(new org.json.simple.JSONObject());

        // Simulate FeignException with status 500 from orgService.createOrganisation
        FeignException fe = mock(FeignException.class);
        when(fe.status()).thenReturn(500);
        when(orgService.createOrganization(any(), any())).thenThrow(fe);

        doNothing().when(trackService).updateTrack(any(), any(), any(), any());

        try (MockedStatic<ErrorLogEventHelper> errorLogMock = mockStatic(ErrorLogEventHelper.class)) {
            ResponseEntity<Object> result = service.createClientConfiguration(alightRequestHeader, alightColleagueSessionToken, configRequest);
            assertNotNull(result.getBody());
//            assertTrue(result.getBody().toString().contains(StartAnyWhereConstants.ORG_CREATION_FAILED));
            errorLogMock.verify(() -> ErrorLogEventHelper.logErrorEvent(any(), any(), any(), eq(fe), any()), atLeastOnce());
        }
    }
    @Test
    void createClientConfiguration_updateOrgUserFeignException412_addsSav003Error() throws Exception {
        setupHappyPathForEntitlements(1, List.of(new EntitlementDetail() {{ setDisplayname("groupcid"); }}));
        User user = new User(); user.setUsername("validUser");
        when(userService.getUserProfile(any(), any())).thenReturn(user);
        when(accountService.getAccounts(any(), any())).thenReturn(List.of(AccountDTO.of("validUser", "acc", "1")));
        when(requestBuilder.buildEntitlementArray(any(), any())).thenReturn(List.of());
        when(requestBuilder.buildAccountRequest(any(), any(), any())).thenReturn(CreateRequest.builder().build());
        when(accountService.createRequestBulk(any(), any())).thenReturn(new org.json.simple.JSONObject());

        // Organisation already exists for this user (412)
        FeignException fe = mock(FeignException.class);
        when(fe.status()).thenReturn(412);
        when(orgService.createOrganization(any(), any())).thenReturn(CreateOrganizationResponse.builder().statusCode(200).msg("ok").errorCode("0").build());
        when(orgService.updateUserToOrganization(any(), any())).thenThrow(fe);

        when(pgService.addNewclientdetails(any(), any(), any(), any())).thenReturn(new ResponseEntity<>(new BaseResponse(), HttpStatus.OK));
        doNothing().when(trackService).updateTrack(any(), any(), any(), any());

        try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class);
             MockedStatic<ErrorLogEventHelper> errorLogMock = mockStatic(ErrorLogEventHelper.class)) {
            ResponseEntity<Object> result = service.createClientConfiguration(alightRequestHeader, alightColleagueSessionToken, configRequest);
            assertNotNull(result.getBody());
            assertTrue(result.getBody().toString().contains("SAV003"));
            logMock.verify(() -> InfoTypeLogEventHelper.logInfoEvent(any(), contains("User already exists")), atLeastOnce());
            errorLogMock.verify(() -> ErrorLogEventHelper.logErrorEvent(any(), any(), any(), eq(fe), any()), atLeastOnce());
        }
    }
    @Test
    void createClientConfiguration_updateOrgUserFeignExceptionOther_addsSav013ErrorAndRemovesFromMap() throws Exception {
        setupHappyPathForEntitlements(1, List.of(new EntitlementDetail() {{ setDisplayname("groupcid"); }}));
        User user = new User(); user.setUsername("validUser");
        when(userService.getUserProfile(any(), any())).thenReturn(user);
        when(accountService.getAccounts(any(), any())).thenReturn(List.of(AccountDTO.of("validUser", "acc", "1")));
        when(requestBuilder.buildEntitlementArray(any(), any())).thenReturn(List.of());
//        when(requestBuilder.buildAccountRequest(any(), any(), any())).thenReturn(CreateRequest.builder().build());
//        when(accountService.createRequestBulk(any(), any())).thenReturn(new org.json.simple.JSONObject());

        // Some other error (not 412)
        FeignException fe = mock(FeignException.class);
        when(fe.status()).thenReturn(500);
        when(orgService.createOrganization(any(), any())).thenReturn(CreateOrganizationResponse.builder().statusCode(200).msg("ok").errorCode("0").build());
        when(orgService.updateUserToOrganization(any(), any())).thenThrow(fe);

        doNothing().when(trackService).updateTrack(any(), any(), any(), any());

        try (MockedStatic<ErrorLogEventHelper> errorLogMock = mockStatic(ErrorLogEventHelper.class)) {
            ResponseEntity<Object> result = service.createClientConfiguration(alightRequestHeader, alightColleagueSessionToken, configRequest);
            assertNotNull(result.getBody());
            assertTrue(result.getBody().toString().contains("SAV013"));
            errorLogMock.verify(() -> ErrorLogEventHelper.logErrorEvent(any(), contains(StartAnyWhereConstants.SAV013_MSG), any(), eq(fe), any()), atLeastOnce());
        }
    }
    @Test
    void createClientConfiguration_bulkRequestFeignException412_addsSav012ErrorAndRemoves() throws Exception {
        setupHappyPathForEntitlements(1, List.of(new EntitlementDetail() {{ setDisplayname("groupcid"); }}));
        User user = new User(); user.setUsername("validUser");
        when(userService.getUserProfile(any(), any())).thenReturn(user);
        when(accountService.getAccounts(any(), any())).thenReturn(List.of(AccountDTO.of("validUser", "acc", "1")));
        when(requestBuilder.buildEntitlementArray(any(), any())).thenReturn(List.of());
        when(requestBuilder.buildAccountRequest(any(), any(), any())).thenReturn(CreateRequest.builder().build());
        // Org creation and user update succeed so we hit the bulk request block
        when(orgService.createOrganization(any(), any())).thenReturn(CreateOrganizationResponse.builder().statusCode(200).msg("ok").errorCode("0").build());
        when(orgService.updateUserToOrganization(any(), any())).thenReturn(UpdateOrganizationResponse.builder().statusCode(200).msg("ok").errorCode("0").build());

        // Simulate FeignException with status 412 from createRequestBulk
        FeignException fe = mock(FeignException.class);
        when(fe.status()).thenReturn(412);
        when(accountService.createRequestBulk(any(), any())).thenThrow(fe);
        doNothing().when(trackService).updateTrack(any(), any(), any(), any());

        try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class);
             MockedStatic<ErrorLogEventHelper> errorLogMock = mockStatic(ErrorLogEventHelper.class)) {
            ResponseEntity<Object> result = service.createClientConfiguration(alightRequestHeader, alightColleagueSessionToken, configRequest);
            assertNotNull(result.getBody());
            assertTrue(result.getBody().toString().contains("SAV012"));
            logMock.verify(() -> InfoTypeLogEventHelper.logInfoEvent(any(), contains("Bulk request failed due to precondition check")), atLeastOnce());
            errorLogMock.verify(() -> ErrorLogEventHelper.logErrorEvent(any(), contains(StartAnyWhereConstants.SAV012_MSG), any(), eq(fe), any()), atLeastOnce());
        }
    }

    @Test
    void createClientConfiguration_bulkRequestFeignExceptionOther_addsSav004ErrorAndRemoves() throws Exception {
        setupHappyPathForEntitlements(1, List.of(new EntitlementDetail() {{ setDisplayname("groupcid"); }}));
        User user = new User(); user.setUsername("validUser");
        when(userService.getUserProfile(any(), any())).thenReturn(user);
        when(accountService.getAccounts(any(), any())).thenReturn(List.of(AccountDTO.of("validUser", "acc", "1")));
        when(requestBuilder.buildEntitlementArray(any(), any())).thenReturn(List.of());
        when(requestBuilder.buildAccountRequest(any(), any(), any())).thenReturn(CreateRequest.builder().build());
        // Org creation and user update succeed so we hit the bulk request block
        when(orgService.createOrganization(any(), any())).thenReturn(CreateOrganizationResponse.builder().statusCode(200).msg("ok").errorCode("0").build());
        when(orgService.updateUserToOrganization(any(), any())).thenReturn(UpdateOrganizationResponse.builder().statusCode(200).msg("ok").errorCode("0").build());

        // Simulate FeignException with status 500 from createRequestBulk
        FeignException fe = mock(FeignException.class);
        when(fe.status()).thenReturn(500);
        when(accountService.createRequestBulk(any(), any())).thenThrow(fe);
        doNothing().when(trackService).updateTrack(any(), any(), any(), any());

        try (MockedStatic<ErrorLogEventHelper> errorLogMock = mockStatic(ErrorLogEventHelper.class)) {
            ResponseEntity<Object> result = service.createClientConfiguration(alightRequestHeader, alightColleagueSessionToken, configRequest);
            assertNotNull(result.getBody());
            assertTrue(result.getBody().toString().contains("SAV004"));
            errorLogMock.verify(() -> ErrorLogEventHelper.logErrorEvent(any(), contains(StartAnyWhereConstants.SAV004_MSG), any(), eq(fe), any()), atLeastOnce());
        }
    }
    @Test
    void createClientConfiguration_pgServiceReturns5xx_setsInternalServerErrorAndReturnsFailed() throws Exception {
        setupHappyPathForEntitlements(1, List.of(new EntitlementDetail() {{ setDisplayname("groupcid"); }}));
        User user = new User(); user.setUsername("validUser");
        when(userService.getUserProfile(any(), any())).thenReturn(user);
        when(accountService.getAccounts(any(), any())).thenReturn(List.of(AccountDTO.of("validUser", "acc", "1")));
        when(requestBuilder.buildEntitlementArray(any(), any())).thenReturn(List.of());
        when(requestBuilder.buildAccountRequest(any(), any(), any())).thenReturn(CreateRequest.builder().build());
        when(accountService.createRequestBulk(any(), any())).thenReturn(new JSONObject());

        when(orgService.createOrganization(any(), any())).thenReturn(CreateOrganizationResponse.builder().statusCode(200).msg("ok").errorCode("0").build());
        when(orgService.updateUserToOrganization(any(), any())).thenReturn(UpdateOrganizationResponse.builder().statusCode(200).msg("ok").errorCode("0").build());

        // Mock Postgres response with 5xx error
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.setErrors(List.of(new ClientConfigError())); // Simulate errors returned
        ResponseEntity<Object> pgResponse = new ResponseEntity<>(baseResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        when(pgService.addNewclientdetails(any(), any(), any(), any())).thenReturn(pgResponse);
        doNothing().when(trackService).updateTrack(any(), any(), any(), any());

        try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class)) {
            ResponseEntity<Object> result = service.createClientConfiguration(alightRequestHeader, alightColleagueSessionToken, configRequest);
            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
//            assertTrue(result.getBody().toString().contains(StartAnyWhereConstants.CONFIGURATION_FAILED));
            logMock.verify(() -> InfoTypeLogEventHelper.logInfoEvent(any(), contains("Postgress save is responding with 5xx")), atLeastOnce());
        }
    }
    @Test
    void createClientConfiguration_pgServiceThrowsPSQLException_setsInternalServerErrorAndReturnsFailed() throws Exception {
        setupHappyPathForEntitlements(1, List.of(new EntitlementDetail() {{ setDisplayname("groupcid"); }}));
        User user = new User(); user.setUsername("validUser");
        when(userService.getUserProfile(any(), any())).thenReturn(user);
        when(accountService.getAccounts(any(), any())).thenReturn(List.of(AccountDTO.of("validUser", "acc", "1")));
        when(requestBuilder.buildEntitlementArray(any(), any())).thenReturn(List.of());
        when(requestBuilder.buildAccountRequest(any(), any(), any())).thenReturn(CreateRequest.builder().build());
        when(accountService.createRequestBulk(any(), any())).thenReturn(new JSONObject());

        when(orgService.createOrganization(any(), any())).thenReturn(CreateOrganizationResponse.builder().statusCode(200).msg("ok").errorCode("0").build());
        when(orgService.updateUserToOrganization(any(), any())).thenReturn(UpdateOrganizationResponse.builder().statusCode(200).msg("ok").errorCode("0").build());

        // Simulate PSQLException thrown by pgService.addNewclientdetails
        when(pgService.addNewclientdetails(any(), any(), any(), any())).thenThrow(new org.postgresql.util.PSQLException("fail", null));
        doNothing().when(trackService).updateTrack(any(), any(), any(), any());

        try (MockedStatic<ErrorLogEventHelper> errorLogMock = mockStatic(ErrorLogEventHelper.class)) {
            ResponseEntity<Object> result = service.createClientConfiguration(alightRequestHeader, alightColleagueSessionToken, configRequest);
            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
            assertTrue(result.getBody().toString().contains(StartAnyWhereConstants.POSTGRESS_SAVE_FAILED));
            errorLogMock.verify(() -> ErrorLogEventHelper.logErrorEvent(any(), eq(StartAnyWhereConstants.POSTGRESS_SAVE_FAILED), any(), any(), any()), atLeastOnce());
        }
    }
    @Test
    public void updateOrgUser_elseBlockTest() throws JsonProcessingException, IOException {
        when(orgService.updateUserToOrganization(any(), any())).thenReturn(UpdateOrganizationResponse.builder().statusCode(200).msg("ok").errorCode("0").build());
        service.updateOrgUser("REMOVE", configRequest, "A1067784", "token");
    }
    @Test
    void testGetRequestorMailId_withLdapKey() {
        // Arrange
        ColleagueSessionToken token = Mockito.mock(ColleagueSessionToken.class);
        Map<String, String> sessionMap = new HashMap<>();
        sessionMap.put(ColleagueSessionToken.CREDENTIALS_LDAP_ID, "ldap_user");
        Mockito.when(token.getColleagueSessionMap()).thenReturn(sessionMap);
        Mockito.when(token.getColleagueSessionMapEntry(ColleagueSessionToken.CREDENTIALS_LDAP_ID)).thenReturn("ldap_user");

        // Act
        String result = service.getRequestorMailId(token);

        // Assert
        assertEquals("ldap_user", result);
    }

    @Test
    void testGetRequestorMailId_withHewittKey() {
        // Arrange
        ColleagueSessionToken token = Mockito.mock(ColleagueSessionToken.class);
        Map<String, String> sessionMap = new HashMap<>();
        sessionMap.put("credentials.ldap.HEWITT-NA.id", "hewitt_user");
        Mockito.when(token.getColleagueSessionMap()).thenReturn(sessionMap);
        Mockito.when(token.getColleagueSessionMapEntry("credentials.ldap.HEWITT-NA.id")).thenReturn("hewitt_user");

        // Act
        String result = service.getRequestorMailId(token);

        // Assert
        assertEquals("hewitt_user", result);
    }

    @Test
    void testGetRequestorMailId_withNoKeys() {
        // Arrange
        ColleagueSessionToken token = Mockito.mock(ColleagueSessionToken.class);
        Map<String, String> sessionMap = new HashMap<>();
        Mockito.when(token.getColleagueSessionMap()).thenReturn(sessionMap);
    	when(configBeanMock.getRequestor()).thenReturn("TEST");

        // Act
        String result = service.getRequestorMailId(token);

        // Assert
        assertEquals("TEST", result);
    }

    @Test
    void testGetRequestorMailId_withException() {
        // Arrange
    	when(configBeanMock.getRequestor()).thenReturn("TEST");

        ColleagueSessionToken token = Mockito.mock(ColleagueSessionToken.class);
        Mockito.when(token.getColleagueSessionMap()).thenThrow(new RuntimeException("test"));

        // Act
        String result = service.getRequestorMailId(token);

        // Assert
        assertEquals("TEST", result);
    }
    // ---- Helpers for setup and private method coverage ----

    private void setupHappyPathForEntitlements(int entCount, List<EntitlementDetail> details) throws Exception {
        when(trackService.checkStatus(any(), any())).thenReturn(null);
        when(checkClientDuplicacy.isDuplicateClient(any(), any(), any())).thenReturn(null);
        doNothing().when(trackService).saveTrack(any(), any());
        when(userService.getAccessToken()).thenReturn("token");

        SecurityManagerEntitlementEntity ent = new SecurityManagerEntitlementEntity();
        ent.setDisplayName("groupcid");
        when(entitlementRepo.findByIsSecuritymanager(1)).thenReturn(List.of(ent,ent,ent));

        EntitlementsResponse entResp = new EntitlementsResponse();
        entResp.setTotalEntitlementCount(entCount);
        entResp.setEntitlementdetails(details);
        when(entitlementService.loadEntitlements(any(), any(), any())).thenReturn(entResp);
    }
    private void setupHappyPathForEntitlements2(int entCount, List<EntitlementDetail> details) throws Exception {
        when(trackService.checkStatus(any(), any())).thenReturn(null);
        when(checkClientDuplicacy.isDuplicateClient(any(), any(), any())).thenReturn(null);
        doNothing().when(trackService).saveTrack(any(), any());
        when(userService.getAccessToken()).thenReturn("token");

        SecurityManagerEntitlementEntity ent = new SecurityManagerEntitlementEntity();
        ent.setDisplayName("groupcid");
        SecurityManagerEntitlementEntity ent2 = new SecurityManagerEntitlementEntity();
        ent2.setDisplayName("groupcid-notfound");
        when(entitlementRepo.findByIsSecuritymanager(1)).thenReturn(List.of(ent,ent2));

        EntitlementsResponse entResp = new EntitlementsResponse();
        entResp.setTotalEntitlementCount(entCount);
        entResp.setEntitlementdetails(details);
        when(entitlementService.loadEntitlements(any(), any(), any())).thenReturn(entResp);
    }

    private UpdateOrganizationRequestDTO invokeBuildAddOrgUserDTO(ClientConfigurationRequest req, String aid) {
        try {
            var m = ClientConfigurationServiceImpl.class.getDeclaredMethod("buildAddOrgUserDTO", ClientConfigurationRequest.class, String.class);
            m.setAccessible(true);
            return (UpdateOrganizationRequestDTO) m.invoke(service, req, aid);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private UpdateOrganizationRequestDTO invokeBuildRemoveOrgUserDTO(ClientConfigurationRequest req, String aid) {
        try {
            var m = ClientConfigurationServiceImpl.class.getDeclaredMethod("buildRemoveOrgUserDTO", ClientConfigurationRequest.class, String.class);
            m.setAccessible(true);
            return (UpdateOrganizationRequestDTO) m.invoke(service, req, aid);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private ResponseEntity<Object> invokeGetResponseEntity(BaseResponse response, String responseMessage, HttpStatus responseStatus, Exception ex, String debugMessage) throws Exception {
        var m = ClientConfigurationServiceImpl.class.getDeclaredMethod("getResponseEntity", BaseResponse.class, String.class, HttpStatus.class, Exception.class, String.class);
        m.setAccessible(true);
        return (ResponseEntity<Object>) m.invoke(service, response, responseMessage, responseStatus, ex, debugMessage);
    }
}