package com.alight.cc.startanywhere.configuration;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.cache.CacheManager;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;

import com.alight.logging.helpers.InfoTypeLogEventHelper;
@ExtendWith(MockitoExtension.class)
class CachingConfigTest {

    private CachingConfig config;

    @BeforeEach
    void setup() {
        config = new CachingConfig();
    }

    //  Test the CacheManager bean creation
    @Test
    void testCacheManagerBeanCreatesExpectedCache() {
        CacheManager manager = config.cacheManager();
        assertNotNull(manager);
        assertTrue(manager instanceof ConcurrentMapCacheManager);

        ConcurrentMapCacheManager mapManager = (ConcurrentMapCacheManager) manager;
        assertNotNull(mapManager.getCache(CachingConfig.saviyntAccessToken));
    }

    // Test the scheduled cache evict method directly
    @Test
    void testReportSaviyntAccessTokenCacheEvictLogsMessage() {
        try (MockedStatic<InfoTypeLogEventHelper> staticMock = Mockito.mockStatic(InfoTypeLogEventHelper.class)) {

            config.reportSaviyntAccessTokenCacheEvict(); // Invoke scheduled method manually

            staticMock.verify(() ->
                InfoTypeLogEventHelper.logInfoEvent(
                    CachingConfig.class.getName(),
                    "Flush Control Center saviyntAccessToken."
                ),
                Mockito.times(1)
            );
        }
    }
}
