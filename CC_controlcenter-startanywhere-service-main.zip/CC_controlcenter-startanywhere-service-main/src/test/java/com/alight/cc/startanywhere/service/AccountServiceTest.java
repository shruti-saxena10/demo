package com.alight.cc.startanywhere.service;

import com.alight.cc.dto.AccountDTO;
import com.alight.cc.startanywhere.feign.SaviyntClient;
import com.alight.cc.startanywhere.saviynt.model.AccountDetails;
import com.alight.cc.startanywhere.saviynt.model.CreateRequest;
import com.alight.cc.startanywhere.saviynt.model.GetAccountsRequest;
import com.alight.cc.startanywhere.saviynt.model.GetAccountsResponse;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;
import com.alight.cc.startanywhere.util.StartAnywhereUtil;
import com.alight.logging.helpers.InfoTypeLogEventHelper;
import feign.FeignException;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AccountServiceTest {

    @Mock
    private SaviyntClient saviyntClient;

    @InjectMocks
    private AccountService accountService;

    @BeforeEach
    void setup() {
        // No-op, handled by MockitoExtension
    }

    // --- getAccounts ---

    @Test
    void getAccounts_returnsAccountDTOs_whenStatusOkAndAccountsPresent() {
        String username = "user";
        String accessToken = "token";

        AccountDetails accountDetails = new AccountDetails();
        accountDetails.setUsername("user1");
        accountDetails.setName("User One");
        accountDetails.setStatus("ACTIVE");

        List<AccountDetails> detailList = new ArrayList<>();
        detailList.add(accountDetails);

        GetAccountsResponse response = new GetAccountsResponse();
        response.setStatusCode(HttpStatus.OK.value());
        response.setAccountDetails(detailList);

        try (MockedStatic<StartAnywhereUtil> utilMock = Mockito.mockStatic(StartAnywhereUtil.class);
             MockedStatic<InfoTypeLogEventHelper> logMock = Mockito.mockStatic(InfoTypeLogEventHelper.class)) {

            when(saviyntClient.getAccounts(anyString(), any(GetAccountsRequest.class))).thenReturn(response);
            utilMock.when(() -> StartAnywhereUtil.calculateSaviyntStatusCode(HttpStatus.OK.value()))
                    .thenReturn(HttpStatus.OK.value());

            List<AccountDTO> result = accountService.getAccounts(username, accessToken);

            assertEquals(1, result.size());
            assertEquals("user1", result.get(0).getUsername());
            logMock.verify(() ->
                InfoTypeLogEventHelper.logInfoEvent(any(), contains("Response from get accounts")), times(1)
            );
        }
    }

    @Test
    void getAccounts_returnsEmptyList_whenStatusOkButNoAccounts() {
        String username = "user";
        String accessToken = "token";

        GetAccountsResponse response = new GetAccountsResponse();
        response.setStatusCode(HttpStatus.OK.value());
        response.setAccountDetails(new ArrayList<>());

        try (MockedStatic<StartAnywhereUtil> utilMock = Mockito.mockStatic(StartAnywhereUtil.class);
             MockedStatic<InfoTypeLogEventHelper> logMock = Mockito.mockStatic(InfoTypeLogEventHelper.class)) {

            when(saviyntClient.getAccounts(anyString(), any(GetAccountsRequest.class))).thenReturn(response);
            utilMock.when(() -> StartAnywhereUtil.calculateSaviyntStatusCode(HttpStatus.OK.value()))
                    .thenReturn(HttpStatus.OK.value());

            List<AccountDTO> result = accountService.getAccounts(username, accessToken);

            assertNotNull(result);
            assertTrue(result.isEmpty());
        }
    }

    @Test
    void getAccounts_returnsEmptyList_whenStatusNotOk() {
        String username = "user";
        String accessToken = "token";

        GetAccountsResponse response = new GetAccountsResponse();
        response.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
        response.setAccountDetails(new ArrayList<>());

        try (MockedStatic<StartAnywhereUtil> utilMock = Mockito.mockStatic(StartAnywhereUtil.class);
             MockedStatic<InfoTypeLogEventHelper> logMock = Mockito.mockStatic(InfoTypeLogEventHelper.class)) {

            when(saviyntClient.getAccounts(anyString(), any(GetAccountsRequest.class))).thenReturn(response);
            utilMock.when(() -> StartAnywhereUtil.calculateSaviyntStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value()))
                    .thenReturn(HttpStatus.INTERNAL_SERVER_ERROR.value());

            List<AccountDTO> result = accountService.getAccounts(username, accessToken);

            assertNotNull(result);
            assertTrue(result.isEmpty());
        }
    }

    @Test
    void getAccounts_returnsEmptyList_whenAccountDetailsNull() {
        String username = "user";
        String accessToken = "token";

        GetAccountsResponse response = new GetAccountsResponse();
        response.setStatusCode(HttpStatus.OK.value());
        response.setAccountDetails(null);

        try (MockedStatic<StartAnywhereUtil> utilMock = Mockito.mockStatic(StartAnywhereUtil.class);
             MockedStatic<InfoTypeLogEventHelper> logMock = Mockito.mockStatic(InfoTypeLogEventHelper.class)) {

            when(saviyntClient.getAccounts(anyString(), any(GetAccountsRequest.class))).thenReturn(response);
            utilMock.when(() -> StartAnywhereUtil.calculateSaviyntStatusCode(HttpStatus.OK.value()))
                    .thenReturn(HttpStatus.OK.value());

            List<AccountDTO> result = accountService.getAccounts(username, accessToken);

            assertNotNull(result);
            assertTrue(result.isEmpty());
        }
    }

    // --- createRequestBulk ---

    @Test
    void createRequestBulk_returnsResponse() {
        CreateRequest cr = mock(CreateRequest.class);
        String accessToken = "token";
        JSONObject expected = new JSONObject();
        expected.put("key", "value");

        when(saviyntClient.createRequest(anyString(), eq(cr))).thenReturn(expected);

        JSONObject result = accountService.createRequestBulk(cr, accessToken);

        assertEquals(expected, result);
        verify(saviyntClient).createRequest(anyString(), eq(cr));
    }



}