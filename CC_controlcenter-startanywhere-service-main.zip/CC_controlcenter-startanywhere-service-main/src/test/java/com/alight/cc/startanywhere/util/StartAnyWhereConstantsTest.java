package com.alight.cc.startanywhere.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.lang.reflect.Field;

@ExtendWith(MockitoExtension.class)
public class StartAnyWhereConstantsTest {
	@Spy
    private StartAnyWhereConstants startAnyWhereConstants;
    @Test
    public void testConstantsValues() {
        assertEquals("Y", StartAnyWhereConstants.YES);
        assertEquals("N", StartAnyWhereConstants.NO);
        assertEquals("SMARTLAUNCH_DEFAULT", StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);
        assertEquals("SMARTLAUNCH_BLANK", StartAnyWhereConstants.SMARTLAUNCH_BLANK);
        assertEquals("POS101", StartAnyWhereConstants.POS101);
        assertEquals("POS102", StartAnyWhereConstants.POS102);
        assertEquals("POS103", StartAnyWhereConstants.POS103);
        assertEquals("POS104", StartAnyWhereConstants.POS104);
        assertEquals("POS105", StartAnyWhereConstants.POS105);
        assertEquals("POS106", StartAnyWhereConstants.POS106);
        assertEquals("POS107", StartAnyWhereConstants.POS107);
        
    }
    
    @Test
    public void testConstantsCoverage() throws Exception {
        Field yesField = StartAnyWhereConstants.class.getDeclaredField("YES");
        Field noField = StartAnyWhereConstants.class.getDeclaredField("NO");

        assertEquals("Y", yesField.get(null));
        assertEquals("N", noField.get(null));
    }
    
}

