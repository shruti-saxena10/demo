package com.alight.cc.startanywhere.service;

import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.contains;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.startsWith;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.json.simple.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.alight.cc.dto.EntitlementDTO;
import com.alight.cc.dto.UserEntitlementsDTO;
import com.alight.cc.model.exception.InvalidRequestException;
import com.alight.cc.startanywhere.configuration.SaviyntConfigurationBean;
import com.alight.cc.startanywhere.exception.CCServiceException;
import com.alight.cc.startanywhere.feign.SaviyntClient;
import com.alight.cc.startanywhere.saviynt.model.EntitlementsResponse;
import com.alight.cc.startanywhere.saviynt.model.GetEntitlementsRequest;
import com.alight.cc.startanywhere.saviynt.model.UpdateUserEntitlementsRequest;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;
import com.alight.logging.helpers.InfoTypeLogEventHelper;

import feign.FeignException;

@ExtendWith(MockitoExtension.class)
class EntitlementServiceTest {

    @Mock
    UserService userService;

    @Mock
    SaviyntClient saviyntClient;

    @Mock
    SaviyntConfigurationBean saviyntConfig;
    
    @Mock
	SaviyntService saviyntService;

    @InjectMocks
    EntitlementService entitlementService;

    @BeforeEach
    void setup() {
        // No-op
    }

    @Test
    void loadEntitlements_successfulResponse() {
        String username = "user";
        String accessToken = "token";
        String clientId = "client";

        when(saviyntConfig.getEndpoint()).thenReturn("http://endpoint");
        EntitlementsResponse mockResponse = new EntitlementsResponse();

        try (MockedStatic<InfoTypeLogEventHelper> logMock = Mockito.mockStatic(InfoTypeLogEventHelper.class)) {
            when(saviyntClient.getEntitlements(anyString(), any(GetEntitlementsRequest.class))).thenReturn(mockResponse);

            EntitlementsResponse result = entitlementService.loadEntitlements(username, accessToken, clientId);

            assertEquals(mockResponse, result);

            ArgumentCaptor<GetEntitlementsRequest> reqCaptor = ArgumentCaptor.forClass(GetEntitlementsRequest.class);
            verify(saviyntClient).getEntitlements(startsWith("Bearer "), reqCaptor.capture());

            GetEntitlementsRequest sentReq = reqCaptor.getValue();
            assertEquals(username, sentReq.getUsername());
            assertTrue(sentReq.getEntQuery().contains(clientId));
            assertEquals("http://endpoint", sentReq.getEndpoint());
            assertEquals(StartAnyWhereConstants.SAVIYNT_ENTITLEMENT_ACTIVE_STATUS, sentReq.getStatus());
            assertEquals(StartAnyWhereConstants.SAVIYNT_MAX_ENTITLEMENTS, sentReq.getMax());
            assertEquals(StartAnyWhereConstants.OFFSET, sentReq.getOffset());

            logMock.verify(() -> InfoTypeLogEventHelper.logInfoEvent(eq(EntitlementService.class.getName()), contains("Response from getting entitlements:")), times(1));
        }
    }

//    @Test
    void loadEntitlements_retriesOnFeignException() {
        String username = "user";
        String accessToken = "token";
        String clientId = "client";

        when(saviyntConfig.getEndpoint()).thenReturn("http://endpoint");
        FeignException feignEx = mock(FeignException.class);
        when(feignEx.status()).thenReturn(500);
        EntitlementsResponse mockResponse = new EntitlementsResponse();

        try (MockedStatic<InfoTypeLogEventHelper> logMock = Mockito.mockStatic(InfoTypeLogEventHelper.class)) {
            when(saviyntClient.getEntitlements(anyString(), any(GetEntitlementsRequest.class)))
                .thenThrow(feignEx)
                .thenThrow(feignEx)
                .thenReturn(mockResponse);

            EntitlementsResponse result = entitlementService.loadEntitlements(username, accessToken, clientId);

            assertEquals(mockResponse, result);
            verify(saviyntClient, times(3)).getEntitlements(anyString(), any(GetEntitlementsRequest.class));
            logMock.verify(() -> InfoTypeLogEventHelper.logInfoEvent(eq(EntitlementService.class.getName()), contains("Response from getting entitlements:")), times(1));
        }
    }

	@Test
	void updateUser_validInput_returnsUserEntitlementsDTO() throws Exception {
		// Arrange
		UserEntitlementsDTO userEntitlements = new UserEntitlementsDTO();
		userEntitlements.setRequestType("REMOVE");
		userEntitlements.setEmail("user@example.com");
		userEntitlements.setUserName("testUser");
		userEntitlements.setAccountName("testAccount");

		EntitlementDTO entitlementDTO = new EntitlementDTO();
		entitlementDTO.setValue("READ_ACCESS");
		userEntitlements.setEntitlements(List.of(entitlementDTO));

		String accessToken = "abc123";

		// Mock dependencies
		when(userService.determineUserTypeByEmailDomain("user@example.com")).thenReturn("INTERNAL");
		when(saviyntService.getEndpoint("INTERNAL")).thenReturn("endpoint123");
		when(saviyntService.getSecuritySystem("INTERNAL")).thenReturn("securitySystemXYZ");

		JSONObject mockResponse = new JSONObject();
		mockResponse.put("status", "success");

		when(saviyntClient.updateEntitlementsOnUser(eq("Bearer " + accessToken), any(UpdateUserEntitlementsRequest.class)))
		.thenReturn(mockResponse);

		// Act
		UserEntitlementsDTO result = entitlementService.updateUser(userEntitlements, accessToken);

		// Assert
		assertNotNull(result);
		assertEquals("testUser", result.getUserName());
		assertEquals("user@example.com", result.getEmail());

		// Optionally verify client call
		verify(saviyntClient).updateEntitlementsOnUser(eq("Bearer " + accessToken), any(UpdateUserEntitlementsRequest.class));
	}
	
	@Test
	void updateUser_validInput_returnsUserEntitlementsDTO_getEndpoint_Null() throws Exception {
		// Arrange
		UserEntitlementsDTO userEntitlements = new UserEntitlementsDTO();
		userEntitlements.setRequestType("REMOVE");
		userEntitlements.setEmail("user@example.com");
		userEntitlements.setUserName("testUser");
		userEntitlements.setAccountName("testAccount");

		EntitlementDTO entitlementDTO = new EntitlementDTO();
		entitlementDTO.setValue("READ_ACCESS");
		userEntitlements.setEntitlements(List.of(entitlementDTO));

		String accessToken = "abc123";

		// Mock dependencies
		when(userService.determineUserTypeByEmailDomain("user@example.com")).thenReturn("INTERNAL");
		when(saviyntService.getEndpoint("INTERNAL")).thenReturn(null);
		when(saviyntService.getSecuritySystem("INTERNAL")).thenReturn("securitySystemXYZ");

		JSONObject mockResponse = new JSONObject();
		mockResponse.put("status", "success");


		assertThrows(CCServiceException.class, () -> {
			entitlementService.updateUser(userEntitlements, accessToken);
		});
	}
	@Test
	void updateUser_validInput_returnsUserEntitlementsDTO_getSecuritySystem_Null() throws Exception {
		// Arrange
		UserEntitlementsDTO userEntitlements = new UserEntitlementsDTO();
		userEntitlements.setRequestType("REMOVE");
		userEntitlements.setEmail("user@example.com");
		userEntitlements.setUserName("testUser");
		userEntitlements.setAccountName("testAccount");

		EntitlementDTO entitlementDTO = new EntitlementDTO();
		entitlementDTO.setValue("READ_ACCESS");
		userEntitlements.setEntitlements(List.of(entitlementDTO));

		String accessToken = "abc123";

		// Mock dependencies
		when(userService.determineUserTypeByEmailDomain("user@example.com")).thenReturn("INTERNAL");
		when(saviyntService.getEndpoint("INTERNAL")).thenReturn("endpoint123");
		when(saviyntService.getSecuritySystem("INTERNAL")).thenReturn(null);

		JSONObject mockResponse = new JSONObject();
		mockResponse.put("status", "success");


		assertThrows(CCServiceException.class, () -> {
			entitlementService.updateUser(userEntitlements, accessToken);
		});
	}

	@Test
	void updateUser_validInput_returnsUserEntitlementsDTO_Null() throws Exception {
		// Arrange
		UserEntitlementsDTO userEntitlements = new UserEntitlementsDTO();
		userEntitlements.setRequestType("REMOVE");
		userEntitlements.setEmail("user@example.com");
		userEntitlements.setUserName("testUser");
		userEntitlements.setAccountName("testAccount");

		EntitlementDTO entitlementDTO = new EntitlementDTO();
		entitlementDTO.setValue("READ_ACCESS");
		userEntitlements.setEntitlements(List.of(entitlementDTO));

		String accessToken = "abc123";

		// Mock dependencies
		when(userService.determineUserTypeByEmailDomain("user@example.com")).thenReturn("INTERNAL");
		when(saviyntService.getEndpoint("INTERNAL")).thenReturn(null);
		when(saviyntService.getSecuritySystem("INTERNAL")).thenReturn(null);

		JSONObject mockResponse = new JSONObject();
		mockResponse.put("status", "success");


		assertThrows(CCServiceException.class, () -> {
			entitlementService.updateUser(userEntitlements, accessToken);
		});
	}

	@SuppressWarnings("unchecked")
	@Test
	void updateUser_CCServiceException_throwsCCServiceException() {
		List<EntitlementDTO> dtoList = new ArrayList<>();
		EntitlementDTO dto = new EntitlementDTO();
		dto.setName("test");
		dto.setValue("test");
		dtoList.add(dto);
		UserEntitlementsDTO userEntitlements = new UserEntitlementsDTO();
		userEntitlements.setRequestType("REMOVE"); // Invalid
		userEntitlements.setEmail("user@example.com");
		userEntitlements.setUserName("testUser");
		userEntitlements.setEntitlements(dtoList);
		String accessToken = "abc123";

		assertThrows(CCServiceException.class, () -> {
			entitlementService.updateUser(userEntitlements, accessToken);
		});
	}

	@SuppressWarnings("unchecked")
	@Test
	void updateUser_missingEmail_throwsInvalidRequestException() {

		List<EntitlementDTO> dtoList = new ArrayList<>();
		EntitlementDTO dto = new EntitlementDTO();
		dto.setName("test");
		dto.setValue("test");
		dtoList.add(dto);

		UserEntitlementsDTO userEntitlements = new UserEntitlementsDTO();
		userEntitlements.setRequestType("REMOVE");
		userEntitlements.setEmail(""); 
		userEntitlements.setUserName("testUser");
		userEntitlements.setEntitlements(dtoList);

		String accessToken = "abc123";

		assertThrows(InvalidRequestException.class, () -> {
			entitlementService.updateUser(userEntitlements, accessToken);
		});
	}


	@Test
	void testValidateEntitlementWithValidData() throws Exception {
		EntitlementService instance = new EntitlementService(); 

		EntitlementDTO dto = EntitlementDTO.of("READ_ACCESS", "test");

		Method method = EntitlementService.class.getDeclaredMethod("validateEntitlement", EntitlementDTO.class);
		method.setAccessible(true);

	}

	@Test
	void testValidateEntitlementWithNullDTO() throws Exception {
		EntitlementService instance = new EntitlementService();

		Method method = EntitlementService.class.getDeclaredMethod("validateEntitlement", EntitlementDTO.class);
		method.setAccessible(true);

		Exception exception = assertThrows(Exception.class, () -> method.invoke(instance, (Object) null));
		Throwable cause = exception.getCause(); 

		assertTrue(cause instanceof InvalidRequestException);
		assertEquals("Invalid user entitlement data", cause.getMessage());
	}

	@Test
	void testValidateEntitlementWithEmptyValue() throws Exception {
		EntitlementService instance = new EntitlementService();

		EntitlementDTO dto = EntitlementDTO.of("READ_ACCESS", "");

		Method method = EntitlementService.class.getDeclaredMethod("validateEntitlement", EntitlementDTO.class);
		method.setAccessible(true);

		Exception exception = assertThrows(Exception.class, () -> method.invoke(instance, dto));
		Throwable cause = exception.getCause();

		assertTrue(cause instanceof InvalidRequestException);
		assertEquals("Invalid user entitlement data", cause.getMessage());
	}

	@Test
	void testValidUserDoesNotThrow_Invoke() throws Exception {
		EntitlementService instance = new EntitlementService();

		UserEntitlementsDTO user = new UserEntitlementsDTO();
		user.setRequestType("REMOVE");
		user.setEmail("user@example.com");
		user.setUserName("testuser");
		user.setEntitlements(Collections.singletonList(EntitlementDTO.of("READ_ACCESS", "test")));

		Method method = EntitlementService.class.getDeclaredMethod("validateUser", UserEntitlementsDTO.class);
		method.setAccessible(true);
		method.invoke(instance, user);
	}


	@Test
	void testValidUserDoesNotThrow_REMOVE() throws Exception {
		try {
			EntitlementService instance = new EntitlementService();

			UserEntitlementsDTO user = new UserEntitlementsDTO();
			user.setRequestType("REMOVE");
			user.setEmail("user@example.com");
			user.setUserName("testuser");
			user.setEntitlements(Collections.singletonList(EntitlementDTO.of("READ_ACCESS", "test")));

			Method method = EntitlementService.class.getDeclaredMethod("validateUser", UserEntitlementsDTO.class);
			method.setAccessible(true);
			method.invoke(instance, user);
		}
		catch (Exception e) {
			fail("Expected no exception, but got: " + e.getCause());
		}

	}
	@Test
	void testValidUserDoesNotThrow_ADD() throws Exception {
		try {
			EntitlementService instance = new EntitlementService();

			UserEntitlementsDTO user = new UserEntitlementsDTO();
			user.setRequestType("ADD");
			user.setEmail("user@example.com");
			user.setUserName("testuser");
			user.setEntitlements(Collections.singletonList(EntitlementDTO.of("READ_ACCESS", "test")));

			Method method = EntitlementService.class.getDeclaredMethod("validateUser", UserEntitlementsDTO.class);
			method.setAccessible(true);
			method.invoke(instance, user);
		}
		catch (Exception e) {
			fail("Expected no exception, but got: " + e.getCause());
		}

	}
	@Test
	void testValidUserDoesNotThrow_EmailNull() throws Exception {
		EntitlementService instance = new EntitlementService();

		UserEntitlementsDTO user = new UserEntitlementsDTO();
		user.setRequestType("REMOVE");
		user.setEmail(null);
		user.setUserName("testuser");
		user.setEntitlements(Collections.singletonList(EntitlementDTO.of("READ_ACCESS", "test")));

		Method method = EntitlementService.class.getDeclaredMethod("validateUser", UserEntitlementsDTO.class);
		method.setAccessible(true);
		Exception exception = assertThrows(Exception.class, () -> method.invoke(instance, user));
		Throwable cause = exception.getCause();

		assertTrue(cause instanceof InvalidRequestException);
		assertEquals("Invalid user data", cause.getMessage());


	}

	@Test
	void testValidUserDoesNotThrow_UserNameNull() throws Exception {

		EntitlementService instance = new EntitlementService();

		UserEntitlementsDTO user = new UserEntitlementsDTO();
		user.setRequestType("REMOVE");
		user.setEmail("user@example.com");
		user.setUserName(null);
		user.setEntitlements(Collections.singletonList(EntitlementDTO.of("READ_ACCESS", "test")));

		Method method = EntitlementService.class.getDeclaredMethod("validateUser", UserEntitlementsDTO.class);
		method.setAccessible(true);
		Exception exception = assertThrows(Exception.class, () -> method.invoke(instance, user));
		Throwable cause = exception.getCause();

		assertTrue(cause instanceof InvalidRequestException);
		assertEquals("Invalid user data", cause.getMessage());



	}
	@Test
	public void testValidEntitlementDoesNotThrow() {
		try {
			EntitlementDTO dto = EntitlementDTO.of("READ_ACCESS", "test");
			Method method = EntitlementService.class.getDeclaredMethod("validateEntitlement", EntitlementDTO.class);
			method.setAccessible(true);
			method.invoke(new EntitlementService(), dto);
		} catch (Exception e) {
			fail("Expected no exception, but got: " + e.getCause());
		}
	}

	@Test
	void testInvalidRequestTypeThrows() throws Exception {
		EntitlementService instance = new EntitlementService();

		UserEntitlementsDTO user = new UserEntitlementsDTO();
		user.setRequestType("TEST"); // Invalid
		user.setEmail("user@example.com");
		user.setUserName("testuser");
		user.setEntitlements(Collections.singletonList(EntitlementDTO.of("READ_ACCESS", "test")));

		Method method = EntitlementService.class.getDeclaredMethod("validateUser", UserEntitlementsDTO.class);
		method.setAccessible(true);

		Exception exception = assertThrows(Exception.class, () -> method.invoke(instance, user));
		Throwable cause = exception.getCause();

		assertTrue(cause instanceof InvalidRequestException);
		assertEquals("User Request type is invalid", cause.getMessage());
	}

	@Test
	void testMissingEmailThrows() throws Exception {
		EntitlementService instance = new EntitlementService();

		UserEntitlementsDTO user = new UserEntitlementsDTO();
		user.setRequestType("REMOVE");
		user.setEmail(""); // Missing
		user.setUserName("testuser");
		user.setEntitlements(Collections.singletonList(EntitlementDTO.of("READ_ACCESS", "test")));

		Method method = EntitlementService.class.getDeclaredMethod("validateUser", UserEntitlementsDTO.class);
		method.setAccessible(true);

		Exception exception = assertThrows(Exception.class, () -> method.invoke(instance, user));
		Throwable cause = exception.getCause();

		assertTrue(cause instanceof InvalidRequestException);
		assertEquals("Invalid user data", cause.getMessage());
	}

	@Test
	void testInvalidEntitlementThrows() throws Exception {
		EntitlementService instance = new EntitlementService();

		UserEntitlementsDTO user = new UserEntitlementsDTO();
		user.setRequestType("REMOVE");
		user.setEmail("user@example.com");
		user.setUserName("testuser");
		user.setEntitlements(Collections.singletonList(EntitlementDTO.of("READ_ACCESS", ""))); // Invalid value

		Method method = EntitlementService.class.getDeclaredMethod("validateUser", UserEntitlementsDTO.class);
		method.setAccessible(true);

		Exception exception = assertThrows(Exception.class, () -> method.invoke(instance, user));
		Throwable cause = exception.getCause();

		assertTrue(cause instanceof InvalidRequestException);
		assertEquals("Invalid user entitlement data", cause.getMessage());
	}

}