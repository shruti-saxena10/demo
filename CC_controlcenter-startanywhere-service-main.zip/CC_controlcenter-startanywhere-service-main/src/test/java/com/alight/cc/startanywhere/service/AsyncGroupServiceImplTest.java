package com.alight.cc.startanywhere.service;



import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import com.alight.asg.model.header.v1_0.RequestHeader;
import com.alight.cc.startanywhere.configuration.SaviyntConfigurationBean;
import com.alight.cc.startanywhere.entity.ClientOnboardingRequestTrackEntity;
import com.alight.cc.startanywhere.entity.SecurityManagerEntitlementEntity;
import com.alight.cc.startanywhere.feign.SaviyntClient;
import com.alight.cc.startanywhere.model.CreateGroupsResponse;
import com.alight.cc.startanywhere.repository.ClientOnboardingRequestTrackRepository;
import com.alight.cc.startanywhere.repository.SecurityManagerEntitlementRepository;
import com.alight.cc.startanywhere.saviynt.model.UpdateUserEntitlementsRequest;
import com.alight.cc.startanywhere.service.impl.AsyncGroupServiceImpl;
import com.alight.cc.startanywhere.util.StartAnywhereSecurityUtil;
import com.alight.cc.startanywhere.util.StartAnywhereUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

import feign.FeignException;

@ExtendWith(MockitoExtension.class)

class AsyncGroupServiceImplTest{

    @InjectMocks
    private AsyncGroupServiceImpl service;

    @Mock
    private ClientOnboardingRequestTrackRepository trackRepo;
    @Mock
    private SaviyntConfigurationBean configBean;
    @Mock
    private SaviyntConfigurationBean saviyntConfig;
    @Mock
    private SecurityManagerEntitlementRepository entitlementRepo;
    @Mock
    private SaviyntClient saviyntClient;
    @Mock
    private UserService userService;
    @Mock
    private ClientOnboardingRequestTrackService clientOnboardingRequestTrackService;

    private SecurityManagerEntitlementEntity entity;
    @Mock
    private ObjectMapper om;

    @Mock
    private JSONParser parser;

    @BeforeEach
    void setup() {
        entity = new SecurityManagerEntitlementEntity();
        entity.setDisplayName("Group-<ClientID>");
        entity.setDescription("Desc-<ClientID>-<ClientName>");

//        when(saviyntConfig.getOwner()).thenReturn(List.of(new Owner("owner1", "1")));
//        when(saviyntConfig.getRequestor()).thenReturn("requestor");
//        when(saviyntConfig.getEntitlementtype()).thenReturn("type");
//        when(saviyntConfig.getSecuritySystem()).thenReturn("secSys");
//        when(saviyntConfig.getEndpointD2()).thenReturn("endpoint");
//        when(saviyntConfig.getDomain()).thenReturn("domain");
//        when(saviyntConfig.getEnvironment()).thenReturn("env");
//        when(saviyntConfig.getApplication()).thenReturn("app");
    }

    @Test
    void testConstructEntitlementRequest() {
        UpdateUserEntitlementsRequest req = service.constructEntitlementRequest("display", "desc");
        assertEquals("display", req.getDisplayname());
        assertEquals("desc", req.getDescription());
    }

    @Test
    void testGetDisplayNamesWithClientId() {
        List<String> result = service.getDisplayNamesWithClientId(List.of(entity), "123", "ClientX");
        assertEquals(1, result.size());
        assertTrue(result.get(0).contains("123"));
    }

    @Test
    void testTransformEntityFields() {
        Map<SecurityManagerEntitlementEntity, Map<String, String>> result =
                AsyncGroupServiceImpl.transformEntityFields(List.of(entity), "123", "ClientX");

        assertTrue(result.containsKey(entity));
        assertEquals("Group-123", result.get(entity).get("displayName"));
        assertEquals("Desc-123-ClientX", result.get(entity).get("description"));
    }

    @Test
    void testGetPresentValues() {
        JSONObject json = new JSONObject();
        json.put("msg", "Success");
        json.put("errorCode", "200");
        json.put("requestid", "req123");
        json.put("requestkey", "key123");

        Map<String, String> result = service.getPresentValues(json);
        assertEquals("Success", result.get("msg"));
        assertEquals("200", result.get("errorCode"));
    }

    @Test
    void testSaveTrack_NewEntity() throws Exception {
        CreateGroupsResponse response = new CreateGroupsResponse();
        response.setClientId("client123");

        RequestHeader header = new RequestHeader();
        header.setCorrelationId("corr123");

        String rawHeader = new ObjectMapper().writeValueAsString(header);
        when(trackRepo.findByCorrelationIdAndClientId("corr123", "client123")).thenReturn(null);

        try (MockedStatic<StartAnywhereSecurityUtil> secUtil = mockStatic(StartAnywhereSecurityUtil.class)) {
            secUtil.when(() -> StartAnywhereSecurityUtil.unCleanIt(any())).thenReturn(rawHeader);
            try (MockedStatic<RequestHeader> reqHeader = mockStatic(RequestHeader.class)) {
                reqHeader.when(() -> RequestHeader.parse(any())).thenReturn(header);
                service.saveTrack(rawHeader, response);
                verify(trackRepo).save(any(ClientOnboardingRequestTrackEntity.class));
            }
        }
    }

    @Test
    void testUpdateTrack() throws Exception {
        CreateGroupsResponse response = new CreateGroupsResponse();
        response.setClientId("client123");

        RequestHeader header = new RequestHeader();
        header.setCorrelationId("corr123");

        String rawHeader = new ObjectMapper().writeValueAsString(header);
        ClientOnboardingRequestTrackEntity entity = new ClientOnboardingRequestTrackEntity();
        when(trackRepo.findByCorrelationIdAndClientId("corr123", "client123")).thenReturn(entity);

        try (MockedStatic<StartAnywhereSecurityUtil> secUtil = mockStatic(StartAnywhereSecurityUtil.class)) {
            secUtil.when(() -> StartAnywhereSecurityUtil.unCleanIt(any())).thenReturn(rawHeader);
            try (MockedStatic<RequestHeader> reqHeader = mockStatic(RequestHeader.class)) {
                reqHeader.when(() -> RequestHeader.parse(any())).thenReturn(header);
                service.updateTrack(rawHeader, response);
                verify(trackRepo).save(entity);
            }
        }
    }

    @Test
    void testCheckValidationBeforeAsyncC_AllBranches() {
        CreateGroupsResponse response = new CreateGroupsResponse();
        RequestHeader header = new RequestHeader();
        header.setCorrelationId("corr123");

        ClientOnboardingRequestTrackEntity trackEntity = new ClientOnboardingRequestTrackEntity();
        trackEntity.setStatus(0);
        trackEntity.setHitCount(1);

        when(configBean.getHitCount()).thenReturn(3);
        //when(configBean.getFallbackTime()).thenReturn(10);
        when(trackRepo.findByCorrelationIdAndClientId(any(), any())).thenReturn(trackEntity);

        try (MockedStatic<StartAnywhereSecurityUtil> secUtil = mockStatic(StartAnywhereSecurityUtil.class)) {
            secUtil.when(() -> StartAnywhereSecurityUtil.unCleanIt(any())).thenReturn("{}");
            try (MockedStatic<RequestHeader> reqHeader = mockStatic(RequestHeader.class)) {
                reqHeader.when(() -> RequestHeader.parse(any())).thenReturn(header);
                try (MockedStatic<StartAnywhereUtil> util = mockStatic(StartAnywhereUtil.class)) {
                    util.when(() -> StartAnywhereUtil.buildResponse(any(), any(), any(), any(), any(), any(), any(), any()))
                            .thenReturn(response);
                    CreateGroupsResponse result = service.checkValidationBeforeAsyncC("token", "{}", "client123", "ClientX");
                    assertNotNull(result);
                }
            }
        }
    }

    @Test
    void testCreateGroupsAsync_SuccessfulFlow() {
        List<SecurityManagerEntitlementEntity> entities = List.of(entity);
        when(entitlementRepo.findAll()).thenReturn(entities);
        when(userService.getFreshAccessToken()).thenReturn("access123");
        when(saviyntClient.updateEntitlementsOnUser(any(), any())).thenReturn(new JSONObject());

        try (MockedStatic<StartAnywhereSecurityUtil> secUtil = mockStatic(StartAnywhereSecurityUtil.class)) {
            secUtil.when(() -> StartAnywhereSecurityUtil.unCleanIt(any())).thenReturn("{}");
            try (MockedStatic<RequestHeader> reqHeader = mockStatic(RequestHeader.class)) {
                RequestHeader header = new RequestHeader();
                header.setCorrelationId("corr123");
                reqHeader.when(() -> RequestHeader.parse(any())).thenReturn(header);
                when(trackRepo.findByCorrelationIdAndClientId(any(), any())).thenReturn(null);
                service.createGroupsAsync("session", "{}", "client123", "ClientX");
                verify(entitlementRepo).findAll();
                verify(userService).getFreshAccessToken();
            }
        }
    }

    @Test
    void testCreateGroupsAsync_UnauthorizedException() throws Exception {
        List<SecurityManagerEntitlementEntity> entities = List.of(entity);
        when(entitlementRepo.findAll()).thenReturn(entities);
        when(userService.getFreshAccessToken()).thenReturn("access123");

        FeignException.Unauthorized unauthorized = mock(FeignException.Unauthorized.class);
        when(unauthorized.contentUTF8()).thenReturn("{\"msg\":\"Unauthorized\"}");
        when(saviyntClient.updateEntitlementsOnUser(any(), any())).thenThrow(unauthorized);

        try (MockedStatic<StartAnywhereSecurityUtil> secUtil = mockStatic(StartAnywhereSecurityUtil.class)) {
            secUtil.when(() -> StartAnywhereSecurityUtil.unCleanIt(any())).thenReturn("{}");
            try (MockedStatic<RequestHeader> reqHeader = mockStatic(RequestHeader.class)) {
                RequestHeader header = new RequestHeader();
                header.setCorrelationId("corr123");
                reqHeader.when(() -> RequestHeader.parse(any())).thenReturn(header);
                when(trackRepo.findByCorrelationIdAndClientId(any(), any())).thenReturn(null);
                service.createGroupsAsync("session", "{}", "client123", "ClientX");
            }
        }
    }

    @Test
    void testCreateGroupsAsync_GeneralException() throws Exception {
        when(entitlementRepo.findAll()).thenThrow(new RuntimeException("Unexpected error"));
        when(userService.getFreshAccessToken()).thenReturn("access123");

        try (MockedStatic<StartAnywhereSecurityUtil> secUtil = mockStatic(StartAnywhereSecurityUtil.class)) {
            secUtil.when(() -> StartAnywhereSecurityUtil.unCleanIt(any())).thenReturn("{}");
            try (MockedStatic<RequestHeader> reqHeader = mockStatic(RequestHeader.class)) {
                RequestHeader header = new RequestHeader();
                header.setCorrelationId("corr123");
                reqHeader.when(() -> RequestHeader.parse(any())).thenReturn(header);
                when(trackRepo.findByCorrelationIdAndClientId(any(), any())).thenReturn(null);

                assertDoesNotThrow(() ->
                        service.createGroupsAsync("session", "{}", "client123", "ClientX"));
            }
        }
    }
    //================================================
    @Test
    void testCreateGroupsAsync_ExceptionBranches() throws Exception {
        List<SecurityManagerEntitlementEntity> entities = List.of(
            new SecurityManagerEntitlementEntity(),
            new SecurityManagerEntitlementEntity(),
            new SecurityManagerEntitlementEntity(),
            new SecurityManagerEntitlementEntity()
        );
        when(entitlementRepo.findAll()).thenReturn(entities);
        when(userService.getFreshAccessToken()).thenReturn("access123");

       // FeignException.Unauthorized unauthorized = mock(FeignException.Unauthorized.class);
        //when(unauthorized.contentUTF8()).thenReturn("invalid-json");

        FeignException feignValidJson = mock(FeignException.class);
        when(feignValidJson.contentUTF8()).thenReturn("{\"msg\":\"Error occurred\",\"errorCode\":\"500\"}");

        FeignException feignInvalidJson = mock(FeignException.class);
       // when(feignInvalidJson.contentUTF8()).thenReturn("not-a-json");

        RuntimeException genericEx = new RuntimeException("Unexpected");

        when(saviyntClient.updateEntitlementsOnUser(anyString(), any()))
            .thenThrow(feignValidJson)
            .thenThrow(feignInvalidJson)
            .thenThrow(genericEx);

        try (MockedStatic<StartAnywhereSecurityUtil> secUtil = mockStatic(StartAnywhereSecurityUtil.class)) {
            secUtil.when(() -> StartAnywhereSecurityUtil.unCleanIt(any())).thenReturn("{}");

            try (MockedStatic<RequestHeader> reqHeader = mockStatic(RequestHeader.class)) {
                RequestHeader header = new RequestHeader();
                header.setCorrelationId("corr123");
                reqHeader.when(() -> RequestHeader.parse(any())).thenReturn(header);

                when(trackRepo.findByCorrelationIdAndClientId(any(), any())).thenReturn(null);

                assertDoesNotThrow(() ->
                    service.createGroupsAsync("session", "{}", "client123", "ClientX"));
            }
        }
    }
    @Test
    void testCreateGroupsAsync_ExceptionBranches1() throws Exception {
        List<SecurityManagerEntitlementEntity> entities = List.of(
            new SecurityManagerEntitlementEntity(),
            new SecurityManagerEntitlementEntity(),
            new SecurityManagerEntitlementEntity(),
            new SecurityManagerEntitlementEntity()
        );
        when(entitlementRepo.findAll()).thenReturn(entities);
        when(userService.getFreshAccessToken()).thenReturn("access123");

       // FeignException.Unauthorized unauthorized = mock(FeignException.Unauthorized.class);
        //when(unauthorized.contentUTF8()).thenReturn("invalid-json");

       // FeignException feignValidJson = mock(FeignException.class);
       // when(feignValidJson.contentUTF8()).thenReturn("{\"msg\":\"Error occurred\",\"errorCode\":\"500\"}");

        FeignException feignInvalidJson = mock(FeignException.class);
       when(feignInvalidJson.contentUTF8()).thenReturn("not-a-json");

        RuntimeException genericEx = new RuntimeException("Unexpected");

        when(saviyntClient.updateEntitlementsOnUser(anyString(), any()))
            .thenThrow(feignInvalidJson)
            .thenThrow(genericEx);

        try (MockedStatic<StartAnywhereSecurityUtil> secUtil = mockStatic(StartAnywhereSecurityUtil.class)) {
            secUtil.when(() -> StartAnywhereSecurityUtil.unCleanIt(any())).thenReturn("{}");

            try (MockedStatic<RequestHeader> reqHeader = mockStatic(RequestHeader.class)) {
                RequestHeader header = new RequestHeader();
                header.setCorrelationId("corr123");
                reqHeader.when(() -> RequestHeader.parse(any())).thenReturn(header);

                when(trackRepo.findByCorrelationIdAndClientId(any(), any())).thenReturn(null);

                assertDoesNotThrow(() ->
                    service.createGroupsAsync("session", "{}", "client123", "ClientX"));
            }
        }
    }

}
