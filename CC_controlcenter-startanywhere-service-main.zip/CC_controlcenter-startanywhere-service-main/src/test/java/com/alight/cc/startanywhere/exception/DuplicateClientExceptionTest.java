package com.alight.cc.startanywhere.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class DuplicateClientExceptionTest {


	@Test
	public void testExceptionMessage() {
		String expectedMessage = "Client ID or Client Name already exists";
		DuplicateClientException exception = new DuplicateClientException(expectedMessage);

		assertEquals(expectedMessage, exception.getMessage());
	}
}
