package com.alight.cc.startanywhere.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.contains;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.alight.asg.model.header.v1_0.RequestHeader;
import com.alight.cc.startanywhere.entity.ClientEntity;
import com.alight.cc.startanywhere.model.BaseResponse;
import com.alight.cc.startanywhere.repository.ClientRepository;
import com.alight.logging.helpers.InfoTypeLogEventHelper;

@ExtendWith(MockitoExtension.class)
public class CheckClientDataTest {
	
	@Mock
    ClientRepository clientRepo;

    @InjectMocks
    CheckClientData dataCheck;

    @BeforeEach
    void setup() {
        // No-op
    }
    
    @Test
    void isNotValidClient_returnsBadRequest() {
        String clientId = "cid";
        String orgName = "org";

        try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class);
             MockedStatic<StartAnywhereUtil> utilMock = mockStatic(StartAnywhereUtil.class)) {

            BaseResponse fakeResponse = new BaseResponse();
            utilMock.when(() -> StartAnywhereUtil.buildResponse(any(), any(), any(), any(), any(), any(), any(), any()))
                    .thenReturn(fakeResponse);

            ResponseEntity<Object> result = dataCheck.isNotValidClient(clientId, orgName);
            assertNotNull(result);
            assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
            assertSame(fakeResponse, result.getBody());
            logMock.verify(() -> InfoTypeLogEventHelper.logInfoEvent(any(), contains("Client doesn’t exist in Postgres DBcid")), times(1));
        }
    }

    

    @Test
    void isNotValidClient_returnsBadRequest_whenOnlyOrgNameExists() {
        String clientId = "cid";
        String orgName = "org";

        
        when(clientRepo.findByClientIdIgnoreCase(clientId)).thenReturn(null);
        when(clientRepo.findByOrgNameIgnoreCase(orgName)).thenReturn(new ClientEntity());

        try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class);
                MockedStatic<StartAnywhereUtil> utilMock = mockStatic(StartAnywhereUtil.class)) {

               BaseResponse fakeResponse = new BaseResponse();
               utilMock.when(() -> StartAnywhereUtil.buildResponse(any(), any(), any(), any(), any(), any(), any(), any()))
                       .thenReturn(fakeResponse);

               ResponseEntity<Object> result = dataCheck.isNotValidClient(clientId, orgName);
               assertNotNull(result);
               assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
               assertSame(fakeResponse, result.getBody());
               logMock.verify(() -> InfoTypeLogEventHelper.logInfoEvent(any(), contains("Not valid client")), times(1));
           }
        
    }

    @Test
    void isNotValidClient_returnsBadRequest_whenOnlyClientIdExists() {
        String clientId = "cid";
        String orgName = "org";

        when(clientRepo.findByClientIdIgnoreCase(clientId)).thenReturn(new ClientEntity());
        when(clientRepo.findByOrgNameIgnoreCase(orgName)).thenReturn(null);

        try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class);
             MockedStatic<StartAnywhereUtil> utilMock = mockStatic(StartAnywhereUtil.class)) {

            BaseResponse fakeResponse = new BaseResponse();
            utilMock.when(() -> StartAnywhereUtil.buildResponse(any(), any(), any(), any(), any(), any(), any(), any()))
                    .thenReturn(fakeResponse);

            ResponseEntity<Object> result = dataCheck.isNotValidClient(clientId, orgName);
            assertNotNull(result);
            assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
            assertSame(fakeResponse, result.getBody());
            logMock.verify(() -> InfoTypeLogEventHelper.logInfoEvent(any(), contains("Not valid client")), times(1));
        }
    }

    @Test
    void isNotValidClient_returnsNotNull() {
        String clientId = "cid";
        String orgName = "org";

        when(clientRepo.findByClientIdIgnoreCase(clientId)).thenReturn(null);
        when(clientRepo.findByOrgNameIgnoreCase(orgName)).thenReturn(null);
        
        try (MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class);
                MockedStatic<StartAnywhereUtil> utilMock = mockStatic(StartAnywhereUtil.class)) {

               BaseResponse fakeResponse = new BaseResponse();
               utilMock.when(() -> StartAnywhereUtil.buildResponse(any(), any(), any(), any(), any(), any(), any(), any()))
                       .thenReturn(fakeResponse);

               ResponseEntity<Object> result = dataCheck.isNotValidClient(clientId, orgName);
               assertNotNull(result);
               assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
               assertSame(fakeResponse, result.getBody());
               logMock.verify(() -> InfoTypeLogEventHelper.logInfoEvent(any(), contains("Client doesn’t exist in Postgres DB")), times(1));
           }
    }

    @Test
    void isNotValidClient_returnsNull() {
        String clientId = "cid";
        String orgName = "org";

        when(clientRepo.findByClientIdIgnoreCase(clientId)).thenReturn(new ClientEntity());
        when(clientRepo.findByOrgNameIgnoreCase(orgName)).thenReturn(new ClientEntity());

        ResponseEntity<Object> result = dataCheck.isNotValidClient(clientId, orgName);
        assertNull(result);
    }
    
    @Test
    void isCheckRequestHeader_missingLocale_returnsBadRequest() throws Exception {
        String rawHeader = "{\"locale\":\"\"}"; // Simulate missing locale
        String cleanedHeader = rawHeader; // Assuming unCleanIt returns the same string

        // Mock static methods if needed (e.g., StartAnywhereSecurityUtil.unCleanIt)
        try (MockedStatic<StartAnywhereSecurityUtil> securityUtilMock = mockStatic(StartAnywhereSecurityUtil.class);
        		MockedStatic<InfoTypeLogEventHelper> logMock = mockStatic(InfoTypeLogEventHelper.class);
        		MockedStatic<RequestHeader> requestHeaderMock = mockStatic(RequestHeader.class)) {

            securityUtilMock.when(() -> StartAnywhereSecurityUtil.unCleanIt(rawHeader)).thenReturn(cleanedHeader);

            RequestHeader mockHeader = mock(RequestHeader.class);
            when(mockHeader.getLocale()).thenReturn(""); // Simulate missing locale
            requestHeaderMock.when(() -> RequestHeader.parse(cleanedHeader)).thenReturn(mockHeader);

            ResponseEntity<Object> response = dataCheck.isCheckRequestHeader(rawHeader);

            assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
            BaseResponse body = (BaseResponse) response.getBody();
            assertEquals(StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST, body.getResponseCode());
            assertEquals(StartAnyWhereConstants.BAD_REQUEST, body.getResponseMessage());
            logMock.verify(() -> InfoTypeLogEventHelper.logInfoEvent(any(), contains("Missing required parameters alightRequestHeader.")), times(1));
        }
    }
    
    @Test
    void isCheckRequestHeader_validLocale_returnsNull() throws Exception {
        String rawHeader = "{\"locale\":\"en_US\"}";
        String cleanedHeader = rawHeader;

        try (
            MockedStatic<StartAnywhereSecurityUtil> securityUtilMock = mockStatic(StartAnywhereSecurityUtil.class);
            MockedStatic<RequestHeader> requestHeaderMock = mockStatic(RequestHeader.class)
        ) {
            securityUtilMock.when(() -> StartAnywhereSecurityUtil.unCleanIt(rawHeader)).thenReturn(cleanedHeader);

            RequestHeader mockParsedHeader = mock(RequestHeader.class);
            when(mockParsedHeader.getLocale()).thenReturn("en_US");
            requestHeaderMock.when(() -> RequestHeader.parse(cleanedHeader)).thenReturn(mockParsedHeader);

            ResponseEntity<Object> response = dataCheck.isCheckRequestHeader(rawHeader);

            assertNull(response); // Method returns null for valid locale
        }
    }


}
