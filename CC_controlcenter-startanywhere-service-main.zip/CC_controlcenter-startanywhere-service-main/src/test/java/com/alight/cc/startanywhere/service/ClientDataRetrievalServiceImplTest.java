package com.alight.cc.startanywhere.service;


import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.alight.cc.startanywhere.entity.AttributeRestrictionLookupEntity;
import com.alight.cc.startanywhere.entity.AttributeTypeLookupEntity;
import com.alight.cc.startanywhere.entity.ClientAttributesEntity;
import com.alight.cc.startanywhere.entity.ClientEntity;
import com.alight.cc.startanywhere.entity.ClientMappingEntity;
import com.alight.cc.startanywhere.entity.ClientProfileEntity;
import com.alight.cc.startanywhere.model.ClientResponse;
import com.alight.cc.startanywhere.repository.AttributeRestrictionLookupRepository;
import com.alight.cc.startanywhere.repository.AttributeTypeLookupRepository;
import com.alight.cc.startanywhere.repository.ClientAttributesRepository;
import com.alight.cc.startanywhere.repository.ClientMappingRepository;
import com.alight.cc.startanywhere.repository.ClientProfileRepository;
import com.alight.cc.startanywhere.repository.ClientRepository;
import com.alight.cc.startanywhere.service.impl.ClientDataRetrievalServiceImpl;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;

@ExtendWith(SpringExtension.class)
public class ClientDataRetrievalServiceImplTest {

	@InjectMocks
	ClientDataRetrievalServiceImpl serviceMock;

	@Mock
	private ClientRepository clientRepoMock;

	@Mock 
	private ClientAttributesRepository clientAttributesRepoMock;

	@Mock
	private ClientMappingRepository clientMappingRepoMock;

	@Mock
	private ClientProfileRepository clientProfileRepoMock;

	@Mock
	AttributeRestrictionLookupRepository attributeRestrictionLookupRepoMock;

	@Mock
	AttributeTypeLookupRepository attributeTypeLookupRepoMock;

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
    void testGetClientData_Success() {
        // Mock client
        ClientEntity mockClient = new ClientEntity();
        mockClient.setClientId("123");
        mockClient.setName("Test Client");
        mockClient.setOrgName("Test Org");

        // Mock profile
        ClientProfileEntity mockProfile = new ClientProfileEntity();
        AttributeTypeLookupEntity mockTypeLookup = new AttributeTypeLookupEntity();
        mockTypeLookup.setKey("Y");  // Mock Data Restriction Key
        mockProfile.setAttributeTypeLookup(mockTypeLookup);

        // Mock attributes
        ClientAttributesEntity mockAttribute = new ClientAttributesEntity();
        AttributeRestrictionLookupEntity restrictionLookup = new AttributeRestrictionLookupEntity();
        restrictionLookup.setKey("Location-User-PII");
        AttributeTypeLookupEntity typeLookup = new AttributeTypeLookupEntity();
        typeLookup.setKey("Y");
        mockAttribute.setAttributeRestrictionLookup(restrictionLookup);
        mockAttribute.setAttributeTypeLookup(typeLookup);
        ClientAttributesEntity mockAttribute1 = new ClientAttributesEntity();
        AttributeRestrictionLookupEntity reasonRestriction = new AttributeRestrictionLookupEntity();
        reasonRestriction.setKey("Reason");

        AttributeTypeLookupEntity reasonType = new AttributeTypeLookupEntity();
        reasonType.setKey("Custom");

        mockAttribute1.setAttributeRestrictionLookup(reasonRestriction);
        mockAttribute1.setAttributeTypeLookup(reasonType);
        // Mock mapping
        ClientMappingEntity mockMapping = new ClientMappingEntity();
        mockMapping.setScrmId("SCRM-123");

        when(clientRepoMock.findByClientId("123")).thenReturn(mockClient);
        when(clientProfileRepoMock.findByControlCenterClientId(mockClient.getId())).thenReturn(mockProfile);
        //when(clientAttributesRepoMock.findByControlCenterClientId("123")).thenReturn(Collections.singletonList(mockAttribute));
        when(clientMappingRepoMock.findByControlCenterClientId("123")).thenReturn(Collections.singletonList(mockMapping));
        when(clientAttributesRepoMock.findByControlCenterClientId("123"))
        .thenReturn(List.of(mockAttribute, mockAttribute1));

        // Call the service method
        ClientResponse response = serviceMock.getClientData("mockToken", "mockHeader", "123");

        // Assertions
        assertNotNull(response);
        assertEquals("Test Client", response.getClientName());
        assertEquals("Test Org", response.getOrgName());
        assertTrue(response.getIsDataRestriction()); // Ensuring "Y" is converted to true
        assertTrue(response.getLocationUserPII()); // Ensuring "Y" is converted to true
        assertEquals("Custom", response.getReason());
    }

    @Test
    void testGetClientData_ClientNotFound() {
        when(clientRepoMock.findByClientId("123")).thenReturn(null);

        ClientResponse response = serviceMock.getClientData("mockToken", "mockHeader", "123");

        assertNotNull(response);
        assertNull(response.getClientName());
        assertNull(response.getOrgName());
        assertFalse(Boolean.TRUE.equals(response.getIsDataRestriction()));

    }

    @Test
    void testGetClientData_ExceptionHandling() {
        when(clientRepoMock.findByClientId(anyString())).thenThrow(new RuntimeException("Database error"));

        assertDoesNotThrow(() -> serviceMock.getClientData("mockToken", "mockHeader", "123"));
    }
    @Test
    void testProfileIsNullOrTypeLookupIsNull_andEmptyAttributes_andEmptyMappings() {
        // Arrange
        String clientId = "123";
        String clientName = "TestCo";
        String OrgName ="TestOrg";
        String token = "mockToken";
        String header = "mockHeader";

        ClientEntity mockClient = new ClientEntity();
        mockClient.setClientId(clientId);
        mockClient.setName(clientName);
        mockClient.setOrgName(OrgName);

        when(clientRepoMock.findByClientId(clientId)).thenReturn(mockClient);

        // profile is null
        when(clientProfileRepoMock.findByControlCenterClientId(mockClient.getId())).thenReturn(null);

        // attributes is empty
        when(clientAttributesRepoMock.findByControlCenterClientId(clientId)).thenReturn(Collections.emptyList());

        // mappings is empty
        when(clientMappingRepoMock.findByControlCenterClientId(clientId)).thenReturn(Collections.emptyList());

        // Act
        ClientResponse response = serviceMock.getClientData(token, header, clientId);

        // Assert
        assertNotNull(response);
        
    }
    @Test
    void testGetClientData_whenAttributesAreEmpty_returnsPOS404() {
        // Arrange
        String clientId = "123";
        String clientName = "AcmeCorp";
        String OrgName ="TestOrg";

        ClientEntity mockClient = new ClientEntity();
        mockClient.setClientId(clientId);
        mockClient.setName(clientName);
        mockClient.setOrgName(OrgName);

        ClientProfileEntity mockProfile = new ClientProfileEntity();
        AttributeTypeLookupEntity typeLookup = new AttributeTypeLookupEntity();
        typeLookup.setKey("Y");
        mockProfile.setAttributeTypeLookup(typeLookup);

        when(clientRepoMock.findByClientId(clientId)).thenReturn(mockClient);
        when(clientProfileRepoMock.findByControlCenterClientId(mockClient.getId())).thenReturn(mockProfile);
        when(clientAttributesRepoMock.findByControlCenterClientId(clientId)).thenReturn(Collections.emptyList()); // 💥 triggers `attributes.isEmpty()`

        // Act
        ClientResponse response = serviceMock.getClientData("token", "header", clientId);

        // Assert
        assertNotNull(response);
        assertEquals("200", response.getResponseCode());
        assertEquals("Fetched Successfully", response.getResponseMessage());
    }

    @Test
    void testGetClientData_whenMappingsAreEmpty_returnsPOS404() {
        // Arrange
        String clientId = "123";
        String clientName = "AcmeCorp";
        String OrgName ="AcmeOrg";
        ClientEntity mockClient = new ClientEntity();
        mockClient.setClientId(clientId);
        mockClient.setName(clientName);
        mockClient.setOrgName(OrgName);

        ClientProfileEntity mockProfile = new ClientProfileEntity();
        AttributeTypeLookupEntity typeLookup = new AttributeTypeLookupEntity();
        typeLookup.setKey("Y");
        mockProfile.setAttributeTypeLookup(typeLookup);

        ClientAttributesEntity attr = new ClientAttributesEntity();
        AttributeRestrictionLookupEntity restriction = new AttributeRestrictionLookupEntity();
        restriction.setKey("Location-User-PII");
        attr.setAttributeRestrictionLookup(restriction);
        attr.setAttributeTypeLookup(typeLookup);

        when(clientRepoMock.findByClientId(clientId)).thenReturn(mockClient);
        when(clientProfileRepoMock.findByControlCenterClientId(mockClient.getId())).thenReturn(mockProfile);
        when(clientAttributesRepoMock.findByControlCenterClientId(clientId)).thenReturn(List.of(attr));
        when(clientMappingRepoMock.findByControlCenterClientId(clientId)).thenReturn(Collections.emptyList()); // triggers `mappings.isEmpty()`

        // Act
        ClientResponse response = serviceMock.getClientData("token", "header", clientId);

        // Assert
        assertNotNull(response);
        assertEquals("200", response.getResponseCode());
        assertEquals("Fetched Successfully", response.getResponseMessage());
    }
    @Test
    public void testHandleRetryFailure_returnsFallbackResponse() {
        // Given
        Exception simulatedException = new RuntimeException("Simulated DB failure");
        String token = "dummy-token";
        String header = "dummy-header";
        String clientID = "dummy-client";

        // When
        ClientResponse response = serviceMock.handleRetryFailure(simulatedException, token, header, clientID);

        // Then
        assertEquals("POS101", response.getErrors().get(0).getErrorCode());
        assertEquals(StartAnyWhereConstants.DB_UNREACHABLE, response.getResponseMessage());
    }
    @Test
    void testGetClientData_profileNotNull_butAttributeTypeLookupNull() {
        // Arrange
        String clientId = "123";
        ClientEntity client = new ClientEntity();
        client.setClientId(clientId);
        client.setName("Test Name");
        client.setOrgName("Org");

        ClientProfileEntity profile = new ClientProfileEntity();
        profile.setAttributeTypeLookup(null); // ⚠️ triggers second condition of || check

        when(clientRepoMock.findByClientId(clientId)).thenReturn(client);
        when(clientProfileRepoMock.findByControlCenterClientId(client.getId())).thenReturn(profile);

        ClientResponse response = serviceMock.getClientData("token", "header", clientId);

        assertEquals("200", response.getResponseCode());
        //assertFalse(response.getIsDataRestriction());
    }

    @Test
    void testGetClientData_attributeWithNullRestrictionLookup_isSkipped() {
        // Arrange
        String clientId = "123";
        ClientEntity client = new ClientEntity();
        client.setClientId(clientId);

        ClientProfileEntity profile = new ClientProfileEntity();
        AttributeTypeLookupEntity type = new AttributeTypeLookupEntity();
        type.setKey("N");
        profile.setAttributeTypeLookup(type);

        ClientAttributesEntity attr = new ClientAttributesEntity();
        attr.setAttributeRestrictionLookup(null); // ⚠️ filtered out
        attr.setAttributeTypeLookup(type);

        when(clientRepoMock.findByClientId(clientId)).thenReturn(client);
        when(clientProfileRepoMock.findByControlCenterClientId(client.getId())).thenReturn(profile);
        when(clientAttributesRepoMock.findByControlCenterClientId(clientId)).thenReturn(List.of(attr));
        when(clientMappingRepoMock.findByControlCenterClientId(clientId)).thenReturn(Collections.singletonList(new ClientMappingEntity()));

        ClientResponse response = serviceMock.getClientData("t", "h", clientId);

        assertNull(response.getLocationUserPII());
        assertNull(response.getReason());
    }

    @Test
    void testGetClientData_attributeWithNullTypeLookup_isSkipped() {
        // Arrange
        String clientId = "123";
        ClientEntity client = new ClientEntity();
        client.setClientId(clientId);

        ClientProfileEntity profile = new ClientProfileEntity();
        AttributeTypeLookupEntity type = new AttributeTypeLookupEntity();
        type.setKey("N");
        profile.setAttributeTypeLookup(type);

        ClientAttributesEntity attr = new ClientAttributesEntity();
        AttributeRestrictionLookupEntity restriction = new AttributeRestrictionLookupEntity();
        restriction.setKey("Location-User-PII");
        attr.setAttributeRestrictionLookup(restriction);
        attr.setAttributeTypeLookup(null); // ⚠️ filtered out

        when(clientRepoMock.findByClientId(clientId)).thenReturn(client);
        when(clientProfileRepoMock.findByControlCenterClientId(client.getId())).thenReturn(profile);
        when(clientAttributesRepoMock.findByControlCenterClientId(clientId)).thenReturn(List.of(attr));
        when(clientMappingRepoMock.findByControlCenterClientId(clientId)).thenReturn(Collections.singletonList(new ClientMappingEntity()));

        ClientResponse response = serviceMock.getClientData("t", "h", clientId);

        assertNull(response.getLocationUserPII());
        assertNull(response.getReason());
    }

    @Test
    void testGetClientData_attributeWithUnsupportedRestrictionKey_isSkipped() {
        // Arrange
        String clientId = "123";
        ClientEntity client = new ClientEntity();
        client.setClientId(clientId);

        ClientProfileEntity profile = new ClientProfileEntity();
        AttributeTypeLookupEntity type = new AttributeTypeLookupEntity();
        type.setKey("Y");
        profile.setAttributeTypeLookup(type);

        ClientAttributesEntity attr = new ClientAttributesEntity();
        AttributeRestrictionLookupEntity restriction = new AttributeRestrictionLookupEntity();
        restriction.setKey("Custom"); // ⚠️ not in [Location-User-PII, Reason]
        attr.setAttributeRestrictionLookup(restriction);
        attr.setAttributeTypeLookup(type);

        when(clientRepoMock.findByClientId(clientId)).thenReturn(client);
        when(clientProfileRepoMock.findByControlCenterClientId(client.getId())).thenReturn(profile);
        when(clientAttributesRepoMock.findByControlCenterClientId(clientId)).thenReturn(List.of(attr));
        when(clientMappingRepoMock.findByControlCenterClientId(clientId)).thenReturn(Collections.singletonList(new ClientMappingEntity()));

        ClientResponse response = serviceMock.getClientData("t", "h", clientId);

        assertNull(response.getLocationUserPII());
        assertNull(response.getReason());
    }
    @Test
    void testGetClientData_filterAcceptsAttribute_butElseIfConditionIsFalse() {
        // Arrange
        String clientId = "789";

        ClientEntity client = new ClientEntity();
        client.setClientId(clientId);
        client.setName("Generic Client");
        client.setOrgName("Some Org");

        ClientProfileEntity profile = new ClientProfileEntity();
        AttributeTypeLookupEntity profileType = new AttributeTypeLookupEntity();
        profileType.setKey("N");
        profile.setAttributeTypeLookup(profileType);

        // Attribute passes filter, but has unrelated key
        ClientAttributesEntity attr = new ClientAttributesEntity();
        AttributeRestrictionLookupEntity restriction = new AttributeRestrictionLookupEntity();
        restriction.setKey("Unrelated"); // ✅ NOT "Location-User-PII" or "Reason"
        AttributeTypeLookupEntity type = new AttributeTypeLookupEntity();
        type.setKey("No-op");
        attr.setAttributeRestrictionLookup(restriction);
        attr.setAttributeTypeLookup(type);

        ClientMappingEntity mapping = new ClientMappingEntity();
        mapping.setScrmId("SCRMX");

        // Mocks
        when(clientRepoMock.findByClientId(clientId)).thenReturn(client);
        when(clientProfileRepoMock.findByControlCenterClientId(client.getId())).thenReturn(profile);
        when(clientAttributesRepoMock.findByControlCenterClientId(clientId)).thenReturn(List.of(attr));
        when(clientMappingRepoMock.findByControlCenterClientId(clientId)).thenReturn(List.of(mapping));

        // Act
        ClientResponse response = serviceMock.getClientData("token", "header", clientId);

        // Assert — ensures condition was false and skipped
        assertNull(response.getLocationUserPII());
        assertNull(response.getReason());
    }
    @Test
    void testMappingsPresentButAllScrmIdsInvalid_shouldReturnErrorResponse() {
        // Arrange
        String clientId = "123";
        ClientEntity mockClient = new ClientEntity();
        mockClient.setClientId(clientId);
        mockClient.setName("TestClient");
        mockClient.setOrgName("TestOrg");
        //.setId("C-100");

        // Profile
        ClientProfileEntity profile = new ClientProfileEntity();
        AttributeTypeLookupEntity profileAttr = new AttributeTypeLookupEntity();
        profileAttr.setKey("Y");
        profile.setAttributeTypeLookup(profileAttr);

        // Valid attributes
        ClientAttributesEntity mockAttr = new ClientAttributesEntity();
        AttributeRestrictionLookupEntity restr = new AttributeRestrictionLookupEntity();
        restr.setKey("Location-User-PII");
        AttributeTypeLookupEntity type = new AttributeTypeLookupEntity();
        type.setKey("Y");
        mockAttr.setAttributeRestrictionLookup(restr);
        mockAttr.setAttributeTypeLookup(type);

        // Mappings with all invalid (null and blank) SCRM IDs
        ClientMappingEntity map1 = new ClientMappingEntity();
        map1.setScrmId("   ");
        ClientMappingEntity map2 = new ClientMappingEntity();
        map2.setScrmId(null);

        // Mock setup
        when(clientRepoMock.findByClientId(clientId)).thenReturn(mockClient);
        when(clientProfileRepoMock.findByControlCenterClientId(mockClient.getId())).thenReturn(profile);
        when(clientAttributesRepoMock.findByControlCenterClientId(clientId)).thenReturn(List.of(mockAttr));
        when(clientMappingRepoMock.findByControlCenterClientId(clientId)).thenReturn(List.of(map1, map2));

        // Act
        ClientResponse response = serviceMock.getClientData("token", "header", clientId);

        // Assert
        assertNotNull(response);
        assertEquals("TestClient", response.getClientName());
        assertEquals("TestOrg", response.getOrgName());
        assertTrue(response.getIsDataRestriction());
        assertNull(response.getScrmId());
        assertNotNull(response.getErrors());
        assertEquals("Client Scrmid don’t exist in Postgres DB", response.getErrors().get(0).getErrorMessage());
    }

}
