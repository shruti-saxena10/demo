package com.alight.cc.startanywhere.util;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class StartAnywhereSecurityUtilTest {
	@Spy
	StartAnywhereSecurityUtil securityUtilMock;

	@SuppressWarnings("static-access")
	@Test
	public void test() {
		assertNotNull(securityUtilMock.cleanIt("testValue"));
		assertNotNull(securityUtilMock.unCleanIt("testValue"));
		assertNotNull(securityUtilMock.cleanSQL("testValue"));
		assertNotNull(securityUtilMock.escapeSQL("testValue"));
		assertNull(securityUtilMock.cleanIt(null));
		assertNull(securityUtilMock.unCleanIt(null));
		assertNull(securityUtilMock.cleanSQL(null));
		assertNull(securityUtilMock.escapeSQL(null));
	}

}
