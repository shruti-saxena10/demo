package com.alight.cc.startanywhere.model;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.meanbean.test.BeanTester;
import org.meanbean.test.Configuration;
import org.meanbean.test.ConfigurationBuilder;

public class StartAnywhereModelTest {

	BeanTester beanTester;
	Configuration configuration;

	@BeforeEach
	public void setup() {
		beanTester = new BeanTester();
		configuration = new ConfigurationBuilder().iterations(1).build();
	}

	@Test
	public void configurationPojoGettersAndSettersTest() {

		beanTester.testBean(ClientModel.class, configuration);
		beanTester.testBean(BaseResponse.class, configuration);


	}

	@AfterEach
	public void tearDown() {
		beanTester = null;
	}
}
