package com.alight.cc.startanywhere.entity;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.meanbean.test.BeanTester;
import org.meanbean.test.Configuration;
import org.meanbean.test.ConfigurationBuilder;

public class StartanywhereEntityTest {
	
	BeanTester beanTester;
	Configuration configuration;

	@BeforeEach
	public void setup() {
		beanTester = new BeanTester();
		configuration = new ConfigurationBuilder().iterations(1).build();
	}

	@Test
	public void configurationPojoGettersAndSettersTest() {

		beanTester.testBean(AttributeRestrictionLookupEntity.class, configuration);
		beanTester.testBean(AttributeTypeLookupEntity.class, configuration);
		beanTester.testBean(ClientAttributesEntity.class, configuration);
		beanTester.testBean(ClientEntity.class, configuration);
		beanTester.testBean(ClientMappingEntity.class, configuration);
		beanTester.testBean(ClientProfileEntity.class, configuration);

	}

	@AfterEach
	public void tearDown() {
		beanTester = null;
	}

	
}
