package com.alight.cc.startanywhere.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.alight.cc.startanywhere.configuration.SaviyntConfigurationBean;
import com.alight.cc.startanywhere.entity.SecurityManagerEntitlementEntity;
import com.alight.cc.startanywhere.feign.SaviyntClient;

@ExtendWith(MockitoExtension.class)
public class SaviyntServiceTest {

	@InjectMocks
	SaviyntService service;

	@Mock
	SaviyntConfigurationBean bean;

	@Mock
	SaviyntClient saviyntClient;

	@Test
	void testGetEndpoint_InternalUser_ReturnsInternalEndpoint() {
		when(bean.getEndpoint()).thenReturn("internal-endpoint");

		String result = service.getEndpoint("INTERNAL");

		assertEquals("internal-endpoint", result);
	}
	@Test
	void testGetEndpoint_InternalUser_ReturnsExternalEndpoint() {
		String result = service.getEndpoint("External");
		assertNull(result);
	}


	@Test
	void testGetEndpoint_NullUserType_ReturnsNull() {
		String result = service.getEndpoint(null);
		assertNull(result);
	}

	@Test
	void testGetSecuritySystem_ExternalUser_ReturnsExternalSecuritySystem() {
		lenient().when(bean.getSecuritySystem()).thenReturn("external-security");

		String result = service.getSecuritySystem("EXTERNAL");

		assertEquals(null, result);
	}

	@Test
	void testGetSecuritySystem_InternalUser_ReturnsInternalSecuritySystem() {
		when(bean.getSecuritySystem()).thenReturn("internal-security");

		String result = service.getSecuritySystem("INTERNAL");

		assertEquals("internal-security", result);
	}

	@Test
	void testGetSecuritySystem_InvalidUserType_ReturnsNull() {
		String result = service.getSecuritySystem("UNKNOWN");
		assertNull(result);
	}

	@Test
	void testGetSecuritySystem_InvalidUserType_Returns_Null() {
		String result = service.getSecuritySystem(null);
		assertNull(result);
	}
	@Test
	void testGetSecuritySystem_InvalidUserType_Returns_External_Null() {
		String result = service.getSecuritySystem("EXTERNAL");
		assertNull(result);
	}

	@Test
	void testGetDisplayNamesWithClientId_ValidEntities_ReturnsFormattedList() {
		SecurityManagerEntitlementEntity entity1 = mock(SecurityManagerEntitlementEntity.class);
		SecurityManagerEntitlementEntity entity2 = mock(SecurityManagerEntitlementEntity.class);

		when(entity1.getDisplayName()).thenReturn("Access<ClientID>");
		when(entity2.getDisplayName()).thenReturn("View<ClientID>");

		when(bean.getPrefix()).thenReturn("PREFIX-");
		when(bean.getApplication()).thenReturn("APP");

		List<String> result = service.getDisplayNamesWithClientId(List.of(entity1, entity2), "123");

		assertEquals(2, result.size());
		assertTrue(result.contains("PREFIX-Access123,APP"));
		assertTrue(result.contains("PREFIX-View123,APP"));
	}

	@Test
	void testGetDisplayNamesWithClientId_EmptyList_ReturnsEmpty() {
		List<String> result = service.getDisplayNamesWithClientId(Collections.emptyList(), "123");
		assertTrue(result.isEmpty());
	}

	@Test
	void testGetDisplayNamesWithClientId_NullList_ReturnsEmpty() {
		List<String> result = service.getDisplayNamesWithClientId(null, "123");
		assertTrue(result.isEmpty());
	}

}
