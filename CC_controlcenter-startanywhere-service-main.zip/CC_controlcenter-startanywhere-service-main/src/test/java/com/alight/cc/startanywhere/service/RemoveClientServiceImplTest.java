package com.alight.cc.startanywhere.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Collections;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.alight.cc.startanywhere.entity.ClientAttributesEntity;
import com.alight.cc.startanywhere.entity.ClientEntity;
import com.alight.cc.startanywhere.entity.ClientMappingEntity;
import com.alight.cc.startanywhere.entity.ClientProfileEntity;
import com.alight.cc.startanywhere.model.BaseResponse;
import com.alight.cc.startanywhere.repository.ClientAttributesRepository;
import com.alight.cc.startanywhere.repository.ClientMappingRepository;
import com.alight.cc.startanywhere.repository.ClientProfileRepository;
import com.alight.cc.startanywhere.repository.ClientRepository;
import com.alight.cc.startanywhere.service.impl.RemoveClientServiceImpl;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;

import jakarta.persistence.PersistenceException;

class RemoveClientServiceImplTest {

    @InjectMocks
    private RemoveClientServiceImpl removeClientService;

    @Mock
    private ClientRepository clientRepo;
    @Mock
    private ClientProfileRepository clientProfileRepo;
    @Mock
    private ClientAttributesRepository clientAttributesRepo;
    @Mock
    private ClientMappingRepository clientMappingRepo;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void deleteClientDetails_whenEntityIsNull_returnsBadRequest() {
        // Arrange
        when(clientRepo.findByClientId("client1")).thenReturn(null);

        // Act
        ResponseEntity<Object> response = removeClientService.deleteClientDetails("token", "header", "client1");

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        BaseResponse body = (BaseResponse) response.getBody();
        assertEquals(StartAnyWhereConstants.BAD_REQUEST, body.getResponseMessage());
    }

    @Test
    void deleteClientDetails_whenProfileIsNull_returnsOkAndLogsLowError() {
        // Arrange
        ClientEntity clientEntity = new ClientEntity();
        clientEntity.setId(123L);
        when(clientRepo.findByClientId("client1")).thenReturn(clientEntity);
        when(clientProfileRepo.findByControlCenterClientId(123L)).thenReturn(null);
        when(clientMappingRepo.findByControlCenterClientId("client1")).thenReturn(null);
        when(clientAttributesRepo.findByControlCenterClientId("client1")).thenReturn(null);

        // Act
        ResponseEntity<Object> response = removeClientService.deleteClientDetails("token", "header", "client1");

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        BaseResponse body = (BaseResponse) response.getBody();
        assertEquals(StartAnyWhereConstants.HTTP_STATUS_SUCCESS, body.getResponseCode());
        assertEquals(StartAnyWhereConstants.DELETED_STATUS, body.getResponseMessage());
    }
    @Test
    void deleteClientDetails_whenMappingsIsNull_returnsOkAndLogsLowError() {
        // Setup
        ClientEntity clientEntity = new ClientEntity();
        clientEntity.setId(123L);

        when(clientRepo.findByClientId("client1")).thenReturn(clientEntity);
        when(clientProfileRepo.findByControlCenterClientId(123L)).thenReturn(mock(ClientProfileEntity.class));
        when(clientMappingRepo.findByControlCenterClientId("client1")).thenReturn(null); // mappings is null
        when(clientAttributesRepo.findByControlCenterClientId("client1")).thenReturn(Arrays.asList(mock(ClientAttributesEntity.class)));

        // Act
        ResponseEntity<Object> response = removeClientService.deleteClientDetails("token", "header", "client1");

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        BaseResponse body = (BaseResponse) response.getBody();
        assertEquals(StartAnyWhereConstants.HTTP_STATUS_SUCCESS, body.getResponseCode());
        verify(clientRepo).deleteByClientId("client1");
    }

    @Test
    void deleteClientDetails_whenMappingsIsEmpty_returnsOkAndLogsLowError() {
        ClientEntity clientEntity = new ClientEntity();
        clientEntity.setId(123L);

        when(clientRepo.findByClientId("client1")).thenReturn(clientEntity);
        when(clientProfileRepo.findByControlCenterClientId(123L)).thenReturn(mock(ClientProfileEntity.class));
        when(clientMappingRepo.findByControlCenterClientId("client1")).thenReturn(Collections.emptyList()); // mappings is empty
        when(clientAttributesRepo.findByControlCenterClientId("client1")).thenReturn(Arrays.asList(mock(ClientAttributesEntity.class)));

        ResponseEntity<Object> response = removeClientService.deleteClientDetails("token", "header", "client1");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(clientRepo).deleteByClientId("client1");
    }

    @Test
    void deleteClientDetails_whenAttributesIsNull_returnsOkAndLogsLowError() {
        ClientEntity clientEntity = new ClientEntity();
        clientEntity.setId(123L);

        when(clientRepo.findByClientId("client1")).thenReturn(clientEntity);
        when(clientProfileRepo.findByControlCenterClientId(123L)).thenReturn(mock(ClientProfileEntity.class));
        when(clientMappingRepo.findByControlCenterClientId("client1")).thenReturn(Arrays.asList(mock(ClientMappingEntity.class)));
        when(clientAttributesRepo.findByControlCenterClientId("client1")).thenReturn(null); // attributes is null

        ResponseEntity<Object> response = removeClientService.deleteClientDetails("token", "header", "client1");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(clientRepo).deleteByClientId("client1");
    }

    @Test
    void deleteClientDetails_whenAttributesIsEmpty_returnsOkAndLogsLowError() {
        ClientEntity clientEntity = new ClientEntity();
        clientEntity.setId(123L);

        when(clientRepo.findByClientId("client1")).thenReturn(clientEntity);
        when(clientProfileRepo.findByControlCenterClientId(123L)).thenReturn(mock(ClientProfileEntity.class));
        when(clientMappingRepo.findByControlCenterClientId("client1")).thenReturn(Arrays.asList(mock(ClientMappingEntity.class)));
        when(clientAttributesRepo.findByControlCenterClientId("client1")).thenReturn(Collections.emptyList()); // attributes is empty

        ResponseEntity<Object> response = removeClientService.deleteClientDetails("token", "header", "client1");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(clientRepo).deleteByClientId("client1");
    }

    @Test
    void deleteClientDetails_whenMappingsAndAttributesArePresent_deletesAll() {
        ClientEntity clientEntity = new ClientEntity();
        clientEntity.setId(123L);

        when(clientRepo.findByClientId("client1")).thenReturn(clientEntity);
        when(clientProfileRepo.findByControlCenterClientId(123L)).thenReturn(mock(ClientProfileEntity.class));
        when(clientMappingRepo.findByControlCenterClientId("client1")).thenReturn(Arrays.asList(mock(ClientMappingEntity.class)));
        when(clientAttributesRepo.findByControlCenterClientId("client1")).thenReturn(Arrays.asList(mock(ClientAttributesEntity.class)));

        ResponseEntity<Object> response = removeClientService.deleteClientDetails("token", "header", "client1");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(clientProfileRepo).deleteByControlCenterClientId("client1");
        verify(clientMappingRepo).deleteByControlCenterClientId("client1");
        verify(clientAttributesRepo).deleteByControlCenterClientId("client1");
        verify(clientRepo).deleteByClientId("client1");
    }

    @Test
    void deleteClientDetails_whenPersistenceExceptionThrown_rethrows() {
        ClientEntity clientEntity = new ClientEntity();
        clientEntity.setId(123L);

        when(clientRepo.findByClientId("client1")).thenReturn(clientEntity);
        when(clientProfileRepo.findByControlCenterClientId(123L)).thenThrow(new PersistenceException("DB error"));

        assertThrows(PersistenceException.class, () ->
                removeClientService.deleteClientDetails("token", "header", "client1")
        );
    }
    @Test
    void handleRetryFailure_returnsTooManyRequests() {
        // Given
        Exception exception = new Exception("Retry failed");

        // When
        ResponseEntity<Object> response = removeClientService.handleRetryFailure(exception, "test", "test", "00095");

        // Then
        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
        assertNotNull(response.getBody());
        BaseResponse body = (BaseResponse) response.getBody();
        }
   
}