package com.alight.cc.startanywhere.configuration;
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

import java.lang.reflect.Field;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
import org.springframework.cloud.openfeign.support.ResponseEntityDecoder;
import org.springframework.cloud.openfeign.support.SpringDecoder;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fasterxml.jackson.databind.ObjectMapper;

import feign.codec.Decoder;
@ExtendWith(SpringExtension.class)
class SaviyntClientConfigTest {
	@InjectMocks
    private SaviyntClientConfig config;
	@Mock
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        objectMapper = mock(ObjectMapper.class); // mock if needed
        config = new SaviyntClientConfig();
        config.objectMapper = objectMapper; // manually inject the mocked ObjectMapper
    }

    @Test
    void testFeignDecoderBeanCreation() throws Exception {
        Decoder decoderBean = config.feignDecoder();

        assertNotNull(decoderBean);
        assertTrue(decoderBean instanceof ResponseEntityDecoder);

       
        Field field = ResponseEntityDecoder.class.getDeclaredField("decoder");
        field.setAccessible(true);
        Object innerDecoder = field.get(decoderBean);

        assertNotNull(innerDecoder);
        assertTrue(innerDecoder instanceof SpringDecoder);
    }
   
    @Test
    void testObjectFactoryReturnsExpectedConverters() {
        // Setup
        ObjectMapper mapper = new ObjectMapper();
        HttpMessageConverter converter = new MappingTextJson2HttpMessageConverter(mapper);
        HttpMessageConverters httpMessageConverters = new HttpMessageConverters(converter);

        // Lambda assignment
        ObjectFactory<HttpMessageConverters> objectFactory = () -> httpMessageConverters;

        // Invocation
        HttpMessageConverters result = objectFactory.getObject();

        // Assertions
        assertNotNull(result);
        assertTrue(result.getConverters().contains(converter));
    }
}
