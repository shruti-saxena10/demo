package com.alight.cc.startanywhere.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.alight.cc.startanywhere.entity.ClientOnboardingRequestTrackEntity;

@Repository
public interface ClientOnboardingRequestTrackRepository
		extends JpaRepository<ClientOnboardingRequestTrackEntity, Long> {


	void deleteByCorrelationId(String correlationId);

	ClientOnboardingRequestTrackEntity findByCorrelationIdAndClientId(String correlationId, String clientId);
	ClientOnboardingRequestTrackEntity findByClientId(String clientId);




}
