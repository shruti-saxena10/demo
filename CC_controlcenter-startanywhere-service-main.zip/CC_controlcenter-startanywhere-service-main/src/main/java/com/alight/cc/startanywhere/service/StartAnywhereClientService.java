package com.alight.cc.startanywhere.service;

import java.io.IOException;

import org.postgresql.util.PSQLException;
import org.springframework.http.ResponseEntity;

import com.alight.cc.startanywhere.model.ClientModel;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface StartAnywhereClientService {

	ResponseEntity<Object> addNewclientdetails(String alightColleagueSessionToken, String alightRequestHeader,
			String ColleagueEmailId, ClientModel request) throws JsonProcessingException, IOException, PSQLException;
}
