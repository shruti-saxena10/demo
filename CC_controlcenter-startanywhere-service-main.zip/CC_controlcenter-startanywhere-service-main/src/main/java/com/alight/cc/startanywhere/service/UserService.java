package com.alight.cc.startanywhere.service;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import com.alight.cc.ControlCenterCommonConstants;
import com.alight.cc.model.DomainLookup;
import com.alight.cc.model.DomainLookupType;
import com.alight.cc.repository.DomainLookupRepository;
import com.alight.cc.startanywhere.configuration.SaviyntLogin;
import com.alight.cc.startanywhere.feign.SaviyntClient;
import com.alight.cc.startanywhere.saviynt.model.GetUserRequest;
import com.alight.cc.startanywhere.saviynt.model.User;
import com.alight.cc.startanywhere.saviynt.model.UserDetailsResponse;
import com.alight.cc.startanywhere.util.SaviyntRequestBuilder;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;
import com.alight.cc.startanywhere.util.StartAnywhereUtil;
import com.alight.logging.helpers.InfoTypeLogEventHelper;
import com.aonhewitt.logging.events.ErrorLogEvent;
import com.aonhewitt.logging.helpers.DebugLogEventHelper;
import com.aonhewitt.logging.helpers.ErrorLogEventHelper;

import feign.FeignException;

@Service
public class UserService {

	@Autowired
	SaviyntClient saviyntClient;

	@Autowired
	SaviyntLogin saviyntLogin;

	@Autowired
	SaviyntRequestBuilder saviyntRequestBuilder;
	
	@Autowired
	DomainLookupRepository domainLookupRepository;
	 	 
	@Autowired
	SaviyntService saviyntService;

	@Cacheable(value = "saviyntAccessToken")
	@Retryable(value = {
			FeignException.class }, maxAttemptsExpression = "#{${app.api.retry.max-attempts:5}}", backoff = @Backoff(delayExpression = "#{${app.api.retry.backoff-delay:1000}}"), exceptionExpression = "#{@retryHelper.is5xx(#root)}")

	public String getAccessToken() {
		String accessToken = null;
		if (saviyntLogin != null && saviyntLogin.getLoginData() != null) {
			JSONObject token = saviyntClient.getAuthToken(saviyntLogin.getLoginData());
			accessToken = (String) token.get(StartAnyWhereConstants.ACCESS_TOKEN_KEY);
		}

		return accessToken;
	}
	public String getFreshAccessToken() {
		String accessToken = null;
		if (saviyntLogin != null && saviyntLogin.getFreshLoginData() != null) {
			JSONObject token = saviyntClient.getAuthToken(saviyntLogin.getFreshLoginData());
			accessToken = (String) token.get(StartAnyWhereConstants.ACCESS_TOKEN_KEY);
		}

		return accessToken;
	}

	@Retryable(value = {
			FeignException.class }, maxAttemptsExpression = "#{${app.api.retry.max-attempts:5}}", backoff = @Backoff(delayExpression = "#{${app.api.retry.backoff-delay:1000}}"), exceptionExpression = "#{@retryHelper.is5xx(#root)}")
	public User getUserProfile(String email, String accessToken) {

		GetUserRequest getUserRequest = GetUserRequest.builder()
				.userQuery(saviyntRequestBuilder.buildGetUserQuery(email)).build();
		UserDetailsResponse userDetailsResponse = saviyntClient
				.getUser(StartAnyWhereConstants.AUTH_TOKEN_PREFIX + accessToken, getUserRequest);
		InfoTypeLogEventHelper.logInfoEvent(UserService.class.getName(),
				"Response from get user: " + userDetailsResponse);
		int statusCode = StartAnywhereUtil.calculateSaviyntStatusCode(userDetailsResponse.getStatusCode());
		User user = null;
		if ((statusCode == HttpStatus.OK.value()) && (userDetailsResponse.getUserdetails().size() > 0)) {
			// Valid response so map back to User Details
			user = userDetailsResponse.getUserdetails().get(0);
			if (userDetailsResponse.getUserdetails().size() > 1) {
				DebugLogEventHelper.logDebugEvent(UserService.class.getName(),
						"More than one user with email found in Saviynt", "getUserProfile",
						"matching email = " + email);
			}
		}

		return user;
	}

	public String determineUserTypeByEmailDomain(String email) {
		List<DomainLookup> internalDomainList = domainLookupRepository.findByDomainType(DomainLookupType.internal);
		boolean isInternalDomain = this.isInternalDomain(internalDomainList, email);
		return isInternalDomain ? ControlCenterCommonConstants.TypeOfUser.INTERNAL.name().toLowerCase()
				: ControlCenterCommonConstants.TypeOfUser.EXTERNAL.name().toLowerCase();
	}
	
	private boolean isInternalDomain(List<DomainLookup> domainLookupList, String email) {
		return domainLookupList.stream().map(DomainLookup::getDomainName)
				.anyMatch(domainName -> StringUtils.endsWithIgnoreCase(email, domainName));
	}
}