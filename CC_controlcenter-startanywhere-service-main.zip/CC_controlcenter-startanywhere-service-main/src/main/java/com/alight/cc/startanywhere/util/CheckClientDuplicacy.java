package com.alight.cc.startanywhere.util;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.alight.cc.startanywhere.entity.ClientEntity;
import com.alight.cc.startanywhere.exception.DuplicateClientException;
import com.alight.cc.startanywhere.model.BaseResponse;
import com.alight.cc.startanywhere.repository.ClientRepository;
import com.alight.logging.helpers.InfoTypeLogEventHelper;

@Component
public class CheckClientDuplicacy {

	@Autowired
	 ClientRepository clientRepo;
	public BaseResponse isDuplicateClient(String clientId, String orgName, String clientName) {
		
		ClientEntity entityClientId = clientRepo.findByClientIdIgnoreCase(clientId);
		ClientEntity entityOrgName =clientRepo.findByOrgNameIgnoreCase(orgName);
		boolean exists = clientRepo.existsByNameIgnoreCase(clientName);
		ArrayList errors = new ArrayList<>();
		if (exists) {
			String message = String.format(StartAnyWhereConstants.CLIENT_NAME_EXISTS_MESSAGE, 
					clientName);

			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Duplicate clientName: " + message);
			DuplicateClientException ex = new DuplicateClientException(message);

			
			@SuppressWarnings("unchecked")
			BaseResponse response= StartAnywhereUtil.buildResponse(
					new BaseResponse(),
					StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
					StartAnyWhereConstants.BAD_REQUEST,
					StartAnyWhereConstants.POS103,
					ex.getMessage(),
					StartAnyWhereConstants.HIGH,
					null,
					errors
					);

			return response;

		} 
		if ((entityClientId != null && entityOrgName != null) ||
			    (entityClientId == null && entityOrgName != null) ||
			    (entityClientId != null && entityOrgName == null)) {

			   String message = String.format(StartAnyWhereConstants.CLIENT_ALREADY_EXISTS_MESSAGE, 
			                            clientId, orgName);

			    InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Duplicate client: " + message);
			    DuplicateClientException ex = new DuplicateClientException(message);

			    @SuppressWarnings("unchecked")
				BaseResponse response = StartAnywhereUtil.buildResponse(
			                   new BaseResponse(),
			                   StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
			                   StartAnyWhereConstants.BAD_REQUEST,
			                   StartAnyWhereConstants.POS103,
			                   ex.getMessage(),
			                   StartAnyWhereConstants.HIGH,
			                   null,
			                   errors
			               );

			    return response;
			}
		return null;
	}
}
