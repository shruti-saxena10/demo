package com.alight.cc.startanywhere.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.alight.cc.startanywhere.entity.ClientProfileEntity;


@Repository
public interface ClientProfileRepository extends JpaRepository<ClientProfileEntity, Long>{
	@Query("SELECT cp FROM ClientProfileEntity cp WHERE cp.client.id = :clientId")
	ClientProfileEntity findByControlCenterClientId(@Param("clientId") Long clientId);

	@Modifying
	@Query("DELETE  FROM ClientProfileEntity cp WHERE cp.client.clientId = :clientId")	
	void deleteByControlCenterClientId(@Param("clientId")String clientId);
}
