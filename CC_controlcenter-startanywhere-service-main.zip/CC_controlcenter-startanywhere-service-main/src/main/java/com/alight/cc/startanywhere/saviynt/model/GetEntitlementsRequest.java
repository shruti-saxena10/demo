package com.alight.cc.startanywhere.saviynt.model;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetEntitlementsRequest {
	private String entQuery;
    private String username;
    private String endpoint;
    private String status;
    private Integer max;
    private Integer offset;
   
    
}
