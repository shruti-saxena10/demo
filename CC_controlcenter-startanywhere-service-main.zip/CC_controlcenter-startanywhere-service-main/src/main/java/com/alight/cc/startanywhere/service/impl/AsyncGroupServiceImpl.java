package com.alight.cc.startanywhere.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import org.hibernate.internal.build.AllowSysOut;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alight.asg.model.header.v1_0.RequestHeader;
import com.alight.cc.startanywhere.configuration.SaviyntConfigurationBean;
import com.alight.cc.startanywhere.entity.ClientOnboardingRequestTrackEntity;
import com.alight.cc.startanywhere.entity.SecurityManagerEntitlementEntity;
import com.alight.cc.startanywhere.feign.SaviyntClient;
import com.alight.cc.startanywhere.model.ClientConfigError;
import com.alight.cc.startanywhere.model.CreateGroupsResponse;
import com.alight.cc.startanywhere.model.CreateGroupsResponse.FailedEntitlement;
import com.alight.cc.startanywhere.model.CreateGroupsResponse.SuccessfulEntitlement;
import com.alight.cc.startanywhere.repository.ClientOnboardingRequestTrackRepository;
import com.alight.cc.startanywhere.repository.SecurityManagerEntitlementRepository;
import com.alight.cc.startanywhere.saviynt.model.Owner;
import com.alight.cc.startanywhere.saviynt.model.UpdateUserEntitlementsRequest;
import com.alight.cc.startanywhere.service.ClientOnboardingRequestTrackService;
import com.alight.cc.startanywhere.service.GroupService;
import com.alight.cc.startanywhere.service.UserService;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;
import com.alight.cc.startanywhere.util.StartAnywhereSecurityUtil;
import com.alight.cc.startanywhere.util.StartAnywhereUtil;
import com.alight.logging.helpers.InfoTypeLogEventHelper;
import com.aonhewitt.logging.events.ErrorLogEvent;
import com.aonhewitt.logging.helpers.ErrorLogEventHelper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import feign.FeignException;
import feign.RetryableException;
import feign.codec.DecodeException;
import feign.codec.EncodeException;
import io.micrometer.common.util.StringUtils;

@Service
public class AsyncGroupServiceImpl{
	@Autowired
	ClientOnboardingRequestTrackRepository trackRepo;
	@Autowired
	SaviyntConfigurationBean configBean;
	@Autowired
    private SaviyntConfigurationBean saviyntConfig;

    @Autowired
    private SecurityManagerEntitlementRepository entitlementRepo;
    @Autowired
	SaviyntClient saviyntClient;

	@Autowired
	UserService userService;
	
	@Autowired
	ClientOnboardingRequestTrackService clientOnboardingRequestTrackService;
	
	private ObjectMapper om = new ObjectMapper();
	JSONParser parser = new JSONParser();
	
	@Async
	public void createGroupsAsync(String sessionToken, String requestHeader, String clientId,
			String clientName) {
		InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
				"Start executing createGroupsAsync service with clientID: " + clientId);
		
		List<CreateGroupsResponse> responseList = new ArrayList<>();
		 List<SuccessfulEntitlement> successfulEntitlementsList = new ArrayList<>();
	    List<FailedEntitlement> failedEntitlementsList= new ArrayList<>();
	    CreateGroupsResponse createGroupsResponse = new CreateGroupsResponse();
		createGroupsResponse.setClientId(clientId);
		createGroupsResponse.setClientName(clientName);
		List<ClientConfigError> errors = new ArrayList<>();
		try {
		    saveTrack( requestHeader, createGroupsResponse);
				String accessTokenRef = userService.getFreshAccessToken();
				 
				List<SecurityManagerEntitlementEntity> entities = entitlementRepo.findAll();
		        		Map<SecurityManagerEntitlementEntity, Map<String, String>> transformEntityFields = transformEntityFields(entities, clientId, clientName);
		        		Optional.ofNullable(transformEntityFields(entities, clientId, clientName))
		        	    .filter(map -> !map.isEmpty())
		        	    .ifPresent(transformedMap ->
		        	        transformedMap.forEach((entity, fields) -> {
		        	            Optional.ofNullable(fields)
		        	                .filter(f -> !f.isEmpty() && f.containsKey("displayName") && f.containsKey("description"))
		        	                .ifPresent(validFields -> {
		        				UpdateUserEntitlementsRequest constructEntitlementRequest = constructEntitlementRequest(validFields.get("displayName"),validFields.get("description"));
		        				SuccessfulEntitlement successfulEntitlement=new SuccessfulEntitlement();
		        				FailedEntitlement failedEntitlement =new FailedEntitlement();
		        				
	        					try {
	        						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
	        								"Request Payload: " + constructEntitlementRequest.toString());
		        				    JSONObject updateEntitlementsOnUser = saviyntClient.updateEntitlementsOnUser(
		        						StartAnyWhereConstants.AUTH_TOKEN_PREFIX+accessTokenRef, constructEntitlementRequest);
		        				    InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
	        								"Response from saviynt: " + updateEntitlementsOnUser);
		        				    Map<String, String> presentValues = getPresentValues(updateEntitlementsOnUser);
		        				    successfulEntitlement.setEntitlementName(validFields.get("description"));
		        				    successfulEntitlement.setRequestId(presentValues.get("requestid"));
		        				    successfulEntitlement.setRequestKey(presentValues.get("requestkey"));
		        				    successfulEntitlementsList.add(successfulEntitlement);
		        				    
		        				 
		        				
		        				}
		        				catch (FeignException.Unauthorized ex) {
		        				    ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
		        				        "Unauthorized access - check token validity", 
		        				        "updateEntitlementsOnUser()", ex, ErrorLogEvent.ERROR_SEVERITY);
		        				    List<ClientConfigError> error = new ArrayList<>();
		        				    CreateGroupsResponse response=StartAnywhereUtil.buildResponse(new CreateGroupsResponse(),
		        							StartAnyWhereConstants.HTTP_STATUS_UNAUTHORIZED, StartAnyWhereConstants.UNAUTHORIZED,
		        							StartAnyWhereConstants.SAV101,
		        							StartAnyWhereConstants.SAVIYNT_SERVER_UNREACHABLE,
		        							StartAnyWhereConstants.HIGH, null, error);
		        				    if (ex.contentUTF8() != null) {
		        			            JSONObject jsonObject = null;
										try {
											jsonObject = (JSONObject) parser.parse(ex.contentUTF8());
											failedEntitlement.setEntitlementName(validFields.get("description"));
											failedEntitlement.setErrorMessage(om.writeValueAsString(response));
											failedEntitlementsList.add(failedEntitlement);
										} catch (ParseException | JsonProcessingException e) {
											e.printStackTrace();
											ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
					        				        "Unexpected exception during entitlement update", 
					        				        "updateEntitlementsOnUser()", e, ErrorLogEvent.ERROR_SEVERITY);
										}
		        				    }
		        				
		        				}catch (FeignException fe) {
		        				    if (fe.contentUTF8() != null) {
		        			            JSONObject jsonObject = null;
										try {
											jsonObject = (JSONObject) parser.parse(fe.contentUTF8());
							
										Map<String, String> presentValues = getPresentValues(jsonObject);
										failedEntitlement.setEntitlementName(validFields.get("description"));
										failedEntitlement.setErrorMessage(presentValues.get("msg"));
										failedEntitlement.setErrorCode(presentValues.get("errorCode"));
										failedEntitlementsList.add(failedEntitlement);
		        				    } catch (Exception e) {
										e.printStackTrace();
										ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
				        				        "Unexpected exception during entitlement update", 
				        				        "updateEntitlementsOnUser()", e, ErrorLogEvent.ERROR_SEVERITY);
									}
		        				       
		        				    }
		        				    
		        				} 
		        				
		        				catch (Exception ex) {
		        				    ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
		        				        "Unexpected exception during entitlement update", 
		        				        "updateEntitlementsOnUser()", ex, ErrorLogEvent.ERROR_SEVERITY);
		        				}
		        	                });
		        	        })
		        	    );
		        		createGroupsResponse.setSuccessfulEntitlements(successfulEntitlementsList);
		        		createGroupsResponse.setFailedEntitlements(failedEntitlementsList);
						updateTrack( requestHeader, createGroupsResponse);
						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
								"createGroupsAsync() method finished with clientID: " + clientId);
						
		} catch (Exception e) {
			ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
					"Exception occurred during  operations: " + e.getMessage(), "createGroups", e,
					ErrorLogEvent.ERROR_SEVERITY);

			
		}
		 
		

	}

	public UpdateUserEntitlementsRequest constructEntitlementRequest(String displayName,String description) {
		InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
				"start execution of constructEntitlementRequest(): ");
        //  Step 1: Map structured owners from config
        List<Owner> owners = saviyntConfig.getOwner().stream()
                .map(o -> new Owner(o.getOwnername(), o.getRank()))
                .collect(Collectors.toList());

        //  Step 2: Assemble the request object
        
        UpdateUserEntitlementsRequest request = UpdateUserEntitlementsRequest.builder()
        		.accesstype(StartAnyWhereConstants.ACCESS_TYPE)
        		.requestor(saviyntConfig.getRequestor())
        		.displayname(displayName)
        		.roletype(StartAnyWhereConstants.ROLE_TYPE)
        		.entitlementtype(saviyntConfig.getEntitlementtype())
        		.suffix(displayName)
        		.requesttype(StartAnyWhereConstants.REQUEST_TYPE_CREATE)
        		.description(description)
        		.category(StartAnyWhereConstants.CATEGORY)
        		.syscritical(StartAnyWhereConstants.SYS_CRITICAL)
        		.soxcritical(StartAnyWhereConstants.SOX_CRITICAL)
        		.securitysystem(saviyntConfig.getSecuritySystem())
        		.endpoint(saviyntConfig.getEndpointD2())
        		.domain( saviyntConfig.getDomain())
        		.environment( saviyntConfig.getEnvironment())
        		.application(saviyntConfig.getApplication())
        		.owner(owners)
        		.build();

        return request;
        
       /* return new UpdateUserEntitlementsRequest(
        	StartAnyWhereConstants.ACCESS_TYPE,                       
            saviyntConfig.getRequestor(),                           
            displayName,                                            
            StartAnyWhereConstants.ROLE_TYPE,                         
            saviyntConfig.getEntitlementtype(),                     
            displayName,                                            
            StartAnyWhereConstants.REQUEST_TYPE_CREATE,                      
            description,                                            
            StartAnyWhereConstants.CATEGORY,                          
            StartAnyWhereConstants.SYS_CRITICAL,                      
            StartAnyWhereConstants.SOX_CRITICAL,                      
            saviyntConfig.getSecuritySystem(),                      
            saviyntConfig.getEndpointD2(),                            
            saviyntConfig.getDomain(),                              
            saviyntConfig.getEnvironment(),                         
            saviyntConfig.getApplication(),                         
            owners                                                  
        );*/
    }
	public List<String> getDisplayNamesWithClientId(List<SecurityManagerEntitlementEntity> entitlementEntities,
			String clientId ,String clientName) {
		if (entitlementEntities == null || entitlementEntities.isEmpty()) {
			return Collections.emptyList();
		}

		return entitlementEntities.stream().map(SecurityManagerEntitlementEntity::getDisplayName)
				.filter(Objects::nonNull)
				.map(value ->  value.replace("<ClientID>", clientId) + "," + saviyntConfig.getApplication())
				.collect(Collectors.toList());
	}

	public static Map<SecurityManagerEntitlementEntity, Map<String, String>> transformEntityFields(
	        List<SecurityManagerEntitlementEntity> entities,
	        String clientId,
	        String clientName) {

	    Map<SecurityManagerEntitlementEntity, Map<String, String>> transformedFields = new HashMap<>();

	    if (entities == null) {
	        return transformedFields; // return empty map instead of null
	    }

	    for (SecurityManagerEntitlementEntity entity : entities) {
	        if (entity == null) {
	            continue; // skip null entities
	        }

	        String displayName = Optional.ofNullable(entity.getDisplayName())
	            .map(name -> name
	                .replace("<ClientID>", clientId))
	            .orElse("");

	        String description = Optional.ofNullable(entity.getDescription())
	            .map(desc -> desc
	                .replace("<ClientID>", clientId)
	                .replace("<ClientName>", clientName))
	            .orElse("");

	        Map<String, String> result = new HashMap<>();
	        result.put("displayName", displayName);
	        result.put("description", description);

	        transformedFields.put(entity, result);
	    }

	    return transformedFields;
	}
	@Transactional
	public void saveTrack(String alightRequestHeader, CreateGroupsResponse configRequest )
			throws JsonProcessingException, IOException {
		InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
				"start  execution of saveTrack(): ");
		alightRequestHeader = StartAnywhereSecurityUtil.unCleanIt(alightRequestHeader);
		RequestHeader parsedRequestHeader = RequestHeader.parse(alightRequestHeader);
		String correlationId = parsedRequestHeader.getCorrelationId();
		String inputJson = om.writeValueAsString(configRequest);
		ClientOnboardingRequestTrackEntity entity = trackRepo.findByCorrelationIdAndClientId(correlationId, configRequest.getClientId());
        if(entity==null) {
        	entity = new ClientOnboardingRequestTrackEntity();
        
		entity.setCorrelationId(correlationId);
		entity.setInputJson(inputJson);
		entity.setClientId(configRequest.getClientId());
		entity.setStatus(0);
		entity.setApiName(StartAnyWhereConstants.SAV_ADGROUPS_API);
		Date startTime = new Date();
		entity.setRequestStartedAt(startTime);
		trackRepo.save(entity);
		InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
				"Completed  execution of saveTrack(): ");
	}

	}
	@Transactional
	public void updateTrack(String alightRequestHeader, CreateGroupsResponse responseList
			) throws JsonProcessingException, IOException {
		// TODO Auto-generated method stub
		InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
				"start execution of updateTrack(): ");
		alightRequestHeader = StartAnywhereSecurityUtil.unCleanIt(alightRequestHeader);
		RequestHeader parsedRequestHeader = RequestHeader.parse(alightRequestHeader);
		String correlationId = parsedRequestHeader.getCorrelationId();
		String clientId = responseList.getClientId();
		ClientOnboardingRequestTrackEntity entity = trackRepo.findByCorrelationIdAndClientId(correlationId, clientId);
		String createGroupsResponseWithErrorJson = om.writeValueAsString(responseList);
		entity.setOutput(createGroupsResponseWithErrorJson);
		entity.setStatus(1);
		Date endTime = new Date();
		entity.setRequestCompletedAt(endTime);
		InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Updating the correlation Id in tracker");
		trackRepo.save(entity);
		InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
				"Completed  execution of updateTrack(): ");
	}
	public CreateGroupsResponse checkValidationBeforeAsyncC(String sessionToken, String requestHeader, String clientId,
			String clientName) {
		InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
				"Started executing checkValidationBeforeAsync service with clientID: " + clientId);
		
		CreateGroupsResponse createGroupsResponse = new CreateGroupsResponse();
		List<ClientConfigError> errors = new ArrayList<>();
		try {
			requestHeader = StartAnywhereSecurityUtil.unCleanIt(requestHeader);
		    RequestHeader parsedRequestHeader = RequestHeader.parse(requestHeader);
		    String correlationId = parsedRequestHeader.getCorrelationId();

		    if(StringUtils.isEmpty(correlationId)) {
				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Correlation ID is : "+correlationId);
				return StartAnywhereUtil.buildResponse(createGroupsResponse, StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
						StartAnyWhereConstants.MISSING_REQUIRED_PARAMETERS_MESSAGE, null, null, null, null, errors);
			} 
		    
		    ClientOnboardingRequestTrackEntity trackEntity = trackRepo.findByCorrelationIdAndClientId(correlationId,
					clientId);
		    ClientOnboardingRequestTrackEntity statustrackEntity = trackRepo.findByClientId(
					clientId);
		    
			if (trackEntity != null) {
				if (trackEntity.getStatus() == 0) {
					int hitCount = trackEntity.getHitCount();
					if (hitCount < configBean.getHitCount()) {
						trackEntity.setHitCount(hitCount + 1);
						trackRepo.save(trackEntity);
						return StartAnywhereUtil.buildResponse(createGroupsResponse,
								StartAnyWhereConstants.HTTP_STATUS_SUCCESS,
								StartAnyWhereConstants.REQUEST_ALREADY_IN_PROGRESS, null, null, null, null, errors);
					} else {
						return StartAnywhereUtil.buildResponse(createGroupsResponse,
								StartAnyWhereConstants.HTTP_STATUS_RATE_LIMIT_EXCEEDED,
								String.format(StartAnyWhereConstants.RATE_LIMIT_EXCEEDED, configBean.getFallbackTime()),
								null, null, StartAnyWhereConstants.HIGH, null, errors);
					}
				}else {
					return StartAnywhereUtil.buildResponse(createGroupsResponse, StartAnyWhereConstants.HTTP_STATUS_SUCCESS,
							StartAnyWhereConstants.REQUEST_COMPLETED_SUCCESSFULLY, null, null, null, null, errors);
				}
			}
				
		
	}catch(Exception e) {
		e.printStackTrace();
	}
		return createGroupsResponse;
	}
	public  Map<String, String> getPresentValues(JSONObject response) {
        Map<String, String> result = new HashMap<>();

        if (response.containsKey("msg")) {
            result.put("msg", response.get("msg").toString());
        }

        if (response.containsKey("errorCode")) {
            result.put("errorCode", response.get("errorCode").toString());
        }

        if (response.containsKey("requestid")) {
            result.put("requestid", response.get("requestid").toString());
        }

        if (response.containsKey("requestkey")) {
            result.put("requestkey", response.get("requestkey").toString());
        }

        return result;
    }
}
