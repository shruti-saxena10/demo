package com.alight.cc.startanywhere.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.alight.cc.startanywhere.entity.ClientEntity;

@Repository
public interface ClientRepository extends JpaRepository<ClientEntity, Long>{

	
	ClientEntity findByClientId(String clientId);
	
	ClientEntity findByClientIdIgnoreCase(String clientId);
	
	ClientEntity findByOrgNameIgnoreCase(String orgName);
	
	void deleteByClientId(String clientId);

	boolean existsByNameIgnoreCase(String clientName);

}
