package com.alight.cc.startanywhere.model;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class ClientConfigurationRequest {

	@NotBlank(message ="clientId is required ")
	@Size( max = 10, message = "clientID can have maximum 10 characters")
	private String clientId;
	@NotBlank(message ="clientName is required ")
	private String clientName;
	@NotBlank(message ="orgName is required ")
	private String orgName;
	@NotNull(message = "isDataRestriction is required")
	private Boolean isDataRestriction;
	@NotNull(message ="Security Manager details needed")
	@Size(min = 1, max = 5, message = "Must have between 1 and 5 Security Managers")
	@Valid
	private List<SecurityManagerEmail> securityManagers;
		
}
