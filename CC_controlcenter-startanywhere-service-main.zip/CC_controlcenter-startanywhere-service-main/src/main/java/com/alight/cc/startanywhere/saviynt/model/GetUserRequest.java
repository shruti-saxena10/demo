package com.alight.cc.startanywhere.saviynt.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class GetUserRequest {
    private String userQuery;
}
