package com.alight.cc.startanywhere.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Recover;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alight.cc.startanywhere.entity.ClientAttributesEntity;
import com.alight.cc.startanywhere.entity.ClientEntity;
import com.alight.cc.startanywhere.entity.ClientMappingEntity;
import com.alight.cc.startanywhere.entity.ClientProfileEntity;
import com.alight.cc.startanywhere.model.BaseResponse;
import com.alight.cc.startanywhere.model.ClientConfigError;
import com.alight.cc.startanywhere.repository.ClientAttributesRepository;
import com.alight.cc.startanywhere.repository.ClientMappingRepository;
import com.alight.cc.startanywhere.repository.ClientProfileRepository;
import com.alight.cc.startanywhere.repository.ClientRepository;
import com.alight.cc.startanywhere.service.RemoveClientService;
import com.alight.cc.startanywhere.util.ClientRetryable;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;
import com.alight.cc.startanywhere.util.StartAnywhereUtil;
import com.alight.logging.helpers.InfoTypeLogEventHelper;
import com.aonhewitt.logging.events.ErrorLogEvent;
import com.aonhewitt.logging.helpers.ErrorLogEventHelper;

import jakarta.persistence.PersistenceException;

@Service
public class RemoveClientServiceImpl implements RemoveClientService {

	@Autowired
	ClientRepository clientRepo;

	@Autowired
	ClientProfileRepository clientProfileRepo;

	@Autowired
	ClientAttributesRepository clientAttributesRepo;

	@Autowired
	ClientMappingRepository clientMappingRepo;

	@ClientRetryable
	@Transactional
	@Override
	public ResponseEntity<Object> deleteClientDetails(String alightColleagueSessionToken, String alightRequestHeader,
			String clientId) {
		// TODO Auto-generated method stub
		InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
				"Inside service layer of delete flow for  :" + clientId);
//create a generic response object
		BaseResponse response = new BaseResponse();
//		Create error array to which we will dynamically add errors in runtime
		List<ClientConfigError> errors = new ArrayList<>();
		try {
			ClientEntity entity = clientRepo.findByClientId(clientId);
//			Check if clientId is valid. If not return with HIGH error
			if (entity == null) {
				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
						"No client found for clientID: " + clientId);
				response = StartAnywhereUtil.buildResponse(response, StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
						StartAnyWhereConstants.BAD_REQUEST, StartAnyWhereConstants.POS112,
						StartAnyWhereConstants.DATA_DOES_NOT_EXISTS_IN_CLIENT_TBL, StartAnyWhereConstants.HIGH, null,
						errors);
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);

			}
			ClientProfileEntity profile = clientProfileRepo.findByControlCenterClientId(entity.getId());
//			check if profile exists for the client. If not add a LOW error to error array else delete the profiles
			if (profile == null) {
				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
						"No profile found for clientID: " + clientId);
				StartAnywhereUtil.buildResponse(response, StartAnyWhereConstants.HTTP_STATUS_SUCCESS,
						StartAnyWhereConstants.OK, StartAnyWhereConstants.POS113,
						StartAnyWhereConstants.DATA_DOES_NOT_EXISTS_IN_CLIENT_PROFILE_TBL, StartAnyWhereConstants.LOW,
						null, errors);
			} else {
				clientProfileRepo.deleteByControlCenterClientId(clientId);
				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
						"Client profile data deleted :" + clientId);

			}
			List<ClientMappingEntity> mappings = clientMappingRepo.findByControlCenterClientId(clientId);
//			check if mapping exists for the client. If not add a LOW error to error array else delete the mappings
			if (mappings == null || mappings.isEmpty()) {
				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
						"No mappings found for clientID: " + clientId);
				StartAnywhereUtil.buildResponse(response, StartAnyWhereConstants.HTTP_STATUS_SUCCESS,
						StartAnyWhereConstants.OK, StartAnyWhereConstants.POS115,
						StartAnyWhereConstants.DATA_DOES_NOT_EXISTS_IN_CLIENT_MAPPING_TBL, StartAnyWhereConstants.LOW,
						null, errors);
			} else {
				clientMappingRepo.deleteByControlCenterClientId(clientId);
				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
						"Client mapping data deleted :" + clientId);
//				Just to check rollback
//				throw new PersistenceException("Something went wrong in DB");

			}
			List<ClientAttributesEntity> attributes = clientAttributesRepo.findByControlCenterClientId(clientId);
//			check if attributes exists for the client. If not add a LOW error to error array else delete the attributes
			if (attributes == null || attributes.isEmpty()) {
				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
						"No attributes found for clientID: " + clientId);
				StartAnywhereUtil.buildResponse(response, StartAnyWhereConstants.HTTP_STATUS_SUCCESS,
						StartAnyWhereConstants.OK, StartAnyWhereConstants.POS114,
						StartAnyWhereConstants.DATA_DOES_NOT_EXISTS_IN_CLIENT_ATTRIBUTE_TBL, StartAnyWhereConstants.HIGH,
						null, errors);

			} else {
				clientAttributesRepo.deleteByControlCenterClientId(clientId);
				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
						"Client attribute data deleted :" + clientId);

			}
//		Once all the child table operations are done delete the parent tables entry
			clientRepo.deleteByClientId(clientId);
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
					"Client data deleted successfully:" + clientId);
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
					"Delete flow service layer ended:" + clientId);

			response.setResponseCode(StartAnyWhereConstants.HTTP_STATUS_SUCCESS);
			response.setResponseMessage(StartAnyWhereConstants.DELETED_STATUS);

			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (PersistenceException pe) {
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
					"Something went wrong in the persistance layer - rolling back and retrying:" + pe.getMessage());
			throw pe;

		}

	}

	@Recover
	public ResponseEntity<Object> handleRetryFailure(Exception ex, String alightColleagueSessionToken, String alightRequestHeader, String clientId) {
		ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
				"Retry exhausted for Add Client Details: " + ex.getMessage(), "recover", ex,
				ErrorLogEvent.ERROR_SEVERITY);

		BaseResponse response = new BaseResponse();
		List<ClientConfigError> errors = new ArrayList<>();
		response = StartAnywhereUtil.buildResponse(new BaseResponse(),
				StartAnyWhereConstants.HTTP_STATUS_SERVICE_UNAVAILABLE, StartAnyWhereConstants.DB_UNREACHABLE,
				StartAnyWhereConstants.POS101, StartAnyWhereConstants.MSGFOR_POS101, StartAnyWhereConstants.HIGH,
				null, errors);

		return new ResponseEntity<Object>(response, HttpStatus.SERVICE_UNAVAILABLE);
	}

}
