package com.alight.cc.startanywhere.util;
import feign.FeignException;
import org.springframework.stereotype.Component;

@Component("retryHelper")
public class FeignRetryHelper {
    public boolean is5xx(Throwable throwable) {
        if (throwable instanceof FeignException) {
            int status = ((FeignException) throwable).status();
            return status >= 500 && status < 600;
        }
        return false;
    }
}