package com.alight.cc.startanywhere.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import com.alight.cc.startanywhere.entity.ClientAttributesEntity;
import com.alight.cc.startanywhere.entity.ClientEntity;
import com.alight.cc.startanywhere.entity.ClientMappingEntity;
import com.alight.cc.startanywhere.entity.ClientProfileEntity;
import com.alight.cc.startanywhere.model.ClientConfigError;
import com.alight.cc.startanywhere.model.ClientResponse;
import com.alight.cc.startanywhere.repository.AttributeRestrictionLookupRepository;
import com.alight.cc.startanywhere.repository.AttributeTypeLookupRepository;
import com.alight.cc.startanywhere.repository.ClientAttributesRepository;
import com.alight.cc.startanywhere.repository.ClientMappingRepository;
import com.alight.cc.startanywhere.repository.ClientProfileRepository;
import com.alight.cc.startanywhere.repository.ClientRepository;
import com.alight.cc.startanywhere.service.ClientDataRetrievalService;
import com.alight.cc.startanywhere.util.ClientRetryable;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;
import com.alight.cc.startanywhere.util.StartAnywhereUtil;
import com.alight.logging.helpers.InfoTypeLogEventHelper;
import com.aonhewitt.logging.events.ErrorLogEvent;
import com.aonhewitt.logging.helpers.ErrorLogEventHelper;


@Service
public class ClientDataRetrievalServiceImpl implements ClientDataRetrievalService {

	@Autowired
	private ClientRepository clientRepo;

	@Autowired 
	private ClientAttributesRepository clientAttributesRepo;

	@Autowired
	private ClientMappingRepository clientMappingRepo;

	@Autowired
	private ClientProfileRepository clientProfileRepo;

	@Autowired
	AttributeRestrictionLookupRepository attributeRestrictionLookupRepo;

	@Autowired
	AttributeTypeLookupRepository attributeTypeLookupRepo;


	@ClientRetryable
	public ClientResponse getClientData(String token, String header, String clientID) {
        InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
                "Started executing getClientData service with clientID: " + clientID );
        ClientResponse clientResponse = new ClientResponse();
        List<ClientConfigError> errors = new ArrayList<>();
        try {
            ClientEntity client = clientRepo.findByClientId(clientID);
            if (client == null) {
                InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
                        "No client found for clientID: " + clientID );
                return StartAnywhereUtil.buildResponse(
                		clientResponse,
                		StartAnyWhereConstants.HTTP_STATUS_SUCCESS,
                        StartAnyWhereConstants.OK,
                        StartAnyWhereConstants.POS104,
                        StartAnyWhereConstants.CLIENT_DOESNT_EXIST_IN_POSTGRES_DB,
                        StartAnyWhereConstants.HIGH,
                        null,
                        errors
                ); 
            }

            clientResponse.setClientName(client.getName());
            clientResponse.setOrgName(client.getOrgName());

            ClientProfileEntity profile = clientProfileRepo.findByControlCenterClientId(client.getId());
            if (profile == null || profile.getAttributeTypeLookup() == null) {
                InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
                        "No profile found for clientID: " + clientID);
                 StartAnywhereUtil.buildResponse(
                		clientResponse,
                		StartAnyWhereConstants.HTTP_STATUS_SUCCESS,
                        StartAnyWhereConstants.OK,
                        StartAnyWhereConstants.POS108,
                        StartAnyWhereConstants.CLIENT_PROFILE_DOESNT_EXIST_IN_POSTGRES_DB,
                        StartAnyWhereConstants.HIGH,
                        null,
                        errors
                );
			} else {

				boolean isDataRestriction = "Y"
						.equalsIgnoreCase(Optional.ofNullable(profile.getAttributeTypeLookup().getKey()).orElse("N"));
				clientResponse.setIsDataRestriction(isDataRestriction);
			}

            List<ClientAttributesEntity> attributes= clientAttributesRepo.findByControlCenterClientId(clientID);
            if (attributes.isEmpty()) {
                InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
                        "No attributes found for clientID: " + clientID);
                 StartAnywhereUtil.buildResponse(
                		clientResponse,
                		StartAnyWhereConstants.HTTP_STATUS_SUCCESS,
                        StartAnyWhereConstants.OK,
                        StartAnyWhereConstants.POS109,
                        StartAnyWhereConstants.CLIENT_ATTRIBUTES_DONT_EXIST_IN_POSTGRES_DB,
                        StartAnyWhereConstants.HIGH,
                        null,
                        errors
                );
                
            }else {

            attributes.stream()
                    .filter(attr -> attr.getAttributeRestrictionLookup() != null
                            && attr.getAttributeTypeLookup() != null
                            && (List.of("Location-User-PII", "Reason")
                            .contains(attr.getAttributeRestrictionLookup().getKey())))
                    .forEach(attr -> {
                        if ("Location-User-PII".equalsIgnoreCase(attr.getAttributeRestrictionLookup().getKey())) {
                            boolean isLocationUserPII = "Y".equalsIgnoreCase(attr.getAttributeTypeLookup().getKey());
                            clientResponse.setLocationUserPII(isLocationUserPII);
                        } else if ("reason".equalsIgnoreCase(attr.getAttributeRestrictionLookup().getKey())) {
                            clientResponse.setReason(attr.getAttributeTypeLookup().getKey());
                        }
                    });
            }
            List<ClientMappingEntity> mappings = clientMappingRepo.findByControlCenterClientId(clientID);
            if (mappings.isEmpty()) {
                InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
                        "No mappings found for clientID: " + clientID);
                 StartAnywhereUtil.buildResponse(
                		clientResponse,
                		StartAnyWhereConstants.HTTP_STATUS_SUCCESS,
                        StartAnyWhereConstants.OK,
                        StartAnyWhereConstants.POS110,
                        StartAnyWhereConstants.CLIENT_MAPPINGS_DONT_EXIST_IN_POSTGRES_DB,
                        StartAnyWhereConstants.HIGH,
                        null,
                        errors
                );
            }

            Optional<String> validScrmId = Optional.ofNullable(mappings).orElse(List.of()).stream()
            	    .map(ClientMappingEntity::getScrmId)
            	    .filter(id -> id != null && !id.isBlank())
            	    .findFirst();


            if (validScrmId.isPresent()) {
                clientResponse.setScrmId(validScrmId.get());
            } else {
                InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
                        "No valid SCRM ID found for clientID: " + clientID);
                 StartAnywhereUtil.buildResponse(
                		clientResponse,
                		StartAnyWhereConstants.HTTP_STATUS_SUCCESS,
                        StartAnyWhereConstants.OK,
                        StartAnyWhereConstants.POS111,
                        StartAnyWhereConstants.CLIENT_SCRMID_DONT_EXIST_IN_POSTGRES_DB,
                        StartAnyWhereConstants.HIGH,
                        null,
                        errors
                );

            }


        } catch (Exception e) {
            ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
                    "Exception occurred during DB operations: " + e.getMessage(),
                    "getClientData", e, ErrorLogEvent.ERROR_SEVERITY);
           
            return StartAnywhereUtil.buildResponse(
            		new ClientResponse() ,
                    StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR,
                    StartAnyWhereConstants.INTERNAL_SERVER_ERROR,
                    StartAnyWhereConstants.POS101,
                    StartAnyWhereConstants.MSGFOR_POS101,
                    StartAnyWhereConstants.HIGH,
                    null,
                    errors
            );
            
        }

        InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
                "Completed executing getClientData service for clientID: " + clientID);
        return clientResponse;
    }

	
    @Recover
    public ClientResponse handleRetryFailure(Exception ex, String token, String header, String clientID) {
        ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
            "Retry exhausted for getClientData: " + ex.getMessage(), "recover", ex, ErrorLogEvent.ERROR_SEVERITY);
        List<ClientConfigError> errors = new ArrayList<>();
        return StartAnywhereUtil.buildResponse(
                new ClientResponse(),
                StartAnyWhereConstants.HTTP_STATUS_SERVICE_UNAVAILABLE,
                StartAnyWhereConstants.DB_UNREACHABLE,
                StartAnyWhereConstants.POS101,
                StartAnyWhereConstants.MSGFOR_POS101,
                StartAnyWhereConstants.HIGH,
                null,
                errors
        );

    }

    
}