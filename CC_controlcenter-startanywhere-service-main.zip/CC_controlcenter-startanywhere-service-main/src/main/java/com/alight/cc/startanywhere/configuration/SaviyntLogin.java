package com.alight.cc.startanywhere.configuration;

import java.io.IOException;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.alight.cc.startanywhere.saviynt.model.LoginData;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;
import com.alight.cloud.data.store.util.DockerSecretsUtil;
import com.alight.logging.helpers.InfoTypeLogEventHelper;
import com.aonhewitt.exceptions.AHBaseException;
import com.aonhewitt.logging.events.ErrorLogEvent;
import com.aonhewitt.logging.helpers.ErrorLogEventHelper;

import jakarta.annotation.PostConstruct;
import lombok.Data;
@Data
@Component
public class SaviyntLogin {

    private static final String USERNAME_KEY = "controlcenter.startanywhere.saviynt.username";
    private static final String PASSWORD_KEY = "controlcenter.startanywhere.saviynt.password";
    

    @Value("${spring.profiles.active}")
    private String profile;

    private LoginData loginData;

    public LoginData getLoginData() {
        if (loginData == null) {
            this.loginData = loadLoginData();
        }
        return loginData;
    }

    @PostConstruct
    public void init() {
        this.loginData = loadLoginData();
    }
    public LoginData getFreshLoginData() {
        return loadLoginData(); // bypasses cache
    }
    LoginData loadLoginData() {
        LoginData loginData = new LoginData();
        String userName = null;
        String password = null;
        try {
        Map<String, String> dockerSecrets = DockerSecretsUtil.load();
        
        InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
        		"docker secrets not recived:"+"User name not found>>>>"+dockerSecrets.get(USERNAME_KEY)+"password not found>>>"+dockerSecrets.get(PASSWORD_KEY));
        if (!dockerSecrets.isEmpty()) {
        if (dockerSecrets.containsKey(USERNAME_KEY)) {
            userName = dockerSecrets.get(USERNAME_KEY);
            loginData.setUsername(userName.trim());
        } else {
            if (!"localdev".equalsIgnoreCase(profile)) {
                ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), USERNAME_KEY + " is not configured in secret",
                        "getSaviyntLogin", new AHBaseException(), ErrorLogEvent.ERROR_SEVERITY);
            }
        }
        if (dockerSecrets.containsKey(PASSWORD_KEY)) {
            password = dockerSecrets.get(PASSWORD_KEY);
            loginData.setPassword(password.trim());
        } else {
            if (!"localdev".equalsIgnoreCase(profile)) {
                ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), PASSWORD_KEY + " is not configured in secret",
                        "getSaviyntLogin", new AHBaseException(), ErrorLogEvent.ERROR_SEVERITY);
            }
        }
        }
        }
        catch (Exception ex) {
        	InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
            		"docker secrets not recived:"+"User name not found>>>>password not found>>>");
        	ex.printStackTrace();
        }
        if (userName != null && password != null) {
            return loginData;
        } else {
            return null;
        }      
    }
}