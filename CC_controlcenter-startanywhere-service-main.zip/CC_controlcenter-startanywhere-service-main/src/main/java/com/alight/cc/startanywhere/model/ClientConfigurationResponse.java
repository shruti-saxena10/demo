package com.alight.cc.startanywhere.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY) 
@JsonPropertyOrder({ "responseCode", "responseMessage","clientName", "orgName", "isDataRestriction","locationUserPII","reason","scrmId","securityManagers", "errors" })
public class ClientConfigurationResponse extends BaseResponse {
	private String clientName;
    private String orgName;
    private Boolean isDataRestriction;
    private Boolean locationUserPII;
    private String reason;
    private String scrmId; 
    private List<SecurityManagerResponse> securityManagers;
}
