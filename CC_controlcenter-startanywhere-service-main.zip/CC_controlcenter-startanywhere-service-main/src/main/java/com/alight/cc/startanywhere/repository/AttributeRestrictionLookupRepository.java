package com.alight.cc.startanywhere.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.alight.cc.startanywhere.entity.AttributeRestrictionLookupEntity;

@Repository
public interface AttributeRestrictionLookupRepository extends JpaRepository<AttributeRestrictionLookupEntity, Long> {

	Optional<AttributeRestrictionLookupEntity> findByKey(String key);
	
	 List<AttributeRestrictionLookupEntity> findAll();
}
