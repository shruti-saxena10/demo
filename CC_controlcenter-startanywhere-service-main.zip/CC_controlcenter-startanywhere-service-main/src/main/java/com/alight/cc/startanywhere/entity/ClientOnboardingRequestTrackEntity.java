package com.alight.cc.startanywhere.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "clientonboarding_request_track")
@Data
public class ClientOnboardingRequestTrackEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
	@Column(name = "correlation_id")
	private String correlationId;
	@Column(name = "input_json")
//	@Lob
	private String inputJson;
	@Column(name = "request_started_at")
	private Date requestStartedAt;
	@Column(name = "errors")
//	@Lob
	private String errors;
	@Column(name = "status")
	private int status;
	@Column(name ="client_id")
	private String clientId;
	@Column(name ="request_completed_at")
	private Date requestCompletedAt;
	@Column(name ="api_name")
	private String apiName;
	@Column(name ="hit_count")
	private int hitCount;
	@Column(name ="output")
	private String output;
}
