package com.alight.cc.startanywhere.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SecurityManagerResponse {
    private String securityManageEmailId;
    private String securityManageAID;
    private List<EntitlementResponse> entitlements;
}
