package com.alight.cc.startanywhere.exception;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.HandlerMethodValidationException;

import com.alight.cc.startanywhere.model.BaseResponse;
import com.alight.cc.startanywhere.model.ClientConfigError;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;
import com.alight.cc.startanywhere.util.StartAnywhereUtil;
import com.aonhewitt.logging.events.ErrorLogEvent;
import com.aonhewitt.logging.helpers.ErrorLogEventHelper;
import com.fasterxml.jackson.databind.JsonMappingException;

import jakarta.validation.ConstraintViolationException;

@RestControllerAdvice
public class GlobalExceptionHandler {


    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<?> handleValidationException(MethodArgumentNotValidException ex) {

        List<ClientConfigError> errors = new ArrayList<>();
        String errorMessage = ex.getBindingResult().getFieldError().getDefaultMessage();
        
        BaseResponse response = StartAnywhereUtil.buildResponse(
            new BaseResponse(),
            StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
            StartAnyWhereConstants.BAD_REQUEST,
            StartAnyWhereConstants.POS106,
            errorMessage,
            StartAnyWhereConstants.HIGH,
            null,
            errors
        );
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(response);
    }

    @ExceptionHandler(MissingServletRequestParameterException.class)
    public ResponseEntity<?> missingRequestParameterException(MissingServletRequestParameterException ex) {
        List<ClientConfigError> errors = new ArrayList<>();
        String errorMessage = StartAnyWhereConstants.MSGFOR_POS106;
        BaseResponse response = StartAnywhereUtil.buildResponse(
            new BaseResponse(),
            StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
            StartAnyWhereConstants.BAD_REQUEST,
            StartAnyWhereConstants.POS106,
            errorMessage,
            StartAnyWhereConstants.HIGH,
            null,
            errors
        );
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(response);
    }

    @ExceptionHandler(HandlerMethodValidationException.class)
    public ResponseEntity<?> handlerMethodValidationException(HandlerMethodValidationException ex) {
        List<ClientConfigError> errors = new ArrayList<>();
        String errorMessage = StartAnyWhereConstants.MSGFOR_POS106;
        BaseResponse response = StartAnywhereUtil.buildResponse(
            new BaseResponse(),
            StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
            StartAnyWhereConstants.BAD_REQUEST,
            StartAnyWhereConstants.POS106,
            errorMessage,
            StartAnyWhereConstants.HIGH,
            null,
            errors
        );
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(response);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Object> handleJsonParseError(HttpMessageNotReadableException ex) {
        String fieldName = null;
        Throwable cause = ex.getCause();
        if (cause instanceof JsonMappingException) {
            JsonMappingException jme = (JsonMappingException) cause;
            if (!jme.getPath().isEmpty()) {
                fieldName = jme.getPath().get(0).getFieldName();
            }
        }
        String message;
        if (fieldName != null) {
            message = String.format("Invalid value for field '%s'. Please provide a valid value.", fieldName);
        } else {
            message = "Invalid input provided. Please check your request payload.";
        }
        
    	 List<ClientConfigError> errors = new ArrayList<>();
         BaseResponse response = StartAnywhereUtil.buildResponse(
             new BaseResponse(),
             StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
             StartAnyWhereConstants.BAD_REQUEST,
             StartAnyWhereConstants.POS106,
             message,
             StartAnyWhereConstants.HIGH,
             null,
             errors
         );
         return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
         
    }
    
    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<?> handleConstraintViolation(ConstraintViolationException ex) {
        List<ClientConfigError> errors = new ArrayList<>();

        String rawMessage = ex.getMessage();
        String finalMessage;

        // Attempt to extract the most meaningful part dynamically
        if (rawMessage != null) {
            // Split by colon and take the last segment (most specific message)
            String[] parts = rawMessage.split(":");
            finalMessage = parts[parts.length - 1].trim();

            // Optional: further clean up if message contains nested structure
            if (finalMessage.contains(",")) {
                finalMessage = finalMessage.substring(0, finalMessage.indexOf(",")).trim();
            }
        } else {
            finalMessage = "Invalid input";
        }

        BaseResponse response = StartAnywhereUtil.buildResponse(
            new BaseResponse(),
            StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
            StartAnyWhereConstants.BAD_REQUEST,
            StartAnyWhereConstants.POS106,
            finalMessage,
            StartAnyWhereConstants.HIGH,
            null,
            errors
        );

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
    }
  
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> handleException(Exception ex) {
        List<ClientConfigError> errors = new ArrayList<>();
        
        BaseResponse response = StartAnywhereUtil.buildResponse(
            new BaseResponse(),
            StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR,
            StartAnyWhereConstants.INTERNAL_SERVER_ERROR,
            StartAnyWhereConstants.POS107,
            StartAnyWhereConstants.UNEXPECTED_ERROR_MESSAGE,
            StartAnyWhereConstants.HIGH,
            null,
            errors
        );
        ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
                "Exception while hiting the endpoint",
                "getClientDetails()", ex, ErrorLogEvent.ERROR_SEVERITY);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
    }
    
}
