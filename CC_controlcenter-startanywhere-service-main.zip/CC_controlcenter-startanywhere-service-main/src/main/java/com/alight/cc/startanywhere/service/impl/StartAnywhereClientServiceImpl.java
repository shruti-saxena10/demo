package com.alight.cc.startanywhere.service.impl;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.commons.lang3.StringUtils;
import org.postgresql.util.PSQLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Recover;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alight.asg.model.header.v1_0.RequestHeader;
import com.alight.asg.model.token.v1_0.ColleagueSessionToken;
import com.alight.cc.startanywhere.entity.AttributeRestrictionLookupEntity;
import com.alight.cc.startanywhere.entity.AttributeTypeLookupEntity;
import com.alight.cc.startanywhere.entity.ClientAttributesEntity;
import com.alight.cc.startanywhere.entity.ClientEntity;
import com.alight.cc.startanywhere.entity.ClientMappingEntity;
import com.alight.cc.startanywhere.entity.ClientProfileEntity;
import com.alight.cc.startanywhere.exception.DuplicateClientException;
import com.alight.cc.startanywhere.model.BaseResponse;
import com.alight.cc.startanywhere.model.ClientConfigError;
import com.alight.cc.startanywhere.model.ClientModel;
import com.alight.cc.startanywhere.model.ClientResponse;
import com.alight.cc.startanywhere.repository.AttributeRestrictionLookupRepository;
import com.alight.cc.startanywhere.repository.AttributeTypeLookupRepository;
import com.alight.cc.startanywhere.repository.ClientAttributesRepository;
import com.alight.cc.startanywhere.repository.ClientMappingRepository;
import com.alight.cc.startanywhere.repository.ClientProfileRepository;
import com.alight.cc.startanywhere.repository.ClientRepository;
import com.alight.cc.startanywhere.service.StartAnywhereClientService;
import com.alight.cc.startanywhere.util.ClientRetryable;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;
import com.alight.cc.startanywhere.util.StartAnywhereSecurityUtil;
import com.alight.cc.startanywhere.util.StartAnywhereUtil;
import com.alight.logging.helpers.InfoTypeLogEventHelper;
import com.aonhewitt.logging.events.ErrorLogEvent;
import com.aonhewitt.logging.helpers.ErrorLogEventHelper;
import com.fasterxml.jackson.core.JsonProcessingException;

@Service
public class StartAnywhereClientServiceImpl implements StartAnywhereClientService {

	@Autowired
	 ClientRepository clientRepo;

	@Autowired 
	private ClientAttributesRepository clientAttributesRepo;

	@Autowired
	private ClientMappingRepository clientMappingRepo;

	@Autowired
	private ClientProfileRepository clientProfileRepo;

	@Autowired
	AttributeRestrictionLookupRepository attributeRestrictionLookupRepo;

	@Autowired
	AttributeTypeLookupRepository attributeTypeLookupRepo;

	 @ClientRetryable
	 @Transactional
	 @Override
	public ResponseEntity<Object> addNewclientdetails(String alightColleagueSessionToken, String alightRequestHeader,
			String ColleagueEmailId,ClientModel request) throws JsonProcessingException, IOException, PSQLException {
		InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Method execution Started in service layer: "+request);
		BaseResponse response = new BaseResponse();
		List<ClientConfigError> errors = new ArrayList<>();
		ClientEntity client = new ClientEntity();
		ClientProfileEntity clientProfileEntity = new ClientProfileEntity();
		ClientMappingEntity clientMappingEntity = new ClientMappingEntity();

		List<AttributeTypeLookupEntity> attributeLookupEntityList = new ArrayList<>();
		List<AttributeRestrictionLookupEntity> attribRestrictEntityList = new ArrayList<>();
		String message = null;
		DuplicateClientException ex = null;

		alightRequestHeader = StartAnywhereSecurityUtil.unCleanIt(alightRequestHeader);
		
		if (StringUtils.isBlank(alightColleagueSessionToken) || StringUtils.isBlank(alightRequestHeader)) {	
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Missing required parameters alightColleagueSessionToken or alightRequestHeader." );

			 response=StartAnywhereUtil.buildResponse(
		        		new BaseResponse(),
		        		StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
		             StartAnyWhereConstants.BAD_REQUEST,
		             StartAnyWhereConstants.POS106,
		             StartAnyWhereConstants.MISSING_REQUIRED_PARAMETERS_MESSAGE,
		             StartAnyWhereConstants.HIGH,
		             null,
		             errors
		     );
			return ResponseEntity.status(HttpStatus.BAD_REQUEST)
					.body(response);

		}
		
		if (StringUtils.isBlank(ColleagueEmailId)) {
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Missing required parameters ColleagueEmailId" +ColleagueEmailId );

			 response=StartAnywhereUtil.buildResponse(
		        		new BaseResponse(),
		        		StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
		             StartAnyWhereConstants.BAD_REQUEST,
		             StartAnyWhereConstants.POS106,
		             StartAnyWhereConstants.MISSING_REQUIRED_PARAMETERS_EMAILD_MESSAGE,
		             StartAnyWhereConstants.HIGH,
		             null,
		             errors
		     );
			return ResponseEntity.status(HttpStatus.BAD_REQUEST)
					.body(response);

		}


		RequestHeader parsedRequestHeader = RequestHeader.parse(alightRequestHeader);
		String locale_code = parsedRequestHeader.getLocale();
		if (StringUtils.isBlank(locale_code)) {
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Missing required parameters alightColleagueSessionToken or alightRequestHeader.");

			 response=StartAnywhereUtil.buildResponse(
		        		new BaseResponse(),
		        		StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
		             StartAnyWhereConstants.BAD_REQUEST,
		             StartAnyWhereConstants.POS106,
		             StartAnyWhereConstants.MISSING_REQUIRED_PARAMETERS_MESSAGE,
		             StartAnyWhereConstants.HIGH,
		             null,
		             errors
		     );
			return ResponseEntity.status(HttpStatus.BAD_REQUEST)
					.body(response);

		}
			String lineage ="primary.clientId="+request.getClientId();
			try {

				LocalDateTime now = LocalDateTime.now();
				Date date = Date.from(now.atZone(ZoneId.systemDefault()).toInstant());

				attribRestrictEntityList = attributeRestrictionLookupRepo.findAll();
				attributeLookupEntityList = attributeTypeLookupRepo.findAll();
					
				ClientEntity entityClientId = clientRepo.findByClientIdIgnoreCase(request.getClientId());
				ClientEntity entityOrgName =clientRepo.findByOrgNameIgnoreCase(request.getOrgName());
				boolean exists = clientRepo.existsByNameIgnoreCase(request.getClientName());
				if (exists) {
					message = String.format(StartAnyWhereConstants.CLIENT_NAME_EXISTS_MESSAGE, 
							request.getClientName());

					InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Duplicate clientName: " + message);
					ex = new DuplicateClientException(message);

					response = StartAnywhereUtil.buildResponse(
							new BaseResponse(),
							StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
							StartAnyWhereConstants.BAD_REQUEST,
							StartAnyWhereConstants.POS103,
							ex.getMessage(),
							StartAnyWhereConstants.HIGH,
							null,
							errors
							);

					return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);

				} 
				if ((entityClientId != null && entityOrgName != null) ||
					    (entityClientId == null && entityOrgName != null) ||
					    (entityClientId != null && entityOrgName == null)) {

					    message = String.format(StartAnyWhereConstants.CLIENT_ALREADY_EXISTS_MESSAGE, 
					                            request.getClientId(), request.getOrgName());

					    InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Duplicate client: " + message);
					    ex = new DuplicateClientException(message);

					    response = StartAnywhereUtil.buildResponse(
					                   new BaseResponse(),
					                   StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
					                   StartAnyWhereConstants.BAD_REQUEST,
					                   StartAnyWhereConstants.POS103,
					                   ex.getMessage(),
					                   StartAnyWhereConstants.HIGH,
					                   null,
					                   errors
					               );

					    return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
					}
                    else {
					//client Details
					InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), " Inserting new ClientEntity record: " + request.getClientId());
					client.setClientId(request.getClientId());
					client.setName(request.getClientName());
					client.setEnvironmentId(1L);
					client.setCreatedAt(date);
					client.setUpdatedAt(date);
					client.setScrmId(request.getClientId());
					client.setOrgName(request.getOrgName());
					client.setLegalName(request.getClientName());
					client.setLineage(lineage);
					client.setSuperviewRestrict(request.getIsDataRestriction());
					ClientEntity savedClient = clientRepo.save(client);
					InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
							"ClientEntity data added successfully:" + request.getClientId());

					if(savedClient!=null) {
						//clientProfileEntity Details
						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Inserting new ClientProfileEntity record: "+request.getClientId());
						clientProfileEntity.setClient(savedClient);
						for(AttributeTypeLookupEntity lookupEntity:attributeLookupEntityList ) {
							if (StartAnyWhereConstants.YES.equalsIgnoreCase(lookupEntity.getKey()) && Boolean.TRUE.equals(request.getIsDataRestriction())) {

								clientProfileEntity.setAttributeTypeLookup(lookupEntity);
							} else if((StartAnyWhereConstants.NO.equalsIgnoreCase(lookupEntity.getKey())) && Boolean.FALSE.equals(request.getIsDataRestriction())) {
								clientProfileEntity.setAttributeTypeLookup(lookupEntity);
							}
						}
						clientProfileEntity.setCreatedAt(date);
						clientProfileEntity.setCreatedBy(ColleagueEmailId);
						clientProfileEntity.setUpdatedAt(date);
						clientProfileEntity.setUpdatedBy(ColleagueEmailId);
						clientProfileRepo.save(clientProfileEntity);
						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
								"ClientProfileEntity data added successfully:" + request.getClientId());

						//clientMappingEntity Details
						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Inserting new ClientMappingEntity record: "+request.getClientId());
						clientMappingEntity.setClient(savedClient);
						clientMappingEntity.setUdpNormalizedClientId(request.getClientId());
						clientMappingEntity.setLiferayOrgId(request.getOrgName());
						clientMappingEntity.setScrmId(request.getClientId());
						clientMappingEntity.setCloudCmsProjectId(request.getClientId());
						clientMappingEntity.setAssistGcc("");
						clientMappingEntity.setCreatedAt(date);
						clientMappingEntity.setCreatedBy(ColleagueEmailId);
						clientMappingEntity.setUpdatedAt(date);
						clientMappingEntity.setUpdatedBy(ColleagueEmailId); 
						clientMappingRepo.save(clientMappingEntity);
						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
								"ClientMappingEntity data added successfully:" + request.getClientId());

						//clientAttributesEntity Details
						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Inserting new ClientAttributesEntity record: "+request.getClientId());
						int index = request.getIsDataRestriction() ? 0 : 1;
						
						for (AttributeRestrictionLookupEntity Res : attribRestrictEntityList.subList(0, attribRestrictEntityList.size() - 1)) { 
							List<AttributeTypeLookupEntity> attriLookupEntityStringList =IntStream.range(0, 2)
								    .mapToObj(attributeLookupEntityList::get)
								    .collect(Collectors.toList());

							for (AttributeTypeLookupEntity lookup : Collections.singletonList(attriLookupEntityStringList.get(index))) {
								ClientAttributesEntity clientAttributesEntity = new ClientAttributesEntity();
								clientAttributesEntity.setClient(savedClient);
								clientAttributesEntity.setAttributeRestrictionLookup(Res);
								
								if (Boolean.TRUE.equals(request.getIsDataRestriction())) {  
									clientAttributesEntity.setAttributeTypeLookup(lookup);
								} else if (Boolean.FALSE.equals(request.getIsDataRestriction())) {
									clientAttributesEntity.setAttributeTypeLookup(lookup);
								} 								
								boolean isSmartLaunchDefault = 
									    StartAnyWhereConstants.YES.equalsIgnoreCase(lookup.getKey()) &&
									    Boolean.TRUE.equals(request.getIsDataRestriction());

									clientAttributesEntity.setComment(
									    isSmartLaunchDefault
									        ? StartAnyWhereConstants.SMARTLAUNCH_DEFAULT
									        : StartAnyWhereConstants.SMARTLAUNCH_BLANK
									);

								clientAttributesEntity.setCreatedAt(date);
								clientAttributesEntity.setCreatedBy(ColleagueEmailId);
								clientAttributesEntity.setUpdatedAt(date);
								clientAttributesEntity.setUpdatedBy(ColleagueEmailId);

								clientAttributesRepo.save(clientAttributesEntity);
							}
						}

						for (AttributeRestrictionLookupEntity Res : attribRestrictEntityList.subList(attribRestrictEntityList.size() - 1, attribRestrictEntityList.size())) { 
							List<AttributeTypeLookupEntity> attriLookupEntityList  =attributeLookupEntityList.subList(attributeLookupEntityList.size() - 2, attributeLookupEntityList.size());

							for (AttributeTypeLookupEntity lookup : Collections.singletonList(attriLookupEntityList.get(index))) {
								ClientAttributesEntity clientAttributesEntity = new ClientAttributesEntity();
								clientAttributesEntity.setClient(savedClient);
								clientAttributesEntity.setAttributeRestrictionLookup(Res);

								if (Boolean.TRUE.equals(request.getIsDataRestriction())) {  
									clientAttributesEntity.setAttributeTypeLookup(lookup);
								} else if (Boolean.FALSE.equals(request.getIsDataRestriction())) {
									clientAttributesEntity.setAttributeTypeLookup(lookup);
								} 
								if (StartAnyWhereConstants.SMARTLAUNCH_DEFAULT.equalsIgnoreCase(lookup.getKey()) && Boolean.TRUE.equals(request.getIsDataRestriction())) {
									clientAttributesEntity.setComment(StartAnyWhereConstants.SMARTLAUNCH_DEFAULT);
								} else if(StartAnyWhereConstants.SMARTLAUNCH_BLANK.equalsIgnoreCase(lookup.getKey()) && Boolean.FALSE.equals(request.getIsDataRestriction())) {
									clientAttributesEntity.setComment(StartAnyWhereConstants.SMARTLAUNCH_BLANK);
								}
								clientAttributesEntity.setCreatedAt(date);
								clientAttributesEntity.setCreatedBy(ColleagueEmailId);
								clientAttributesEntity.setUpdatedAt(date);
								clientAttributesEntity.setUpdatedBy(ColleagueEmailId);

								clientAttributesRepo.save(clientAttributesEntity);
							}
						}

						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
								"ClientAttributesRepo data added successfully:" + request.getClientId());
					}

					InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Method execution Ended in service layer: "+request.getClientId());
					response.setResponseCode(StartAnyWhereConstants.POS201);
					response.setResponseMessage(StartAnyWhereConstants.SAVED_STATUS);
					return new ResponseEntity<Object>(response, HttpStatus.CREATED);
				} 

			}
			catch (Exception e) {
				ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), "Exception occurred while adding ClientDetails to PostgreSQL: ",
						"", e, ErrorLogEvent.ERROR_SEVERITY);
				
				 response=StartAnywhereUtil.buildResponse(
			        		new BaseResponse(),
			        		StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR,
			             StartAnyWhereConstants.INTERNAL_SERVER_ERROR,
			             StartAnyWhereConstants.POS500,
			             e.getClass().getSimpleName() + ": " + e.getMessage(),
			             StartAnyWhereConstants.HIGH,
			             null,
			             errors
			     );
	
				 return new ResponseEntity<Object>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
	}

	 @Recover
	    public ResponseEntity<Object> handleRetryFailure(Exception ex, String alightColleagueSessionToken, String alightRequestHeader,
				ClientModel request) {
	        ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
	            "Retry attempts exhausted while adding ClientDetails to PostgreSQL: " + ex.getMessage(), "recover", ex, ErrorLogEvent.ERROR_SEVERITY);

	        BaseResponse response = new BaseResponse();
	        List<ClientConfigError> errors = new ArrayList<>();
	        response= StartAnywhereUtil.buildResponse(
	        		response,
	                StartAnyWhereConstants.HTTP_STATUS_SERVICE_UNAVAILABLE,
	                StartAnyWhereConstants.DB_UNREACHABLE,
	                StartAnyWhereConstants.POS101,
	                StartAnyWhereConstants.MSGFOR_POS101,
	                StartAnyWhereConstants.HIGH,
	                null,
	                errors
	        );
	       
	        return new ResponseEntity<Object>(response, HttpStatus.SERVICE_UNAVAILABLE);
	    }

}
