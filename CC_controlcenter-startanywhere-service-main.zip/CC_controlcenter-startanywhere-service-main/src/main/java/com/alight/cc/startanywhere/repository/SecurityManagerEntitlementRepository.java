package com.alight.cc.startanywhere.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.alight.cc.startanywhere.entity.SecurityManagerEntitlementEntity;

@Repository
public interface SecurityManagerEntitlementRepository extends JpaRepository<SecurityManagerEntitlementEntity, Long>{
	List<SecurityManagerEntitlementEntity> findByIsSecuritymanager(Integer isSecuritymanager);

}