package com.alight.cc.startanywhere.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alight.asg.model.header.v1_0.RequestHeader;
import com.alight.cc.startanywhere.configuration.SaviyntConfigurationBean;
import com.alight.cc.startanywhere.entity.ClientOnboardingRequestTrackEntity;
import com.alight.cc.startanywhere.feign.SaviyntClient;
import com.alight.cc.startanywhere.model.ClientConfigError;
import com.alight.cc.startanywhere.model.CreateGroupsResponse;
import com.alight.cc.startanywhere.repository.ClientOnboardingRequestTrackRepository;
import com.alight.cc.startanywhere.repository.SecurityManagerEntitlementRepository;
import com.alight.cc.startanywhere.service.ClientOnboardingRequestTrackService;
import com.alight.cc.startanywhere.service.GroupService;
import com.alight.cc.startanywhere.service.UserService;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;
import com.alight.cc.startanywhere.util.StartAnywhereSecurityUtil;
import com.alight.cc.startanywhere.util.StartAnywhereUtil;
import com.alight.logging.helpers.InfoTypeLogEventHelper;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.micrometer.common.util.StringUtils;

@Service
public class GroupServiceImpl implements GroupService {
	@Autowired
	ClientOnboardingRequestTrackRepository trackRepo;
	@Autowired
	SaviyntConfigurationBean configBean;
	
    
    @Autowired
	SaviyntClient saviyntClient;

	@Autowired
	UserService userService;
	
	@Autowired
	ClientOnboardingRequestTrackService clientOnboardingRequestTrackService;
	@Autowired
	AsyncGroupServiceImpl asyncGroupServiceImpl;
	
	JSONParser parser = new JSONParser();
	
	
	public CreateGroupsResponse checkValidationBeforeAsync(String sessionToken, String requestHeader, String clientId,
			String clientName) {
		InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
				"Start executing checkValidationBeforeAsync service with clientID: " + clientId);
		
		CreateGroupsResponse createGroupsResponse = new CreateGroupsResponse();
		List<ClientConfigError> errors = new ArrayList<>();
		try {
			requestHeader = StartAnywhereSecurityUtil.unCleanIt(requestHeader);
		    RequestHeader parsedRequestHeader = RequestHeader.parse(requestHeader);
		    String correlationId = parsedRequestHeader.getCorrelationId();
				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Correlation ID is : "+correlationId);
		    if(StringUtils.isEmpty(correlationId)||correlationId.equals("0")) {
				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Correlation ID is : "+correlationId);
				return StartAnywhereUtil.buildResponse(createGroupsResponse, StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
						StartAnyWhereConstants.MISSING_REQUIRED_PARAMETERS_MESSAGE, null, null, null, null, errors);
			} 
		    
		    ClientOnboardingRequestTrackEntity trackEntity = trackRepo.findByCorrelationIdAndClientId(correlationId,
					clientId);
		    ClientOnboardingRequestTrackEntity statustrackEntity = trackRepo.findByClientId(
					clientId);
		    
			if (trackEntity != null) {
				if (trackEntity.getStatus() == 0) {
					int hitCount = trackEntity.getHitCount();
					if (hitCount < configBean.getHitCount()) {
						trackEntity.setHitCount(hitCount + 1);
						trackRepo.save(trackEntity);
						return StartAnywhereUtil.buildResponse(createGroupsResponse,
								StartAnyWhereConstants.HTTP_STATUS_SUCCESS,
								StartAnyWhereConstants.REQUEST_ALREADY_IN_PROGRESS, null, null, null, null, errors);
					} else {
						return StartAnywhereUtil.buildResponse(createGroupsResponse,
								StartAnyWhereConstants.HTTP_STATUS_RATE_LIMIT_EXCEEDED,
								String.format(StartAnyWhereConstants.RATE_LIMIT_EXCEEDED, configBean.getFallbackTime()),
								null, null, StartAnyWhereConstants.HIGH, null, errors);
					}
				}else {
					return StartAnywhereUtil.buildResponse(createGroupsResponse, StartAnyWhereConstants.HTTP_STATUS_SUCCESS,
							StartAnyWhereConstants.REQUEST_COMPLETED_SUCCESSFULLY, null, null, null, null, errors);
				}
			}else if(statustrackEntity!=null) {
				if (statustrackEntity.getStatus() == 0) {
				return StartAnywhereUtil.buildResponse(createGroupsResponse,
						StartAnyWhereConstants.HTTP_STATUS_SUCCESS,
						StartAnyWhereConstants.REQUEST_ALREADY_IN_PROGRESS_WITH_CORR_ID +statustrackEntity.getCorrelationId(), null, null, null, null, errors);
				}
				else {
					return StartAnywhereUtil.buildResponse(createGroupsResponse, StartAnyWhereConstants.HTTP_STATUS_SUCCESS,
							StartAnyWhereConstants.REQUEST_COMPLETED_SUCCESSFULLY_WITH_CORR_ID+statustrackEntity.getCorrelationId(), null, null, null, null, errors);
				}
				}
			else {
				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Triggering async...createGroupsAsync()");
				asyncGroupServiceImpl.createGroupsAsync(sessionToken, requestHeader, clientId, clientName);
				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "continuing .....other logic");
				 return StartAnywhereUtil.buildResponse(
						new CreateGroupsResponse(),
		             StartAnyWhereConstants.POS201,
		             StartAnyWhereConstants.REQUEST_SUBMITTED_SUCESSFULLY,
		             null,
		             null,
		             null,
		             null,
		             errors);
			}
				
		
	}catch(Exception e) {
		e.printStackTrace();
	}
		return createGroupsResponse;
	}

}
