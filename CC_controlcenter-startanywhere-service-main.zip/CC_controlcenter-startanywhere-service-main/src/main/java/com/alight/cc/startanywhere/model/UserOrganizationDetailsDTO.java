package com.alight.cc.startanywhere.model;

import com.alight.cc.dto.OrganizationDetailsDTO;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserOrganizationDetailsDTO {

	private String username;
    private String org_start_date;
    private String org_end_date;
    private String orgmembership;
    
    
}
