package com.alight.cc.startanywhere.configuration;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import com.alight.cc.startanywhere.saviynt.model.Owner;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Configuration
@ConfigurationProperties(prefix = "controlcenter.startanywhere.saviynt")
public class SaviyntConfigurationBean {
	@Value("${controlcenter.startanywhere.saviynt.endpoint:}")
	private String endpoint;
	@Value("${controlcenter.startanywhere.saviynt.entitlementOwners:}")
	private List<String> entitlementOwners;
	@Value("${controlcenter.startanywhere.saviynt.application:}")
	private String application;

	@Value("${controlcenter.startanywhere.saviynt.prefix:}")
	private String prefix;
	@Value("${controlcenter.startanywhere.saviynt.defaultEmailID:}")
	private String defaultEmailID;
	@Value("${controlcenter.startanywhere.saviynt.defaultUserName:}")
	private String defaultUserName;
	@Value("${controlcenter.startanywhere.saviynt.defaultAccountName:}")
	private String defaultAccountName;
	@Value("${controlcenter.startanywhere.saviynt.entitlementtype}")
	private String entitlementtype;
	@Value("${controlcenter.startanywhere.saviynt.securitysystem}")
	private String securitySystem;
	@Value("${controlcenter.startanywhere.saviynt.businessjustification}")
	private String businessJustification;
	@Value("${app.api.retry.hit-count}")
	private int hitCount;
	@Value("${app.api.retry.fallback-time}")
	private int fallbackTime;
	// Bound via @ConfigurationProperties
    private List<Owner> owner;
	private String requestor;
	private String endpointD2;
	private String domain;
	private String environment;
	
}