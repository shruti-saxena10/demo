package com.alight.cc.startanywhere.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class SecurityManagerEmail {
	@NotBlank(message ="Email cannot be blank")
	private String emailId;	

}
