package com.alight.cc.startanywhere.util;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.alight.cc.startanywhere.configuration.SaviyntConfigurationBean;
import com.alight.cc.startanywhere.repository.SecurityManagerEntitlementRepository;
import com.alight.cc.startanywhere.saviynt.model.CreateRequest;
import com.alight.cc.startanywhere.saviynt.model.Entitlement;

@Component
public class SaviyntRequestBuilder {
	@Value("${saviynt.cn.path:}")
    private String saviyntCommonNamePath;
	@Autowired
	SecurityManagerEntitlementRepository entitlementRepo;
	@Autowired
	SaviyntConfigurationBean saviyntConfig;
	
	public String buildGetUserQuery(String email) {
		return String.format("%s = '%s' and %s = '%s'", StartAnyWhereConstants.GET_REQUEST_EMAIL_SEARCH, email, StartAnyWhereConstants.GET_REQUEST_USER_STATUS,
				StartAnyWhereConstants.GET_REQUEST_USER_ACTIVE_STATUS);
	}

	public List<Entitlement> buildEntitlementArray(List<String> entitlementList, String clientId) {
		// TODO Auto-generated method stub
//		List<SecurityManagerEntitlementEntity> entitlementEntities = entitlementRepo.findAll();
		List<Entitlement> entitlements = new ArrayList<>(entitlementList.size());
		entitlements = entitlementList.stream().map(s -> buildEntitlement(s, clientId))
				.collect(Collectors.toList());
		return entitlements;
	}
	private Entitlement buildEntitlement(String s, String clientId) {
		// TODO Auto-generated method stub
		String prefix = saviyntConfig.getPrefix();
		String application = saviyntConfig.getApplication();
		String entitlement_value = prefix + s + ","
				+ application;
		Entitlement entitlement = Entitlement.builder().entitlementtype(saviyntConfig.getEntitlementtype())
				.entitlementvalue(entitlement_value).businessjustification(saviyntConfig.getBusinessJustification())
				.updatetype(StartAnyWhereConstants.ADD).build();
		return entitlement;
	}
	public CreateRequest buildAccountRequest(List<Entitlement> entitlements, String userName, String accountName) {
		// TODO Auto-generated method stub
		CreateRequest req = CreateRequest.builder().accountname(accountName).endpoint(saviyntConfig.getEndpoint()).createnewaccounttaskifnotexist(StartAnyWhereConstants.TRUE)
				.entitlement(entitlements).requesttype(StartAnyWhereConstants.REQUEST_TYPE).securitysystem(saviyntConfig.getSecuritySystem())
				.status(StartAnyWhereConstants.GET_REQUEST_USER_ACTIVE_STATUS).username(userName).build();
		return req;
	}

}