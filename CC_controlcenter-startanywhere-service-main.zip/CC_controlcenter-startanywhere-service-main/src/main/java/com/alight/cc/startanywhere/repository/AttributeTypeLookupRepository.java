package com.alight.cc.startanywhere.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.alight.cc.startanywhere.entity.AttributeTypeLookupEntity;

@Repository
public interface AttributeTypeLookupRepository extends JpaRepository<AttributeTypeLookupEntity, Long>{

	Optional<AttributeTypeLookupEntity> findByKey(String key);
}
