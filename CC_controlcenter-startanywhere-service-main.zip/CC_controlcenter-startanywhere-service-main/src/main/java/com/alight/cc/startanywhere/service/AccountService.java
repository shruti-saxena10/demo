package com.alight.cc.startanywhere.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import com.alight.cc.dto.AccountDTO;
import com.alight.cc.startanywhere.feign.SaviyntClient;
import com.alight.cc.startanywhere.saviynt.model.CreateRequest;
import com.alight.cc.startanywhere.saviynt.model.GetAccountsRequest;
import com.alight.cc.startanywhere.saviynt.model.GetAccountsResponse;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;
import com.alight.cc.startanywhere.util.StartAnywhereUtil;
import com.alight.logging.helpers.InfoTypeLogEventHelper;

import feign.FeignException;

@Service
public class AccountService {
	@Autowired
	SaviyntClient saviyntClient;

	@Retryable(value = {
			FeignException.class }, maxAttemptsExpression = "#{${app.api.retry.max-attempts:5}}", backoff = @Backoff(delayExpression = "#{${app.api.retry.backoff-delay:1000}}"), exceptionExpression = "#{@retryHelper.is5xx(#root)}")
	public List<AccountDTO> getAccounts(String username, String accessToken) {
		GetAccountsRequest getAccountsRequest = GetAccountsRequest.of(username, StartAnyWhereConstants.END_POINT);
		GetAccountsResponse getAccountsResponse = saviyntClient
				.getAccounts(StartAnyWhereConstants.AUTH_TOKEN_PREFIX + accessToken, getAccountsRequest);
		InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
				"Response from get accounts: " + getAccountsResponse);
		int statusCode = StartAnywhereUtil.calculateSaviyntStatusCode(getAccountsResponse.getStatusCode());
		if ((statusCode == HttpStatus.OK.value())
				&& CollectionUtils.isNotEmpty(getAccountsResponse.getAccountDetails())) {
			return getAccountsResponse.getAccountDetails().stream().map(accountDetails -> AccountDTO
					.of(accountDetails.getUsername(), accountDetails.getName(), accountDetails.getStatus()))
					.collect(Collectors.toList());
		} else {
			// Return empty list
			return new ArrayList<>();
		}
	}

	@Retryable(value = {
			FeignException.class }, maxAttemptsExpression = "#{${app.api.retry.max-attempts:5}}", backoff = @Backoff(delayExpression = "#{${app.api.retry.backoff-delay:1000}}"), exceptionExpression = "#{@retryHelper.is5xx(#root)}")
	public JSONObject createRequestBulk(CreateRequest cr, String accessToken) {
		// TODO Auto-generated method stub
		JSONObject createResponse = saviyntClient.createRequest(StartAnyWhereConstants.AUTH_TOKEN_PREFIX + accessToken,
				cr);
		return createResponse;

	}

}
