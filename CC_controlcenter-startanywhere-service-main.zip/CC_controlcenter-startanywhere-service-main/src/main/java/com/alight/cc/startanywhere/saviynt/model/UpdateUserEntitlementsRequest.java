package com.alight.cc.startanywhere.saviynt.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UpdateUserEntitlementsRequest {
    private String accesstype;
    private String requestor;
    private String displayname;
    private String roletype;
    private String entitlementtype;
    private String suffix;
    private String requesttype;
    private String description;
    private String category;
    private int syscritical;
    private int soxcritical;
    private String securitysystem;
    private String endpoint;
    private String domain;
    private String environment;
    private String application;
    private List<Owner> owner;
    
    private String username;
    private String accountname;
    private String createNewAccountTaskIfNotExist = Boolean.TRUE.toString();
    private List<Entitlement> entitlements;
}