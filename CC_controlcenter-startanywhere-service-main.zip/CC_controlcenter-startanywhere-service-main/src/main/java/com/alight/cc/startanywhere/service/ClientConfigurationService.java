package com.alight.cc.startanywhere.service;

import java.io.IOException;

import org.springframework.http.ResponseEntity;

import com.alight.cc.startanywhere.model.ClientConfigurationRequest;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface ClientConfigurationService {

	ResponseEntity<Object> createClientConfiguration(String alightRequestHeader, String alightColleagueSessionToken,
			ClientConfigurationRequest configRequest) throws JsonProcessingException, IOException;

}
