package com.alight.cc.startanywhere.saviynt.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor(staticName = "of")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Entitlement {

	private String entitlementtype;
	private String entitlementvalue;
	private String businessjustification;
	private String updatetype;
}
