package com.alight.cc.startanywhere.model;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Valid
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ClientModel {

	@NotBlank(message = "Validation failed: clientId must not be empty/blank/null")
	@Size(min = 0, max = 10, message = "Validation failed: clientId cannot exceed 10 characters.")
	private String clientId;
	
	@NotBlank(message = "Validation failed: clientName must not be empty/blank/null")
	@Size(min = 0, max = 100, message = "Validation failed: clientName cannot exceed 100 characters.")
	private String clientName;
	
	@NotBlank(message = "Validation failed: orgName must not be empty/blank/null")
	private String orgName;
	
	@NotNull(message = "Validation failed: isDataRestriction must not be null.")
	private Boolean isDataRestriction;

	
}
