package com.alight.cc.startanywhere.service;

import java.io.IOException;

import com.alight.cc.startanywhere.model.ClientResponse;

public interface ClientDataRetrievalService {
	ClientResponse getClientData(String alightColleagueSessionToken, String alightRequestHeader,
			String clientId)throws IOException;
}
