package com.alight.cc.startanywhere.configuration;

import org.springframework.http.MediaType;
import org.springframework.http.converter.json.AbstractJackson2HttpMessageConverter;

import com.fasterxml.jackson.databind.ObjectMapper;

public class MappingTextJson2HttpMessageConverter extends AbstractJackson2HttpMessageConverter {

    public MappingTextJson2HttpMessageConverter(ObjectMapper objectMapper) {
        super(objectMapper, new MediaType("text", "json"));
    }
}