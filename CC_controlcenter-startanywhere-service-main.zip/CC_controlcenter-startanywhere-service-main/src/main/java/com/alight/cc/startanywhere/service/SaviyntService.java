package com.alight.cc.startanywhere.service;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alight.cc.ControlCenterCommonConstants;
import com.alight.cc.startanywhere.configuration.SaviyntConfigurationBean;
import com.alight.cc.startanywhere.entity.SecurityManagerEntitlementEntity;
import com.alight.cc.startanywhere.feign.SaviyntClient;

@Component
public class SaviyntService {

	
	@Autowired
	SaviyntConfigurationBean bean;
	
	@Autowired
	SaviyntClient saviyntClient;

	
	public String getEndpoint(String userType) {
		if (userType != null) {
			if (userType.equalsIgnoreCase(ControlCenterCommonConstants.TypeOfUser.INTERNAL.name())) {
				return bean.getEndpoint();
			}
		}
		return null;
	}

	public String getSecuritySystem(String userType) {
		if (userType != null) {
			 if (userType.equalsIgnoreCase(ControlCenterCommonConstants.TypeOfUser.INTERNAL.name())) {
				return bean.getSecuritySystem();
			}
		}
		return null;
	}

	public List<String> getDisplayNamesWithClientId(List<SecurityManagerEntitlementEntity> entitlementEntities,
			String clientId) {
		if (entitlementEntities == null || entitlementEntities.isEmpty()) {
			return Collections.emptyList();
		}

		return entitlementEntities.stream().map(SecurityManagerEntitlementEntity::getDisplayName)
				.filter(Objects::nonNull)
				.map(value -> bean.getPrefix() + value.replace("<ClientID>", clientId) + "," + bean.getApplication())
				.collect(Collectors.toList());
	}
}