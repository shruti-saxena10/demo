package com.alight.cc.startanywhere.saviynt.model;
import lombok.Data;

@Data
public class LoginData {
    private String username;
    private String password;
}