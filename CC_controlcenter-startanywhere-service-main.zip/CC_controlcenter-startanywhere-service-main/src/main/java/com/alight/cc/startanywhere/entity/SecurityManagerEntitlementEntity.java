package com.alight.cc.startanywhere.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "securitymanager_entitlements", schema = "public")
public class SecurityManagerEntitlementEntity {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
    private Long id;	
	@Column(name = "is_securitymanager")
    private Integer isSecuritymanager;
	@Column(name = "display_name")
    private String displayName;
	@Column(name = "description")
	 private String description;	
	}