package com.alight.cc.startanywhere.saviynt.model;

import java.util.List;

import com.alight.cc.startanywhere.model.EntitlementOwnerResponse;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This class contains all the attributes that are relevant to a Saviynt entitlement.  TBD which ones are needed.
 */


@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class EntitlementDetail {
    
    private String description;
    private String endpoint;
    private String entitlement_value;
    private String displayname;
    private String status;
    @JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
    private List<String> entitlementOwner;
}

