package com.alight.cc.startanywhere.saviynt.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor(staticName = "of")
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class OrganizationUser {
    private String username;
    private String updatetype;
	
}
