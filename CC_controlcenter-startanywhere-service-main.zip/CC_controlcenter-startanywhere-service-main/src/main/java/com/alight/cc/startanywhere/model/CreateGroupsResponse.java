package com.alight.cc.startanywhere.model;

import java.util.List;

import org.json.simple.JSONObject;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY) 
public class CreateGroupsResponse extends BaseResponse {
	 private String clientId;
	    private String clientName;
	    private List<SuccessfulEntitlement> successfulEntitlements;
	    private List<FailedEntitlement> failedEntitlements;

	    @Data
	    @NoArgsConstructor
	    @AllArgsConstructor
	    @JsonInclude(JsonInclude.Include.NON_EMPTY) 
	    public static class SuccessfulEntitlement {
	        private String entitlementName;
	        private String requestId;
	        private String requestKey;
	    }

	    @Data
	    @NoArgsConstructor
	    @AllArgsConstructor
	    @JsonInclude(JsonInclude.Include.NON_EMPTY) 
	    public static class FailedEntitlement {
	        private String entitlementName;
	        private String errorCode;
	        private String errorMessage;
	    }
    
}