package com.alight.cc.startanywhere.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.retry.annotation.Recover;
import org.springframework.stereotype.Service;

import com.alight.cc.ControlCenterCommonConstants;
import com.alight.cc.dto.OrganizationDetailsDTO;
import com.alight.cc.dto.UserOrganizationDetailResponseDTO;
import com.alight.cc.model.DomainLookup;
import com.alight.cc.model.DomainLookupType;
import com.alight.cc.repository.DomainLookupRepository;
import com.alight.cc.startanywhere.configuration.SaviyntConfigurationBean;
import com.alight.cc.startanywhere.entity.SecurityManagerEntitlementEntity;
import com.alight.cc.startanywhere.feign.SaviyntClient;
import com.alight.cc.startanywhere.model.ClientConfigError;
import com.alight.cc.startanywhere.model.ClientConfigurationResponse;
import com.alight.cc.startanywhere.model.ClientRequest;
import com.alight.cc.startanywhere.model.ClientResponse;
import com.alight.cc.startanywhere.model.EntitlementOwnerResponse;
import com.alight.cc.startanywhere.model.EntitlementResponse;
import com.alight.cc.startanywhere.model.SecurityManagerRequest;
import com.alight.cc.startanywhere.model.SecurityManagerResponse;
import com.alight.cc.startanywhere.repository.SecurityManagerEntitlementRepository;
import com.alight.cc.startanywhere.saviynt.model.EntitlementDetail;
import com.alight.cc.startanywhere.saviynt.model.EntitlementsResponse;
import com.alight.cc.startanywhere.saviynt.model.GetEntitlementsRequest;
import com.alight.cc.startanywhere.saviynt.model.GetUserRequest;
import com.alight.cc.startanywhere.saviynt.model.User;
import com.alight.cc.startanywhere.saviynt.model.UserDetailsResponse;
import com.alight.cc.startanywhere.saviynt.model.UserOrganisationDetailRequest;
import com.alight.cc.startanywhere.service.ClientDataRetrievalService;
import com.alight.cc.startanywhere.service.FetchClientConfigurationService;
import com.alight.cc.startanywhere.service.UserService;
import com.alight.cc.startanywhere.util.ClientRetryable;
import com.alight.cc.startanywhere.util.SaviyntRequestBuilder;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;
import com.alight.cc.startanywhere.util.StartAnywhereUtil;
import com.alight.logging.helpers.InfoTypeLogEventHelper;
import com.aonhewitt.logging.events.ErrorLogEvent;
import com.aonhewitt.logging.helpers.DebugLogEventHelper;
import com.aonhewitt.logging.helpers.ErrorLogEventHelper;
import com.aonhewitt.logging.helpers.LogEventUtil;

import feign.FeignException;

@Service
public class FetchClientConfigurationServiceImpl implements FetchClientConfigurationService {
	
	@Autowired
	SaviyntConfigurationBean bean;
	
	@Autowired
	SaviyntClient saviyntClient;

	@Autowired
	UserService userService;

	@Autowired
	SaviyntRequestBuilder saviyntRequestBuilder;

	@Autowired
	DomainLookupRepository domainLookupRepository;
	@Autowired
	ClientDataRetrievalService clientDataRetrievalService;
	@Autowired
	SecurityManagerEntitlementRepository securityManagerEntitlementRepository;

	@ClientRetryable
	public ClientConfigurationResponse getClientConfigurationDetails(String alightColleagueSessionToken,
			String alightRequestHeader, ClientRequest request) throws IOException, RuntimeException, FeignException {
		ClientConfigurationResponse clientConfigurationResponse = new ClientConfigurationResponse();
		List<ClientConfigError> errors = new ArrayList<>();
		try {
			DebugLogEventHelper.logDebugEvent(this.getClass().getName(), "Entered getClientConfigurationDetails",
					"Starting method execution", LogEventUtil.DEBUG_SEVERITY);

			List<SecurityManagerResponse> securityManagers = new ArrayList<>();

			ClientResponse clientData = clientDataRetrievalService.getClientData(alightColleagueSessionToken,
					alightRequestHeader, request.getClientId());

			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
					"Fetched client data for ID: " + request.getClientId());

			if (Optional.ofNullable(clientData).map(ClientResponse::getErrors).map(List::isEmpty).orElse(true)) {
				// errors list is non-null and empty — safe to proceed
				clientConfigurationResponse.setResponseCode(StartAnyWhereConstants.HTTP_STATUS_SUCCESS);
				clientConfigurationResponse.setResponseMessage(StartAnyWhereConstants.OK);
				clientConfigurationResponse.setClientName(clientData.getClientName());
				clientConfigurationResponse.setOrgName(clientData.getOrgName());
				clientConfigurationResponse.setIsDataRestriction(clientData.getIsDataRestriction());
				clientConfigurationResponse.setLocationUserPII(clientData.getLocationUserPII());
				clientConfigurationResponse.setReason(clientData.getReason());
				clientConfigurationResponse.setScrmId(clientData.getScrmId());

				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
						"Client configuration populated for: " + clientData.getClientName());
			} else {
				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
						StartAnyWhereConstants.CLIENT_DOESNT_EXIST_IN_POSTGRES_DB + request.getClientId());
				clientConfigurationResponse.setResponseCode(clientData.getResponseCode());
				clientConfigurationResponse.setResponseMessage(clientData.getResponseMessage());
				clientConfigurationResponse.setClientName(clientData.getClientName());
				clientConfigurationResponse.setOrgName(clientData.getOrgName());
				clientConfigurationResponse.setIsDataRestriction(clientData.getIsDataRestriction());
				clientConfigurationResponse.setLocationUserPII(clientData.getLocationUserPII());
				clientConfigurationResponse.setReason(clientData.getReason());
				clientConfigurationResponse.setScrmId(clientData.getScrmId());
				errors.addAll(clientData.getErrors());
				return StartAnywhereUtil.buildResponse(clientConfigurationResponse,
						StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST, StartAnyWhereConstants.BAD_REQUEST,
						null,
						null, null,
						null, errors);
			}
			Set<String> dubligetEmailCheking =new HashSet<>();
			List<SecurityManagerRequest> securityManages = request.getSecurityManagers();
			
			SecurityManagerRequest securityManagerRequest=new SecurityManagerRequest();
			securityManagerRequest.setEmailId(bean.getDefaultEmailID());
			securityManages.add(securityManagerRequest);
			if (securityManages != null && !securityManages.isEmpty()) {
				for (SecurityManagerRequest manager : securityManages) {
					SecurityManagerResponse securityManagerResponse = new SecurityManagerResponse();
					String email = manager.getEmailId();
					email=email.toLowerCase();
					if(dubligetEmailCheking.contains(email))
					continue;
					dubligetEmailCheking.add(email);
					securityManagerResponse.setSecurityManageEmailId(email);

					DebugLogEventHelper.logDebugEvent(this.getClass().getName(), "Processing Security Manager Email",
							email, LogEventUtil.DEBUG_SEVERITY);

					String accessToken = userService.getAccessToken();
					if (accessToken == null) {
						return StartAnywhereUtil.buildResponse(clientConfigurationResponse,
								StartAnyWhereConstants.HTTP_STATUS_SUCCESS, StartAnyWhereConstants.OK,
								StartAnyWhereConstants.SAV102,
								StartAnyWhereConstants.SAVIYNT_FUNCTIONAL_ID_AND_PASSWORD_INVALID,
								StartAnyWhereConstants.HIGH, null, errors);
					}
					String userType = determineUserTypeByEmailDomain(email);
					String endpoint = getEndpoint(userType);

					GetUserRequest getUserRequest = GetUserRequest.builder()
							.userQuery(saviyntRequestBuilder.buildGetUserQuery(email)).build();

					UserDetailsResponse userDetailsResponse = saviyntClient
							.getUser(StartAnyWhereConstants.AUTH_TOKEN_PREFIX + accessToken, getUserRequest);

					if (!Optional.ofNullable(userDetailsResponse).map(UserDetailsResponse::getUserdetails)
							.filter(details -> !details.isEmpty()).isPresent()) {

						ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
								"No user details returned from Saviynt for email: " + email, "", null,
								ErrorLogEvent.ERROR_SEVERITY);

						 StartAnywhereUtil.buildResponse(clientConfigurationResponse,
								StartAnyWhereConstants.HTTP_STATUS_SUCCESS, StartAnyWhereConstants.OK,
								StartAnyWhereConstants.SAV103,
								StartAnyWhereConstants.USER_DETAILS_DOESNT_EXIST_IN_SAVIYNT, StartAnyWhereConstants.LOW,
								email, errors);
						 continue;
					}

					User user = userDetailsResponse.getUserdetails().get(0);
					if (!user.getEmail().equalsIgnoreCase(email)) {
						ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
								"Security Manager mismatch: request email vs Saviynt user email", "", null,
								ErrorLogEvent.ERROR_SEVERITY);

						return StartAnywhereUtil.buildResponse(clientConfigurationResponse,
								StartAnyWhereConstants.HTTP_STATUS_SUCCESS, StartAnyWhereConstants.OK,
								StartAnyWhereConstants.SAV002,
								StartAnyWhereConstants.SECURITY_MANAGER_DOESNT_EXIST_IN_SAVIYNT,
								StartAnyWhereConstants.LOW, email, errors);
					}

					securityManagerResponse.setSecurityManageAID(user.getUsername());

					UserOrganisationDetailRequest userOrgDetailRequest = UserOrganisationDetailRequest.builder()
							.username(user.getUsername()).max(StartAnyWhereConstants.MAX).build();

					UserOrganizationDetailResponseDTO response = saviyntClient.getOrganizationUserDetails(
							StartAnyWhereConstants.AUTH_TOKEN_PREFIX + accessToken, userOrgDetailRequest);
					if (Optional.ofNullable(response).map(UserOrganizationDetailResponseDTO::getOrganizations)
							.filter(orgs -> !orgs.isEmpty()).isPresent()) {

						List<String> organizationNames = Optional.ofNullable(response.getOrganizations())
								.orElse(Collections.emptyList()).stream()
								.map(OrganizationDetailsDTO::getOrganizationname).filter(Objects::nonNull)
								.collect(Collectors.toList());

						boolean containsClientId = organizationNames.stream()
								.anyMatch(name -> name.equals(request.getClientId()));

						if (!containsClientId) {
							ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
									StartAnyWhereConstants.SECURITY_MANAGER_DOESNT_BELONGS_TO_SAVIYNT_CLINET, "", null,
									ErrorLogEvent.ERROR_SEVERITY);

							StartAnywhereUtil.buildResponse(clientConfigurationResponse,
									StartAnyWhereConstants.HTTP_STATUS_SUCCESS, StartAnyWhereConstants.OK,
									StartAnyWhereConstants.SAV006,
									StartAnyWhereConstants.SECU_MANAGER_DOESNT_BELONGS_TO_SAVIYNT_CLINET,
									StartAnyWhereConstants.LOW, email, errors);
						}
						if (containsClientId) {
						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
								"Loading initial Saviynt entitlements");

						EntitlementsResponse entitlementsResponse = loadEntitlements(user.getUsername(), endpoint,
								accessToken, new ArrayList<>(), 0, request.getClientId());
						List<SecurityManagerEntitlementEntity> securityManagerEntitlementresponse = securityManagerEntitlementRepository
								.findByIsSecuritymanager(1);

						List<String> updatedEntitlementDisplayname = getDisplayNamesWithClientId(
								securityManagerEntitlementresponse, request.getClientId());
						List<EntitlementResponse> entitlements = new ArrayList<>();
						List<String> availableEntitlementValues = Optional.ofNullable(entitlementsResponse)
							    .map(EntitlementsResponse::getEntitlementdetails)
							    .orElse(Collections.emptyList())
							    .stream()
							    .map(EntitlementDetail::getEntitlement_value)
							    .filter(Objects::nonNull)
							    .collect(Collectors.toList());


						// Identify which expected display names are NOT found in the entitlement
						// response
						List<String> missingDisplayNames = Optional.ofNullable(updatedEntitlementDisplayname)
							    .orElse(Collections.emptyList())
							    .stream()
							    .filter(expected -> Optional.ofNullable(availableEntitlementValues)
							        .orElse(Collections.emptyList())
							        .stream()
							        .noneMatch(expected::equals))
							    .collect(Collectors.toList());


						// If any expected entitlement is missing, build failure response
						if (!missingDisplayNames.isEmpty()) {
							String result = missingDisplayNames.stream()
								    .map(e -> e.replace(bean.getApplication(), "").replace(bean.getPrefix(), ""))
								    .collect(Collectors.joining(" "));
		

							 StartAnywhereUtil.buildResponse(clientConfigurationResponse,
											StartAnyWhereConstants.HTTP_STATUS_SUCCESS, StartAnyWhereConstants.OK,
											StartAnyWhereConstants.SAV008,
											StartAnyWhereConstants.ENTITLEMENT + result
													+ StartAnyWhereConstants.ENTITLEMENT_NOT_AVAILABLE,
											StartAnyWhereConstants.LOW, email, errors);

						}

						// Collect all matching entitlement details into response object
						List<EntitlementResponse> matchedResponses = Optional.ofNullable(entitlementsResponse)
							    .map(EntitlementsResponse::getEntitlementdetails)
							    .orElse(Collections.emptyList())
							    .stream()
							    .filter(detail -> 
							        detail != null &&
							        detail.getEntitlement_value() != null &&
							        Optional.ofNullable(updatedEntitlementDisplayname).orElse(Collections.emptyList())
							            .contains(detail.getEntitlement_value())
							    )
							    .map(detail -> {
							        EntitlementResponse EntitlementResponse = new EntitlementResponse();
							        EntitlementResponse.setEndpoint(detail.getEndpoint());
							        EntitlementResponse.setEntitlementValue(detail.getEntitlement_value());
							        EntitlementResponse.setDescription(detail.getDescription());
							        EntitlementResponse.setStatus(detail.getStatus());

							        // Safely collect entitlement owners
							        List<EntitlementOwnerResponse> owners = Optional.ofNullable(detail.getEntitlementOwner())
							            .orElse(Collections.emptyList())
							            .stream()
							            .filter(owner -> owner != null && !owner.isBlank())
							            .map(owner -> {
							                EntitlementOwnerResponse ownerRes = new EntitlementOwnerResponse();
							                ownerRes.setAID(owner);
							                return ownerRes;
							            }).collect(Collectors.toList());

							        EntitlementResponse.setEntitlementOwner(owners);
							        return EntitlementResponse;
							    })
							    .collect(Collectors.toList());


						// Add all matched entitlements to the response holder
						entitlements.addAll(matchedResponses);
						securityManagerResponse.setEntitlements(entitlements);

						securityManagers.add(securityManagerResponse);
						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
								"Finished loading Saviynt entitlements");
					}

					}else {
						StartAnywhereUtil.buildResponse(clientConfigurationResponse,
								StartAnyWhereConstants.HTTP_STATUS_SUCCESS, StartAnyWhereConstants.OK,
								StartAnyWhereConstants.SAV006,
								StartAnyWhereConstants.SECURITY_MANAGER_DOESNT_BELONGS_TO_SAVIYNT_CLINET,
								StartAnyWhereConstants.LOW, email, errors);
					}
				}

				clientConfigurationResponse.setSecurityManagers(securityManagers);
			}
		} catch (IOException ex) {
			ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
					"Exception occurred while adding the client details", "", ex, ErrorLogEvent.ERROR_SEVERITY);
			return StartAnywhereUtil.buildResponse(new ClientConfigurationResponse(),
					StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR,
					StartAnyWhereConstants.INTERNAL_SERVER_ERROR, StartAnyWhereConstants.POS101,
					StartAnyWhereConstants.MSGFOR_POS101, StartAnyWhereConstants.HIGH, null, errors);

		}

		return clientConfigurationResponse;
	}

	private EntitlementsResponse loadEntitlements(String username, String endpoint, String accessToken,
			List<EntitlementDetail> allEntitlementDetails, Integer offset, String clientId) {
		DebugLogEventHelper.logDebugEvent(this.getClass().getName(), "Preparing GetEntitlementsRequest",
				"loadEntitlements method initiated", LogEventUtil.DEBUG_SEVERITY);

		GetEntitlementsRequest getEntitlementsRequest = GetEntitlementsRequest.builder().username(username)
				.entQuery(StartAnyWhereConstants.ENTQUERY + clientId + StartAnyWhereConstants.LIKEOPERATER).endpoint(endpoint)
				.status(StartAnyWhereConstants.SAVIYNT_ENTITLEMENT_ACTIVE_STATUS)
				.offset(offset).build();

		InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Sending entitlement request for user: "
				+ username + ", clientId: " + clientId + ", endpoint: " + endpoint);

		EntitlementsResponse entitlementsResponse = saviyntClient
				.getEntitlements(StartAnyWhereConstants.AUTH_TOKEN_PREFIX + accessToken, getEntitlementsRequest);

		InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
				"Response from getting entitlements: " + entitlementsResponse);

		if (entitlementsResponse == null) {
			ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
					"Received null response while fetching entitlements", "Null response from Saviynt client", null,
					ErrorLogEvent.ERROR_SEVERITY);
			throw new RuntimeException("Entitlements response is null");
		}

		int statusCode = StartAnywhereUtil.calculateSaviyntStatusCode(entitlementsResponse.getStatusCode());

		if (HttpStatus.OK.value() == statusCode) {
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
					"Successfully retrieved entitlements for user: " + username);
		} else {
			ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), "Entitlement request failed",
					String.format("getEntitlements failed with status %d, message: %s, error code: %s", statusCode,
							entitlementsResponse.getMsg(), entitlementsResponse.getErrorCode()),
					null, ErrorLogEvent.ERROR_SEVERITY);
			throw new RuntimeException("Error retrieving entitlements from Saviynt");
		}

		DebugLogEventHelper.logDebugEvent(this.getClass().getName(), "Entitlements retrieved",
				"Returning EntitlementsResponse from loadEntitlements", LogEventUtil.DEBUG_SEVERITY);

		return entitlementsResponse;
	}

	private String determineUserTypeByEmailDomain(String email) {
		List<DomainLookup> internalDomainList = domainLookupRepository.findByDomainType(DomainLookupType.internal);
		boolean isInternalDomain = this.isInternalDomain(internalDomainList, email);
		return isInternalDomain ? ControlCenterCommonConstants.TypeOfUser.INTERNAL.name().toLowerCase()
				: ControlCenterCommonConstants.TypeOfUser.EXTERNAL.name().toLowerCase();
	}

	private boolean isInternalDomain(List<DomainLookup> domainLookupList, String email) {
		return domainLookupList.stream().map(DomainLookup::getDomainName)
				.anyMatch(domainName -> StringUtils.endsWithIgnoreCase(email, domainName));
	}

	public String getEndpoint(String userType) {
		if (userType != null) {
			if (userType.equalsIgnoreCase(ControlCenterCommonConstants.TypeOfUser.INTERNAL.name())) {
				return bean.getEndpoint();
			}
		}
		return null;
	}

	public List<String> getDisplayNamesWithClientId(List<SecurityManagerEntitlementEntity> entitlementEntities,
			String clientId) {
		if (entitlementEntities == null || entitlementEntities.isEmpty()) {
			return Collections.emptyList();
		}

		return entitlementEntities.stream().map(SecurityManagerEntitlementEntity::getDisplayName)
				.filter(Objects::nonNull)
				.map(value -> bean.getPrefix() + value.replace("<ClientID>", clientId) + "," + bean.getApplication())
				.collect(Collectors.toList());
	}

	@Recover
	public ClientConfigurationResponse handleRetryFailure(Exception ex, String token, String header,
			ClientRequest request) {
		ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
				"Retry exhausted for getClientData: " + ex.getMessage(), "recover", ex, ErrorLogEvent.ERROR_SEVERITY);
		List<ClientConfigError> errors = new ArrayList<>();
		if (ex instanceof FeignException) {
			// Handle Feign-specific failure
			return StartAnywhereUtil.buildResponse(new ClientConfigurationResponse(),
					StartAnyWhereConstants.HTTP_STATUS_SERVICE_UNAVAILABLE, StartAnyWhereConstants.DB_UNREACHABLE,
					StartAnyWhereConstants.SAV101, StartAnyWhereConstants.SAVIYNT_SERVER_UNREACHABLE,
					StartAnyWhereConstants.HIGH, null, errors);
		} else {
			return StartAnywhereUtil.buildResponse(new ClientConfigurationResponse(),
					StartAnyWhereConstants.HTTP_STATUS_SERVICE_UNAVAILABLE, StartAnyWhereConstants.DB_UNREACHABLE,
					StartAnyWhereConstants.POS101, StartAnyWhereConstants.MSGFOR_POS101, StartAnyWhereConstants.HIGH,
					null, errors);
		}
	}
	public ClientConfigurationResponse validateClientRequest(String alightRequestHeader, ClientRequest request) {
	    List<ClientConfigError> errors = new ArrayList<>();

	    if (isNullOrEmpty(alightRequestHeader)) {
	        return StartAnywhereUtil.buildResponse(
	            new ClientConfigurationResponse(),
	            StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
	            StartAnyWhereConstants.MISSING_REQUIRED_PARAMETERS_MESSAGE,
	            null,
	            null,
	            null,
	            null,
	            errors
	        );
	    }

	    if (request == null || isNullOrEmpty(request.getClientId())) {
	        return StartAnywhereUtil.buildResponse(
	            new ClientConfigurationResponse(),
	            StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
	            StartAnyWhereConstants.BAD_REQUEST,
	            null,
	            StartAnyWhereConstants.BAD_REQUEST_MSG,
	            StartAnyWhereConstants.HIGH,
	            null,
	            errors
	        );
	    }

	    if (isNullOrEmpty(request.getClientName())) {
	        return StartAnywhereUtil.buildResponse(
	            new ClientConfigurationResponse(),
	            StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
	            StartAnyWhereConstants.BAD_REQUEST,
	            null,
	            StartAnyWhereConstants.MSG_FOR_NULLOREMPTY,
	            StartAnyWhereConstants.HIGH,
	            null,
	            errors
	        );
	    }
	    
	    
	    List<SecurityManagerRequest> managers = request.getSecurityManagers();

	    // Scenario 3: securityManagers is missing
	    if (managers == null) {
	        return StartAnywhereUtil.buildResponse(
	            new ClientConfigurationResponse(),
	            StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
	            StartAnyWhereConstants.BAD_REQUEST,
	            null,
	            StartAnyWhereConstants.WHEN_SEC_MNGR_FIELD_MISSING,
	            StartAnyWhereConstants.HIGH,
	            null,
	            errors
	        );
	    }


	    // Scenario 1: contains empty object(s)
	    for (SecurityManagerRequest sm : managers) {
	        if (sm == null || isNullOrEmpty(sm.getEmailId())) {
	            return StartAnywhereUtil.buildResponse(
	                new ClientConfigurationResponse(),
	                StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
	                StartAnyWhereConstants.BAD_REQUEST,
	                null,
	                StartAnyWhereConstants.INVALID_EMAIL,
	                StartAnyWhereConstants.HIGH,
	                null,
	                errors
	            );
	        }


	    }

	    return null; // Indicates validation passed
	}

	private boolean isNullOrEmpty(String value) {
	    return value == null || value.trim().isEmpty();
	}

}
