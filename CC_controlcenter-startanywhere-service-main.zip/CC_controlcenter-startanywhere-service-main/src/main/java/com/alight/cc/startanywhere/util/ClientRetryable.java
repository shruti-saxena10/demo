package com.alight.cc.startanywhere.util;

import org.postgresql.util.PSQLException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;

import com.alight.cc.startanywhere.exception.DuplicateClientException;

import feign.FeignException;

import java.io.IOException;
import java.lang.annotation.*;

@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Retryable(
    retryFor = {
        org.springframework.dao.QueryTimeoutException.class,
        org.springframework.dao.RecoverableDataAccessException.class,
        jakarta.persistence.PersistenceException.class,
        org.springframework.dao.DataAccessException.class,
        jakarta.persistence.EntityNotFoundException.class,
        org.springframework.dao.DataIntegrityViolationException.class,
        jakarta.validation.ConstraintViolationException.class,
        org.springframework.dao.DuplicateKeyException.class,
        Exception.class, RuntimeException.class,
        PSQLException.class,
        DuplicateClientException.class,
        FeignException.class, 
		IOException.class, 
    },
    maxAttemptsExpression = "#{${app.api.retry.max-attempts:5}}",
    backoff = @Backoff(delayExpression = "#{${app.api.retry.backoff-delay:1000}}"),
    recover = "handleRetryFailure"
)
public @interface ClientRetryable {
}
