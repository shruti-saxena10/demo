package com.alight.cc.startanywhere.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.alight.cc.startanywhere.entity.ClientMappingEntity;


@Repository
public interface ClientMappingRepository extends JpaRepository<ClientMappingEntity, Long>{
	@Query("SELECT cm FROM ClientMappingEntity cm WHERE cm.client.clientId = :clientId")
    List<ClientMappingEntity> findByControlCenterClientId(@Param("clientId") String clientId);

	@Modifying
	@Query("DELETE  FROM ClientMappingEntity cm WHERE cm.client.clientId = :clientId")
	void deleteByControlCenterClientId(@Param("clientId")String clientId);
	
}
