package com.alight.cc.startanywhere.configuration;

import java.util.Map;
import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.alight.cloud.data.store.util.DockerSecretsUtil;

import jakarta.persistence.EntityManagerFactory;

@Configuration
@EnableTransactionManagement
@EntityScan(basePackages = {
    "com.alight.cc.startanywhere.entity",
    "com.alight.cc.startanywhere.model",
    "com.alight.cc.model",
})
@EnableJpaRepositories(
    basePackages = {
        "com.alight.cc.startanywhere.repository",
        "com.alight.cc.repository",
    },
    entityManagerFactoryRef = "PostgresEntityManagerFactory",
    transactionManagerRef = "PostgresTransactionManager"
)
public class PostgreRDSConfig {
	
	@Autowired
	StartAnyWhereConfigBean bean;

    @Bean(name = "PostgresEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean PostgresEntityManagerFactory() {
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(PostgresDataSource());
        //em.setPackagesToScan("com.alight.cc.startanywhere.*");
        em.setPackagesToScan(
                "com.alight.cc.startanywhere.repository",
                "com.alight.cc.startanywhere.entity",
                "com.alight.cc.startanywhere.model",
                "com.alight.cc.model"
                
            );
        em.setJpaVendorAdapter(new HibernateJpaVendorAdapter());

        Properties properties = new Properties();
        properties.setProperty("hibernate.dialect", bean.getDialect());
        properties.setProperty("hibernate.show_sql", bean.getShow_sql());
        em.setJpaProperties(properties);

        return em;
    }

    @Bean(name = "PostgresDataSource")
    public DataSource PostgresDataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName(bean.getDriverClassName());
        String dbUrl = bean.getPostgresServerDBUrl()+bean.getPostgresServerDatabase();
        dataSource.setUrl(dbUrl);
        
        Map<String, String> secrets = DockerSecretsUtil.load();
		if (!secrets.isEmpty()) {

			bean.setPostgresServerUserName(secrets.containsKey("postgresql.cc.startanywhere.user")
					? secrets.get("postgresql.cc.startanywhere.user") : "");
			bean.setPostgresServerPassword(secrets.containsKey("postgresql.cc.startanywhere.password")
					? secrets.get("postgresql.cc.startanywhere.password") : "");
		}
		 dataSource.setUsername(bean.getPostgresServerUserName().trim());
	     dataSource.setPassword(bean.getPostgresServerPassword().trim());
	     
        return dataSource;
    }

    @Bean(name = "PostgresTransactionManager")
    public PlatformTransactionManager PostgresTransactionManager(@Qualifier("PostgresEntityManagerFactory") EntityManagerFactory emf) {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(emf);
        transactionManager.setDataSource(PostgresDataSource());
        return transactionManager;
    }
}
