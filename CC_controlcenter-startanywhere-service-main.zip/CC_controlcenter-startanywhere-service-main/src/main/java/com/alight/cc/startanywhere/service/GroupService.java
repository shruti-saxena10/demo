package com.alight.cc.startanywhere.service;

import java.util.concurrent.CompletableFuture;

import com.alight.cc.startanywhere.model.CreateGroupsResponse;

import jakarta.validation.constraints.NotBlank;

public interface GroupService {
    //CompletableFuture<CreateGroupsResponse> createGroupsAsync(String sessionToken, String requestHeader, String clientId, String clientName);

	CreateGroupsResponse checkValidationBeforeAsync(String alightColleagueSessionToken, String alightRequestHeader,
			String clientId, String clientName);

	//CompletableFuture<CreateGroupsResponse> createGroupsAsyncC(String sessionToken, String requestHeader,
			//String clientId, String clientName);
}
