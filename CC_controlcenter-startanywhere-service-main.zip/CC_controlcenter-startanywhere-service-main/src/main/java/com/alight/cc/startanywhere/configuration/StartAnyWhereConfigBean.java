package com.alight.cc.startanywhere.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Configuration
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class StartAnyWhereConfigBean {
	
	@Value("${datasource.postgres.dbUrl}")
	private String postgresServerDBUrl;
	
	@Value("${datasource.postgres.driverClassName}")
	private String driverClassName;
	
	@Value("${datasource.postgres.database}")
	private String postgresServerDatabase;
	
	@Value("${datasource.postgres.credentials.userSecret}")
	private String postgresServerUserName;
	
	@Value("${datasource.postgres.credentials.passwordSecret}")
    private String postgresServerPassword;
    
	@Value("${datasource.postgres.hibernate.dialect}")
    private String dialect;
	
	@Value("${datasource.postgres.hibernate.show_sql}")
    private String show_sql;
	
}
