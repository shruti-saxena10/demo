package com.alight.cc.startanywhere.exception;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.http.HttpStatus;

public class CCServiceException extends RuntimeException {

    private HttpStatus httpStatus;

    public CCServiceException(HttpStatus httpStatus, String errorMessage) {
        super(errorMessage);
        this.httpStatus = httpStatus;
    }

    public CCServiceException(HttpStatus httpStatus, String errorMessage, Throwable cause) {
        super(errorMessage, cause);
        this.httpStatus = httpStatus;
    }

    public String getMessage() {
        Throwable cause = this.getCause() != null ? ExceptionUtils.getRootCause(this) : null;
        if (cause != null) {
            StringBuilder msgBuilder = new StringBuilder(super.getMessage());
            return msgBuilder.append("( Cause: ")
                    .append(cause.getLocalizedMessage())
                    .append(")")
                    .toString();
        }
        return super.getMessage();
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }
}
