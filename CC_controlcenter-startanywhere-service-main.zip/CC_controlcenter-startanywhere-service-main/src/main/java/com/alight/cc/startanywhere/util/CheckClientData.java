package com.alight.cc.startanywhere.util;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.alight.asg.model.header.v1_0.RequestHeader;
import com.alight.cc.startanywhere.entity.ClientEntity;
import com.alight.cc.startanywhere.exception.DuplicateClientException;
import com.alight.cc.startanywhere.model.BaseResponse;
import com.alight.cc.startanywhere.repository.ClientRepository;
import com.alight.logging.helpers.InfoTypeLogEventHelper;


@Component
public class CheckClientData {

	@Autowired
	ClientRepository clientRepo;

	@SuppressWarnings("unchecked")
	public ResponseEntity<Object> isNotValidClient(String clientId, String orgName) {
		ArrayList errors = new ArrayList<>();
		String message = null;
		DuplicateClientException ex = null;
		ClientEntity entityClientId = clientRepo.findByClientIdIgnoreCase(clientId);
		ClientEntity entityOrgName =clientRepo.findByOrgNameIgnoreCase(orgName);
		if ((entityClientId == null && entityOrgName != null) ||
				(entityClientId != null && entityOrgName == null)) {
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Client id %s or org name %s not valid");
			message = String.format(StartAnyWhereConstants.CLIENT_NOT_VALID_MESSAGE, 
					clientId, orgName);

			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Not valid client: " + message);
			ex = new DuplicateClientException(message);

			BaseResponse response = StartAnywhereUtil.buildResponse(
					new BaseResponse(),
					StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
					StartAnyWhereConstants.BAD_REQUEST,
					StartAnyWhereConstants.POS106,
					ex.getMessage(),
					StartAnyWhereConstants.HIGH,
					null,
					errors
					);

			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		else if (entityClientId == null && entityOrgName == null) {
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
					StartAnyWhereConstants.CLIENT_DOESNT_EXIST_IN_POSTGRES_DB + clientId);
			BaseResponse response=  StartAnywhereUtil.buildResponse(new BaseResponse(),
					StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
					StartAnyWhereConstants.BAD_REQUEST,
					StartAnyWhereConstants.POS106, StartAnyWhereConstants.CLIENT_DOESNT_EXIST_IN_POSTGRES_DB,
					StartAnyWhereConstants.HIGH, null, errors);


			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
		return null;
	}


	@SuppressWarnings("unchecked")
	public ResponseEntity<Object> isCheckRequestHeader(String alightRequestHeader) throws IOException {
		alightRequestHeader = StartAnywhereSecurityUtil.unCleanIt(alightRequestHeader);
		RequestHeader parsedRequestHeader = RequestHeader.parse(alightRequestHeader);
		String locale_code = parsedRequestHeader.getLocale();
		if (StringUtils.isBlank(locale_code)) 
		{
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Missing required parameters alightRequestHeader." +alightRequestHeader );
			ArrayList errors = new ArrayList<>();

			BaseResponse response=StartAnywhereUtil.buildResponse(
					new BaseResponse(),
					StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
					StartAnyWhereConstants.BAD_REQUEST,
					StartAnyWhereConstants.POS106,
					StartAnyWhereConstants.MISSING_REQUIRED_PARAMETERS_MESSAGE,
					StartAnyWhereConstants.HIGH,
					null,
					errors
					);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST)
					.body(response);

		}
		return null;

	}
}
