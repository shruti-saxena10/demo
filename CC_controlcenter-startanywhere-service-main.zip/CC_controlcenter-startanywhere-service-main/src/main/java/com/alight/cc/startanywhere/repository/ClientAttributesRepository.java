package com.alight.cc.startanywhere.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.alight.cc.startanywhere.entity.ClientAttributesEntity;

@Repository
public interface ClientAttributesRepository extends JpaRepository<ClientAttributesEntity, Long> {
	@Query("SELECT ca FROM ClientAttributesEntity ca WHERE ca.client.clientId = :clientId")
    List<ClientAttributesEntity> findByControlCenterClientId(@Param("clientId") String clientId);
	@Modifying
	@Query("DELETE  FROM ClientAttributesEntity ca WHERE ca.client.clientId = :clientId")		
	void deleteByControlCenterClientId(@Param("clientId")String clientId);
}
