package com.alight.cc.startanywhere.feign;

import org.json.simple.JSONObject;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.alight.cc.dto.UserOrganizationDetailResponseDTO;
import com.alight.cc.startanywhere.configuration.SaviyntClientConfig;
import com.alight.cc.startanywhere.model.OrganizationUserDetailResponseDTO;
import com.alight.cc.startanywhere.saviynt.model.CreateOrganizationRequest;
import com.alight.cc.startanywhere.saviynt.model.CreateOrganizationResponse;
import com.alight.cc.startanywhere.saviynt.model.CreateRequest;
import com.alight.cc.startanywhere.saviynt.model.EntitlementsResponse;
import com.alight.cc.startanywhere.saviynt.model.GetAccountsRequest;
import com.alight.cc.startanywhere.saviynt.model.GetAccountsResponse;
import com.alight.cc.startanywhere.saviynt.model.GetEntitlementsRequest;
import com.alight.cc.startanywhere.saviynt.model.GetUserRequest;
import com.alight.cc.startanywhere.saviynt.model.LoginData;
import com.alight.cc.startanywhere.saviynt.model.OrganisationUserDetailRequest;
import com.alight.cc.startanywhere.saviynt.model.UpdateOrganizationRequest;
import com.alight.cc.startanywhere.saviynt.model.UpdateOrganizationResponse;
import com.alight.cc.startanywhere.saviynt.model.UpdateUserEntitlementsRequest;
import com.alight.cc.startanywhere.saviynt.model.UserDetailsResponse;
import com.alight.cc.startanywhere.saviynt.model.UserOrganisationDetailRequest;


//@FeignClient(name = "saviyntCloud", url = "https://alight-test-support.saviyntcloud.com", configuration = SaviyntClientConfig.class)





@FeignClient(name = "saviyntCloud", url = "${controlcenter.startanywhere.saviynt.url}", configuration = SaviyntClientConfig.class)
@Component
public interface SaviyntClient {

	@PostMapping(value = "/ECM/api/login", consumes = "application/json")
	JSONObject getAuthToken(@RequestBody LoginData data);

	@PostMapping(value = "/ECM/api/v5/getUser", consumes = "application/json", produces = "text/json;charset=utf-8")
	UserDetailsResponse getUser(@RequestHeader(value = "Authorization") String authorizationHeader,
			@RequestBody GetUserRequest getUserRequest);

	@PostMapping(value = "/ECM/api/v5/getEntitlements", consumes = "application/json")
	EntitlementsResponse getEntitlements(@RequestHeader(value = "Authorization") String authorizationHeader,
			@RequestBody GetEntitlementsRequest getEntitlementsRequest);

	// Response One user have a muliple clients
	@PostMapping(value = "/ECM/api/v5/getOrganizationUserDetails", consumes = "application/json")
	UserOrganizationDetailResponseDTO getOrganizationUserDetails(
			@RequestHeader(value = "Authorization") String authorizationHeader,
			@RequestBody UserOrganisationDetailRequest userDetailRequest);
	
	// Response One client have a muliple users
	@PostMapping(value = "/ECM/api/v5/getOrganizationUserDetails", consumes = "application/json")// one client have muliple users
	OrganizationUserDetailResponseDTO getUserOrganizationDetails(
			@RequestHeader(value = "Authorization") String authorizationHeader,
			@RequestBody OrganisationUserDetailRequest userDetailRequest);

	@PostMapping(value = "/ECM/api/v5/createOrganization", consumes = "application/json")
	CreateOrganizationResponse createOrganization(@RequestHeader(value = "Authorization") String authorizationHeader,
			@RequestBody CreateOrganizationRequest updateOrgRequest);

	@PostMapping(value = "/ECM/api/v5/updateOrganizationUsers", consumes = "application/json")
	UpdateOrganizationResponse addUsersToOrganization(
			@RequestHeader(value = "Authorization") String authorizationHeader,
			@RequestBody UpdateOrganizationRequest updateOrganizationRequest);
	@PostMapping(value = "/ECM/api/v5/createrequest", consumes = "application/json")
    JSONObject createRequest(@RequestHeader(value = "Authorization") String authorizationHeader,
			@RequestBody CreateRequest createRequest);
	@PostMapping(value = "/ECM/api/v5/getAccounts", consumes = "application/json")
	GetAccountsResponse getAccounts(@RequestHeader(value = "Authorization") String authorizationHeader,
			@RequestBody GetAccountsRequest getAccountsRequest);
	@PostMapping( value = "/ECM/api/v5/createrequest", consumes = "application/json")
    JSONObject updateEntitlementsOnUser(@RequestHeader(value = "Authorization") String authorizationHeader,
                                         @RequestBody UpdateUserEntitlementsRequest getEntitlementsRequest);
	
}
