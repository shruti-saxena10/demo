package com.alight.cc.startanywhere.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EntitlementResponse {
    private String endpoint;
    private String entitlementValue;
    private String description;
    private String status;
    private List<EntitlementOwnerResponse> entitlementOwner;
}
