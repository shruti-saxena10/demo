package com.alight.cc.startanywhere.entity;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "client")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ClientEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
    private Long id;

	@Column(name = "client_id")
	private String clientId;
	
	@Column(name = "name")
    private String name;
	
	@Column(name = "environment_id")
    private Long environmentId;
	
	@Column(name = "created_at")
    private Date createdAt;
	
	@Column(name = "updated_at")
    private Date updatedAt;

	
	@Column(name = "scrm_id")
    private String scrmId;
	
	@Column(name = "org_name")
    private String orgName;
	
	@Column(name = "legal_name")
    private String legalName;
	
	@Column(name = "lineage")
    private String lineage;
	
	@Column(name = "superview_restrict")
    private Boolean superviewRestrict;
	
	
}
