package com.alight.cc.startanywhere.service.impl;

import static com.alight.cc.startanywhere.util.StartAnyWhereConstants.FUNCTIONAL_ID;
import static com.alight.cc.startanywhere.util.StartAnyWhereConstants.LOW;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.json.simple.JSONObject;
import org.postgresql.util.PSQLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.alight.asg.model.header.v1_0.ResponseHeader;
import com.alight.asg.model.token.v1_0.ColleagueSessionToken;
import com.alight.cc.dto.AccountDTO;
import com.alight.cc.dto.OrganizationUserDTO;
import com.alight.cc.dto.UpdateOrganizationRequestDTO;
import com.alight.cc.startanywhere.configuration.SaviyntConfigurationBean;
import com.alight.cc.startanywhere.entity.SecurityManagerEntitlementEntity;
import com.alight.cc.startanywhere.model.BaseResponse;
import com.alight.cc.startanywhere.model.ClientConfigError;
import com.alight.cc.startanywhere.model.ClientConfigurationRequest;
import com.alight.cc.startanywhere.model.ClientConfigurationResponse;
import com.alight.cc.startanywhere.model.ClientModel;
import com.alight.cc.startanywhere.model.CreateOrganizationRequestDTO;
import com.alight.cc.startanywhere.model.SecurityManagerEmail;
import com.alight.cc.startanywhere.repository.SecurityManagerEntitlementRepository;
import com.alight.cc.startanywhere.saviynt.model.CreateOrganizationResponse;
import com.alight.cc.startanywhere.saviynt.model.CreateRequest;
import com.alight.cc.startanywhere.saviynt.model.Entitlement;
import com.alight.cc.startanywhere.saviynt.model.EntitlementDetail;
import com.alight.cc.startanywhere.saviynt.model.EntitlementsResponse;
import com.alight.cc.startanywhere.saviynt.model.UpdateOrganizationResponse;
import com.alight.cc.startanywhere.saviynt.model.User;
import com.alight.cc.startanywhere.service.AccountService;
import com.alight.cc.startanywhere.service.ClientConfigurationService;
import com.alight.cc.startanywhere.service.ClientOnboardingRequestTrackService;
import com.alight.cc.startanywhere.service.EntitlementService;
import com.alight.cc.startanywhere.service.OrganizationService;
import com.alight.cc.startanywhere.service.UserService;
import com.alight.cc.startanywhere.util.CheckClientDuplicacy;
import com.alight.cc.startanywhere.util.SaviyntRequestBuilder;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;
import com.alight.cc.startanywhere.util.StartAnywhereSecurityUtil;
import com.alight.cc.startanywhere.util.StartAnywhereUtil;
import com.alight.logging.helpers.InfoTypeLogEventHelper;
import com.aonhewitt.logging.events.ErrorLogEvent;
import com.aonhewitt.logging.helpers.ErrorLogEventHelper;
import com.fasterxml.jackson.core.JsonProcessingException;

import feign.FeignException;

@Service
public class ClientConfigurationServiceImpl implements ClientConfigurationService {

	@Autowired
	UserService userService;

	@Autowired
	OrganizationService orgService;

	@Autowired
	AccountService accountService;

	@Autowired
	EntitlementService entitlementService;

	@Autowired
	SaviyntRequestBuilder requestBuilder;

	@Autowired
	StartAnywhereClientServiceImpl pgService;
	@Autowired
	ClientOnboardingRequestTrackService trackService;
	@Autowired
	SecurityManagerEntitlementRepository entitlementRepo;
	@Autowired
	CheckClientDuplicacy checkClientDuplicacy;
	
	@Autowired
    private SaviyntConfigurationBean saviyntConfig;
	@Override
	public ResponseEntity<Object> createClientConfiguration(String alightRequestHeader,
			String alightColleagueSessionToken, ClientConfigurationRequest configRequest)
			throws JsonProcessingException, IOException {
		// TODO Auto-generated method stub
		InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Method execution Started in Main Service: ");

		List<ClientConfigError> errors = new ArrayList<>();
		BaseResponse response = new BaseResponse();
		InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Checking the status of the correlation Id");
		ResponseEntity<Object> status = trackService.checkStatus(alightRequestHeader, configRequest);
		if (status != null) {
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Entry for this correlation ID found");
			return status;
		}
		InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "No Entries for this correlation ID found");
		InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Saving the correlation Id in tracker");
		trackService.saveTrack(alightRequestHeader, configRequest);
//		At the very start check if Client already exists in Postgress DB or not
		BaseResponse duplicateClient = checkClientDuplicacy.isDuplicateClient(configRequest.getClientId(),
				configRequest.getOrgName(), configRequest.getClientName());
		if (duplicateClient != null) {
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Client already exists in Postgres DB");
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Updating the correlation Id in tracker");
			errors.addAll(duplicateClient.getErrors());
			trackService.updateTrack(alightRequestHeader, configRequest, errors, duplicateClient);
			return new ResponseEntity<>(duplicateClient, HttpStatus.BAD_REQUEST);
		} else {
//			First check if ADGroups are available in saviynt or not
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Generating accessToken");
			String accessToken = "";
			try {
				accessToken = userService.getAccessToken();

			} catch (FeignException fe) {
				HttpStatus excStatus = HttpStatus.valueOf(fe.status());
				if (excStatus != null && excStatus == HttpStatus.UNAUTHORIZED) {
					response = StartAnywhereUtil.buildResponse(new BaseResponse(),
							StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR,
							StartAnyWhereConstants.INTERNAL_SERVER_ERROR, StartAnyWhereConstants.SAV102,
							StartAnyWhereConstants.SAVIYNT_FUNCTIONAL_ID_AND_PASSWORD_INVALID,
							StartAnyWhereConstants.HIGH, null, errors);
					InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
							"Updating the correlation Id in tracker");
					trackService.updateTrack(alightRequestHeader, configRequest, errors, response);
					return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
				} else {
					response = StartAnywhereUtil.buildResponse(new BaseResponse(),
							StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR,
							StartAnyWhereConstants.INTERNAL_SERVER_ERROR, StartAnyWhereConstants.SAV101,
							StartAnyWhereConstants.SAVIYNT_SERVER_UNREACHABLE, StartAnyWhereConstants.HIGH, null,
							errors);
					InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
							"Updating the correlation Id in tracker");
					trackService.updateTrack(alightRequestHeader, configRequest, errors, response);
					return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);

				}

			}
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
					"Fetching entitlements for Security managers from Postgress DB");
			List<SecurityManagerEntitlementEntity> entityList = entitlementRepo.findByIsSecuritymanager(1);
			List<String> entitlementList = entityList.stream()
					.map(e -> e.getDisplayName().replace("<ClientID>", configRequest.getClientId()))
					.collect(Collectors.toList());
			List<String> entitlementListCopy = new ArrayList<String>(entitlementList);
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
					"Fetching entitlements for Security managers from Saviynt");
			try {
				EntitlementsResponse entitlementsResponse = entitlementService.loadEntitlements(null, accessToken,
						configRequest.getClientId());

				int entitlementCount = entitlementsResponse.getTotalEntitlementCount();
				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
						"Total Entitlement Count is :" + entitlementCount);
				if (entitlementCount > 0) {
					List<String> targetEntitlements = entitlementsResponse.getEntitlementdetails().stream()
							.map(EntitlementDetail::getDisplayname).collect(Collectors.toList());
					if (targetEntitlements.size() > 0) {
						entitlementList.retainAll(targetEntitlements);
//						if (entitlementList.isEmpty()) {
//							InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
//									"Target ADGroups are not available for clientID :" + configRequest.getClientId());
//							response = StartAnywhereUtil.buildResponse(new BaseResponse(),
//									StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR,
//									StartAnyWhereConstants.INTERNAL_SERVER_ERROR, StartAnyWhereConstants.SAV011,
//									StartAnyWhereConstants.SAV011_MSG, StartAnyWhereConstants.HIGH, null, errors);
//							InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
//									"Updating the correlation Id in tracker");
//							trackService.updateTrack(alightRequestHeader, configRequest, errors);
//							return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
//
//						}
//						Check if any target entitlement is missing
						if (entitlementList.size() < 3) {
							Set<String> set1 = new HashSet<>(targetEntitlements);
							List<String> missing = entitlementListCopy.stream().filter(s -> !set1.contains(s))
									.collect(Collectors.toList());
							String msg = StartAnyWhereConstants.ENTITLEMENT;
							for (String s : missing) {
								msg = msg + s + " ,";

							}
							msg = msg + StartAnyWhereConstants.ENTITLEMENT_NOT_AVAILABLE;
							response = StartAnywhereUtil.buildResponse(response,
									StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR,
									StartAnyWhereConstants.INTERNAL_SERVER_ERROR, StartAnyWhereConstants.SAV008, msg,
									StartAnyWhereConstants.HIGH, null, errors);
							InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
									"Updating the correlation Id in tracker");
							trackService.updateTrack(alightRequestHeader, configRequest, errors, response);
							return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);

						}

					}

				} else {
					InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
							"ADGroups are not available for clientID :" + configRequest.getClientId());
					response = StartAnywhereUtil.buildResponse(new BaseResponse(),
							StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR,
							StartAnyWhereConstants.INTERNAL_SERVER_ERROR, StartAnyWhereConstants.SAV010,
							StartAnyWhereConstants.SAV010_MSG, StartAnyWhereConstants.HIGH, null, errors);
					InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
							"Updating the correlation Id in tracker");
					trackService.updateTrack(alightRequestHeader, configRequest, errors, response);
					return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);

				}
			} catch (FeignException fe) {
				ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), fe.getMessage(),
						"createClientConfiguration()", fe, ErrorLogEvent.ERROR_EVENT_TYPE);

				response = StartAnywhereUtil.buildResponse(response,
						StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR,
						StartAnyWhereConstants.INTERNAL_SERVER_ERROR, StartAnyWhereConstants.SAV009,
						StartAnyWhereConstants.SAV009_MSG, StartAnyWhereConstants.HIGH, null, errors);
				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
						"Updating the correlation Id in tracker");
				trackService.updateTrack(alightRequestHeader, configRequest, errors, response);
				return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);

			}
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
					"Fetching usernames for Security managers from Saviynt");

			List<SecurityManagerEmail> securityManagers = configRequest.getSecurityManagers();
			LinkedHashMap<String, String> validMailMap = new LinkedHashMap<>();
			LinkedHashMap<String, String> invalidMailMap = new LinkedHashMap<>();

//			call the userDetails service for each email id to find the Aid for them
			for (SecurityManagerEmail s : securityManagers) {
				String email = StartAnywhereSecurityUtil.cleanIt(s.getEmailId());
				try {
					InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
							"Fetching user details for :" + s.getEmailId());

					User u = userService.getUserProfile(s.getEmailId(), accessToken);
					if (u == null) {
						invalidMailMap.put(email, "invalid emailId");
						StartAnywhereUtil.buildResponse(response, null, null, StartAnyWhereConstants.SAV002,
								StartAnyWhereConstants.SECURITY_MANAGER_DOESNT_EXIST_IN_SAVIYNT,
								StartAnyWhereConstants.LOW, email, errors);

					} else {
						validMailMap.put(email, u.getUsername());
					}
				} catch (FeignException ex) {
					InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
							"Unable to fetch user details from Saviynt");
					ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), ex.getMessage(),
							"createClientConfiguration()", ex, ErrorLogEvent.ERROR_EVENT_TYPE);

					StartAnywhereUtil.buildResponse(response, null, null, StartAnyWhereConstants.SAV016,
							StartAnyWhereConstants.SAV016_MSG, StartAnyWhereConstants.LOW, email, errors);

				}
			}
//			check if there is any valid mail ids in request --?
			if (validMailMap.isEmpty()) {
				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
						"Not a single security manager provided is valid. But still moving ahead with Default value");
				
//				response = StartAnywhereUtil.buildResponse(response, StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
//						StartAnyWhereConstants.N0_VALID_SECURITY_MANAGER, null, null, null, null, errors);
//				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
//						"Updating the correlation Id in tracker");
//				trackService.updateTrack(alightRequestHeader, configRequest, errors, response);
//				return getResponseEntity(response, StartAnyWhereConstants.N0_VALID_SECURITY_MANAGER,
//						HttpStatus.BAD_REQUEST, null, StartAnyWhereConstants.N0_VALID_SECURITY_MANAGER);
			}
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
					"User detail fetching completed for all the Security managers");
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
					"Fetching accountName for Security managers");

//			Get account details for the valid security managers
			LinkedHashMap<String, String> accountMap = new LinkedHashMap<>();
			Iterator<Map.Entry<String, String>> itr = validMailMap.entrySet().iterator();
			while (itr.hasNext()) {
				Map.Entry<String, String> e = itr.next();
				try {
					InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
							"Fetching accountName for:" + e.getKey());

					List<AccountDTO> accounts = accountService.getAccounts(e.getValue(), accessToken);
					if (accounts.isEmpty()) {
						StartAnywhereUtil.buildResponse(response, null, null, StartAnyWhereConstants.SAV015,
								StartAnyWhereConstants.SAV015_MSG, StartAnyWhereConstants.LOW, e.getKey(), errors);

						itr.remove();
					} else {
						Optional<AccountDTO> account = accounts.stream().filter(
								a -> a.getStatus().equals(StartAnyWhereConstants.GET_REQUEST_USER_ACTIVE_STATUS))
								.findFirst().or(() -> accounts.stream()
										.filter(a -> a.getStatus().equals(StartAnyWhereConstants.MANUALLY_PROVISIONED_STATUS)).findFirst());
//					email to account name mapping
						if (account.isPresent())
							accountMap.put(e.getKey(), account.get().getAccountname());
						else {
							StartAnywhereUtil.buildResponse(response, null, null, StartAnyWhereConstants.SAV017,
									StartAnyWhereConstants.SAV017_MSG, StartAnyWhereConstants.LOW, e.getKey(), errors);

							itr.remove();
						}

					}
				} catch (FeignException ex) {
					ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), ex.getMessage(),
							"createClientConfiguration()", ex, ErrorLogEvent.ERROR_EVENT_TYPE);
					StartAnywhereUtil.buildResponse(response, null, null, StartAnyWhereConstants.SAV014,
							StartAnyWhereConstants.SAV014_MSG, StartAnyWhereConstants.LOW, e.getKey(), errors);

				}
			}
			if (accountMap.isEmpty()) {
				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
						"Not a single security manager has a valid Account. But still moving ahead with Default value");
				
//				StartAnywhereUtil.buildResponse(response, StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR,
//						StartAnyWhereConstants.SECURTY_MANAGERS_DONOT_HAVE_ACCOUNTS, null, null, null, null, errors);
//				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
//						"Updating the correlation Id in tracker");
//				trackService.updateTrack(alightRequestHeader, configRequest, errors, response);				
//				return getResponseEntity(response, StartAnyWhereConstants.SECURTY_MANAGERS_DONOT_HAVE_ACCOUNTS,
//						HttpStatus.INTERNAL_SERVER_ERROR, null,
//						StartAnyWhereConstants.SECURTY_MANAGERS_DONOT_HAVE_ACCOUNTS);

			}
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
					"Fetching accountNames for all Security managers completed");

			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Creating org with Funtional ID");

			CreateOrganizationRequestDTO createOrfReq = CreateOrganizationRequestDTO.builder()
					.organizationname(configRequest.getClientId()).username(saviyntConfig.getRequestor()).build();
			try {
				CreateOrganizationResponse createOrgResp = orgService.createOrganization(createOrfReq, accessToken);
				if (createOrgResp.getStatusCode() == 200) {
					InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Orgnaisation created successfully");
				}

			} catch (FeignException ex) {
				HttpStatus excStatus = HttpStatus.valueOf(ex.status());
				if (excStatus != null && excStatus.value() == 412) {
					InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
							"Orgnaisation already exists. So adding the Security Managers");
					StartAnywhereUtil.buildResponse(response, null, null, StartAnyWhereConstants.SAV001,
							StartAnyWhereConstants.SAV001_MSG, StartAnyWhereConstants.LOW, null, errors);
				} else {
					ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), ex.getMessage(),
							"createClientConfiguration()", ex, ErrorLogEvent.ERROR_EVENT_TYPE);
					StartAnywhereUtil.buildResponse(response, StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR,
							StartAnyWhereConstants.ORG_CREATION_FAILED, null, null, null, null, errors);
					InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
							"Updating the correlation Id in tracker");
					trackService.updateTrack(alightRequestHeader, configRequest, errors, response);
					return getResponseEntity(response, StartAnyWhereConstants.ORG_CREATION_FAILED,
							HttpStatus.INTERNAL_SERVER_ERROR, ex, StartAnyWhereConstants.ORG_CREATION_FAILED);
				}

			}
			List<Entitlement> entitlements = requestBuilder.buildEntitlementArray(entitlementList,
					configRequest.getClientId());
//			Add Christina's details		
			validMailMap.put(saviyntConfig.getDefaultEmailID(), saviyntConfig.getDefaultUserName());
			accountMap.put(saviyntConfig.getDefaultEmailID(), saviyntConfig.getDefaultAccountName());
			Iterator<Map.Entry<String, String>> itr1 = validMailMap.entrySet().iterator();
//			Iterate throw each aid and hit the update endpoint
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
					"Adding security managers to Organisation one by one");

			while (itr1.hasNext()) {
				Map.Entry<String, String> e = itr1.next();
				String mailId = e.getKey();
				String userName = e.getValue();
				String accountName = accountMap.get(mailId);

				try {
					InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
							"Adding organisation for : " + mailId);

					UpdateOrganizationResponse updateOrgResp = updateOrgUser("ADD", configRequest, userName,
							accessToken);
					if (updateOrgResp.getStatusCode() == 200) {
						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
								"User added successfully : " + mailId);

					}

				} catch (FeignException ex) {
					HttpStatus excStatus = HttpStatus.valueOf(ex.status());
//					Check if that user already exists for the org
					if (excStatus != null && excStatus.value() == 412) {
						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
								"User already exists in Saviynt for this org :" + mailId);
						ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), ex.getMessage(),
								"createClientConfiguration()", ex, ErrorLogEvent.ERROR_EVENT_TYPE);
						StartAnywhereUtil.buildResponse(response, null, null, StartAnyWhereConstants.SAV003,
								StartAnyWhereConstants.SAV003_MSG, StartAnyWhereConstants.LOW, mailId, errors);

					} else {
						ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), StartAnyWhereConstants.SAV013_MSG,
								"createClientConfiguration()", ex, ErrorLogEvent.ERROR_EVENT_TYPE);

						StartAnywhereUtil.buildResponse(response, null, null, StartAnyWhereConstants.SAV013,
								StartAnyWhereConstants.SAV013_MSG, StartAnyWhereConstants.LOW, mailId, errors);

//							remove from valid map so that we can check the count before adding it to postgress
						itr1.remove();
//				             skip rest of the operation for this security manager
						continue;
					}

				}

				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
						"Adding entitlements to security manager :" + mailId);
				CreateRequest cr = requestBuilder.buildAccountRequest(entitlements, userName, accountName);
				try {
					JSONObject createResponse = accountService.createRequestBulk(cr, accessToken);
					InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
							"Bulk request sent : " + createResponse.toJSONString() + "for :" + mailId);

				} catch (FeignException fe) {
					HttpStatus excStatus = HttpStatus.valueOf(fe.status());
					if (excStatus != null && excStatus.value() == 412) {
						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
								"Bulk request failed due to precondition check");
						ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), StartAnyWhereConstants.SAV012_MSG,
								"createClientConfiguration()", fe, ErrorLogEvent.ERROR_EVENT_TYPE);

						StartAnywhereUtil.buildResponse(response, null, null, StartAnyWhereConstants.SAV012,
								StartAnyWhereConstants.SAV012_MSG, StartAnyWhereConstants.LOW, mailId, errors);

						itr1.remove();
					} else {
						ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), StartAnyWhereConstants.SAV004_MSG,
								"createClientConfiguration()", fe, ErrorLogEvent.ERROR_EVENT_TYPE);

						StartAnywhereUtil.buildResponse(response, null, null, StartAnyWhereConstants.SAV004,
								StartAnyWhereConstants.SAV004_MSG, StartAnyWhereConstants.LOW, mailId, errors);

						itr1.remove();
					}

				}

			}
			if (validMailMap.isEmpty()) {
				StartAnywhereUtil.buildResponse(response, StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR,
						StartAnyWhereConstants.ALL_REQUESTS_FAILED, null, null, null, null, errors);
				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
						"Updating the correlation Id in tracker");
				trackService.updateTrack(alightRequestHeader, configRequest, errors, response);
				
				return getResponseEntity(response, StartAnyWhereConstants.CONFIGURATION_FAILED,
						HttpStatus.INTERNAL_SERVER_ERROR, null, null);

			} else {
				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
						"Saviynt steps are completed. Moving ahead with Postgress Insert");

				ClientModel cm = ClientModel.builder().clientId(configRequest.getClientId())
						.clientName(configRequest.getClientName())
						.isDataRestriction(configRequest.getIsDataRestriction()).orgName(configRequest.getOrgName())
						.build();
				try {
					alightColleagueSessionToken =StartAnywhereSecurityUtil.cleanIt(alightColleagueSessionToken);
					alightColleagueSessionToken = StartAnywhereSecurityUtil.unCleanIt(alightColleagueSessionToken);
					ColleagueSessionToken colleagueSessionToken = ColleagueSessionToken.parse(alightColleagueSessionToken);
					String ColleagueEmailId = getRequestorMailId(colleagueSessionToken);				
					ResponseEntity<Object> pgResponse = pgService.addNewclientdetails(alightColleagueSessionToken,
							alightRequestHeader, ColleagueEmailId, cm);
					if (pgResponse.getStatusCode().is2xxSuccessful()) {
						BaseResponse r = (BaseResponse) pgResponse.getBody();
						if (r.getErrors() != null)
							errors.addAll(r.getErrors());
						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Postgress save completed");
						
						StartAnywhereUtil.buildResponse(response, StartAnyWhereConstants.HTTP_STATUS_SUCCESS,
								StartAnyWhereConstants.CONFIGURATION_SUCCESSFUL, null, null, null, null, errors);
						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
								"Updating the correlation Id in tracker");
						trackService.updateTrack(alightRequestHeader, configRequest, errors, response);
						return getResponseEntity(response, StartAnyWhereConstants.CONFIGURATION_SUCCESSFUL,
								HttpStatus.OK, null, null);
					}
					if (pgResponse.getStatusCode().is5xxServerError()) {
						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
								"Postgress save is responding with 5xx");
						BaseResponse r = (BaseResponse) pgResponse.getBody();
						if (r.getErrors() != null)
							errors.addAll(r.getErrors());
						StartAnywhereUtil.buildResponse(response,
								StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR,
								StartAnyWhereConstants.INTERNAL_SERVER_ERROR, null, null, null, null, errors);
						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
								"Updating the correlation Id in tracker");
						trackService.updateTrack(alightRequestHeader, configRequest, errors, response);
						
						return getResponseEntity(response, StartAnyWhereConstants.CONFIGURATION_FAILED,
								HttpStatus.INTERNAL_SERVER_ERROR, null, null);

					}
				} catch (PSQLException | IOException e) {
					// TODO Auto-generated catch block
					ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
							StartAnyWhereConstants.POSTGRESS_SAVE_FAILED, "createClientConfiguration()", e,
							ErrorLogEvent.ERROR_EVENT_TYPE);
					StartAnywhereUtil.buildResponse(response, StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR,
							StartAnyWhereConstants.POSTGRESS_SAVE_FAILED, null, null, null, null, errors);
					InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
							"Updating the correlation Id in tracker");
					trackService.updateTrack(alightRequestHeader, configRequest, errors, response);					
					return getResponseEntity(response, StartAnyWhereConstants.POSTGRESS_SAVE_FAILED,
							HttpStatus.INTERNAL_SERVER_ERROR, null, null);
				}
			}
			return null;

		}

	}

	public String getRequestorMailId(ColleagueSessionToken colleagueToken) {
		// TODO Auto-generated method stub
		String adminId="";
		try
		{
			boolean ldapKey = colleagueToken.getColleagueSessionMap().containsKey(ColleagueSessionToken.CREDENTIALS_LDAP_ID);
			if(ldapKey)
			{
				adminId = colleagueToken.getColleagueSessionMapEntry(ColleagueSessionToken.CREDENTIALS_LDAP_ID);	

			}
			else if(colleagueToken.getColleagueSessionMap().containsKey("credentials.ldap.HEWITT-NA.id"))
			{
				adminId = colleagueToken.getColleagueSessionMapEntry("credentials.ldap.HEWITT-NA.id");
			}
			else
			{
				adminId = saviyntConfig.getRequestor();
			}
		}

		catch(Exception exception)
		{
			ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),"Exception occurred while fetching requestor mail Id",
					" getRequestorMailId()", exception, ErrorLogEvent.ERROR_SEVERITY);
			adminId = saviyntConfig.getRequestor();
			return adminId;
		}
		adminId = adminId!=null?adminId:saviyntConfig.getRequestor();
		return adminId;
	}

	private UpdateOrganizationRequestDTO buildAddOrgUserDTO(ClientConfigurationRequest configRequest, String aid) {
		// TODO Auto-generated method stub
		List<OrganizationUserDTO> userDTOList = new ArrayList<>();
		OrganizationUserDTO userDTO = new OrganizationUserDTO(aid, "ADD");
		userDTOList.add(userDTO);
		UpdateOrganizationRequestDTO updateOrgReqDTO = new UpdateOrganizationRequestDTO(configRequest.getClientId(),
				saviyntConfig.getRequestor(), userDTOList);
		return updateOrgReqDTO;
	}

	private UpdateOrganizationRequestDTO buildRemoveOrgUserDTO(ClientConfigurationRequest configRequest, String aid) {
		// TODO Auto-generated method stub
		List<OrganizationUserDTO> userDTOList = new ArrayList<>();
		OrganizationUserDTO userDTO = new OrganizationUserDTO(aid, "Remove");
		userDTOList.add(userDTO);
		UpdateOrganizationRequestDTO updateOrgReqDTO = new UpdateOrganizationRequestDTO(configRequest.getClientId(),
				saviyntConfig.getRequestor(), userDTOList);
		return updateOrgReqDTO;
	}

	public UpdateOrganizationResponse updateOrgUser(String updateType, ClientConfigurationRequest configRequest,
			String aid, String accessToken) {
		UpdateOrganizationResponse updateOrgResp = null;
		if (updateType.equalsIgnoreCase("ADD"))
			updateOrgResp = orgService.updateUserToOrganization(buildAddOrgUserDTO(configRequest, aid), accessToken);
		else
			updateOrgResp = orgService.updateUserToOrganization(buildRemoveOrgUserDTO(configRequest, aid), accessToken);
		return updateOrgResp;
	}

//	public static <T> List<List<T>> partitionList(List<T> list, int maxSize) {
//		List<List<T>> partitions = new ArrayList<>();
//		for (int i = 0; i < list.size(); i += maxSize) {
//			partitions.add(list.subList(i, Math.min(i + maxSize, list.size())));
//		}
//		return partitions;
//	}

	private ResponseEntity<Object> getResponseEntity(BaseResponse response, String responseMessage,
			HttpStatus responseStatus, Exception ex, String debugMessage) {

		HttpHeaders httpHeaders = new HttpHeaders();
		ResponseEntity<Object> responseEntity = null;

		try {
			String resCd = (responseStatus == HttpStatus.OK) ? "0" : "-999";
			String resMsg = (responseMessage != null) ? responseMessage : "";
			ResponseHeader responseHeader = new ResponseHeader();
			responseHeader.setResponseCode(resCd);
			responseHeader.setResponseDescription(resMsg);
			httpHeaders.add("alightResponseHeader", responseHeader.toJson());
		} catch (JsonProcessingException e) {
			httpHeaders = null;
		}

		if (ex != null) {
			ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), "Error in configuring client :",
					"createClientConfiguration()", ex, ErrorLogEvent.ERROR_SEVERITY);
			responseEntity = new ResponseEntity<Object>(ex, httpHeaders, responseStatus);
		} else {
			if (debugMessage != null) {
				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
						"createClientConfiguration()" + debugMessage);
			}
			responseEntity = new ResponseEntity<Object>(response, httpHeaders, responseStatus);
		}

		return responseEntity;
	}
}
