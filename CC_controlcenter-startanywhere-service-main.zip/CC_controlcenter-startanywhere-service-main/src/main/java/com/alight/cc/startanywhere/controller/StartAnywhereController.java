package com.alight.cc.startanywhere.controller;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alight.asg.model.token.v1_0.ColleagueSessionToken;
import com.alight.cc.startanywhere.model.BaseResponse;
import com.alight.cc.startanywhere.model.ClientConfigError;
import com.alight.cc.startanywhere.model.ClientConfigurationRequest;
import com.alight.cc.startanywhere.model.ClientConfigurationResponse;
import com.alight.cc.startanywhere.model.ClientModel;
import com.alight.cc.startanywhere.model.ClientRequest;
import com.alight.cc.startanywhere.model.ClientResponse;
import com.alight.cc.startanywhere.model.CreateGroupsResponse;
import com.alight.cc.startanywhere.service.ClientConfigurationService;
import com.alight.cc.startanywhere.service.ClientDataRetrievalService;
import com.alight.cc.startanywhere.service.DeleteClientConfigurationService;
import com.alight.cc.startanywhere.service.FetchClientConfigurationService;
import com.alight.cc.startanywhere.service.GroupService;
import com.alight.cc.startanywhere.service.RemoveClientService;
import com.alight.cc.startanywhere.service.StartAnywhereClientService;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;
import com.alight.cc.startanywhere.util.StartAnywhereSecurityUtil;
import com.alight.cc.startanywhere.util.StartAnywhereUtil;
import com.alight.logging.helpers.InfoTypeLogEventHelper;
import com.aonhewitt.logging.events.ErrorLogEvent;
import com.aonhewitt.logging.helpers.ErrorLogEventHelper;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.exc.MismatchedInputException;

import jakarta.json.JsonException;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

@RestController
@Validated
public class StartAnywhereController {

	
	@Autowired
	private StartAnywhereClientService startAnywhereClientService;
	
	@Autowired
	private ClientDataRetrievalService clientDataRetrievalService;
	
	@Autowired
	RemoveClientService removeClientService;
	
	@Autowired
	FetchClientConfigurationService fetchClientConfigurationService;
	
	@Autowired
	ClientConfigurationService clientConfigService;
	@Autowired
	GroupService groupService;
	
	@Autowired
	private DeleteClientConfigurationService deleteClientConfigurationService;
	
	@PostMapping(value = "/clients", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> addNewclientdetails(
			@RequestHeader(name = "alightColleagueSessionToken", required = true) String alightColleagueSessionToken,
			@RequestHeader(name = "alightRequestHeader", required = true) String alightRequestHeader,
			@Valid @RequestBody(required = true) ClientModel request) throws JsonProcessingException
	{
		
		try {
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
					"Inside Controller add the new ClientDetails to PostgreSQL: "+request.getClientId());				
			alightColleagueSessionToken =StartAnywhereSecurityUtil.cleanIt(alightColleagueSessionToken);
			alightRequestHeader =StartAnywhereSecurityUtil.cleanIt(alightRequestHeader);
			alightColleagueSessionToken = StartAnywhereSecurityUtil.unCleanIt(alightColleagueSessionToken);
			ColleagueSessionToken colleagueSessionToken = ColleagueSessionToken.parse(alightColleagueSessionToken);
			String ColleagueEmailId = colleagueSessionToken.getLdapIdFromColleagueSessionToken();
			ResponseEntity<Object> res=	startAnywhereClientService.addNewclientdetails(alightColleagueSessionToken,alightRequestHeader,ColleagueEmailId,request);
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
					"Successfully added new ClientDetails to PostgreSQL from Controller : "+res);	
		    return res;
		}  
		catch (JsonException | JsonParseException | JsonMappingException  | UnsupportedEncodingException ex) {
			ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), "Unable to parse session token",
					"addClientdetails()", (Throwable) ex, ErrorLogEvent.ERROR_SEVERITY);
			
			List<ClientConfigError> errors = new ArrayList<>();
			BaseResponse response=StartAnywhereUtil.buildResponse(
	        		new BaseResponse(),
	             StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR,
	             StartAnyWhereConstants.INTERNAL_SERVER_ERROR,
	             StartAnyWhereConstants.POS500,
	             StartAnyWhereConstants.INVALID_TOKEN,
	             StartAnyWhereConstants.HIGH,
	             null,
	             errors
	     );
		        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
			
		}
		catch (Throwable ex) {
			ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), "Exception occurred while adding ClientDetails to PostgreSQL:",
					"addClientdetails()", ex, ErrorLogEvent.ERROR_SEVERITY);
			List<ClientConfigError> errors = new ArrayList<>();
			BaseResponse response=StartAnywhereUtil.buildResponse(
	        		new BaseResponse(),
	             StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR,
	             StartAnyWhereConstants.INTERNAL_SERVER_ERROR,
	             StartAnyWhereConstants.POS500,
	             StartAnyWhereConstants.INTERNAL_SERVER_ERROR,
	             StartAnyWhereConstants.HIGH,
	             null,
	             errors
	     );
		        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);

		}
	}

	@GetMapping(value = "/fetchClients", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ClientResponse> getClientDetails(
	        @RequestHeader(name = "alightColleagueSessionToken", required = true) String alightColleagueSessionToken,
	        @RequestHeader(name = "alightRequestHeader", required = true) String alightRequestHeader,
	        @RequestParam(name = "clientId", required = true) String clientId
	        ) {
	    try {
	       
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Method execution Statrt in Controller: ");
	        // Call Service
			ClientResponse response =new ClientResponse();
			if (clientId == null || clientId.trim().isEmpty()) {
				List<ClientConfigError> errors = new ArrayList<>();
			    return ResponseEntity.badRequest().body(
			        StartAnywhereUtil.buildResponse(
			        	response,
			            StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
			            StartAnyWhereConstants.BAD_REQUEST,
			            StartAnyWhereConstants.POS106,
			            StartAnyWhereConstants.BAD_REQUEST_MSG,
			            StartAnyWhereConstants.HIGH,
			            null,
			            errors
			        )
			    );
			}else {
	         response = clientDataRetrievalService.getClientData(
	                alightColleagueSessionToken, alightRequestHeader, clientId);
			}
	        if (StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR.equals(response.getResponseCode())) {
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
	        }
	        else if (StartAnyWhereConstants.HTTP_STATUS_SERVICE_UNAVAILABLE.equals(response.getResponseCode())) {
	        	return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(response);
	        }
	        
	        return ResponseEntity.ok(response);

	    } catch (Exception ex) {  // Catch generic exceptions properly
	        ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
	                "Exception occurred while retrieving client details",
	                "getClientDetails()", ex, ErrorLogEvent.ERROR_SEVERITY);

	        // Create an error response properly
	        List<ClientConfigError> errors = new ArrayList<>();
	        ClientResponse errorResponse=StartAnywhereUtil.buildResponse(
	        		new ClientResponse(),
	        		StartAnyWhereConstants.HTTP_STATUS_SERVICE_UNAVAILABLE,
	        		StartAnyWhereConstants.INTERNAL_SERVER_ERROR,
                    StartAnyWhereConstants.HTTP_STATUS_SERVICE_UNAVAILABLE,
                    StartAnyWhereConstants.INTERNAL_SERVER_ERROR,
                    StartAnyWhereConstants.HIGH,
                    null,
                    errors
            );
	        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(errorResponse);
	    }
	}
	@DeleteMapping(value = "/clients", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> deleteClientDetails(
			@RequestHeader(name = "alightColleagueSessionToken", required = true) String alightColleagueSessionToken,
			@RequestHeader(name = "alightRequestHeader", required = true) String alightRequestHeader,
			@RequestParam(name = "clientId",required = true) @NotBlank String clientId) {
		try {
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
					"Inside controler for deleteClientDetails flow");			
			alightColleagueSessionToken = StartAnywhereSecurityUtil.cleanIt(alightColleagueSessionToken);
			alightRequestHeader = StartAnywhereSecurityUtil.cleanIt(alightRequestHeader);
			return removeClientService.deleteClientDetails(alightColleagueSessionToken, alightRequestHeader, clientId);

		} catch (Exception ex) {
			  ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
		                "Exception occurred while retrieving client details",
		                "getClientDetails()", ex, ErrorLogEvent.ERROR_SEVERITY);

		        // Create an error response properly
		        List<ClientConfigError> errors = new ArrayList<>();
		        BaseResponse errorResponse=StartAnywhereUtil.buildResponse(
		        		new BaseResponse(),
		        		StartAnyWhereConstants.HTTP_STATUS_NOT_IMPLEMENTED,
	                    StartAnyWhereConstants.NOT_IMPLEMENTED,
	                    StartAnyWhereConstants.POS501,
	                    StartAnyWhereConstants.MSGFOR_POS501,
	                    StartAnyWhereConstants.HIGH,
	                    null,
	                    errors
	            );
		        return ResponseEntity.status(HttpStatus.NOT_IMPLEMENTED).body(errorResponse);

			}
	}
	@PostMapping(value = "/fetchClientConfigurations", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ClientConfigurationResponse> getClientConfigurationDetails(
        @RequestHeader(name = "alightColleagueSessionToken", required = true) String alightColleagueSessionToken,
        @RequestHeader(name = "alightRequestHeader", required = true) String alightRequestHeader,
        @RequestBody ClientRequest request
    ) {
	    try {
	       
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Method execution Statrt in Controller: ");
			
	        // Call validation method
						ClientConfigurationResponse validationResponse = fetchClientConfigurationService.validateClientRequest(alightRequestHeader, request);
						if (validationResponse != null) {
							if (StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST
									.equals(validationResponse.getResponseCode())) {
								return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(validationResponse);
							}
							}
						// Call Service
			ClientConfigurationResponse response = fetchClientConfigurationService.getClientConfigurationDetails(alightColleagueSessionToken,alightRequestHeader,request);
			if (StartAnyWhereConstants.HTTP_STATUS_SERVICE_UNAVAILABLE.equals(response.getResponseCode())) {
	        	return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(response);
	        }
			return ResponseEntity.ok(response);

	    } catch (Exception ex) {  // Catch generic exceptions properly
	        ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
	                "Exception occurred while retrieving client details",
	                "getClientDetails()", ex, ErrorLogEvent.ERROR_SEVERITY);

	        // Create an error response properly
	        ClientConfigurationResponse errorResponse = new ClientConfigurationResponse();
	        //errorResponse.setResponseMessage("Internal Server Error");
	        //errorResponse.setResponseCode("POS101");
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
	    }
	}
	
	@PostMapping(value = "/clientConfigurations", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> addClientConfiguration(
			@RequestHeader(name="alightRequestHeader",required = true) String alightRequestHeader,
			@RequestHeader(name="alightColleagueSessionToken",required = true) String alightColleagueSessionToken,
			@Valid @RequestBody ClientConfigurationRequest configRequest
			) {
		try {
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Method execution Started in Controller: ");
			// Sanitize the Inputs for CheckMarx compliance.
			alightRequestHeader = StartAnywhereSecurityUtil.cleanIt(alightRequestHeader);
//			alightColleagueSessionToken = StartAnywhereSecurityUtil.cleanIt(alightColleagueSessionToken);
			// Call Service Implementation method.
			if (alightRequestHeader == null || alightRequestHeader.trim().isEmpty()) {
			    return new ResponseEntity<Object>("Header cannot be empty",HttpStatus.BAD_REQUEST);
			}
//			Sanitize the request body
			 configRequest.setClientId(StartAnywhereSecurityUtil.cleanIt(configRequest.getClientId()));
			 configRequest.setClientId(StartAnywhereSecurityUtil.unCleanIt(configRequest.getClientId()));
			 configRequest.setClientName(StartAnywhereSecurityUtil.cleanIt(configRequest.getClientName()));
			 configRequest.setClientName(StartAnywhereSecurityUtil.unCleanIt(configRequest.getClientName()));
			 configRequest.setOrgName(StartAnywhereSecurityUtil.cleanIt(configRequest.getOrgName()));
			 configRequest.setOrgName(StartAnywhereSecurityUtil.unCleanIt(configRequest.getOrgName()));

			 
			ResponseEntity<Object> responseEntity = clientConfigService.createClientConfiguration(alightRequestHeader,
				alightColleagueSessionToken, configRequest);
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Method execution ended in Controller: ");
			return responseEntity;
		} catch (Exception colleagueException) {
			ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), "Exception occurred while creating client configuration",
				" addClientConfiguration()", colleagueException, ErrorLogEvent.ERROR_SEVERITY);
			return new ResponseEntity<Object>(colleagueException, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(value = "/ADGroups", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CreateGroupsResponse> createClientGroups(
            @RequestHeader(name = "alightColleagueSessionToken") String alightColleagueSessionToken,
            @RequestHeader(name = "alightRequestHeader") String alightRequestHeader,
            @RequestParam(name = "clientId") @NotBlank String clientId,
            @RequestParam(name = "clientName") @NotBlank String clientName) throws InterruptedException, ExecutionException {
		
		try {
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "execution start for createClientGroups()");
			CreateGroupsResponse checkValidationBeforeAsync = groupService.checkValidationBeforeAsync(alightColleagueSessionToken, alightRequestHeader, clientId, clientName);
			if(checkValidationBeforeAsync!=null) {
			
		  if(StartAnyWhereConstants.HTTP_STATUS_SUCCESS.equals(checkValidationBeforeAsync.getResponseCode())) {
				return ResponseEntity.status(HttpStatus.OK).body(checkValidationBeforeAsync);
			}
			else if (StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST
					.equals(checkValidationBeforeAsync.getResponseCode())) {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(checkValidationBeforeAsync);
			} else if (StartAnyWhereConstants.HTTP_STATUS_RATE_LIMIT_EXCEEDED
					.equals(checkValidationBeforeAsync.getResponseCode())) {
				return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).body(checkValidationBeforeAsync);
			}
			else if (StartAnyWhereConstants.POS201
					.equals(checkValidationBeforeAsync.getResponseCode())) {
				return ResponseEntity.status(HttpStatus.CREATED).body(checkValidationBeforeAsync);
			}
			}
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
					"Execution completed for createClientGroups() ");		
			} catch (Exception ex) {
			ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
					"Exception occurred while create groups details", "createGroup()", ex,
					ErrorLogEvent.ERROR_SEVERITY);
			List<ClientConfigError> errors = new ArrayList<>();
			CreateGroupsResponse response=StartAnywhereUtil.buildResponse(
					new CreateGroupsResponse(),
	             StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR,
	             StartAnyWhereConstants.INTERNAL_SERVER_ERROR,
	             null,
	             null,
	             null,
	             null,
	             errors
	     );
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		
		}
		return null;
		
    }
	
	@DeleteMapping(value = "/clientsConfigurations", consumes = MediaType.APPLICATION_JSON_VALUE,  produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getDeleteClientConfigurationDetails(
			@RequestHeader(name = "alightColleagueSessionToken", required = true) String alightColleagueSessionToken,
			@RequestHeader(name = "alightRequestHeader", required = true) String alightRequestHeader,
			@RequestParam(name = "clientId",required = true)
			@NotBlank(message = "clientId must not be blank") String clientId,
			@RequestParam(name = "orgName",required = true) 
			@NotBlank(message = "orgName must not be blank") String orgName,
			@RequestParam(name = "securityManagerEmailId", required = false) 
			List<@Email(message = "One or more emails are invalid")String> securityManagerEmailId) {
		try {

			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Method execution Start in Controller: ");
			List<String> securityManagerEmailIdList = new ArrayList<>();
 			alightColleagueSessionToken =StartAnywhereSecurityUtil.cleanIt(alightColleagueSessionToken);
			alightRequestHeader =StartAnywhereSecurityUtil.cleanIt(alightRequestHeader);
			clientId = StartAnywhereSecurityUtil.cleanIt(clientId);
			orgName = StartAnywhereSecurityUtil.cleanIt(orgName);
			securityManagerEmailIdList = Optional.ofNullable(securityManagerEmailId)
				    .orElse(Collections.emptyList())
				    .stream()
				    .map(StartAnywhereSecurityUtil::cleanIt)
				    .collect(Collectors.toList());

			ResponseEntity<Object> res=	deleteClientConfigurationService.getDeleteClientConfigurationDetails(alightColleagueSessionToken,alightRequestHeader,
					clientId, orgName, securityManagerEmailIdList);
			
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), " Method execution Ended from Controller: " +res);
			return res;

		} catch (Exception ex) {  
			// Catch generic exceptions properly
			ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
					"Exception occurred while retrieving client details",
					"getDeleteClientConfigurationDetails()", ex, ErrorLogEvent.ERROR_SEVERITY);

			// Create an error response properly
			List<ClientConfigError> errors = new ArrayList<>();
			BaseResponse errorResponse=StartAnywhereUtil.buildResponse(
					new BaseResponse(),
					StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR,
					StartAnyWhereConstants.INTERNAL_SERVER_ERROR,
					StartAnyWhereConstants.POS500,
					StartAnyWhereConstants.INTERNAL_SERVER_ERROR,
					StartAnyWhereConstants.HIGH,
					null,
					errors
					);
			
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
		}
	}

}
