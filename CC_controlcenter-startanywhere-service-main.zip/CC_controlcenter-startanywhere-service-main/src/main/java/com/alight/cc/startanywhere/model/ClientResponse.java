package com.alight.cc.startanywhere.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY) 
@JsonPropertyOrder({ "responseCode", "responseMessage","clientName", "orgName", "isDataRestriction","locationUserPII","reason","scrmId", "errors" })
public class ClientResponse extends BaseResponse implements Serializable {
    private static final long serialVersionUID = 1L;
    private String clientName;
    private String orgName;
    private Boolean isDataRestriction;
    private Boolean locationUserPII;
    private String reason;
    private String scrmId;   	
}
	