package com.alight.cc.startanywhere.util;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;

import com.alight.cc.startanywhere.model.BaseResponse;
import com.alight.cc.startanywhere.model.ClientConfigError;
import com.alight.cc.startanywhere.model.ClientResponse;

public class StartAnywhereUtil {

	public static <T extends BaseResponse> T buildResponse(
            T response,
            String responseCode,
            String responseMessage,
            String errorCode,
            String errorMessage,
            String errorSeverity,
            String emailId,
            List<ClientConfigError> errors) {

        response.setResponseCode(responseCode);
        response.setResponseMessage(responseMessage);

        ClientConfigError error = new ClientConfigError();
        error.setErrorCode(errorCode);
        error.setErrorMessage(errorMessage);
        error.setErrorSeverity(errorSeverity);
        error.setEmailId(emailId);

        //errors.add(error);
        if (isValidError(error)) {
            errors.add(error);
        }
        response.setErrors(errors);

        return response;
    }
	 public static int calculateSaviyntStatusCode(int saviyntResponseStatusCode) {
	        if (saviyntResponseStatusCode == 0) {
	            return HttpStatus.OK.value();
	        } else {
	            return HttpStatus.valueOf(saviyntResponseStatusCode).value();
	        }
}
	// Define the helper
	 private static boolean isValidError(ClientConfigError error) {
	     return error.getErrorCode() != null ||
	            error.getErrorMessage() != null ||
	            error.getErrorSeverity() != null ||
	            error.getEmailId() != null;
	 }
}