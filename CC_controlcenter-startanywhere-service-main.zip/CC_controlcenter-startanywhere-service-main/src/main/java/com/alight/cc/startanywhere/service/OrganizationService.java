package com.alight.cc.startanywhere.service;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import com.alight.cc.dto.UpdateOrganizationRequestDTO;
import com.alight.cc.dto.UserOrganizationDetailResponseDTO;
import com.alight.cc.startanywhere.exception.CCServiceException;
import com.alight.cc.startanywhere.feign.SaviyntClient;
import com.alight.cc.startanywhere.model.CreateOrganizationRequestDTO;
import com.alight.cc.startanywhere.model.OrganizationUserDetailResponseDTO;
import com.alight.cc.startanywhere.saviynt.model.CreateOrganizationResponse;
import com.alight.cc.startanywhere.saviynt.model.OrganisationUserDetailRequest;
import com.alight.cc.startanywhere.saviynt.model.CreateOrganizationRequest;
import com.alight.cc.startanywhere.saviynt.model.OrganizationUser;
import com.alight.cc.startanywhere.saviynt.model.UpdateOrganizationRequest;
import com.alight.cc.startanywhere.saviynt.model.UpdateOrganizationResponse;
import com.alight.cc.startanywhere.saviynt.model.UserOrganisationDetailRequest;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;
import com.alight.cc.startanywhere.util.StartAnywhereUtil;
import com.alight.logging.helpers.InfoTypeLogEventHelper;

import feign.FeignException;

@Service
public class OrganizationService {

	@Autowired
	UserService userService;

	@Autowired
	SaviyntClient saviyntClient;

	@Retryable(value = {
			FeignException.class }, maxAttemptsExpression = "#{${app.api.retry.max-attempts:5}}", backoff = @Backoff(delayExpression = "#{${app.api.retry.backoff-delay:1000}}"), exceptionExpression = "#{@retryHelper.is5xx(#root)}")
	public CreateOrganizationResponse createOrganization(CreateOrganizationRequestDTO createOrganizationRequest,
			String accessToken) {
		if (StringUtils.isNotEmpty(createOrganizationRequest.getOrganizationname())
				&& StringUtils.isNotEmpty(createOrganizationRequest.getUsername())) {
			CreateOrganizationRequest updateOrgRequest = CreateOrganizationRequest.builder()
					.organizationname(createOrganizationRequest.getOrganizationname())
					.username(createOrganizationRequest.getUsername()).build();

			CreateOrganizationResponse response = saviyntClient
					.createOrganization(StartAnyWhereConstants.AUTH_TOKEN_PREFIX + accessToken, updateOrgRequest);
			InfoTypeLogEventHelper.logInfoEvent(UserService.class.getName(),
					"Response from create organisation: " + response);
			int statusCode = StartAnywhereUtil.calculateSaviyntStatusCode(Integer.parseInt(response.getErrorCode()));
			CreateOrganizationResponse organizationResponse = CreateOrganizationResponse.builder()
					.msg(response.getMsg()).errorCode(response.getErrorCode()).statusCode(statusCode).build();
			return organizationResponse;
		} else {
			throw new CCServiceException(HttpStatus.PRECONDITION_FAILED,
					"Unable to create organization - Missing mandatory parameter(s)");
		}

	}

	@Retryable(value = {
			FeignException.class }, maxAttempts = 3, backoff = @org.springframework.retry.annotation.Backoff(delay = 1000), exceptionExpression = "#{@retryHelper.is5xx(#root)}")
	public UpdateOrganizationResponse updateUserToOrganization(UpdateOrganizationRequestDTO updateOrganizationRequest,
			String accessToken) {
		if (StringUtils.isNotEmpty(updateOrganizationRequest.getOrganizationname())
				&& StringUtils.isNotEmpty(updateOrganizationRequest.getUsername())
				&& CollectionUtils.isNotEmpty(updateOrganizationRequest.getUsers())) {
			UpdateOrganizationRequest updateOrgRequest = buildUpdateOrgRequest(updateOrganizationRequest);
			UpdateOrganizationResponse response = saviyntClient
					.addUsersToOrganization(StartAnyWhereConstants.AUTH_TOKEN_PREFIX + accessToken, updateOrgRequest);
			InfoTypeLogEventHelper.logInfoEvent(UserService.class.getName(),
					"Response from adding or removing  user: " + response);
			int statusCode = StartAnywhereUtil.calculateSaviyntStatusCode(Integer.parseInt(response.getErrorCode()));
			UpdateOrganizationResponse organizationResponse = UpdateOrganizationResponse.builder()
					.msg(response.getMsg()).errorCode(response.getErrorCode()).statusCode(statusCode).build();
			return organizationResponse;
		} else {
			throw new CCServiceException(HttpStatus.PRECONDITION_FAILED,
					"Unable to update user to the organization - Missing mandatory parameter(s)");
		}
	}

	@Retryable(value = {
			FeignException.class }, maxAttemptsExpression = "#{${app.api.retry.max-attempts:5}}", backoff = @Backoff(delayExpression = "#{${app.api.retry.backoff-delay:1000}}"), exceptionExpression = "#{@retryHelper.is5xx(#root)}")
	
		public  UserOrganizationDetailResponseDTO getUserDetailsForOrganization(String accessToken, UserOrganisationDetailRequest userRequestDetail){
		
		if (userRequestDetail != null && StringUtils.isNotEmpty(userRequestDetail.getUsername())) {
					UserOrganisationDetailRequest userOrgDetailRequest = UserOrganisationDetailRequest.builder()
							.username(userRequestDetail.getUsername()).max(StartAnyWhereConstants.MAX).build();
				UserOrganizationDetailResponseDTO response = saviyntClient.getOrganizationUserDetails(StartAnyWhereConstants.AUTH_TOKEN_PREFIX + accessToken, userOrgDetailRequest);
				InfoTypeLogEventHelper.logInfoEvent(UserService.class.getName(), "Response getting user detail for the organization: " + response);
				int statusCode = StartAnywhereUtil.calculateSaviyntStatusCode(Integer.parseInt(response.getErrorCode()));
				UserOrganizationDetailResponseDTO organizationDetailResponse = UserOrganizationDetailResponseDTO.builder()
						.msg(response.getMsg())
						.displaycount(response.getDisplaycount())
						.organizations(response.getOrganizations())
						.username(response.getUsername())
						.errorCode(response.getErrorCode())
						.totalcount(response.getTotalcount())
						.statusCode(statusCode).build();

				return  organizationDetailResponse;
			}

			else{
				throw new CCServiceException(HttpStatus.PRECONDITION_FAILED, "Unable to get user details for the organization");
			}
		
	 }
	
	@Retryable(value = {
			FeignException.class }, maxAttemptsExpression = "#{${app.api.retry.max-attempts:5}}", backoff = @Backoff(delayExpression = "#{${app.api.retry.backoff-delay:1000}}"), exceptionExpression = "#{@retryHelper.is5xx(#root)}")
	
		public  OrganizationUserDetailResponseDTO getUserOrganizationDetails(String accessToken, OrganisationUserDetailRequest userRequestDetail, String clientId){
		if(userRequestDetail!=null) {
			if(StringUtils.isNotEmpty(userRequestDetail.getOrganizationname()) && clientId.equalsIgnoreCase(userRequestDetail.getOrganizationname())){
				OrganisationUserDetailRequest userOrgDetailRequest = OrganisationUserDetailRequest.builder()
						.organizationname(userRequestDetail.getOrganizationname()).max(StartAnyWhereConstants.MAX).build();
					OrganizationUserDetailResponseDTO response = saviyntClient.getUserOrganizationDetails(StartAnyWhereConstants.AUTH_TOKEN_PREFIX + accessToken, userOrgDetailRequest);
				InfoTypeLogEventHelper.logInfoEvent(UserService.class.getName(), "Response getting organization detail for the user: " + response);
				OrganizationUserDetailResponseDTO organizationDetailResponse = OrganizationUserDetailResponseDTO.builder()
						
						.displaycount(response.getDisplaycount())
						.msg(response.getMsg())
						.totalcount(response.getTotalcount())
						.offset(response.getOffset())
						.max(response.getMax())
						.organizationname(response.getOrganizationname())
						.errorCode(response.getErrorCode())
						.users(response.getUsers()).build();

				return  organizationDetailResponse;
			}

			else{
				throw new CCServiceException(HttpStatus.PRECONDITION_FAILED, "Unable to get organization details for the users ");
			}
		}
		return null;
	 }
	
	private UpdateOrganizationRequest buildUpdateOrgRequest(UpdateOrganizationRequestDTO updateOrganizationRequest) {
		OrganizationUser organizationUser = OrganizationUser.builder()
				.username(updateOrganizationRequest.getUsers().get(0).getUsername())
				.updatetype(updateOrganizationRequest.getUsers().get(0).getUpdatetype()).build();
		List<OrganizationUser> organizationUserList = Arrays.asList(organizationUser);
		UpdateOrganizationRequest updateOrgRequest = UpdateOrganizationRequest.builder()
				.organizationname(updateOrganizationRequest.getOrganizationname())
				.username(updateOrganizationRequest.getUsername()).users(organizationUserList).build();
		return updateOrgRequest;
	}
}
