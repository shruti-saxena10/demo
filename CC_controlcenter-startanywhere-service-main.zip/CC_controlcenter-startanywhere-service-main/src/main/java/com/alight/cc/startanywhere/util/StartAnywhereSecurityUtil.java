package com.alight.cc.startanywhere.util;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.safety.Whitelist;

public class StartAnywhereSecurityUtil {

	/**
	 * Method to check/update inputValue and remove/escape value to compliance
	 * with security <br>
	 * if inputValue is null method will return null
	 * 
	 * @param inputValue
	 * @return
	 */
	public static String cleanIt(String inputValue) {
		if (inputValue != null) {
			return Jsoup.clean(
					StringEscapeUtils
							.escapeHtml(StringEscapeUtils.escapeJavaScript(StringEscapeUtils.escapeSql(inputValue))),
					Whitelist.basic());
		} else {
			return null;
		}
	}

	public static String cleanSQL(String inputValue) {
		if (inputValue != null) {
			return Jsoup.clean(StringEscapeUtils.escapeSql(inputValue), Whitelist.basic());
		} else {
			return null;
		}
	}

	public static String escapeSQL(String inputValue) {
		if (inputValue != null) {
			inputValue = inputValue.replace("?", "&QUES;&");
			return StringUtils.replace(inputValue, "'", "''");
		} else {
			return null;
		}
	}

	public static String unCleanIt(String inputValue) {
		if (inputValue != null) {
			inputValue = StringEscapeUtils.unescapeHtml(StringEscapeUtils.unescapeJavaScript(inputValue));
			inputValue = inputValue.replace("''", "'");
			inputValue = inputValue.replace("&gt;", ">");
			inputValue = inputValue.replace("&lt;", "<");
			inputValue = inputValue.replace("&amp;", "&");
			return inputValue;
		} else {
			return null;
		}
	}

}
