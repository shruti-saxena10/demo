package com.alight.cc.startanywhere.entity;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "attribute_type_lookup", schema = "coat")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AttributeTypeLookupEntity implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
    private Long id;
	
	@Column(name = "key", updatable = false, insertable = false)
	private String key;
	
	@Column(name = "description", updatable = false, insertable = false)
    private String description;
	
	@Column(name = "created_at")
    private Date createdAt;
	
	@Column(name = "created_by")
    private String createdBy;
	
	@Column(name = "updated_at")
    private Date updatedAt;
	
	@Column(name = "updated_by")
    private String updatedBy;

}
