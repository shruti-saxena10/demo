package com.alight.cc.startanywhere.saviynt.model;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetAccountsResponse {

    private String msg;
    private String displaycount;
    private String totalcount;
    private String errorCode;
    private int statusCode;
    @JsonProperty("Accountdetails")
    private List<AccountDetails> accountDetails;
}
