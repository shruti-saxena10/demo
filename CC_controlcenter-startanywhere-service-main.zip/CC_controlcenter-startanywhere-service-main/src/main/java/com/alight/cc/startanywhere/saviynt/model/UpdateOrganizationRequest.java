package com.alight.cc.startanywhere.saviynt.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
@Data
@AllArgsConstructor(staticName = "of")
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class UpdateOrganizationRequest {

    private String organizationname;
    private String username;
    private List<OrganizationUser> users;
	}