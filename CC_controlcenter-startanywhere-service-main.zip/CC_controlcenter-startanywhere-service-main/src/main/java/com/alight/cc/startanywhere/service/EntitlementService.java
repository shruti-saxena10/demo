package com.alight.cc.startanywhere.service;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import com.alight.cc.startanywhere.configuration.SaviyntConfigurationBean;
import com.alight.cc.startanywhere.exception.CCServiceException;
import com.alight.cc.startanywhere.feign.SaviyntClient;
import com.alight.cc.startanywhere.model.ClientConfigError;

import com.alight.cc.ControlCenterCommonConstants;
import com.alight.cc.dto.EntitlementDTO;
import com.alight.cc.dto.UserEntitlementsDTO;
import com.alight.cc.model.exception.InvalidRequestException;
import com.alight.cc.startanywhere.saviynt.model.Entitlement;
import com.alight.cc.startanywhere.saviynt.model.EntitlementDetail;
import com.alight.cc.startanywhere.saviynt.model.EntitlementsResponse;
import com.alight.cc.startanywhere.saviynt.model.GetEntitlementsRequest;
import com.alight.cc.startanywhere.saviynt.model.UpdateUserEntitlementsRequest;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;
import com.alight.cc.startanywhere.util.StartAnywhereUtil;
import com.alight.logging.helpers.InfoTypeLogEventHelper;
import com.aonhewitt.logging.events.ErrorLogEvent;
import com.aonhewitt.logging.helpers.ErrorLogEventHelper;
import com.fasterxml.jackson.core.JsonProcessingException;

import feign.FeignException;

@Service
public class EntitlementService {

	@Autowired
	UserService userService;

	@Autowired
	SaviyntClient saviyntClient;
	@Autowired
	SaviyntConfigurationBean saviyntConfig;
	@Autowired
	SaviyntService saviyntService;


	@Retryable(value = {
			FeignException.class }, maxAttemptsExpression = "#{${app.api.retry.max-attempts:5}}", backoff = @Backoff(delayExpression = "#{${app.api.retry.backoff-delay:1000}}"), exceptionExpression = "#{@retryHelper.is5xx(#root)}")
	
	public EntitlementsResponse loadEntitlements(String username, String accessToken, String clientId) {
		GetEntitlementsRequest getEntitlementsRequest = GetEntitlementsRequest.builder().username(username)
				.entQuery(StartAnyWhereConstants.ENTQUERY + clientId + StartAnyWhereConstants.LIKEOPERATER)
				.endpoint(saviyntConfig.getEndpoint()).status(StartAnyWhereConstants.SAVIYNT_ENTITLEMENT_ACTIVE_STATUS)
				.max(StartAnyWhereConstants.SAVIYNT_MAX_ENTITLEMENTS).offset(StartAnyWhereConstants.OFFSET).build();
		EntitlementsResponse entitlementsResponse = saviyntClient
				.getEntitlements(StartAnyWhereConstants.AUTH_TOKEN_PREFIX + accessToken, getEntitlementsRequest);
		InfoTypeLogEventHelper.logInfoEvent(EntitlementService.class.getName(),
				"Response from getting entitlements: " + entitlementsResponse);
		return entitlementsResponse;
	}
	
	@Retryable(value = {
			FeignException.class }, maxAttemptsExpression = "#{${app.api.retry.max-attempts:5}}", backoff = @Backoff(delayExpression = "#{${app.api.retry.backoff-delay:1000}}"), exceptionExpression = "#{@retryHelper.is5xx(#root)}")
	public UserEntitlementsDTO updateUser(UserEntitlementsDTO userEntitlements, String accessToken) throws JsonProcessingException {
		validateUser(userEntitlements);
		String userEndpoint = getUserEndpoint(userEntitlements);
		String serviceSystem = getServiceSystem(userEntitlements);
		if (StringUtils.isNotBlank(userEndpoint) && StringUtils.isNotBlank(serviceSystem)) {
			List<Entitlement> entitlements = convertEntitlements(userEntitlements.getEntitlements());
			UpdateUserEntitlementsRequest request = new UpdateUserEntitlementsRequest();
			request.setRequesttype(userEntitlements.getRequestType().toUpperCase());
			request.setEndpoint(userEndpoint);
			request.setUsername(userEntitlements.getUserName());
			request.setAccountname(userEntitlements.getAccountName());
			request.setSecuritysystem(serviceSystem);
			request.setCreateNewAccountTaskIfNotExist(Boolean.TRUE.toString());
			request.setEntitlements(entitlements);
					
			InfoTypeLogEventHelper.logInfoEvent(UserService.class.getName(), "Request remove updating entitlements in Saviynt: " + request);
			
			JSONObject response =
					saviyntClient.updateEntitlementsOnUser(StartAnyWhereConstants.AUTH_TOKEN_PREFIX + accessToken, request);
			InfoTypeLogEventHelper.logInfoEvent(UserService.class.getName(), "Response remove from updating entitlements: " + response);
			return userEntitlements;
		} else {
			throw new CCServiceException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to remove the entitlements endpoint for this user");
		}
	}
	
	private void validateUser(UserEntitlementsDTO user) {
		if (!StringUtils.equalsIgnoreCase(ControlCenterCommonConstants.SAVIYNT_REQUEST_TYPE.ADD.name(), user.getRequestType()) &&
				!StringUtils.equalsIgnoreCase(ControlCenterCommonConstants.SAVIYNT_REQUEST_TYPE.REMOVE.name(), user.getRequestType())) {
			throw new InvalidRequestException("User Request type is invalid");
		}
		if (StringUtils.isEmpty(user.getEmail()) || StringUtils.isEmpty(user.getUserName())) {
			throw new InvalidRequestException("Invalid user data");
		}
		user.getEntitlements().forEach(entitlementDTO -> validateEntitlement(entitlementDTO));
	}

	private void validateEntitlement(EntitlementDTO entitlementDTO) {
		if (entitlementDTO == null ||
				(StringUtils.isEmpty(entitlementDTO.getValue()))) {
			throw new InvalidRequestException("Invalid user entitlement data");
		}
		
	}

	private String getUserEndpoint(UserEntitlementsDTO userEntitlementsDTO) {
		String userType = userService.determineUserTypeByEmailDomain(userEntitlementsDTO.getEmail());
		return saviyntService.getEndpoint(userType);
	}

	private String getServiceSystem(UserEntitlementsDTO userEntitlementsDTO) {
		 String userType = ControlCenterCommonConstants.TypeOfUser.INTERNAL.name();
		return saviyntService.getSecuritySystem(userType);
	}

	public List<Entitlement> convertEntitlements(List<EntitlementDTO> entitlementDTOList) {
		
		List<Entitlement> entitlements =entitlementDTOList.stream()
				.map(entitlementDTO -> Entitlement.of(saviyntConfig.getEntitlementtype(),
						entitlementDTO.getValue(),
					saviyntConfig.getBusinessJustification(), ControlCenterCommonConstants.SAVIYNT_REQUEST_TYPE.REMOVE.name()))
				.collect(Collectors.toList());

		return entitlements;
	}
}
