package com.alight.cc.startanywhere.configuration;

import com.alight.logging.helpers.InfoTypeLogEventHelper;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

@Configuration
@EnableCaching
@EnableScheduling
public class CachingConfig {

    public static final String saviyntAccessToken = "saviyntAccessToken";

    @Bean
    public CacheManager cacheManager() {
        ConcurrentMapCacheManager cacheManager = new ConcurrentMapCacheManager(saviyntAccessToken);
        return cacheManager;
    }

    @CacheEvict(allEntries = true, value = "saviyntAccessToken")
    @Scheduled(fixedRateString = "${caching.spring.saviyntAccessTokenTTL:3000000}", initialDelay = 1000)
    public void reportSaviyntAccessTokenCacheEvict() {
        InfoTypeLogEventHelper.logInfoEvent(CachingConfig.class.getName(),
                "Flush Control Center saviyntAccessToken.");
    }
}