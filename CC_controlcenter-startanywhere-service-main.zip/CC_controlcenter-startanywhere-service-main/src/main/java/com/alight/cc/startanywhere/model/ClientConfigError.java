package com.alight.cc.startanywhere.model;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Builder
public class ClientConfigError {
	private String emailId;
	private String errorCode;
	private String errorMessage;
	private String errorSeverity;
}