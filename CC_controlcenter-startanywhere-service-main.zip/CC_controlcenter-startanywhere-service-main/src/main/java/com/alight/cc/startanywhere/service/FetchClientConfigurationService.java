package com.alight.cc.startanywhere.service;

import java.io.IOException;

import com.alight.cc.startanywhere.model.ClientConfigurationResponse;
import com.alight.cc.startanywhere.model.ClientRequest;

import feign.FeignException;

public interface FetchClientConfigurationService {


	//ClientConfigurationResponse getClientConfigurationDetails(ClientRequest request);

	ClientConfigurationResponse getClientConfigurationDetails(String alightColleagueSessionToken,
			String alightRequestHeader, ClientRequest request) throws IOException,RuntimeException,FeignException;

	ClientConfigurationResponse validateClientRequest(String alightRequestHeader, ClientRequest request);

}
