package com.alight.cc.startanywhere.service.impl;

import static com.alight.cc.startanywhere.util.StartAnyWhereConstants.FUNCTIONAL_ID;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.postgresql.util.PSQLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Recover;
import org.springframework.stereotype.Service;

import com.alight.cc.ControlCenterCommonConstants;
import com.alight.cc.dto.AccountDTO;
import com.alight.cc.dto.EntitlementDTO;
import com.alight.cc.dto.OrganizationDetailsDTO;
import com.alight.cc.dto.OrganizationUserDTO;
import com.alight.cc.dto.UpdateOrganizationRequestDTO;
import com.alight.cc.dto.UserEntitlementsDTO;
import com.alight.cc.dto.UserOrganizationDetailResponseDTO;
import com.alight.cc.repository.DomainLookupRepository;
import com.alight.cc.startanywhere.configuration.SaviyntConfigurationBean;
import com.alight.cc.startanywhere.entity.SecurityManagerEntitlementEntity;
import com.alight.cc.startanywhere.feign.SaviyntClient;
import com.alight.cc.startanywhere.model.BaseResponse;
import com.alight.cc.startanywhere.model.ClientConfigError;
import com.alight.cc.startanywhere.model.ClientConfigurationResponse;
import com.alight.cc.startanywhere.model.EntitlementOwnerResponse;
import com.alight.cc.startanywhere.model.EntitlementResponse;
import com.alight.cc.startanywhere.model.OrganizationUserDetailResponseDTO;
import com.alight.cc.startanywhere.model.UserOrganizationDetailsDTO;
import com.alight.cc.startanywhere.repository.ClientRepository;
import com.alight.cc.startanywhere.repository.SecurityManagerEntitlementRepository;
import com.alight.cc.startanywhere.saviynt.model.EntitlementDetail;
import com.alight.cc.startanywhere.saviynt.model.EntitlementsResponse;
import com.alight.cc.startanywhere.saviynt.model.OrganisationUserDetailRequest;
import com.alight.cc.startanywhere.saviynt.model.UpdateOrganizationResponse;
import com.alight.cc.startanywhere.saviynt.model.User;
import com.alight.cc.startanywhere.saviynt.model.UserOrganisationDetailRequest;
import com.alight.cc.startanywhere.service.AccountService;
import com.alight.cc.startanywhere.service.DeleteClientConfigurationService;
import com.alight.cc.startanywhere.service.EntitlementService;
import com.alight.cc.startanywhere.service.OrganizationService;
import com.alight.cc.startanywhere.service.RemoveClientService;
import com.alight.cc.startanywhere.service.SaviyntService;
import com.alight.cc.startanywhere.service.UserService;
import com.alight.cc.startanywhere.util.CheckClientData;
import com.alight.cc.startanywhere.util.CheckClientDuplicacy;
import com.alight.cc.startanywhere.util.ClientRetryable;
import com.alight.cc.startanywhere.util.SaviyntRequestBuilder;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;
import com.alight.cc.startanywhere.util.StartAnywhereSecurityUtil;
import com.alight.cc.startanywhere.util.StartAnywhereUtil;
import com.alight.logging.helpers.InfoTypeLogEventHelper;
import com.aonhewitt.logging.events.ErrorLogEvent;
import com.aonhewitt.logging.helpers.ErrorLogEventHelper;
import com.fasterxml.jackson.core.JsonProcessingException;

import feign.FeignException;

@Service
public class DeleteClientConfigurationServiceImpl implements DeleteClientConfigurationService{

	@Autowired
	SaviyntService saviyntService;

	@Autowired
	@Lazy
	RemoveClientService removeClientService;

	@Autowired
	SaviyntClient saviyntClient;

	@Autowired
	ClientRepository clientRepo;

	@Autowired
	UserService userService;

	@Autowired
	SaviyntConfigurationBean bean;

	@Autowired
	SaviyntRequestBuilder saviyntRequestBuilder;

	@Autowired
	DomainLookupRepository domainLookupRepository;

	@Autowired
	CheckClientDuplicacy checkClientDuplicacy;

	@Autowired
	SecurityManagerEntitlementRepository securityManagerEntitlementRepository;

	@Autowired
	AccountService accountService;

	@Autowired
	EntitlementService entitlementService;

	@Autowired
	OrganizationService orgService;

	@Autowired
	CheckClientData checkClientData;

	
	@ClientRetryable
	@Override
	public ResponseEntity<Object> getDeleteClientConfigurationDetails(String alightColleagueSessionToken,
			String alightRequestHeader,  String clientId,  String orgName,
			List<String> securityManagerEmailId) throws JsonProcessingException, IOException, PSQLException {
		// TODO Auto-generated method stub

		InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
				"Inside service layer of delete flow for  DeleteClientConfigurationDetails :" + clientId);

		BaseResponse response = new BaseResponse();
		List<ClientConfigError> errors = new ArrayList<>(); 

		UserEntitlementsDTO userEntitlements = new UserEntitlementsDTO();
		List<EntitlementResponse> listEntitlements = new ArrayList<>();
		LinkedHashMap<String, String> validMailMap = new LinkedHashMap<>();
		LinkedHashMap<String, String> invalidMailMap = new LinkedHashMap<>();
		LinkedHashMap<String, String> accountMap = new LinkedHashMap<>();
		List<AccountDTO> accounts = new ArrayList<>();
		User user = new User();
		List<User> listOfUsers= new ArrayList<>();
		boolean valid = false;
		boolean containsClientId = false;
		orgName = StartAnywhereSecurityUtil.unCleanIt(orgName);
		List<String> orgExist = new ArrayList<>();
		
		InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Checking the locale in alightRequestHeader");
		ResponseEntity<Object> headerCheck = checkClientData.isCheckRequestHeader(alightRequestHeader);
		if(headerCheck!=null) {
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Validating the alightRequestHeader");
			return headerCheck;
		}

		InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Generating accessToken");
		String accessToken = "";
		try {
			accessToken = userService.getAccessToken();

		} catch (FeignException e) {
			HttpStatus excStatus = HttpStatus.valueOf(e.status());
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
					"Saviynt Functional Id and password Invalid");
			ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), e.getMessage(),
					"DeleteClientConfiguration()", e, ErrorLogEvent.ERROR_EVENT_TYPE);

			if (excStatus != null && excStatus == HttpStatus.UNAUTHORIZED) {
				response = StartAnywhereUtil.buildResponse(new BaseResponse(),
						StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR,
						StartAnyWhereConstants.INTERNAL_SERVER_ERROR, StartAnyWhereConstants.SAV102,
						StartAnyWhereConstants.SAVIYNT_FUNCTIONAL_ID_AND_PASSWORD_INVALID,
						StartAnyWhereConstants.HIGH, null, errors);
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
			}
			else {
				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
						"Saviynt Server unreachable");
				ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), e.getMessage(),
						"DeleteClientConfiguration()", e, ErrorLogEvent.ERROR_EVENT_TYPE);
				response = StartAnywhereUtil.buildResponse(new BaseResponse(),
						StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR,
						StartAnyWhereConstants.INTERNAL_SERVER_ERROR, StartAnyWhereConstants.SAV101,
						StartAnyWhereConstants.SAVIYNT_SERVER_UNREACHABLE, StartAnyWhereConstants.HIGH, null,
						errors);

				return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);

			}
		}
		try {
			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Checking the clientID of the orgName" +clientId +orgName);
			ResponseEntity<Object> duplicateClient = checkClientData.isNotValidClient(clientId, orgName);
			if(duplicateClient!=null) {
				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Client doestn't exists in Postgres DB");
				return duplicateClient;
			}else {
				if(securityManagerEmailId==null || securityManagerEmailId.isEmpty()
						|| securityManagerEmailId.stream().allMatch(s -> s == null || s.trim().isEmpty()
						||  s.trim().equalsIgnoreCase("null"))) {
					InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
							"securityManagerEmailId must not be null :" + securityManagerEmailId);
					return ResponseEntity.badRequest().body(
							StartAnywhereUtil.buildResponse(
									response,
									StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
									StartAnyWhereConstants.BAD_REQUEST,
									StartAnyWhereConstants.POS106,
									StartAnyWhereConstants.EMAIL_BAD_REQUEST_MSG,
									StartAnyWhereConstants.HIGH,
									null,
									errors
									)
							);
				}else {
					List<String> cleanListSecurityManagerEmail = securityManagerEmailId.stream()
							.filter(s -> s != null && !s.trim().isEmpty())
							.collect(Collectors.toList());
					InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
							"Cleaned securityManagerEmailId list. Removed null entries. Final count:" + cleanListSecurityManagerEmail.size());

					// Start the user details
					InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
							"Starting the process of fetching user details for SecurityManagerEmails :" + cleanListSecurityManagerEmail);
					for (String s : cleanListSecurityManagerEmail) {
						String email = s;
						try {
							InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
									"Fetching user details for :" + email);

							user = userService.getUserProfile(email, accessToken);
							listOfUsers.add(user);
							if (user == null) {
								invalidMailMap.put(email, email);
							} else {
								validMailMap.put(email, user.getUsername());
							}
						} catch (FeignException e) {
							InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
									"Unable to fetch user details from Saviynt");
							ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), e.getMessage(),
									"DeleteClientConfiguration()", e, ErrorLogEvent.ERROR_EVENT_TYPE);

							StartAnywhereUtil.buildResponse(response, null, null, StartAnyWhereConstants.SAV016,
									StartAnyWhereConstants.SAV016_MSG, StartAnyWhereConstants.LOW, email, errors);

						}
					}
					InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
							"Ending the process of fetching user details for SecurityManagerEmails :" + cleanListSecurityManagerEmail);
					//end the user details
					
					if (invalidMailMap != null && !invalidMailMap.isEmpty()) {
					    Iterator<Map.Entry<String, String>> itr = invalidMailMap.entrySet().iterator();

					    boolean hasValid = validMailMap != null && !validMailMap.isEmpty();

					    if (!hasValid) {
					        InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
					            "No user details returned from Saviynt for email");
					    }

					    while (itr.hasNext()) {
					        Map.Entry<String, String> entry = itr.next();
					        String mailId = entry.getValue();

					        ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
					            "No user details returned from Saviynt for email: " + mailId, "", null,
					            ErrorLogEvent.ERROR_SEVERITY);

					        response = StartAnywhereUtil.buildResponse(response,
					            hasValid ? null : StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST,
					            hasValid ? null : StartAnyWhereConstants.BAD_REQUEST,
					            StartAnyWhereConstants.SAV002,
					            StartAnyWhereConstants.SECURITY_MANAGER_DOESNT_EXIST_IN_SAVIYNT,
					            StartAnyWhereConstants.LOW,
					            mailId,
					            errors);
					    }

					    if (!hasValid) {
					        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
					    }
					}

					 InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
					            "Starting  Get account details from the user");
					 // Start the account Details
					if (validMailMap != null && !validMailMap.isEmpty()) {
						//Get account details for the valid security managers
						 InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
						            "Get account details for the valid security managers");

						Iterator<Map.Entry<String, String>> itr = validMailMap.entrySet().iterator();
						while (itr.hasNext()) {
							Map.Entry<String, String> e = itr.next();
							try {
								InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
										"Fetching accountName for:" + e.getKey());

								accounts = accountService.getAccounts(e.getValue(), accessToken);
								if (accounts.isEmpty()) {
									StartAnywhereUtil.buildResponse(response, null, null, StartAnyWhereConstants.SAV015,
											StartAnyWhereConstants.SAV015_MSG, StartAnyWhereConstants.LOW, e.getKey(), errors);

								} else {
									AccountDTO account = accounts.get(0);
									//email to account name mapping
									if(account.getStatus().equalsIgnoreCase("1")) {
										accountMap.put(e.getKey(), account.getAccountname());
									}
									else {
										InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
												"Not active account details for security manager");
										ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), "Not active account details for security manager",
												"DeleteClientConfiguration()", null, ErrorLogEvent.ERROR_EVENT_TYPE);
										StartAnywhereUtil.buildResponse(response, StartAnyWhereConstants.HTTP_STATUS_SUCCESS, StartAnyWhereConstants.DELETE_STATUS, 
												StartAnyWhereConstants.SAV021, StartAnyWhereConstants.SAV021_MSG,StartAnyWhereConstants.LOW, user.getEmail(), errors);

									}
								} 
							}catch (FeignException exe) {
								InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
										"Could not fetch Account Details for Security Manager");
								ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), exe.getMessage(),
										"DeleteClientConfiguration()", exe, ErrorLogEvent.ERROR_EVENT_TYPE);
								StartAnywhereUtil.buildResponse(response, null, null, StartAnyWhereConstants.SAV014,
										StartAnyWhereConstants.SAV014_MSG, StartAnyWhereConstants.LOW, user.getEmail(), errors);

							}
						}
					}

					if (accountMap.isEmpty()) {
						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
								"None of the security manager has an account in Saviynt");
						response = 
								StartAnywhereUtil.buildResponse(response, StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR,
										StartAnyWhereConstants.INTERNAL_SERVER_ERROR,
										StartAnyWhereConstants.SAV024,
										StartAnyWhereConstants.SECURTY_MANAGERS_DONOT_HAVE_ACCOUNTS, StartAnyWhereConstants.HIGH,
										null, errors);
						return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);

					}
					InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
							"Fetching accountNames for all Security managers completed");

					//end account Details
					//Start org Details
					UserOrganizationDetailResponseDTO orgResp = new UserOrganizationDetailResponseDTO();
					List<UserOrganizationDetailResponseDTO> userOrgResponseList = new ArrayList<>();
					InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
							"Starting the fetching user details for organization from Saviynt");
					List<User> cleanList = listOfUsers.stream()
							.filter(u -> u != null) 
							.collect(Collectors.toList());


					if(  cleanList !=null && !cleanList.isEmpty()) {
						for(User u : cleanList) {
							try {
								InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
										"Starting retrieval of initial Saviynt organization details for user");
								UserOrganisationDetailRequest userOrgDetailRequest = UserOrganisationDetailRequest.builder()
										.username(u.getUsername()).build();

								orgResp=orgService.getUserDetailsForOrganization(accessToken, userOrgDetailRequest);
								userOrgResponseList.add(orgResp);

								if (Optional.ofNullable(orgResp).map(UserOrganizationDetailResponseDTO::getOrganizations)
										.filter(orgs -> !orgs.isEmpty()).isPresent()) {

									List<String> organizationNames = Optional.ofNullable(orgResp.getOrganizations())
											.orElse(Collections.emptyList()).stream()
											.map(OrganizationDetailsDTO::getOrganizationname).filter(Objects::nonNull)
											.collect(Collectors.toList());

									 containsClientId = organizationNames.stream()
											.anyMatch(name -> name.contains(clientId));

									if (!containsClientId) {
										
										ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
												StartAnyWhereConstants.SECURITY_MANAGER_DOESNT_BELONGS_TO_SAVIYNT_CLINET, "", null,
												ErrorLogEvent.ERROR_SEVERITY);

												StartAnywhereUtil.buildResponse(response,
												StartAnyWhereConstants.HTTP_STATUS_SUCCESS, StartAnyWhereConstants.OK,
												StartAnyWhereConstants.SAV006,
												StartAnyWhereConstants.SECURITY_MANAGER_DOESNT_BELONGS_TO_SAVIYNT_CLINET,
												StartAnyWhereConstants.LOW, u.getEmail(), errors);
												orgExist.add(u.getEmail());
									}

								} 
								else {
									ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), "Security Manager doesn’t belongs to the Orgnization in saviynt",
											"DeleteClientConfiguration()", null, ErrorLogEvent.ERROR_EVENT_TYPE);
									response = StartAnywhereUtil.buildResponse(response,
											StartAnyWhereConstants.HTTP_STATUS_SUCCESS, StartAnyWhereConstants.DELETE_STATUS,
											StartAnyWhereConstants.SAV006,
											StartAnyWhereConstants.SECURITY_MANAGER_DOESNT_BELONGS_TO_SAVIYNT_CLINET,
											StartAnyWhereConstants.LOW, u.getEmail(), errors);
									return ResponseEntity.status(HttpStatus.OK).body(response); 
								}

								InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
										"Ending retrieval of initial Saviynt Org details for user");


							}
							catch (FeignException fe) {
								ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), fe.getMessage(),
										"DeleteClientConfiguration()", fe, ErrorLogEvent.ERROR_EVENT_TYPE);

								response = StartAnywhereUtil.buildResponse(response,
										StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR,
										StartAnyWhereConstants.INTERNAL_SERVER_ERROR, StartAnyWhereConstants.SAV026,
										StartAnyWhereConstants.SAV026_MSG, StartAnyWhereConstants.HIGH, u.getEmail(), errors);

								return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);

							}
							InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
									"Ending the fetching user details for organization from Saviynt");
							// end the org detials

							//start the entitlement details
							try {
								InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
										"Initiating retrieval of initial Saviynt entitlement details for user");

								if (containsClientId) {
								EntitlementsResponse entitlementsResponse = entitlementService.loadEntitlements(u.getUsername(), accessToken,
										clientId);

								List<SecurityManagerEntitlementEntity> securityManagerEntitlementresponse = securityManagerEntitlementRepository
										.findByIsSecuritymanager(1);

								List<String> updatedEntitlementDisplayname = saviyntService.getDisplayNamesWithClientId(securityManagerEntitlementresponse, 
										clientId);


								List<String> availableEntitlementValues = Optional.ofNullable(entitlementsResponse)
										.map(EntitlementsResponse::getEntitlementdetails)
										.orElse(Collections.emptyList())
										.stream()
										.map(EntitlementDetail::getEntitlement_value)
										.filter(Objects::nonNull)
										.collect(Collectors.toList());


								// Identify which expected display names are NOT found in the entitlement
								List<String> missingDisplayNames = Optional.ofNullable(updatedEntitlementDisplayname)
										.orElse(Collections.emptyList())
										.stream()
										.filter(expected -> Optional.ofNullable(availableEntitlementValues)
												.orElse(Collections.emptyList())
												.stream()
												.noneMatch(expected::equals))
										.collect(Collectors.toList());
								

								// If any expected entitlement is missing, build failure response
								if (!missingDisplayNames.isEmpty()) {
									String result = missingDisplayNames.stream()
										    .map(e -> e.replace(bean.getApplication(), "").replace(bean.getPrefix(), ""))
										    .collect(Collectors.joining(" "));
				

									 StartAnywhereUtil.buildResponse(response,
													StartAnyWhereConstants.HTTP_STATUS_SUCCESS, StartAnyWhereConstants.DELETE_STATUS,
													StartAnyWhereConstants.SAV008,
													StartAnyWhereConstants.ENTITLEMENT + result
															+ StartAnyWhereConstants.ENTITLEMENT_NOT_AVAILABLE,
													StartAnyWhereConstants.LOW, u.getEmail(), errors);

								}
								
								InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
										" Starting Collecting matching entitlement details for user. ");

								// Collect all matching entitlement details into response object
								List<EntitlementResponse> matchedResponses = Optional.ofNullable(entitlementsResponse)
										.map(EntitlementsResponse::getEntitlementdetails)
										.orElse(Collections.emptyList())
										.stream()
										.filter(detail -> 
										detail != null &&
										detail.getEntitlement_value() != null &&
										Optional.ofNullable(updatedEntitlementDisplayname).orElse(Collections.emptyList())
										.contains(detail.getEntitlement_value())
												)
										.map(detail -> {
											EntitlementResponse EntitlementResponse = new EntitlementResponse();
											EntitlementResponse.setEndpoint(detail.getEndpoint());
											EntitlementResponse.setEntitlementValue(detail.getEntitlement_value());
											EntitlementResponse.setDescription(detail.getDescription());
											EntitlementResponse.setStatus(detail.getStatus());

											// Safely collect entitlement owners
											List<EntitlementOwnerResponse> owners = Optional.ofNullable(detail.getEntitlementOwner())
													.orElse(Collections.emptyList())
													.stream()
													.filter(owner -> owner != null && !owner.isBlank())
													.map(owner -> {
														EntitlementOwnerResponse ownerRes = new EntitlementOwnerResponse();
														ownerRes.setAID(owner);
														return ownerRes;
													}).collect(Collectors.toList());

											EntitlementResponse.setEntitlementOwner(owners);
											return EntitlementResponse;
										})
										.collect(Collectors.toList());


								// Add all matched entitlements to the response holder
								InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
										"  Ending Collecting matching entitlement details for user: "+ matchedResponses);
								listEntitlements.addAll(matchedResponses);

								InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
										"Ending retrieval of initial Saviynt entitlement details for user");
							}
						}
							catch (FeignException fe) {
								ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), fe.getMessage(),
										"DeleteClientConfiguration()", fe, ErrorLogEvent.ERROR_EVENT_TYPE);
								response = 
										StartAnywhereUtil.buildResponse(response,
												StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR,
												StartAnyWhereConstants.INTERNAL_SERVER_ERROR, StartAnyWhereConstants.SAV009,
												StartAnyWhereConstants.SAV009_MSG, StartAnyWhereConstants.HIGH, u.getEmail(), errors);

								return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);

							}

						}
					}
					
					
					Iterator<Map.Entry<String, String>> itr1 = validMailMap.entrySet().iterator();
					while (itr1.hasNext()) {
						Map.Entry<String, String> entry = itr1.next();
						String mailId = entry.getKey();
						if (orgExist.contains(entry.getKey())) {
							InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
									"Deletion skipped: Security Manager is not associated with the specified organization in Saviynt."
									+ " No entitlement or organization removal necessary:" +mailId);
							
							itr1.remove(); // Safely removes the entry
						}
					}

					//Retrieve total users associated with the organization
					try {
						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
								" Starting retrieve total users associated with the organization. ");
						OrganisationUserDetailRequest orgUserDetailRequest = OrganisationUserDetailRequest.builder()
								.organizationname(clientId).max(StartAnyWhereConstants.MAX).build();

						OrganizationUserDetailResponseDTO orguserRespose = orgService.getUserOrganizationDetails(accessToken, orgUserDetailRequest, clientId);


						List<String> orgUsersList = Optional.ofNullable(orguserRespose.getUsers())
								.filter(users -> !users.isEmpty())
								.map(users -> users.stream()
										.map(UserOrganizationDetailsDTO::getUsername)
										.collect(Collectors.toList()))
								.orElse(new ArrayList<>());

						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
								" Organization user list size : "+orgUsersList.size());
						List<String> validUserList = Optional.ofNullable(listOfUsers)
								.orElse(Collections.emptyList())
								.stream()
								.map(us -> us != null ? us.getUsername() : null) // Safely handle null User objects
								.filter(Objects::nonNull) // Filter out null usernames
								.collect(Collectors.toList());


						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
								" Security manager user list size : "+validUserList.size());

						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
								"Initiating validation: comparing Security Manager list with Organization User list for consistency.\n"
										+ "");
						valid = isValid(orgUsersList, validUserList);
						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
								" validation: comparing Security Manager list with Organization User list :"
										+ "orgUsersList: %s"
										+ "validUserList: %s" +orgUsersList +validUserList );

						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
								" Ending retrieve total users associated with the organization.");

					}catch (FeignException exception) {
						HttpStatus excStatus = HttpStatus.valueOf(exception.status());

						if (exception != null && excStatus.value() == 412) {
							InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
									"Unable to get organization details for the users  :");
							ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), exception.getMessage(),
									"RemoveClientConfiguration()", exception, ErrorLogEvent.ERROR_EVENT_TYPE);

							StartAnywhereUtil.buildResponse(response, StartAnyWhereConstants.HTTP_STATUS_SUCCESS, StartAnyWhereConstants.DELETE_STATUS, StartAnyWhereConstants.SAV025,
									StartAnyWhereConstants.SAV025_MSG, StartAnyWhereConstants.LOW, null, errors);

						} else {
							ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), StartAnyWhereConstants.SAV013_MSG,
									"DeleteClientConfiguration()", exception, ErrorLogEvent.ERROR_EVENT_TYPE);

							StartAnywhereUtil.buildResponse(response, StartAnyWhereConstants.HTTP_STATUS_SUCCESS, StartAnyWhereConstants.DELETE_STATUS, StartAnyWhereConstants.SAV023,
									StartAnyWhereConstants.SAV023_MSG, StartAnyWhereConstants.LOW, null, errors);

						}
					}
					// end the collecting the Entitlements informations
					

					
					/// starting the remove the entitlements 
					
					//Update EntitlementsDtos
					InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
							"Starting Update EntitlementsDto Details");

					List<EntitlementDTO> entitlements = Optional.ofNullable(listEntitlements)
							.orElse(Collections.emptyList())
							.stream()
							.map(resp -> EntitlementDTO.of(
									ControlCenterCommonConstants.SAVIYNT_ENTITLEMENT_TYPE,
									resp.getEntitlementValue())
									)
							.collect(Collectors.toList());

					InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
							"Ending Update EntitlementsDto Details: "+entitlements);
					//Iterate throw each aid and hit the update endpoint
					Iterator<Map.Entry<String, String>> itr2 = validMailMap.entrySet().iterator();
					while (itr2.hasNext()) {
						Map.Entry<String, String> e = itr2.next();
						String mailId = e.getKey();
						String userName = e.getValue();
						String accountName = accountMap.get(mailId);
						// remove the entitlements 
						try {
							InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
									"Initiating entitlement removal process :  " + mailId);

							userEntitlements.setRequestType(ControlCenterCommonConstants.SAVIYNT_REQUEST_TYPE.REMOVE.name());
							userEntitlements.setUserName(userName);
							userEntitlements.setAccountName(accountName);
							userEntitlements.setEmail(mailId);
							userEntitlements.setEntitlements(entitlements);

							UserEntitlementsDTO updateUserEntitlements = new UserEntitlementsDTO();
							updateUserEntitlements = entitlementService.updateUser(userEntitlements, accessToken);

							if (CollectionUtils.isEmpty(updateUserEntitlements.getEntitlements())) {
								InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
										"Unable to delete: no entitlement details available for the specified user from Saviynt : " + mailId);
								ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
										"Unable to delete: no entitlement details available for the specified user from Saviynt" + updateUserEntitlements.getEmail(), "", null,
										ErrorLogEvent.ERROR_SEVERITY);

								response = StartAnywhereUtil.buildResponse(response,
										StartAnyWhereConstants.HTTP_STATUS_SUCCESS, StartAnyWhereConstants.DELETE_STATUS,
										StartAnyWhereConstants.SAV008,
										StartAnyWhereConstants.ENTITLEMENTS_STATUS,
										StartAnyWhereConstants.HIGH, 
										updateUserEntitlements.getEmail(), errors);

							}

						} catch (FeignException exception) {
							HttpStatus excStatus = HttpStatus.valueOf(exception.status());

							if (exception != null && excStatus.value() == 412) {
								InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
										"Unable to match endpoint for this user :" + mailId);
								ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), exception.getMessage(),
										"DeleteClientConfiguration()", exception, ErrorLogEvent.ERROR_EVENT_TYPE);

								StartAnywhereUtil.buildResponse(response, StartAnyWhereConstants.HTTP_STATUS_SUCCESS, StartAnyWhereConstants.DELETE_STATUS, StartAnyWhereConstants.SAV022,
										StartAnyWhereConstants.SAV022_MSG, StartAnyWhereConstants.LOW, mailId, errors);

							} else {
								ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), StartAnyWhereConstants.SAV013_MSG,
										"DeleteClientConfiguration()", exception, ErrorLogEvent.ERROR_EVENT_TYPE);

								StartAnywhereUtil.buildResponse(response, StartAnyWhereConstants.HTTP_STATUS_SUCCESS, StartAnyWhereConstants.DELETE_STATUS, StartAnyWhereConstants.SAV023,
										StartAnyWhereConstants.SAV023_MSG, StartAnyWhereConstants.LOW, mailId, errors);

							}
						}
						//ending the entitlement remove process
						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
								"Ending the entitlement removal process: "+clientId);

						//remove the organization

						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
								"Starting fetching client access information for user");
						List<OrganizationDetailsDTO> org = new ArrayList<>();

						if(userOrgResponseList!=null && !userOrgResponseList.isEmpty()) {
							for (UserOrganizationDetailResponseDTO userOrg :userOrgResponseList) {
								UserOrganizationDetailResponseDTO dto = new UserOrganizationDetailResponseDTO();
								dto.setUsername(userOrg.getUsername());

								if(userOrg.getOrganizations()!=null) {
									org.addAll(userOrg.getOrganizations());
								}
								else
								{
									ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
											"No organizations found for user", "", null,
											ErrorLogEvent.ERROR_SEVERITY);

									StartAnywhereUtil.buildResponse(response,
											StartAnyWhereConstants.HTTP_STATUS_SUCCESS, StartAnyWhereConstants.DELETE_STATUS,
											StartAnyWhereConstants.SAV018,
											StartAnyWhereConstants.SAV018_MSG,
											StartAnyWhereConstants.LOW, user.getEmail(), errors);

								}

							}
						}

						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
								"Ending fetching client access information for user");
						
						List<String> uniqueOrgNameList = new ArrayList<>(
							    org.stream()
							        .map(OrganizationDetailsDTO::getOrganizationname)
							        .filter(Objects::nonNull)
							        .filter(name -> name.contains(clientId)) //  filter by clientId
							        .collect(Collectors.toCollection(LinkedHashSet::new))
							);


						if(uniqueOrgNameList!= null && !uniqueOrgNameList.isEmpty()) { 
							for(String orgDetail :uniqueOrgNameList) {
								if (clientId.equalsIgnoreCase(orgDetail)) {

									try {
										InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
												"Initiating organization removal process : " + mailId);

										UpdateOrganizationResponse updateOrgResp = new UpdateOrganizationResponse();

										if (StringUtils.isNotBlank(orgDetail)) {
											InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
													"Organizationname : " + orgDetail);

											updateOrgResp = updateOrgUser("REMOVE", orgDetail, userName,accessToken);
										}
										if (updateOrgResp.getStatusCode() == 200) {
											InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
													"User removed from organization successfully : " + mailId);

										}


									} catch (FeignException EX) {
										HttpStatus excStatus = HttpStatus.valueOf(EX.status());
										//	Check if that user already deleted for the org
										if (EX != null && excStatus.value() == 412) {
											InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
													"User already deleted in Saviynt for this org :" + mailId);
											ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), EX.getMessage(),
													"DeleteClientConfiguration()", EX, ErrorLogEvent.ERROR_EVENT_TYPE);

											StartAnywhereUtil.buildResponse(response, StartAnyWhereConstants.HTTP_STATUS_SUCCESS, StartAnyWhereConstants.OK, StartAnyWhereConstants.SAV020,
													StartAnyWhereConstants.SAV020_MSG, StartAnyWhereConstants.LOW, null, errors);

										} else {
											ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), StartAnyWhereConstants.SAV013_MSG,
													"DeleteClientConfiguration()", EX, ErrorLogEvent.ERROR_EVENT_TYPE);

											StartAnywhereUtil.buildResponse(response, StartAnyWhereConstants.HTTP_STATUS_SUCCESS, StartAnyWhereConstants.OK, StartAnyWhereConstants.SAV019,
													StartAnyWhereConstants.SAV019_MSG, StartAnyWhereConstants.LOW, mailId, errors);

										}

									}

								}
							}
						}

					}

					InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
							"Ending the organization removal process: "+clientId);
					
						InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
								"Saviynt steps are completed. Moving ahead with Postgress Delete");

						try {
							if(valid) {
								InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
										"Starting the postgress delete process");
								ResponseEntity<Object> pgResponse = removeClientService.deleteClientDetails(alightColleagueSessionToken, alightRequestHeader,clientId);

								if (pgResponse.getStatusCode().is2xxSuccessful()) {
									InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
											"Saviynt steps are completed. Postgress Deleted with ErrorList");
									BaseResponse r = (BaseResponse) pgResponse.getBody();
									if (Optional.ofNullable(r.getErrors()).filter(err -> !err.isEmpty()).isPresent())
										errors.addAll(r.getErrors());
										
										InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Postgress Delete completed");
										r.setResponseCode(StartAnyWhereConstants.HTTP_STATUS_SUCCESS);
										r.setResponseMessage(StartAnyWhereConstants.DELETE_STATUS);
										r.setErrors(errors);

										return ResponseEntity.status(HttpStatus.OK).body(r);

								}
								if (pgResponse.getStatusCode().is5xxServerError()) {
									InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
											"Postgress save is responding with 5xx");
									BaseResponse r = (BaseResponse) pgResponse.getBody();
									if (Optional.ofNullable(r.getErrors()).filter(err -> !err.isEmpty()).isPresent())
										errors.addAll(r.getErrors());

									r = StartAnywhereUtil.buildResponse(response,
											StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR,
											StartAnyWhereConstants.INTERNAL_SERVER_ERROR, StartAnyWhereConstants.POS500, StartAnyWhereConstants.DELETE_CONFIGURATION_FAILED, StartAnyWhereConstants.HIGH, null, errors);

									return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(r);

								}
							}
							else {
								InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
										"Deletion of PostgreSQL database blocked due to presence of active security managers. "
												+ "Please ensure all security dependencies are cleared before retrying.\n"
												+ "");
							}
						}
						catch (Exception e) {
							// TODO Auto-generated catch block
							ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
									StartAnyWhereConstants.POSTGRESS_SAVE_FAILED, "DeleteClientConfiguration()", e,
									ErrorLogEvent.ERROR_EVENT_TYPE);

							StartAnywhereUtil.buildResponse(response, StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR, StartAnyWhereConstants.INTERNAL_SERVER_ERROR,
									StartAnyWhereConstants.POS500, StartAnyWhereConstants.POSTGRESS_DELETE_FAILED, StartAnyWhereConstants.HIGH, null, errors);


							return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
						}

					

				}

			}

			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Ending the process of delete the client details");

			response.setResponseCode(StartAnyWhereConstants.HTTP_STATUS_SUCCESS);
			response.setResponseMessage(StartAnyWhereConstants.DELETE_STATUS);

			InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
					"Ending service layer of delete flow for  DeleteClientConfigurationDetails :" + clientId);


			return new ResponseEntity<>(response, HttpStatus.OK);

		}
		catch (Exception e) {
			ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), "Exception occurred while delete the client details",
					"", e, ErrorLogEvent.ERROR_SEVERITY);

			response=StartAnywhereUtil.buildResponse(
					new BaseResponse(),
					StartAnyWhereConstants.HTTP_STATUS_INTERNAL_SERVER_ERROR,
					StartAnyWhereConstants.INTERNAL_SERVER_ERROR,
					StartAnyWhereConstants.POS500,
					e.getClass().getSimpleName() + ": " + e.getMessage(),
					StartAnyWhereConstants.HIGH,
					null,
					errors
					);

			return new ResponseEntity<Object>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}



	//update
	@Recover
	public ResponseEntity<Object> handleRetryFailure(Exception ex, String alightColleagueSessionToken, 
			String alightRequestHeader, String clientId,  String orgName,
			List<String> securityManagerEmailId) {
		ErrorLogEventHelper.logErrorEvent(this.getClass().getName(),
				"Retry exhausted for delete the client configuration details: " + ex.getMessage(), "recover", ex,
				ErrorLogEvent.ERROR_SEVERITY);

		BaseResponse response = new BaseResponse();
		List<ClientConfigError> errors = new ArrayList<>();

		if (ex instanceof FeignException) {
			// Handle Feign-specific failure
			response = StartAnywhereUtil.buildResponse(new ClientConfigurationResponse(),
					StartAnyWhereConstants.HTTP_STATUS_SERVICE_UNAVAILABLE, StartAnyWhereConstants.DB_UNREACHABLE,
					StartAnyWhereConstants.SAV101, StartAnyWhereConstants.SAVIYNT_SERVER_UNREACHABLE,
					StartAnyWhereConstants.HIGH, null, errors);
			return new ResponseEntity<Object>(response, HttpStatus.SERVICE_UNAVAILABLE);
		} else {
			response = StartAnywhereUtil.buildResponse(new ClientConfigurationResponse(),
					StartAnyWhereConstants.HTTP_STATUS_SERVICE_UNAVAILABLE, StartAnyWhereConstants.DB_UNREACHABLE,
					StartAnyWhereConstants.POS101, StartAnyWhereConstants.MSGFOR_POS101, StartAnyWhereConstants.HIGH,
					null, errors);
			return new ResponseEntity<Object>(response, HttpStatus.SERVICE_UNAVAILABLE);
		}


	}

	private UpdateOrganizationResponse updateOrgUser(String updateType,
			String Organizationname, String aid, String accessToken) {
		UpdateOrganizationResponse updateOrgResp = null;
		if (updateType.equalsIgnoreCase("remove"))
			updateOrgResp = orgService.updateUserToOrganization(buildRemoveOrgUserDTO(Organizationname, aid), accessToken);
		return updateOrgResp;
	}

	private UpdateOrganizationRequestDTO buildRemoveOrgUserDTO(String Organizationname, String aid) {
		// TODO Auto-generated method stub
		List<OrganizationUserDTO> userDTOList = new ArrayList<>();
		OrganizationUserDTO userDTO = new OrganizationUserDTO(aid, ControlCenterCommonConstants.SAVIYNT_REQUEST_TYPE.REMOVE.name());
		userDTOList.add(userDTO);
		UpdateOrganizationRequestDTO updateOrgReqDTO = new UpdateOrganizationRequestDTO(Organizationname,
				bean.getRequestor(), userDTOList); 

		return updateOrgReqDTO;
	}

	public boolean isValid(List<String> orgUserList, List<String> currentValidList) {
		boolean sameSize = orgUserList.size() == currentValidList.size();
		boolean orgContainsCurrent = orgUserList.containsAll(currentValidList);
		boolean currentContainsOrg = currentValidList.containsAll(orgUserList);

		// Condition 1: exact match
		if (sameSize && orgContainsCurrent && currentContainsOrg) {
			return true;
		}

		// Condition 2: currentValidList is larger and contains all orgUserList
		if (currentValidList.size() > orgUserList.size() && currentContainsOrg) {
			return true;
		}

		return false;
	}


}



