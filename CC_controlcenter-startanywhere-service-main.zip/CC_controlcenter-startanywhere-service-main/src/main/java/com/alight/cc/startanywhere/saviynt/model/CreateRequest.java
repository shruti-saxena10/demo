package com.alight.cc.startanywhere.saviynt.model;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CreateRequest {

	private String requesttype;
	private String username;
	private String endpoint;
	private String securitysystem;
	private String status;
	private String accountname;
	private String createnewaccounttaskifnotexist ;
	private List<Entitlement> entitlement;
}
