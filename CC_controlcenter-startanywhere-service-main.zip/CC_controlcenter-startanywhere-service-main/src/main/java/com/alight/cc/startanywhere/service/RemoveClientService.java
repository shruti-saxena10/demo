package com.alight.cc.startanywhere.service;

import org.springframework.http.ResponseEntity;

public interface RemoveClientService {

	ResponseEntity<Object> deleteClientDetails(String alightColleagueSessionToken, String alightRequestHeader,
			String clientId);

}
