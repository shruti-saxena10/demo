package com.alight.cc.startanywhere.service;

import java.io.IOException;
import java.util.List;

import org.postgresql.util.PSQLException;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.core.JsonProcessingException;

public interface DeleteClientConfigurationService {

	ResponseEntity<Object> getDeleteClientConfigurationDetails(String alightColleagueSessionToken,
			String alightRequestHeader,  String clientId,  String orgName,
			List<String> securityManagerEmailId) throws JsonProcessingException, IOException, PSQLException;
}
