package com.alight.cc.startanywhere.service;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alight.asg.model.header.v1_0.RequestHeader;
import com.alight.asg.model.header.v1_0.ResponseHeader;
import com.alight.cc.startanywhere.configuration.SaviyntConfigurationBean;
import com.alight.cc.startanywhere.entity.ClientOnboardingRequestTrackEntity;
import com.alight.cc.startanywhere.model.ClientConfigError;
import com.alight.cc.startanywhere.model.ClientConfigurationRequest;
import com.alight.cc.startanywhere.model.ClientConfigurationResponse;
import com.alight.cc.startanywhere.repository.ClientOnboardingRequestTrackRepository;
import com.alight.cc.startanywhere.util.StartAnyWhereConstants;
import com.alight.cc.startanywhere.util.StartAnywhereSecurityUtil;
import com.alight.logging.helpers.InfoTypeLogEventHelper;
import com.aonhewitt.logging.events.ErrorLogEvent;
import com.aonhewitt.logging.helpers.ErrorLogEventHelper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
@Transactional
public class ClientOnboardingRequestTrackService {

	@Autowired
	ClientOnboardingRequestTrackRepository trackRepo;
	@Autowired
	SaviyntConfigurationBean configBean;
	private ObjectMapper om = new ObjectMapper();

	public ResponseEntity<Object> checkStatus(String alightRequestHeader, ClientConfigurationRequest configRequest)
			throws JsonProcessingException, IOException {
		ClientConfigurationResponse response = new ClientConfigurationResponse();
		HttpStatus responseStatus = HttpStatus.OK;
		alightRequestHeader = StartAnywhereSecurityUtil.unCleanIt(alightRequestHeader);
		RequestHeader parsedRequestHeader = RequestHeader.parse(alightRequestHeader);
		String correlationId = parsedRequestHeader.getCorrelationId();
		InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Correlation ID is : "+correlationId);
		if(StringUtils.isEmpty(correlationId)||correlationId.equals("0")) {
			response.setResponseCode(StartAnyWhereConstants.HTTP_STATUS_BAD_REQUEST);
			response.setResponseMessage(StartAnyWhereConstants.MISSING_REQUIRED_PARAMETERS_MESSAGE);
			return getResponseEntity(response, StartAnyWhereConstants.MISSING_REQUIRED_PARAMETERS_MESSAGE,
					HttpStatus.BAD_REQUEST, null, null);	
		}
		String clientId = configRequest.getClientId();
		ClientOnboardingRequestTrackEntity trackEntity = trackRepo.findByCorrelationIdAndClientId(correlationId,
				clientId);
		if (trackEntity != null) {
			if (trackEntity.getStatus() == 0) {
				int hitCount = trackEntity.getHitCount();
				if (hitCount < configBean.getHitCount()) {
					trackEntity.setHitCount(hitCount + 1);
					trackRepo.save(trackEntity);
					response.setResponseCode(StartAnyWhereConstants.HTTP_STATUS_SUCCESS);
					response.setResponseMessage(StartAnyWhereConstants.REQUEST_ALREADY_IN_PROGRESS);
					return getResponseEntity(response, StartAnyWhereConstants.REQUEST_ALREADY_IN_PROGRESS,
							HttpStatus.OK, null, null);
				}
				else {
					response.setResponseCode(StartAnyWhereConstants.HTTP_STATUS_RATE_LIMIT_EXCEEDED);
					response.setResponseMessage(String.format(StartAnyWhereConstants.RATE_LIMIT_EXCEEDED,configBean.getFallbackTime()));
					return getResponseEntity(response, StartAnyWhereConstants.REQUEST_ALREADY_IN_PROGRESS,
							HttpStatus.TOO_MANY_REQUESTS, null, null);
				}
			} else {
				String json = trackEntity.getOutput();
				if (json!=null && !json.isBlank()) {
					response = om.readValue(json, new TypeReference<ClientConfigurationResponse>() {
					});
					if(StringUtils.isNotBlank(response.getResponseCode()))
					responseStatus =HttpStatus.valueOf(Integer.parseInt(response.getResponseCode()));
				}
//
//				response.setResponseCode(StartAnyWhereConstants.HTTP_STATUS_SUCCESS);
//				response.setResponseMessage(StartAnyWhereConstants.CONFIGURATION_SUCCESSFUL);
//				trackRepo.delete(trackEntity);
			
				return getResponseEntity(response, null, responseStatus, null,
						null);

			}
		}
		return null;

	}

	public void saveTrack(String alightRequestHeader, ClientConfigurationRequest configRequest)
			throws JsonProcessingException, IOException {
		alightRequestHeader = StartAnywhereSecurityUtil.unCleanIt(alightRequestHeader);
		RequestHeader parsedRequestHeader = RequestHeader.parse(alightRequestHeader);
		String correlationId = parsedRequestHeader.getCorrelationId();
		String inputJson = om.writeValueAsString(configRequest);
		ClientOnboardingRequestTrackEntity entity = new ClientOnboardingRequestTrackEntity();
		entity.setCorrelationId(correlationId);
		entity.setInputJson(inputJson);
		entity.setClientId(configRequest.getClientId());
		entity.setStatus(0);
		entity.setApiName(StartAnyWhereConstants.SAV_CREATE_API);
		Date startTime = new Date();
		entity.setRequestStartedAt(startTime);
		trackRepo.save(entity);
	}

	public ResponseEntity<Object> getResponseEntity(ClientConfigurationResponse response, String responseMessage,
			HttpStatus responseStatus, Exception ex, String debugMessage) {

		HttpHeaders httpHeaders = new HttpHeaders();
		ResponseEntity<Object> responseEntity = null;

		try {
			String resCd = (responseStatus == HttpStatus.OK) ? "0" : "-999";
			String resMsg = (responseMessage != null) ? responseMessage : "";
			ResponseHeader responseHeader = new ResponseHeader();
			responseHeader.setResponseCode(resCd);
			responseHeader.setResponseDescription(resMsg);
			httpHeaders.add("alightResponseHeader", responseHeader.toJson());
		} catch (JsonProcessingException e) {
			httpHeaders = null;
		}

		if (ex != null) {
			ErrorLogEventHelper.logErrorEvent(this.getClass().getName(), "Error in fetching Colleague Information:",
					"fetchColleagueInfo()", ex, ErrorLogEvent.ERROR_SEVERITY);
			responseEntity = new ResponseEntity<Object>(ex, httpHeaders, responseStatus);
		} else {
			if (debugMessage != null) {
				InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(),
						"fetchColleagueInfo() method - " + debugMessage);
			}
			responseEntity = new ResponseEntity<Object>(response, httpHeaders, responseStatus);
		}

		return responseEntity;
	}

	public void updateTrack(String alightRequestHeader, ClientConfigurationRequest configRequest,
			List<ClientConfigError> errors, Object response) throws JsonProcessingException, IOException {
		// TODO Auto-generated method stub
		alightRequestHeader = StartAnywhereSecurityUtil.unCleanIt(alightRequestHeader);
		RequestHeader parsedRequestHeader = RequestHeader.parse(alightRequestHeader);
		String correlationId = parsedRequestHeader.getCorrelationId();
		String clientId = configRequest.getClientId();
		ClientOnboardingRequestTrackEntity entity = trackRepo.findByCorrelationIdAndClientId(correlationId, clientId);
		String errorJson = om.writeValueAsString(errors);
		String fullResponse = om.writeValueAsString(response);
		entity.setErrors(errorJson);
		entity.setStatus(1);
		entity.setOutput(fullResponse);
		Date endTime = new Date();
		entity.setRequestCompletedAt(endTime);
		InfoTypeLogEventHelper.logInfoEvent(this.getClass().getName(), "Updating the correlation Id in tracker");
		trackRepo.save(entity);
	}

}
