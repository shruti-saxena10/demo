## CC_controlcenter-startanywhere-service
## CC_controlcenter-startanywhere-service
CC_controlcenter-startanywhere-service is a Spring Boot 3.3.x dockerized web service. This web service exposes Rest API endpoints for doing the startanywhere work in control center.

### Support information:
| | |
|---|---|
| **Service Owner/Group**: [Gaurav Pandey](mailto:gaurav.pandey@alight.com?subject=CC_controlcenter-startanywhere-service)|
| **Service Dev Team**: [Prince Sachdeva](mailto:prince.sachdeva@alight.com?subject=CC_controlcenter-startanywhere-service),[Falguni Pathak](mailto:falguni.pathak@alight.com?subject=CC_controlcenter-startanywhere-service)|
| **Technical Contact**: [Gaurav Pandey](mailto:gaurav.pandey.2?subject=CC_controlcenter-startanywhere-service),[Prince Sachdeva](mailto:prince.sachdeva@alight.com?subject=CC_controlcenter-startanywhere-service)|
| **Backend Systems Interacted With**: Postgres RDS, Saviynt|
| **Link to New Relic Prod Dashboard**: [prod-CC_controlcenter-startanywhere](https://one.newrelic.com/launcher/nr1-core.explorer?pane=eyJuZXJkbGV0SWQiOiJhcG0tbmVyZGxldHMub3ZlcnZpZXciLCJlbnRpdHlJZCI6Ik56VXlOekF5ZkVGUVRYeEJVRkJNU1VOQlZFbFBUbnd4TWpBd05qTXpORFkifQ==)|
| **Internal services lists**: NA|
| **Link to Service Interaction Flow Diagrams**: NA|
| **Monitoring Alerts Specification**: No Custom Alerts, Only Default NR Alerts setup for all ACE Services.|
| **Support Group**: [DG-Alight-Global-DCCCP](mailto:DG-Alight-Global-DCCCP@alight.com?subject=CC_controlcenter-startanywhere-service), [DG-Alight-Global-HWCCP](mailto:DG-Alight-Global-HWCCP@alight.com?subject=CC_controlcenter-startanywhere-service)|
| **JIRA Type**: https://alightdevelopmentandit.atlassian.net/jira/software/c/projects/CDT/boards/16|

###  Link to the API spec
https://bitbucket.alight.com/projects/OL/repos/CC_controlcenter-startanywhere-service/browse/api/openapi.yaml
# build trigger 1
# build trigger 2
